package com.bharosa.vcrypt.common.util;


import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import com.bharosa.common.logger.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public final class XMLParserFactory {

    static private Logger logger = Logger.getLogger(XMLParserFactory.class);
    static boolean supportsResolverSuppress = true;

    private XMLParserFactory() {
    }

    /**
     * Creates a new instance of SAX parser.
     *
     * @return SAXParser a SAX parser.
     * @throws ParserConfigurationException
     * @throws SAXException
     */
    public static SAXParser createSAXParserInstance() throws ParserConfigurationException, SAXException {
        final SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
        saxParserFactory.setValidating(false);
        SAXParser parser = null; 
        try 
        {
          parser = saxParserFactory.newSAXParser();
          parser.getXMLReader().setEntityResolver(new XMLParserFactory.ARMSecureEntityResolver());
        } catch (Throwable e) 
        {
          logger.warn("createSAXParserInstance(): Failed to create the sax parser with modified factory, will try again. error message=" + e.getMessage(), e);
        } 
        return parser;
    }

    /**
     * Creates a new instance of DOM parser.
     *
     * @return DocumentBuilder a DOM document builder.
     * @throws ParserConfigurationException
     */
    public static DocumentBuilder createDOMParserInstance() throws ParserConfigurationException {
        final DocumentBuilderFactory domParserFactory = DocumentBuilderFactory.newInstance();
        domParserFactory.setValidating(false);
        final DocumentBuilder documentBuilder = domParserFactory.newDocumentBuilder();
        documentBuilder.setEntityResolver(new XMLParserFactory.ARMSecureEntityResolver());
        return documentBuilder;
    }
    
    public static class ARMSecureEntityResolver implements EntityResolver {
    public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException 
    {
      return new InputSource(new ByteArrayInputStream(new byte[0]));
    }
  }
}
