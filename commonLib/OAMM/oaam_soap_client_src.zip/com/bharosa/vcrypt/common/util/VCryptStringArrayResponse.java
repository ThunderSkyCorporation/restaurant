package com.bharosa.vcrypt.common.util;

import java.util.Arrays;
/*
 * Copyright (c) 2006 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * VCryptStringArrayResponse
 * <p/>
 * Date: Jun 26, 2006
 *
 * @since 3.0
 */
public class VCryptStringArrayResponse {

	private String[] elements;
	private VCryptResponse repsonse;

	public VCryptStringArrayResponse(String[] data, VCryptResponse repsonse) {
		this.elements= data;
		this.repsonse = repsonse;
	}

	public String[] getElements() {
		return elements;
	}

	public VCryptResponse getRepsonse() {
		return repsonse;
	}

	public String toString() {
		return "VCryptStringArrayResponse. " +
				"; elements=" + (elements == null ? null : Arrays.asList(elements)) +
				"; repsonse=" + repsonse +
				';';
	}

} // end VCryptStringArrayResponse
