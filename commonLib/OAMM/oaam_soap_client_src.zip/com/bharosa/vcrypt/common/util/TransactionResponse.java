/**
 * 
 */
package com.bharosa.vcrypt.common.util;

/**
 * @author jomy
 *
 */

public class TransactionResponse {
    private Long transactionId;
    
    public TransactionResponse(Long transactionId){
        this.transactionId = transactionId;
    }
    public Long getTransactionId(){
        return transactionId;
    }
    
    public void setTransactionId(Long transactionId){
        this.transactionId = transactionId;
    }
 
    public String toString(){
        return "TransactionResponse{" +
        "transactionId ="+transactionId;
    }
}
