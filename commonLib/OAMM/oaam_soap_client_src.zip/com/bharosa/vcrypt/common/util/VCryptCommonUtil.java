package com.bharosa.vcrypt.common.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */


import com.bharosa.common.logger.Logger;
import com.bharosa.common.util.Base64;
import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.BharosaPropertyBoolean;
import com.bharosa.common.util.BharosaPropertyString;
import com.bharosa.common.util.DateUtil;
import com.bharosa.common.util.FileUtil;
import com.bharosa.common.util.StringUtil;
import com.bharosa.vcrypt.common.intf.VCryptCommon;
import com.bharosa.vcrypt.common.intf.VCryptSOAP;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.StringReader;

import java.lang.reflect.Constructor;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.xml.sax.InputSource;


/**
 * Provides utility method to instantiate classes required from VCryptCommon.
 * And also other convenience methods.
 *
 * @author bosco
 */

public class VCryptCommonUtil {

    static private Logger logger = Logger.getLogger(VCryptCommonUtil.class);
    private final static Object lockObject = new Object();
    static int uidCounter = 0;

    static Random rand = new Random();

    public static final String rootNode_vCryptResponse = "VCryptResponse";
    public static final String rootNode_vCryptObjectResponse = "VCryptObjectResponse";

    private static final String rootNode_VCryptStringArrayResponse = "VCryptStringArrayResponse";
    private static final String rootNode_VCryptBooleanResponse = "VCryptBooleanResponse";
    private static final String rootNode_VCryptIntResponse = "VCryptIntResponse";
    private static final String rootNode_ListElements = "GetListElementsRequest";
    private static final String rootNode_listsByType = "GetListsByTypeRequest";
    private static final String rootNode_createList = "CreateList";
    private static final String rootNode_isElementInlist = "IsElementInList";
    private static final String rootNode_transactionResponse = "transactionResponse";
    private static BharosaPropertyString digestAlgo = new BharosaPropertyString("common.uid.digest", "MD5");
    private static VCryptCommon vcryptCommon;

    /**
     * This methods instantiates a *new instance of VCryptCommon class.
     *
     * @return Returns new instance of VCryptCommon class. It will return null
     *         if the instance could not be created.
     */
    static private VCryptCommon newVCryptCommonInstance() {
        if (logger.isDebugEnabled()) logger.debug("Creating new VCryptCommon instance...");
        try {
            boolean useSoap = BharosaConfig.getBoolean("vcrypt.tracker.soap.useSOAPServer", false);
            String commonClassName = BharosaConfig.get("vcrypt.common.util.classname");
            if (commonClassName == null || commonClassName.trim().equals("")) {
                if (useSoap) {
                    commonClassName = BharosaConfig.get("vcrypt.common.util.soap.classname",
                            "com.bharosa.vcrypt.common.impl.VCryptCommonSOAPImpl");
                } else {
                    commonClassName = BharosaConfig.get("vcrypt.common.util.static.classname",
                            "com.bharosa.vcrypt.common.impl.VCryptCommonMonitorImpl");
                }
            }
            //Loading VCryptCommonInstance
            if (logger.isDebugEnabled()) logger.debug("Loading class " + commonClassName);
            return (VCryptCommon) Class.forName(commonClassName).newInstance();
        } catch (Exception ex) {
            logger.error("Error creating VCryptCommon instance.", ex);
            return null;
        }
    }


    /**
     * This methods instantiates a new instance of VCryptSOAP class.
     *
     * @param serverUrl   Service Url
     * @param serviceName Service Name
     * @return Returns new instance of VCryptSOAP class. It will return null
     *         if the instance could not be created.
     */
    static public VCryptSOAP newVCryptSOAPInstance(String serverUrl, String serviceName) {
        if (logger.isDebugEnabled()) logger.debug("Creating new VCryptCommon instance...");
        try {
            String className = BharosaConfig.get("vcrypt.common.util.vcryptsoap.impl.classname",
                    "com.bharosa.vcrypt.common.impl.VCryptSOAPAxisImpl");
            boolean useFilter = BharosaConfig.getBoolean("vcrypt.common.util.vcryptsoap.useFilter", true);
            if (useFilter) {
                className = BharosaConfig.get("vcrypt.common.util.vcryptsoap.filter.impl.classname",
                        "com.bharosa.vcrypt.common.impl.VCryptSOAPFilterImpl");
            }
            //Loading class
            if (logger.isDebugEnabled()) logger.debug("Loading class " + className);
            Class soapClass = Class.forName(className);
            Constructor classConstructor =
                    soapClass.getConstructor(new Class[]{String.class, String.class});

            return (VCryptSOAP) classConstructor.newInstance(new Object[]{serverUrl, serviceName});
        } catch (Exception ex) {
            logger.error("Error creating VCryptSOAP instance. serverUrl="
                    + serverUrl + ", serviceName=" + serviceName, ex);
            return null;
        }
    }

    /**
     * Method replace all the html escape/special chars with their respective code
     *
     * @param str a <code>String</code> value
     * @return a <code>String</code> value
     */
    public static String encode(String str) {
        if (StringUtil.isEmpty(str)) {
            return "";
        }
        //replace all '&'
        str = str.replaceAll("\\&", "&amp;");
        //replace all '<'
        str = str.replaceAll("\\<", "&lt;");
        //replace all '>'
        str = str.replaceAll("\\>", "&gt;");
        //replace all '"'
        str = str.replaceAll("\"", "&quot;");
        //replace all '
        str = str.replaceAll("\\'", "&#39;");
        //replace all ','
        str = str.replaceAll("\\,", "&#44;");
        //replace all '\'
        str = str.replaceAll("\\\\", "&#92;");
        return str;
    }

    public static String encodeXmlElement(String str) {
        if (str != null) {
            if (str.indexOf("]]>") > 0)
                return encode(str);
            else
                return encodeAsCDATA(str);
        }
        return str;
    }

    /**
     * Encode as CDATA.
     * <p/>
     * From the W3C Spec: The text inside a CDATA section will be ignored by the parser.
     *
     * @param str value to be CDATA encoded
     * @return CDATA encoded string
     */
    public static String encodeAsCDATA(String str) {
        if (StringUtil.isEmpty(str)) {
            return "";
        }
        StringBuffer strBuf = new StringBuffer();
        strBuf.append("<![CDATA[");
        strBuf.append(str);
        strBuf.append("]]>");
        return strBuf.toString();
    }

    static public String generateUID(String seed) {
        if (logger.isDebugEnabled()) logger.debug("Generating new UID");


        MessageDigest digest = null;
        String uid = seed;
        if (uid == null) {
            uid = String.valueOf(new Object().hashCode());
        }

        try {            
            digest = MessageDigest.getInstance(digestAlgo.getValue());
        } catch (NoSuchAlgorithmException e) {
            logger.error("BharosaMessageDigest algorithm not found!");
        }

        try {
            String prefix;
            synchronized (lockObject) {
                prefix = String.valueOf(uidCounter++);
                try {
                    //run the clock for 1 milli second, so we can get
                    //a unique milli-second
                    lockObject.wait(1);
                } catch (Exception ex) {
                    logger.error("error while waiting for 1 milli second", ex);
                }
            }
            long time = System.currentTimeMillis();
            long randomNumber = rand.nextLong();

            uid += "-" + time + "-" + randomNumber;
            if (logger.isDebugEnabled()) logger.debug("Preparing to md5Sum: " + uid);

            digest.update(uid.getBytes());

            byte[] array = digest.digest();
            StringBuffer sb = new StringBuffer();
            for (int j = 0; j < array.length; ++j) {
                int b = array[j] & 0xFF;
                if (b < 0x10) sb.append('0');
                sb.append(Integer.toHexString(b));
            }
            uid = prefix + "_" + sb.toString();
        } catch (Exception e) {
            logger.error("Error generating UID: " + e.getMessage());
        }

        return uid;
    }

    static public String toXMLCreateUserEnvLogRequest(Map nvList) {
        if (logger.isDebugEnabled()) logger.debug("toXMLCreateUserEnvLogRequest() enter()");
        StringBuffer xmlString = new StringBuffer(500);
        xmlString.append("<CreateUserEnvLogRequest><parameterList>");
        Iterator iter = nvList.keySet().iterator();
        while (iter.hasNext()) {
            String name = (String) iter.next();
            String value = (String) nvList.get(name);
            if (value != null) {
                xmlString.append("<parameter>");
                xmlString.append(getXmlElement("name", name));
                xmlString.append(getXmlElement("value", value));
                xmlString.append("</parameter>");
            }
        }
        xmlString.append("</parameterList></CreateUserEnvLogRequest>");
        return xmlString.toString();
    }


    static public Map fromXMLCreateUserEnvLogRequest(String xmlString) {
        if (logger.isDebugEnabled()) logger.debug("fromXMLCreateUserEnvLogRequest() enter()");

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("fromXMLCreateUserEnvLogRequest() got null xmlString");
            return null;
        }

        HashMap userEnvList = new HashMap();
        String rootNode = "CreateUserEnvLogRequest";

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("parameterList")) {
                    //Lets the the parameter element
                    NodeList paramList = node.getChildNodes();
                    for (int p = 0; p < paramList.getLength(); p++) {
                        Node param = paramList.item(p);
                        String paramName = param.getNodeName();
                        Node valueParam = param.getFirstChild();
                        if (valueParam == null) {
                            continue;
                        }
                        if (paramName.equalsIgnoreCase("parameter")) {
                            //Lets the name value
                            String name = null;
                            String value = null;
                            NodeList nvList = param.getChildNodes();
                            for (int n = 0; n < nvList.getLength(); n++) {
                                Node nv = nvList.item(n);
                                String nvName = nv.getNodeName();
                                Node valueNv = nv.getFirstChild();
                                if (valueNv == null) {
                                    continue;
                                }
                                if (nvName.equalsIgnoreCase("name")) {
                                    name = valueNv.getNodeValue();
                                } else if (nvName.equalsIgnoreCase("value")) {
                                    value = valueNv.getNodeValue();
                                } else if (!nvName.startsWith("#")) {
                                    logger.error("Invalid element name <" +
                                            nvName + "> in parameter element xml " + xmlString);
                                }
                            }
                            if (!StringUtil.isEmpty(name) && !StringUtil.isEmpty(value)) {
                                userEnvList.put(name, value);
                            }
                        } else if (!paramName.startsWith("#")) {
                            logger.error("Invalid element name <" +
                                    paramName + "> in parameterList element xml " + xmlString);
                        }
                    }

                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" +
                            nodeName + "> in xml " + xmlString);
                }
            }
            return userEnvList;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }

    static public String toXMLCreateUserEnvLogResponse(Long userEnvLogId) {
        if (logger.isDebugEnabled()) logger.debug("toXMLCreateUserEnvLogResponse() enter()");
        StringBuffer xmlString = new StringBuffer(500);
        xmlString.append("<CreateUserEnvLogResponse>");
        xmlString.append(getXmlElement("userEnvLogId", userEnvLogId));
        xmlString.append("</CreateUserEnvLogResponse>");
        return xmlString.toString();
    }

    static public Long fromXMLCreateUserEnvLogResponse(String xmlString) {
        if (logger.isDebugEnabled()) logger.debug("fromXMLCreateUserEnvLogResponse() enter()");

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("fromXMLCreateUserEnvLogResponse() got null xmlString");
            return null;
        }

        Long retVal = null;
        String rootNode = "CreateUserEnvLogResponse";

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("userEnvLogId")) {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value)) {
                        retVal = new Long(value.trim());
                    }
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" +
                            nodeName + "> in xml " + xmlString);
                }
            }
            return retVal;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }

    static public String toXMLLong(Long value) {
        if (logger.isDebugEnabled()) logger.debug("toXMLLong() enter()");
        StringBuffer xmlString = new StringBuffer(500);
        xmlString.append("<Long>");
        xmlString.append(getXmlElement("value", value));
        xmlString.append("</Long>");
        return xmlString.toString();
    }

    static public Long fromXMLLong(String xmlString) {
        if (logger.isDebugEnabled()) logger.debug("fromXMLLong() enter()");

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("fromXMLLong() got null xmlString");
            return null;
        }

        Long retVal = null;
        String rootNode = "Long";

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("value")) {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value)) {
                        retVal = new Long(value.trim());
                    }
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" +
                            nodeName + "> in xml " + xmlString);
                }
            }
            return retVal;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }

    static public String toXMLString(String value) {
        if (logger.isDebugEnabled()) logger.debug("toXMLString() enter()");
        return getXmlElement("String", getXmlElement("value", value)).toString();
    }

    static public String fromXMLString(String xmlString) {
        if (logger.isDebugEnabled()) logger.debug("fromXMLString() enter()");

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("fromXMLString() got null xmlString");
            return null;
        }

        String retVal = null;
        String rootNode = "String";

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("value")) {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value)) {
                        retVal = value.trim();
                    }
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" +
                            nodeName + "> in xml " + xmlString);
                }
            }
            return retVal;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }

    static public String toXMLBoolean(Boolean value) {
        if (logger.isDebugEnabled()) logger.debug("toXMLBoolean() enter()");
        StringBuffer xmlString = new StringBuffer(500);
        xmlString.append("<Boolean>");
        xmlString.append(getXmlElement("value", value));
        xmlString.append("</Boolean>");
        return xmlString.toString();
    }

    static public Boolean fromXMLBoolean(String xmlString) {
        if (logger.isDebugEnabled()) logger.debug("fromXMLBoolean() enter()");

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("fromXMLBoolean() got null xmlString");
            return null;
        }

        Boolean retVal = null;
        String rootNode = "Boolean";

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("value")) {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value)) {
                        retVal = Boolean.valueOf(value.trim());
                    }
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" +
                            nodeName + "> in xml " + xmlString);
                }
            }
            return retVal;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }


    static public String toStringArrayXml(String arrayName, String elementName, String[] strArray) {

        if (logger.isDebugEnabled())
            logger.debug("toStringArrayXml elementName=" + elementName);

        StringBuffer xmlString = new StringBuffer(500);
        if (strArray != null && strArray.length != 0) {
            for (int i = 0; i < strArray.length; i++) {
                if (!StringUtil.isEmpty(strArray[i])) {
                    xmlString.append(getXmlElement(elementName, strArray[i]));
                }
            }
        }
        return getXmlElement(arrayName, xmlString).toString();
    }

    static public String[] fromStringArray(Node parent, String elementName) {
        if (logger.isDebugEnabled()) logger.debug("fromStringArray() elementName=" + elementName);
        List resultList = new ArrayList();
        NodeList nodeList = parent.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            String nodeName = node.getNodeName();
            Node valueNode = node.getFirstChild();
            if (valueNode == null) {
                continue;
            }
            if (nodeName.equalsIgnoreCase(elementName)) {
                String value = valueNode.getNodeValue();
                if (value != null) {
                    value = value.trim();
                }
                resultList.add(value);
            } else if (!nodeName.startsWith("#")) {
                logger.error("Invalid element name <" + nodeName + ">");
            }
        }
        String resultArr[] = new String[resultList.size()];
        Iterator iter = resultList.iterator();
        for (int i = 0; iter.hasNext(); i++) {
            resultArr[i] = (String) iter.next();
        }
        return resultArr;
    }


    public static String toListMembersXml(String requestId, String listName) {

        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(getXmlElement("requestId", requestId));
        xmlBuffer.append(getXmlElement("listName", listName));
        return getXmlElement(rootNode_ListElements, xmlBuffer).toString();
    }

    public static Map fromListMembersXml(String xmlString) {

        if (logger.isDebugEnabled()) logger.debug("To xml:" + rootNode_ListElements);

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("null xmlString");
            return null;
        }

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode_ListElements)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            Map nvList = new HashMap();
            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("requestId")) {
                    String value = valueNode.getNodeValue();
                    nvList.put("requestId", value);
                } else if (nodeName.equalsIgnoreCase("listName")) {
                    String value = valueNode.getNodeValue().trim();
                    nvList.put("listName", value);
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" + nodeName + ">");
                }
            }
            return nvList;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }

    public static String toGetListsByTypeXml(String requestId, int listType) {
        if (logger.isDebugEnabled()) logger.debug(rootNode_listsByType);
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(getXmlElement("requestId", requestId));
        xmlBuffer.append(getXmlElement("listType", listType));
        return getXmlElement(rootNode_listsByType, xmlBuffer).toString();
    }

    public static Map fromGetListsByTypeXml(String xmlString) {

        if (logger.isDebugEnabled()) logger.debug("To xml:" + rootNode_listsByType);

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("null xmlString");
            return null;
        }

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode_listsByType)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            Map nvList = new HashMap();
            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("requestId")) {
                    String value = valueNode.getNodeValue();
                    nvList.put("requestId", value);
                } else if (nodeName.equalsIgnoreCase("listType")) {
                    String value = valueNode.getNodeValue().trim();
                    nvList.put("listType", new Integer(value));
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" + nodeName + ">");
                }
            }
            return nvList;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }

    static public String toUpdateListXml(String requestId, String listName, String[] toAdd, String[] toRemove) {

        if (logger.isDebugEnabled())
            logger.debug("toUpdateListXml requestId=" + requestId);

        StringBuffer xmlString = new StringBuffer(500);
        xmlString.append("<UpdateList>");

        xmlString.append(getXmlElement("requestId", requestId));
        xmlString.append(getXmlElement("listName", listName));

        xmlString.append("<add>");
        if (toAdd != null && toAdd.length != 0) {
            for (int i = 0; i < toAdd.length; i++) {
                if (!StringUtil.isEmpty(toAdd[i])) {
                    xmlString.append(getXmlElement("name", toAdd[i]));
                }
            }
        }
        xmlString.append("</add>");

        xmlString.append("<delete>");
        if (toRemove != null && toRemove.length != 0) {
            for (int i = 0; i < toRemove.length; i++) {
                if (!StringUtil.isEmpty(toRemove[i])) {
                    xmlString.append(getXmlElement("name", toRemove[i]));
                }
            }
        }
        xmlString.append("</delete>");
        xmlString.append("</UpdateList>");
        return xmlString.toString();
    } // end toUpdateListXml

    static public Map fromUpdateList(String xmlString) {

        if (logger.isDebugEnabled()) logger.debug("fromUpdateList");

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("null xmlString");
            return null;
        }

        Map retVal = new HashMap();
        String rootNode = "UpdateList";

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            ArrayList addList = new ArrayList();
            ArrayList deleteList = new ArrayList();
            retVal.put("add", addList);
            retVal.put("delete", deleteList);
            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("requestId")) {
                    retVal.put("requestId", valueNode.getNodeValue());
                } else if (nodeName.equalsIgnoreCase("listName")) {
                    retVal.put("listName", valueNode.getNodeValue());
                } else if (nodeName.equalsIgnoreCase("add")) {
                    valueNode.getNodeValue();
                    NodeList addNodeList = node.getChildNodes();
                    for (int r = 0; r < addNodeList.getLength(); r++) {
                        Node childNode = addNodeList.item(r);
                        String childNodeName = childNode.getNodeName();
                        Node addNode = childNode.getFirstChild();
                        if (addNode == null) {
                            continue;
                        }
                        if (childNodeName.equalsIgnoreCase("name")) {
                            addList.add(addNode.getNodeValue());
                        } else if (!childNodeName.startsWith("#")) {
                            logger.error(
                                    "Invalid element name <" + childNodeName + "> in add element xml " + xmlString);
                        }
                    }
                } else if (nodeName.equalsIgnoreCase("delete")) {
                    valueNode.getNodeValue();
                    NodeList delNodeList = node.getChildNodes();
                    for (int r = 0; r < delNodeList.getLength(); r++) {
                        Node delNode = delNodeList.item(r);
                        String childNodeName = delNode.getNodeName();
                        Node childNode = delNode.getFirstChild();
                        if (childNode == null) {
                            continue;
                        }
                        if (childNodeName.equalsIgnoreCase("name")) {
                            deleteList.add(childNode.getNodeValue());
                        } else if (!childNodeName.startsWith("#")) {
                            logger.error(
                                    "Invalid element name <" + childNodeName + "> in delete element xml " + xmlString);
                        }
                    }
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return retVal;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }

    } // end fromUpdateList

    public static String toIsElementInListXml(String requestId, String listName, String elementValue) {
        if (logger.isDebugEnabled()) logger.debug(rootNode_isElementInlist);
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(getXmlElement("requestId", requestId));
        xmlBuffer.append(getXmlElement("listName", listName));
        xmlBuffer.append(getXmlElement("elementValue", elementValue));
        return getXmlElement(rootNode_isElementInlist, xmlBuffer).toString();
    }

    public static Map fromIsElementInListXml(String xmlString) {

        if (logger.isDebugEnabled()) logger.debug("To xml:" + rootNode_isElementInlist);

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("null xmlString");
            return null;
        }

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode_isElementInlist)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            Map nvList = new HashMap();
            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("requestId")) {
                    String value = valueNode.getNodeValue();
                    nvList.put("requestId", value);
                } else if (nodeName.equalsIgnoreCase("listName")) {
                    String value = valueNode.getNodeValue().trim();
                    nvList.put("listName", value);
                } else if (nodeName.equalsIgnoreCase("elementValue")) {
                    String value = valueNode.getNodeValue().trim();
                    nvList.put("elementValue", value);
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" + nodeName + ">");
                }
            }
            return nvList;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }


    public static String toCreateListXml(String requestId, String listName, int listType) {
        if (logger.isDebugEnabled()) logger.debug(rootNode_createList);
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(getXmlElement("requestId", requestId));
        xmlBuffer.append(getXmlElement("listName", listName));
        xmlBuffer.append("<listType>").append(listType).append("</listType>");
        return getXmlElement(rootNode_createList, xmlBuffer).toString();
    }

    public static Map fromCreateListXml(String xmlString) {

        if (logger.isDebugEnabled()) logger.debug("To xml:" + rootNode_createList);

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("null xmlString");
            return null;
        }

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode_createList)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            Map nvList = new HashMap();
            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("requestId")) {
                    String value = valueNode.getNodeValue();
                    nvList.put("requestId", value);
                } else if (nodeName.equalsIgnoreCase("listName")) {
                    String value = valueNode.getNodeValue();
                    nvList.put("listName", value);
                } else if (nodeName.equalsIgnoreCase("listType")) {
                    String value = valueNode.getNodeValue().trim();
                    nvList.put("listType", new Integer(value));
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" + nodeName + ">");
                }
            }
            return nvList;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }


    public static String toVCryptStringArrayResponseXml(VCryptStringArrayResponse response) {

        if (response == null) {
            return null;
        }

        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append("<elements>");
        for (int i = 0; i < response.getElements().length; i++) {
            String s = response.getElements()[i];
            xmlBuffer.append(getXmlElement("name", s));
        }
        xmlBuffer.append("</elements>");
        xmlBuffer.append(toVCryptResponseXml(response.getRepsonse()));
        return getXmlElement(rootNode_VCryptStringArrayResponse, xmlBuffer).toString();
    }

    public static VCryptStringArrayResponse fromVCryptStringArrayResponseXml(String xmlString) {

        if (logger.isDebugEnabled()) logger.debug("fromVCryptStringArrayResponseXml");

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("null xmlString");
            return null;
        }
        String rootNode = rootNode_VCryptStringArrayResponse;

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            VCryptResponse response = null;
            ArrayList elementList = new ArrayList();
            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("elements")) {
                    valueNode.getNodeValue();
                    NodeList addNodeList = node.getChildNodes();
                    for (int r = 0; r < addNodeList.getLength(); r++) {
                        Node childNode = addNodeList.item(r);
                        String childNodeName = childNode.getNodeName();
                        Node addNode = childNode.getFirstChild();
                        if (addNode == null) {
                            continue;
                        }
                        if (childNodeName.equalsIgnoreCase("name")) {
                            elementList.add(addNode.getNodeValue());
                        } else if (!childNodeName.startsWith("#")) {
                            logger.error("Invalid element name <" + childNodeName + "> in elements xml " + xmlString);
                        }
                    }
                } else if (nodeName.equalsIgnoreCase(VCryptCommonUtil.rootNode_vCryptResponse)) {
                    response = VCryptCommonUtil.getVCryptResponse(node);
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }

            String[] elements;
            if (elementList == null || elementList.isEmpty()) {
                elements = new String[0];
            } else {
                elements = new String[elementList.size()];
                elementList.toArray(elements);
            }
            return new VCryptStringArrayResponse(elements, response);
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }

    static public String toVCryptResponseListXml(VCryptResponse[] response) {
   	 String result = "<responseList>";
   	 for (int i = 0; i < response.length; i++) {
   		 result += toVCryptResponseXml(response[i]);
   	 }
   	 return result + "</responseList>";
    }

    static public String toVCryptResponseXml(VCryptResponse response) {

        if (response == null) {
            return "";
        }

        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(getXmlElement("success", String.valueOf(response.isSuccess())));
        xmlBuffer.append(getXmlElement("responseCode", response.getResponseCode()));
        xmlBuffer.append(getXmlElement("errorMessage", response.getErrorMessage()));
        xmlBuffer.append(getXmlElement("errorMessageRBKey", response.getErrorMessageRBKey()));
        xmlBuffer.append(toStringArrayXml("errorMessageParams", "value", response.getErrorMessageParams()));
        xmlBuffer.append(getXmlElement("sessionId", response.getSessionId()));
        xmlBuffer.append(getXmlElement("server", response.getServer()));
        xmlBuffer.append(getXmlElement("timeStamp", String.valueOf(response.getTimeStamp().getTime())));
        xmlBuffer.append(toTransactionResponseXml(response.getTransactionResponse()));

        Map map = response.getExtendedDataMap();
        if (map != null && !map.isEmpty()) {
            StringBuffer buf = new StringBuffer();
            Iterator itr = map.keySet().iterator();
            while (itr.hasNext()) {
                String key = (String) itr.next();
                String value = (String) map.get(key);
                buf.append("<MapEntry>");
                buf.append(VCryptCommonUtil.getXmlElement("Name", key));
                buf.append(VCryptCommonUtil.getXmlElement("Value", value));
                buf.append("</MapEntry>");
            }
            xmlBuffer.append(VCryptCommonUtil.getXmlElement("extendedDataMap", buf));
        }

        return getXmlElement(rootNode_vCryptResponse, xmlBuffer).toString();

    } // end toUpdateListXml

    static public String toVCryptObjectResponseXml(VCryptObjectResponse response) {

        if (response == null) {
            return "";
        }

        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(getXmlElement("xmlValue", response.getXmlValue()));
        xmlBuffer.append(getXmlElement("success", String.valueOf(response.isSuccess())));
        xmlBuffer.append(getXmlElement("responseCode", response.getResponseCode()));
        xmlBuffer.append(getXmlElement("errorMessage", response.getErrorMessage()));
        xmlBuffer.append(getXmlElement("errorMessageRBKey", response.getErrorMessageRBKey()));
        xmlBuffer.append(toStringArrayXml("errorMessageParams", "value", response.getErrorMessageParams()));
        xmlBuffer.append(getXmlElement("sessionId", response.getSessionId()));
        xmlBuffer.append(getXmlElement("server", response.getServer()));
        xmlBuffer.append(getXmlElement("timeStamp", String.valueOf(response.getTimeStamp().getTime())));
        xmlBuffer.append(toTransactionResponseXml(response.getTransactionResponse()));

        Map map = response.getExtendedDataMap();
        if (map != null && !map.isEmpty()) {
            StringBuffer buf = new StringBuffer();
            Iterator itr = map.keySet().iterator();
            while (itr.hasNext()) {
                String key = (String) itr.next();
                String value = (String) map.get(key);
                buf.append("<MapEntry>");
                buf.append(VCryptCommonUtil.getXmlElement("Name", key));
                buf.append(VCryptCommonUtil.getXmlElement("Value", value));
                buf.append("</MapEntry>");
            }
            xmlBuffer.append(VCryptCommonUtil.getXmlElement("extendedDataMap", buf));
        }

        return getXmlElement(rootNode_vCryptObjectResponse, xmlBuffer).toString();

    } 
    
    static public String toTransactionResponseXml(TransactionResponse transactionResponse) {
        if (transactionResponse == null) {
            return "";
        }

        StringBuffer xmlBuffer = new StringBuffer(200);
        xmlBuffer.append(getXmlElement("transactionId", transactionResponse.getTransactionId()));
        return getXmlElement(rootNode_transactionResponse, xmlBuffer).toString();

    }

    static public VCryptResponse[] fromVCryptResponseListXml(String xmlString) {
       if (logger.isDebugEnabled())
          logger.debug("fromVCryptResponseListXml enter()");
       if (StringUtil.isEmpty(xmlString)) {
          logger.warn("fromVCryptResponseListXml got null xmlString");
          return null;
       }
       try {
          final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
          Document document = builder.parse(new InputSource(new StringReader(xmlString)));
          Node root = null;
          NodeList rootList = document.getChildNodes();
          for (int i = 0; i < rootList.getLength(); i++) {
             Node node = rootList.item(i);
             if (node.getNodeName().equalsIgnoreCase("responseList")) {
                root = node;
                break;
             }
          }

          if (root == null) {
             logger.warn("fromVCryptResponseListXml got null xmlString Invalid Xml Missing: responseList, xmlString=" + xmlString);
             return null;
          }

          List updates = new ArrayList();
          NodeList nodeList = root.getChildNodes();
    		for (int i = 0; i < nodeList.getLength(); i++) {
    		   Node node = nodeList.item(i);
    		   String nodeName = node.getNodeName();
    		   Node valueNode = node.getFirstChild();
    		   if (valueNode == null)
    		      continue;

    		   if (nodeName.equalsIgnoreCase(rootNode_vCryptResponse)) {
    		      updates.add(getVCryptResponse(node));
    		   }
    		}
    		
    		VCryptResponse[] result = new VCryptResponse[updates.size()];
    		return (VCryptResponse[]) updates.toArray(result);
       } catch (Exception ex) {
          logger.error("fromVCryptResponseListXml Exception while parsing xml =" + xmlString, ex);
          return null;
       }
    }

    static public VCryptResponse fromVCryptResponseXml(String xmlString) {

        if (logger.isDebugEnabled()) logger.debug("fromUpdateList");

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("null xmlString");
            return null;
        }

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode_vCryptResponse)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            return getVCryptResponse(root);

        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }

    } // end fromVCryptResponseXml

    static public VCryptObjectResponse fromVCryptObjectResponseXml(String xmlString) {

        if (logger.isDebugEnabled()) logger.debug("fromVCryptObjectResponseXml");

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("null xmlString");
            return null;
        }

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode_vCryptObjectResponse)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            return getVCryptObjectResponse(root);

        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }

    } // end fromVCryptResponseXml
    
    public static VCryptResponse getVCryptResponse(Node root) {

        VCryptResponse response = new VCryptResponse();

        NodeList nodeList = root.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            String nodeName = node.getNodeName();
            Node valueNode = node.getFirstChild();
            if (valueNode == null) {
                continue;
            }
            if (nodeName.equalsIgnoreCase("success")) {
                response.setSuccess(Boolean.valueOf(valueNode.getNodeValue()).booleanValue());
            } else if (nodeName.equalsIgnoreCase("responseCode")) {
                response.setResponseCode(valueNode.getNodeValue());
            } else if (nodeName.equalsIgnoreCase("errorMessage")) {
                response.setErrorMessage(valueNode.getNodeValue());
            } else if (nodeName.equalsIgnoreCase("errorMessageRBKey")) {
                response.setErrorMessageRBKey(valueNode.getNodeValue());
            } else if (nodeName.equalsIgnoreCase("errorMessageParams")) {
                response.setErrorMessageParams(fromStringArray(node, "value"));
            } else if (nodeName.equalsIgnoreCase("sessionId")) {
               response.setSessionId(valueNode.getNodeValue());
            } else if (nodeName.equalsIgnoreCase("server")) {
                response.setServer(valueNode.getNodeValue());
            } else if (nodeName.equalsIgnoreCase("timeStamp")) {
                response.setTimeStamp(new Date(Long.parseLong(valueNode.getNodeValue())));
            } else if (nodeName.equalsIgnoreCase(rootNode_transactionResponse)) {
                NodeList transactionResponse = node.getChildNodes();
                for (int j = 0; j < transactionResponse.getLength(); j++) {
                    Node transactionResponseNode = transactionResponse.item(j);
                    if (transactionResponseNode.getNodeName().equals("transactionId")) {
                        response.setTransactionResponse(new TransactionResponse(new Long(transactionResponseNode.getFirstChild().getNodeValue())));
                    }
                }
            } else if (nodeName.equalsIgnoreCase("extendedDataMap")) {
                Map map = new HashMap();
                NodeList mapData = node.getChildNodes();
                for (int j = 0; j < mapData.getLength(); j++) {
                    Node mapEntry = mapData.item(j);
                    if (mapEntry.getNodeName().equalsIgnoreCase("MapEntry")) {
                        NodeList mapEntryList = mapEntry.getChildNodes();
                        String key = null;
                        String value = null;
                        for (int k = 0; k < mapEntryList.getLength(); k++) {
                            Node nameMapNode = mapEntryList.item(k);
                            if (nameMapNode.getNodeName().equals("Name")) {
                                key = nameMapNode.getFirstChild().getNodeValue();
                            } else if (nameMapNode.getNodeName().equals("Value")) {
                                value = nameMapNode.getFirstChild().getNodeValue();
                            }
                        }
                        map.put(key, value);
                    } // value
                } // end for
                response.setExtendedDataMap(map);
            } else if (!nodeName.startsWith("#")) {
                logger.error("Invalid element name <" + nodeName + ">");
            }
        }
        return response;

    }

  public static VCryptObjectResponse getVCryptObjectResponse(Node root) {

      VCryptObjectResponse response = new VCryptObjectResponse();
      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
          Node node = nodeList.item(i);
          String nodeName = node.getNodeName();
          Node valueNode = node.getFirstChild();
          if (valueNode == null) {
              continue;
          }
          if (nodeName.equalsIgnoreCase("xmlValue")) {
              response.setXmlValue(valueNode.getNodeValue());
          }else if (nodeName.equalsIgnoreCase("success")) {
              response.setSuccess(Boolean.valueOf(valueNode.getNodeValue()).booleanValue());
          } else if (nodeName.equalsIgnoreCase("responseCode")) {
              response.setResponseCode(valueNode.getNodeValue());
          } else if (nodeName.equalsIgnoreCase("errorMessage")) {
              response.setErrorMessage(valueNode.getNodeValue());
          } else if (nodeName.equalsIgnoreCase("errorMessageRBKey")) {
              response.setErrorMessageRBKey(valueNode.getNodeValue());
          } else if (nodeName.equalsIgnoreCase("errorMessageParams")) {
              response.setErrorMessageParams(fromStringArray(node, "value"));
          } else if (nodeName.equalsIgnoreCase("sessionId")) {
             response.setSessionId(valueNode.getNodeValue());
          } else if (nodeName.equalsIgnoreCase("server")) {
              response.setServer(valueNode.getNodeValue());
          } else if (nodeName.equalsIgnoreCase("timeStamp")) {
              response.setTimeStamp(new Date(Long.parseLong(valueNode.getNodeValue())));
          } else if (nodeName.equalsIgnoreCase(rootNode_transactionResponse)) {
              NodeList transactionResponse = node.getChildNodes();
              for (int j = 0; j < transactionResponse.getLength(); j++) {
                  Node transactionResponseNode = transactionResponse.item(j);
                  if (transactionResponseNode.getNodeName().equals("transactionId")) {
                      response.setTransactionResponse(new TransactionResponse(new Long(transactionResponseNode.getFirstChild().getNodeValue())));
                  }
              }
          } else if (nodeName.equalsIgnoreCase("extendedDataMap")) {
              Map map = new HashMap();
              NodeList mapData = node.getChildNodes();
              for (int j = 0; j < mapData.getLength(); j++) {
                  Node mapEntry = mapData.item(j);
                  if (mapEntry.getNodeName().equalsIgnoreCase("MapEntry")) {
                      NodeList mapEntryList = mapEntry.getChildNodes();
                      String key = null;
                      String value = null;
                      for (int k = 0; k < mapEntryList.getLength(); k++) {
                          Node nameMapNode = mapEntryList.item(k);
                          if (nameMapNode.getNodeName().equals("Name")) {
                              key = nameMapNode.getFirstChild().getNodeValue();
                          } else if (nameMapNode.getNodeName().equals("Value")) {
                              value = nameMapNode.getFirstChild().getNodeValue();
                          }
                      }
                      map.put(key, value);
                  } // value
              } // end for
              response.setExtendedDataMap(map);
          } else if (!nodeName.startsWith("#")) {
              logger.error("Invalid element name <" + nodeName + ">");
          }
      }
      return response;

  }

    public static String toVCryptIntResponseXml(VCryptIntResponse response) {
        if (response == null) return null;
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(getXmlElement("value", response.getValue()));
        xmlBuffer.append(toVCryptResponseXml(response.getRepsonse()));
        return getXmlElement(rootNode_VCryptIntResponse, xmlBuffer).toString();
    }

    public static VCryptIntResponse fromVCryptIntResponse(String xmlString) {

        if (logger.isDebugEnabled()) logger.debug("fromVCryptIntResponse");

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("fromVCryptIntResponse null xmlString");
            return null;
        }
        String rootNode = rootNode_VCryptIntResponse;
        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            VCryptResponse response = null;
            int responseValue = -1;
            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("value")) {
                    String value = valueNode.getNodeValue().trim();
                    responseValue = (Integer.valueOf(value.toLowerCase())).intValue();
                } else if (nodeName.equalsIgnoreCase(VCryptCommonUtil.rootNode_vCryptResponse)) {
                    response = VCryptCommonUtil.getVCryptResponse(node);
                } else if (!nodeName.startsWith("#")) {
                    logger.error("fromVCryptIntResponse Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }

            return new VCryptIntResponse(responseValue, response);
        } catch (Exception ex) {
            logger.error("fromVCryptIntResponse Error xml =" + xmlString, ex);
            return null;
        }
    }

    public static String toVCryptBooleanResponseXml(VCryptBooleanResponse response) {
        if (response == null) return null;
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append("<value>").append(response.getValue() ? "true" : "false").append("</value>");
        xmlBuffer.append(toVCryptResponseXml(response.getRepsonse()));
        return getXmlElement(rootNode_VCryptBooleanResponse, xmlBuffer).toString();
    }

    public static VCryptBooleanResponse fromVCryptBooleanResponseXml(String xmlString) {

        if (logger.isDebugEnabled()) logger.debug("fromVCryptBooleanResponseXml");

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("null xmlString");
            return null;
        }
        String rootNode = rootNode_VCryptBooleanResponse;

        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                return null;
            }

            VCryptResponse response = null;
            boolean responseValue = false;
            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("value")) {
                    String value = valueNode.getNodeValue().trim();
                    responseValue = (Boolean.valueOf(value.toLowerCase())).booleanValue();
                } else if (nodeName.equalsIgnoreCase(VCryptCommonUtil.rootNode_vCryptResponse)) {
                    response = VCryptCommonUtil.getVCryptResponse(node);
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }

            return new VCryptBooleanResponse(responseValue, response);
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }

    /**
     * Return well formed xml element, encodes the value
     *
     * @param name  name of the element
     * @param value value, handles null
     * @return xml element string buffer
     */
    public static StringBuffer getXmlElement(String name, String value) {
        return getXmlElement(name, value, true);
    }

    public static StringBuffer getXmlElement(String name, boolean value) {
        return getXmlElement(name, Boolean.toString(value), true);
    }

    public static StringBuffer getXmlElement(String name, Object value) {
        return getXmlElement(name, value != null ? value.toString() : null, true);
    }

    public static StringBuffer getXmlElement(String name, long value) {
        return getXmlElement(name, String.valueOf(value), true);
    }

    public static StringBuffer getXmlElement(String name, Long value) {
        String strValue = (value != null) ? value.toString() : null;
        return getXmlElement(name, strValue, true);
    }

    public static StringBuffer getXmlElement(String name, Date value) {
        String strValue = (value != null) ? DateUtil.getFormattedDateWithMilliSecs(value) : null;
        return getXmlElement(name, strValue, false);
    }

    /**
     * Return xml element, doesn't encode value
     *
     * @param name  name of the element
     * @param value value, handles null
     * @return xml element string buffer
     */
    public static StringBuffer getXmlElement(String name, StringBuffer value) {
        return getXmlElement(name, value.toString(), false);
    }

    /**
     * Return xml element, encodes value as CDATA.
     *
     * @param name   name of the element
     * @param value  value, handles null
     * @param encode encoding flag
     * @return xml element string buffer
     */
    public static StringBuffer getXmlElement(String name, String value, boolean encode) {
        StringBuffer elementXml = new StringBuffer();
        elementXml.append("<").append(name).append(">");
        if (!StringUtil.isEmpty(value))
            elementXml.append(encode ? encodeXmlElement(value) : value);
        elementXml.append("</").append(name).append(">");
        return elementXml;
    }

    /**
     * This methods returns an instance of VCryptTracker class.
     *
     * @return Returns instance of VCryptTracker class
     */
    static public VCryptCommon getVCryptCommonInstance() {
        if (vcryptCommon != null) {
            return vcryptCommon;
        }
        synchronized (VCryptCommonUtil.class) {
            if (vcryptCommon == null) {
                logger.info("Creating new VCryptTracker instance...");
                try {
                    vcryptCommon = newVCryptCommonInstance();
                } catch (Exception ex) {
                    logger.error("Error creating VCryptTracker instance.", ex);
                }
            }
        }
        return vcryptCommon;
    }

    /**
     * @param loginId login id to validate
     * @return login id
     */
    public static String validateLoginId(String loginId) {
        int truncateLoginIdLength = BharosaConfig.getInt("vcrypt.login.id.truncate.length", 64);
        if (loginId != null) {
            loginId = loginId.trim();
            if (loginId.length() > truncateLoginIdLength) {
                logger.info("LoginId=" + loginId + " is greater than "
                        + truncateLoginIdLength + ", so truncating it");
                loginId = loginId.substring(0, truncateLoginIdLength);
            }
        }
        return loginId;
    }

    /**
     * @param userId user id to Validate
     * @return userId
     */
    public static String validateUserId(String userId) {
        int truncateUserIdLength = BharosaConfig.getInt("vcrypt.ext.user.id.truncate.length", 255);
        if (userId != null) {
            userId = userId.trim();
            if (userId.length() > truncateUserIdLength) {
                logger.error("UserId=" + userId + " is greater than "
                        + truncateUserIdLength + ", so truncating it");
                userId = userId.substring(0, truncateUserIdLength);
            }
        }
        return userId;
    }

    public static String getWSAuthUserPassword() {
        String passwd = null;
        String keyStore = BharosaConfig.get("vcrypt.soap.auth.keystoreFile", "system_client.keystore");
        String keyStorePassword = BharosaConfig.get("vcrypt.soap.auth.keystorePassword");
        String keyStoreType = BharosaConfig.get("vcrypt.soap.auth.keystoreType", "JCEKS");
        String keyAlias = BharosaConfig.get("vcrypt.soap.auth.alias", "vcrypt.soap.call.passwd");
        String keyAliasPassword = BharosaConfig.get("vcrypt.soap.auth.aliasPassword");

        String decodedKeyStorePassword = null;
        String decodedKeyAliasPassword = null;
        boolean isBase64encoded = BharosaConfig.getBoolean("vcrypt.soap.call.password.base64encoded", true);
        if (isBase64encoded) {
            try {
                decodedKeyStorePassword = Base64.decodeBase64(keyStorePassword);
            } catch (Throwable ignore) {
            }
            if (decodedKeyStorePassword == null || decodedKeyStorePassword.trim().equals(""))
                decodedKeyStorePassword = keyStorePassword;


            try {
                decodedKeyAliasPassword = Base64.decodeBase64(keyAliasPassword);
            } catch (Throwable ignore) {
            }
            if (decodedKeyAliasPassword == null || decodedKeyAliasPassword.trim().equals(""))
                decodedKeyAliasPassword = keyAliasPassword;
        }
        try {
            byte[] key = KeyStoreUtil.getKey(FileUtil.getInputStream(keyStore), decodedKeyStorePassword, keyStoreType, keyAlias, decodedKeyAliasPassword);
            if (key != null)
                passwd = new String(key).trim();
            if (logger.isDebugEnabled())
                logger.debug("getWSAuthUserPassword keyStore=" + keyStore + ", isBase64encoded=" + isBase64encoded + ", keyStoreType=" + keyStoreType + ", passwd lengh=" + (passwd != null ? passwd.length() : 0));
        } catch (Throwable e) {
            logger.error("getWSAuthUserPassword keyStore=" + keyStore + ", keyStorePassword=" + keyStorePassword
                    + ", decodedKeyStorePassword=" + decodedKeyStorePassword + ", keyStoreType=" + keyStoreType
                    + ", keyAlias=" + keyAlias + ", keyAliasPassword=" + keyAliasPassword
                    + ", decodedKeyAliasPassword=" + decodedKeyAliasPassword + ", isBase64encoded=" + isBase64encoded, e);
        }
        return passwd;
    }    
    
  static public VCryptObjectResponse[] fromVCryptObjectResponsesXml(String xmlString) {

      if (logger.isDebugEnabled()) logger.debug("fromVCryptObjectResponsesXml");

      if (StringUtil.isEmpty(xmlString)) {
          logger.warn("null xmlString");
          return null;
      }
      
      List<VCryptObjectResponse> retList = new ArrayList<VCryptObjectResponse>();
      String xmlresponses[] = xmlString.split("</VCryptObjectResponse>");
      for(int j=0;j<xmlresponses.length;j++){         
        try {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlresponses[j]+"</VCryptObjectResponse>")));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
              Node node = rootList.item(i);
              if (node.getNodeName().equalsIgnoreCase(rootNode_vCryptObjectResponse)) {
                  root = node;
                  retList.add(getVCryptObjectResponse(root));
              }
            }
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
      }
      return (VCryptObjectResponse[])retList.toArray(new VCryptObjectResponse[retList.size()]);
  } // end fromVCryptResponseXml    
}
