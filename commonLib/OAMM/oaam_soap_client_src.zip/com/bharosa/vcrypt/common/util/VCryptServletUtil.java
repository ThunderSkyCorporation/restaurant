package com.bharosa.vcrypt.common.util;

import com.bharosa.common.util.StringUtil;
import com.bharosa.common.util.UserDefEnum;
import com.bharosa.common.util.BharosaConfig;
import com.bharosa.vcrypt.common.intf.VCryptCommon;
import com.bharosa.common.logger.Logger;

import com.bharosa.common.util.IPUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.net.URLDecoder;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.TreeMap;

/**
 * This utility class provides a set of methods which provide an easy way to implement the
 * Bharosa Authenticator api. It requires all needed information to be accessible from
 * the session and request variables except that information which is passed to the method.
 *
 * @author Luke
 */

public class VCryptServletUtil {

    public static final String HTTP_USER_AGENT = "userAgent";
    public static final String LOCAL_LANG = "localLang";
    public static final String LOCAL_COUNTRY = "localCountry";
    public static final String LOCAL_VARIANT = "localVariant";

    static Logger logger = Logger.getLogger(VCryptServletUtil.class);

    public static Integer browserFPType
            = new Integer(UserDefEnum.getElementValue("vcrypt.fingerprint.type.enum", "browser"));
    public static Integer digitalFPType
            = new Integer(UserDefEnum.getElementValue("vcrypt.fingerprint.type.enum", 
                          BharosaConfig.get("bharosa.uio.default.device.identification.scheme","flash")));

    /**
     * This methods removes all the states stored in the HTTP session
     * object.
     * @param session HttpSession object to reset
     */
    public static void resetSession(HttpSession session) {
        if (logger.isDebugEnabled()) logger.debug("resetSession(): httpSessionId=" + session.getId());
        session.removeAttribute("vcrypt_common");
        session.removeAttribute("vcrypt_requestId");

        //From auth
        session.removeAttribute("vcrypt_prev_session_id");
        session.removeAttribute("vcrypt_auth");
        session.removeAttribute("authResult");
        session.removeAttribute("vcrypt_auth_user");
    }

    /**
     * Returns a VCryptCommon session
     *
     * @param session an HttpSession object
     * @return VCryptCommon session object
     */
    public static VCryptCommon getVCryptCommon(HttpSession session) {
        VCryptCommon vcryptCommon =
                (VCryptCommon) session.getAttribute("vcrypt_common");
        if (vcryptCommon == null) {
            //Let create a new instance.
            if (logger.isDebugEnabled()) logger.debug("Creating new VCryptCommon instance");
            vcryptCommon = VCryptCommonUtil.getVCryptCommonInstance();
            if (vcryptCommon == null) {
                logger.error("Failed to create instance of VCryptCommon");
                return null;
            }
            session.setAttribute("vcrypt_common", vcryptCommon);
        }
        return vcryptCommon;
    }

    public static void setRequestId(HttpServletRequest request, String requestId) {
        if (request != null && requestId != null) {
            HttpSession session = request.getSession();
            if (session != null) {
                session.setAttribute("vcrypt_requestId", requestId);
            }
        }
    }

    public static String getRequestId(HttpServletRequest request) {
        HttpSession session = request.getSession();
        String requestId = (String) session.getAttribute("vcrypt_requestId");
        if (requestId != null) {
            return requestId;
        }
        synchronized (session) {
            requestId = (String) session.getAttribute("vcrypt_requestId");
            if (requestId == null) {
                //create a new requestId
                requestId = VCryptCommonUtil.generateUID(getRemoteIP(request));
                if (logger.isDebugEnabled()) logger.debug("Generating new requestId=" + requestId
                        + ", for http session id=" + session.getId());
                session.setAttribute("vcrypt_requestId", requestId);
            }
        }
        return requestId;
    }

    public static String getBrowserFingerPrint(String uas, String language, String country, String variant) {
        TreeMap nvList = new TreeMap();
        nvList.put(HTTP_USER_AGENT, uas);
        nvList.put(LOCAL_LANG, language);
        nvList.put(LOCAL_COUNTRY, country);
        nvList.put(LOCAL_VARIANT, variant);
        return StringUtil.concat(nvList);
    }

    public static Object[] getBrowserFingerPrint(HttpServletRequest request) {
        if (logger.isDebugEnabled()) logger.debug("getBrowserFingerPrint() enter. url="
                + request.getRequestURL());

        String fingerPrint = (String) request.getAttribute("vcrypt_browser_fingerprint");
        if (!StringUtil.isEmpty(fingerPrint)) {
            return new Object[]{browserFPType, fingerPrint};
        }

        Object[] fpArr = new Object[2];
        fpArr[0] = browserFPType;
        Locale locale = request.getLocale();        
        fpArr[1] = getBrowserFingerPrint(request.getHeader("user-agent"), locale.getLanguage(), locale.getCountry(), locale.getVariant());
        request.setAttribute("vcrypt_browser_fingerprint", fingerPrint);
        return fpArr;
    }

    /**
     * Method returns null if client is null or fpStr is invalid.
     *
     * @param client
     * @param fpStr
     * @return
     */

    public static String getFlashFingerPrint( String client, String fpStr ) {
        if (client != null && client.equalsIgnoreCase("vfc")) {
            if (fpStr != null) {
                TreeMap map = parseQueryString(fpStr);
                if(map.size()==0) {
                  logger.info("Invalid FingerPrint. Fingerprint given: " + fpStr);
                  return null;
                }
                else return  StringUtil.concat(map);
            }
        }
        logger.info("Invalid Client. Client given: " + client);
        return null;
    }

    public static Object[] getFlashFingerPrint(HttpServletRequest request) {
        if (logger.isDebugEnabled()) logger.debug("getFlashFingerPrint() enter. url="
                + request.getRequestURL());

        String fingerPrint = (String) request.getAttribute("vcrypt_flash_fingerprint");
        if (!StringUtil.isEmpty(fingerPrint)) {
            return new Object[]{digitalFPType, fingerPrint};
        }

        Object[] fpArr = new Object[2];
        String client = request.getParameter("client");
        String fpStr = request.getParameter("fp");
        fingerPrint = getFlashFingerPrint(client, fpStr);

        fpArr[0] = digitalFPType;
        fpArr[1] = fingerPrint;
        request.setAttribute("vcrypt_flash_fingerprint", fingerPrint);
        return fpArr;
    }

    public static TreeMap parseQueryString(String query) {

        TreeMap nvList = new TreeMap();
        if (query == null) {
            return nvList;
        }
        StringTokenizer st = new StringTokenizer(query, "&=");
        while (st.hasMoreTokens()) {
            String name = st.nextToken();
            if (st.hasMoreTokens()) {
                try {
                    String value = URLDecoder.decode(st.nextToken(), "UTF-8");
                    nvList.put(name.trim(), value.trim());
                } catch (Exception ex) {
                    logger.debug("Bad encoding in flash fingerprinting.", ex);
                }
            }
        }
        return nvList;
    }

    public static String getRemoteIP(HttpServletRequest request) {
        logger.debug("Getting the remote ip address...");

        boolean checkProxiedIps = BharosaConfig.getBoolean("vcrypt.tracker.ip.detectProxiedIP", false);

        String ip = null;
        
        String ipHeaderName = BharosaConfig.get("bharosa.ip.header.name", "X-Forwarded-For");
        String proxiedIps = request.getHeader(ipHeaderName);

        if (proxiedIps != null && checkProxiedIps) {
            String[] allIps = proxiedIps.split(",");

            logger.debug("Detected " + allIps.length + " forwarded ip addresses: " + proxiedIps
            + ", using HTTP header " + ipHeaderName);

            ip = allIps[0].trim();
        }

        if (ip == null || !IPUtil.isValidIP(ip)) {
            ip = request.getRemoteAddr();
        }

        return ip;
    }

}//end class VCryptServletUtil
