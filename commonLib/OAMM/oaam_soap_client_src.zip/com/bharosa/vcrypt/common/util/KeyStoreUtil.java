package com.bharosa.vcrypt.common.util;

import com.bharosa.common.util.Base64;

import com.bharosa.common.util.FileUtil;
import com.bharosa.common.util.StringUtil;

import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.Key;
import java.security.KeyStore;
import java.util.Properties;
import java.util.Enumeration;

public class KeyStoreUtil {

    private static final String TO_FILE_NAME = "writetofilename";
    private static final String KS_FILE_NAME = "keystorefilename";
    private static final String KS_TYPE = "keystoretype";
    private static final String KS_PASSWD = "keystorepasswd";
    private static final String KS_ALIAS = "keystorealias";
    private static final String KS_ALIAS_PASSWD = "keystorealiaspasswd";
    private static final String KEY_FILE = "keyfile";
    private static final String ALGORITHM = "algorithm";
    private static final String TO_BASE64 = "tobase64";
    private static final String FROM_BASE64 = "frombase64";
    private static final String PRINT_ENCODED_PASSWORDS = "printencodedpasswords";

    public static byte[] getKey(InputStream inputStream, String ksPwd, String ksType, String ksAlias, String ksKeyPwd)
            throws Exception {
        KeyStore keyStore = KeyStore.getInstance(ksType);
        keyStore.load(inputStream, ksPwd.toCharArray());
        byte[] result = keyStore.getKey(ksAlias, ksKeyPwd.toCharArray()).getEncoded();
        inputStream.close();
        return result;
    }



    public static void writeKeyToFile(Properties properties)
            throws Exception {

        String ksFileName = properties.getProperty(KS_FILE_NAME);
        String ksType = properties.getProperty(KS_TYPE);
        //String ksPwd = properties.getProperty(KS_PASSWD);
        String ksPwd = getCredentialsFromConsole(KS_PASSWD);
        String ksAlias = properties.getProperty(KS_ALIAS);
        //String ksKeyPwd = properties.getProperty(KS_ALIAS_PASSWD);
        String ksKeyPwd = getCredentialsFromConsole(KS_ALIAS_PASSWD);
        String toFile = properties.getProperty(TO_FILE_NAME);
        StringBuffer buffer = new StringBuffer();
        if (ksFileName == null || ksFileName.equals("")) buffer.append(KS_FILE_NAME).append("=<value>").append(" ");
        if (ksType == null || ksType.equals("")) buffer.append(KS_TYPE).append("=<value>").append(" ");
        if (ksPwd == null || ksPwd.equals("")) buffer.append(KS_PASSWD).append("=<value>").append(" ");
        if (ksAlias == null || ksAlias.equals("")) buffer.append(KS_ALIAS).append("=<value>").append(" ");
        if (ksKeyPwd == null || ksKeyPwd.equals("")) buffer.append(KS_ALIAS_PASSWD).append("=<value>").append(" ");
        if (toFile == null || toFile.equals("")) buffer.append(TO_FILE_NAME).append("=<value>").append(" ");
        if (!buffer.toString().equals("")) {
            System.err.println("Required inputs :" + buffer.substring(0, buffer.length() - 1));
            return;
        }

        File f = new File(toFile);
        if (f.exists())
            throw new RuntimeException(toFile + " exists!");

        FileInputStream fileInputStream = null;
        try {
          fileInputStream = new FileInputStream(ksFileName);
          byte[] b = getKey(fileInputStream, ksPwd, ksType, ksAlias, ksKeyPwd);
          if (b != null) {
              FileOutputStream fos = null;
              try {
                  f.createNewFile();
                  fos = new FileOutputStream(f);
                  fos.write(b);
              } catch (Throwable e) {
                  throw new RuntimeException(toFile + ", failed creation!");
              } finally {
                FileUtil.closeStream(fos);
              }
          }
        } finally {
          FileUtil.closeStream(fileInputStream);
        }
        System.out.println("writeKeyToFile done! file=" + toFile);
    }

    public static void updateOrCreateKeyStore(Properties properties) throws Exception {

        String ksFileName = properties.getProperty(KS_FILE_NAME);
        String ksType = properties.getProperty(KS_TYPE);
        //String ksPwd = properties.getProperty(KS_PASSWD);
        String ksPwd = getCredentialsFromConsole(KS_PASSWD);
        String ksKeyPwd = getCredentialsFromConsole(KS_ALIAS_PASSWD);
        String ksAlias = properties.getProperty(KS_ALIAS);
        //String ksKeyPwd = properties.getProperty(KS_ALIAS_PASSWD);
        String keyFile = properties.getProperty(KEY_FILE);
        String algorithm = properties.getProperty(ALGORITHM);
        String printEncodedPasswords = properties.getProperty(PRINT_ENCODED_PASSWORDS);

        StringBuffer buffer = new StringBuffer();
        if (ksFileName == null || ksFileName.equals("")) buffer.append(KS_FILE_NAME).append("=<value>").append(" ");
        if (ksType == null || ksType.equals("")) buffer.append(KS_TYPE).append("=<value>").append(" ");
        if (ksPwd == null || ksPwd.equals("")) buffer.append(KS_PASSWD).append("=<value>").append(" ");
        if (ksAlias == null || ksAlias.equals("")) buffer.append(KS_ALIAS).append("=<value>").append(" ");
        if (ksKeyPwd == null || ksKeyPwd.equals("")) buffer.append(KS_ALIAS_PASSWD).append("=<value>").append(" ");
        if (keyFile == null || keyFile.equals("")) buffer.append(KEY_FILE).append("=<value>").append(" ");
        if (algorithm == null || algorithm.equals("")) buffer.append(ALGORITHM).append("=<value>").append(" ");
        if (!buffer.toString().equals("")) {
            System.err.println("Required inputs :" + buffer.substring(0, buffer.length() - 1));
            return;
        }

        KeyStore ks = KeyStore.getInstance(ksType);
        File ksFile = new File(ksFileName);
        FileInputStream ksStream = null;
        FileOutputStream fileOutputStream = null;
        try {
          ksStream = ksFile.exists() ? new FileInputStream(ksFile) : null;
          ks.load(ksStream, ksPwd.toCharArray());
          InputStream inputStream = null;
          byte keyBuffer[] = null;
          try {
            inputStream = new FileInputStream(keyFile);
            int inBytes = inputStream.available();
            keyBuffer = new byte[inBytes];
            inputStream.read(keyBuffer, 0, inBytes);
          } finally {
              inputStream.close();
          }
          ks.setKeyEntry(ksAlias, new SecretKeySpec(keyBuffer, algorithm), ksKeyPwd.toCharArray(), null);
          fileOutputStream = new FileOutputStream(ksFile);
          ks.store(fileOutputStream, ksPwd.toCharArray());
        } finally {
          FileUtil.closeStream(ksStream);
          FileUtil.closeStream(fileOutputStream);
        }
        System.out.println("updateOrCreateKeyStore done!");
        System.out.println("Keystore file:" + ksFileName + ",algorithm=" + algorithm);
        if ("true".equalsIgnoreCase(printEncodedPasswords)) {
            System.out.println("KeyStore Password=" + Base64.encodeBase64(ksPwd));
            System.out.println("Alias Password=" + Base64.encodeBase64(ksKeyPwd));
        }
    }

    public static void updateOrCreateKeyStoreWithAutoGeneratedKey(Properties properties) throws Exception {

        String ksFileName = properties.getProperty(KS_FILE_NAME);
        String ksType = properties.getProperty(KS_TYPE);
        //String ksPwd = properties.getProperty(KS_PASSWD);
        String ksPwd = getCredentialsFromConsole(KS_PASSWD);
        String ksKeyPwd = getCredentialsFromConsole(KS_ALIAS_PASSWD);
        String ksAlias = properties.getProperty(KS_ALIAS);
        //String ksKeyPwd = properties.getProperty(KS_ALIAS_PASSWD);
        String algorithm = properties.getProperty(ALGORITHM);
        String printEncodedPasswords = properties.getProperty(PRINT_ENCODED_PASSWORDS);

        StringBuffer buffer = new StringBuffer();
        if (ksFileName == null || ksFileName.equals("")) buffer.append(KS_FILE_NAME).append("=<value>").append(" ");
        if (ksType == null || ksType.equals("")) buffer.append(KS_TYPE).append("=<value>").append(" ");
        if (ksPwd == null || ksPwd.equals("")) buffer.append(KS_PASSWD).append("=<value>").append(" ");
        if (ksAlias == null || ksAlias.equals("")) buffer.append(KS_ALIAS).append("=<value>").append(" ");
        if (ksKeyPwd == null || ksKeyPwd.equals("")) buffer.append(KS_ALIAS_PASSWD).append("=<value>").append(" ");
        if (algorithm == null || algorithm.equals("")) buffer.append(ALGORITHM).append("=<value>").append(" ");
        if (!buffer.toString().equals("")) {
            System.err.println("Required inputs :" + buffer.substring(0, buffer.length() - 1));
            return;
        }

        KeyStore ks = KeyStore.getInstance(ksType);
        File ksFile = new File(ksFileName);
        FileInputStream ksStream = null;
        FileOutputStream fileOutputStream = null;
        try {
          ksStream = ksFile.exists() ? new FileInputStream(ksFile) : null;
          ks.load(ksStream, ksPwd.toCharArray());
          if (ksFileName == null)
              ksFileName = "";
          Key key = KeyGenerator.getInstance(algorithm).generateKey();
          ks.setKeyEntry(ksAlias, key, ksKeyPwd.toCharArray(), null);
          fileOutputStream = new FileOutputStream(ksFile);
          ks.store(fileOutputStream, ksPwd.toCharArray());
          System.out.println("updateOrCreateKeyStoreWithAutoGeneratedKey done!");
          System.out.println("Keystore file is " + ksFileName + ",algorithm=" + algorithm);
          if ("true".equalsIgnoreCase(printEncodedPasswords)) {
              System.out.println("KeyStore Password=" + Base64.encodeBase64(ksPwd));
              System.out.println("Alias Password=" + Base64.encodeBase64(ksKeyPwd));
          }
        } finally {
          FileUtil.closeStream(ksStream);
          FileUtil.closeStream(fileOutputStream);
        }
    }

    private static void generateKey(Properties properties) throws Exception {

        String ksFileName = properties.getProperty(KS_FILE_NAME);
        String algorithm = properties.getProperty(ALGORITHM);
//        String printEncodedPasswords = properties.getProperty(PRINT_ENCODED_PASSWORDS);

        StringBuffer buffer = new StringBuffer();
        if (ksFileName == null || ksFileName.equals("")) buffer.append(KS_FILE_NAME).append("=<value>").append(" ");
        if (algorithm == null || algorithm.equals("")) buffer.append(ALGORITHM).append("=<value>").append(" ");
        if (!buffer.toString().equals("")) {
            System.err.println("Required inputs : " + buffer.substring(0, buffer.length() - 1));
            return;
        }
        Key key = KeyGenerator.getInstance(algorithm).generateKey();
        System.out.println("Generated Encoded key = " + new String(Base64.encodeBase64(key.getEncoded())));
    }
    
    private static void base64encode(Properties props) {
        String toBase64 = props.getProperty(TO_BASE64);
        if (toBase64 == null)
            System.err.println("Required input " + TO_BASE64);
        else {
        	System.out.println("base64encode is done!");
            System.out.println("Base64 Encoded value = "+Base64.encodeBase64(toBase64));
        }
    }

    private static void base64decode(Properties props) {
        String fromBase64 = props.getProperty(FROM_BASE64);
        if (fromBase64 == null)
            System.err.println("Required input " + FROM_BASE64);
        else {
        	System.out.println("base64decode is done!");
            System.out.println("Base64 Decoded value = "+Base64.decodeBase64(fromBase64));
        }
    }

    public static Key getKeyAsKeyObject(InputStream inputStream, String ksPwd, String ksType, String ksAlias, String ksKeyPwd)
            throws Exception {
      try {
        KeyStore keyStore = KeyStore.getInstance(ksType);
        keyStore.load(inputStream, ksPwd.toCharArray());
        Key result = keyStore.getKey(ksAlias, ksKeyPwd.toCharArray());
        return result;
      } finally {
        FileUtil.closeStream(inputStream);
      }
    }

    public static void main(String args[]) {
        FileInputStream fileInputStream  = null;
        try {
            String usage = "Usage: java " + KeyStoreUtil.class.getName() + " [ writeKeyToFile | updateOrCreateKeyStore | updateOrCreateKeyStoreWithAutoGeneratedKey | base64encode | base64decode ]";
            if (args.length < 1) {
                System.err.println(usage);
                System.exit(1);
            }

            Properties props = new Properties();
            for (int i = 1; i < args.length; i++) {
                String arg = args[i];
                int split = arg.indexOf("=");
                if (split > 0 && split < arg.length()) {
                    String key = arg.substring(0, split);
                    String value = arg.substring(split + 1);
                    props.put(key.trim().toLowerCase(), value.trim());
                }
            }

            String readFromFile = props.getProperty("readfromfile");
            if (readFromFile != null) {
                Properties tmpProps = new Properties();
                fileInputStream = new FileInputStream(readFromFile);
                tmpProps.load(fileInputStream);
                Enumeration enumeration = tmpProps.keys();
                while (enumeration.hasMoreElements()) {
                    String key = (String) enumeration.nextElement();
                    props.put(key.trim().toLowerCase(), tmpProps.getProperty(key).trim());
                }
            }


            if (args[0].equals("writeKeyToFile")) {
                writeKeyToFile(props);
            } else if (args[0].equals("updateOrCreateKeyStore")) {
                updateOrCreateKeyStore(props);
            } else if (args[0].equals("updateOrCreateKeyStoreWithAutoGeneratedKey")) {
                updateOrCreateKeyStoreWithAutoGeneratedKey(props);
            } else if (args[0].equals("base64encode")) {
                base64encode(props);
            } else if (args[0].equals("base64decode")) {
                base64decode(props);
            } else if (args[0].equals("generateKey")) {
            	generateKey(props);
            } else {
                System.err.println(usage);
                System.exit(1);
            }
        } catch (Exception e) {
            System.err.println(e);
        } finally { 
          FileUtil.closeStream(fileInputStream);
        }
    }
    
    private static final String getCredentialsFromConsole(String prompt_msg){
            if(StringUtil.isEmpty(prompt_msg))
                return null ;
            
            Console con = System.console();  
            char[] pwd = null ;
            if (con != null)  
            {
                int count = 0 ;
                int MAX_PWD = 3 ;
                do
                { 
                    if(prompt_msg.equals(KS_PASSWD) || prompt_msg.equals(KS_ALIAS_PASSWD))
                    pwd = con.readPassword("Enter %s: ", prompt_msg);                    
                    con.writer().write("\n\n");  // output a couple of newlines    
                } while (pwd==null && ++count < MAX_PWD);  
            }
            return new String(pwd);        
    }    


}
