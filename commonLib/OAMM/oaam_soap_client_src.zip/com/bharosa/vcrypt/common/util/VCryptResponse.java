package com.bharosa.vcrypt.common.util;
/*
 * Copyright (c) 2006 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;

import java.io.Serializable;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * VCryptResponse
 * <p/>
 * Date: Jun 26, 2006
 *
 * @since 3.0
 */
public class VCryptResponse implements Serializable {

	private boolean success;
	private Date timeStamp;
	private String responseCode;
	private String errorMessage;
	private String   errorMessageRBKey;
	private String[] errorMessageParams;
	private String server = BharosaConfig.getServerName();
	private Map extendedDataMap;
	private String sessionId;
	private TransactionResponse transactionResponse;

	public static final String DATA_CITY_NAME = "DATA_CITY_NAME";
	public static final String DATA_STATE_NAME = "DATA_STATE_NAME";
	public static final String DATA_COUNTRY_NAME = "DATA_COUNTRY_NAME";

	public static final String DATA_REMOTE_IP_ADDRESS = "DATA_REMOTE_IP_ADDRESS";
	public static final String DATA_DEVICE_ID = "DATA_DEVICE_ID";

	// Success
	public static final String SUCCESS = "0";
	// Input Errors
	public static final String INVALID_DATA = "1";

	// Data Errors
	public static final String NO_DATA = "10";

	// Operational
	public static final String NOT_SUPPORTED = "50";
	public static final String APPLICATION_ERROR = "51";
	public static final String VALIDATION_ERROR = "52";
	public static final String UNEXPECTED_ERROR = "99";

	public VCryptResponse() {
		this(null);
	}

	public VCryptResponse(String sessionId) {
		this(true, sessionId, SUCCESS, null);
		this.timeStamp = new Date();
	}

	public VCryptResponse(String responseCode, String errorMessage) {
		this(null, responseCode, errorMessage);
	}

	public VCryptResponse(String sessionId, String responseCode, String errorMessage) {
		this(false, sessionId, responseCode, errorMessage);
	}

	private VCryptResponse(boolean success, String sessionId, String responseCode, String errorMessage) {
		this.success = success;
		this.sessionId = sessionId;
		this.responseCode = responseCode;
		this.errorMessage = errorMessage;
		this.errorMessageRBKey  = null;
		this.errorMessageParams = null;
		this.timeStamp = new Date();
	}

	public boolean isSuccess() {
		return this.success;
	}

	public String getResponseCode() {
		return this.responseCode;
	}

	public String getErrorMessage() {
		return this.errorMessage == null ? "" : this.errorMessage;
	}

	public String getErrorMessageRBKey() {
		return this.errorMessageRBKey;
	}

	public String[] getErrorMessageParams() {
		return this.errorMessageParams;
	}

	public Date getTimeStamp() {
		return this.timeStamp;
	}

	public String getServer() {
		return this.server;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public void setErrorMessageRBKey(String errorMessageRBKey) {
		this.errorMessageRBKey = errorMessageRBKey;
	}

	public void setErrorMessageParams(String[] errorMessageParams) {
		this.errorMessageParams = errorMessageParams;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public void setServer(String server) {
		this.server = server;
	}

	public static VCryptResponse getSuccess() {
		return new VCryptResponse();
	}

	public static VCryptResponse getUnexpectedErrorResponse() {
    VCryptResponse vr = new VCryptResponse(UNEXPECTED_ERROR, "Unexpected error.");
    vr.setErrorMessageRBKey("oaam.generic.systemerror");
    return vr;
	}

	public void addExtendedData(String key, String value) {

		if (key == null || value == null) return;

		if (extendedDataMap == null)
			extendedDataMap = new HashMap();

		extendedDataMap.put(key, value);
	}

	public void setExtendedDataMap(Map map) {
		this.extendedDataMap = map;
	}

	public Map getExtendedDataMap() {
		return (extendedDataMap == null) ?
			Collections.EMPTY_MAP :
			Collections.unmodifiableMap(extendedDataMap);
	}

	public String getExtendedMap(String key) {
		Map map = getExtendedDataMap();
		if (map != null) {
			return (String) map.get(key);
		}
		return null;
	}

	public String getSessionId() {
		return sessionId;
	}

	public VCryptResponse setSessionId(String sessionId) {
		this.sessionId = sessionId;
		return this;
	}

	public TransactionResponse getTransactionResponse() {
		return transactionResponse;
	}

	public VCryptResponse setTransactionResponse(TransactionResponse transactionResponse) {
		this.transactionResponse = transactionResponse;
		return this;
	}

	public String toString() {
		return "VCryptResponse{" +
			"success=" + success +
			", timeStamp=" + timeStamp +
			", responseCode='" + responseCode + "'" +
			", errorMessage='" + getErrorMessage() + "'" +
			", errorMessageRBKey='" + errorMessageRBKey + "'" +
			", errorMessageParams='" + errorMessageParams + "'" +
			", server='" + server + "'" +
			", extendedDataMap=" + extendedDataMap +
			", sess='" + sessionId + "'" +
			", transactionResponse='" + transactionResponse +
			"}";
	}

} // end VCryptResponse

