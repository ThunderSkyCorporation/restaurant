/* $Header: oaam/apps/oaam_core/src/com/bharosa/vcrypt/common/util/VCryptObjectResponse.java /main/6 2011/06/07 03:02:23 esubrama Exp $ */

/* Copyright (c) 2009, 2011, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
      djoyce    03/04/10 - Add missing class

 */

package com.bharosa.vcrypt.common.util;

@SuppressWarnings("unchecked")
public class VCryptObjectResponse<E> extends VCryptResponse {

    private E value;
    
    private String xmlValue;

    public VCryptObjectResponse(E e, String sessionId) {
      super(sessionId);
      value = e;
    }
    
    public VCryptObjectResponse(E e, String responseCode, String errorMessage) {
      super(responseCode, errorMessage);
      value = e;
    }
  
    public VCryptObjectResponse(E e, String sessionId, String responseCode, String errorMessage) {
      super(sessionId, responseCode, errorMessage);
      value = e;
    }

    public VCryptObjectResponse(E value) {
        this.value = value;
    }

    public VCryptObjectResponse() {
        this(null);
    }

    public E getObject() {
        return value;
    }
    
    public void setObject(E value) {
      this.value = value;
    }


  public String toString() {
    return "VCryptObjectResponse{" + "success=" + this.isSuccess() + 
           ", timeStamp=" + getTimeStamp() + 
           ", responseCode='" + getResponseCode() + "'" +
           ", errorMessage='" + getErrorMessage() + "'" + 
           ", errorMessageRBKey='" + getErrorMessageRBKey() + "'" + 
           ", errorMessageParams='" + getErrorMessageParams() + "'" + 
           ", server='" + getServer() + "'" + 
           ", extendedDataMap=" + getExtendedDataMap() + 
           ", sess='" + getSessionId() + "'" +
           ", transactionResponse='" + getTransactionResponse() + 
           ", value='" + (value == null ? "" : value.toString()) + "'" +
           "}";
  }

    public void setXmlValue(String xmlValue) {
        this.xmlValue = xmlValue;
    }

    public String getXmlValue() {
        return xmlValue;
    }
}
