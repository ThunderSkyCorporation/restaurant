package com.bharosa.vcrypt.common.util;
/**
 * VCryptIntResponse
 * <p/>
 * Date: Jun 26, 2006
 *
 * @since 3.0
 */
public class VCryptIntResponse {

    private int value;
    private VCryptResponse repsonse;

    public VCryptIntResponse(int data, VCryptResponse repsonse) {
        this.value = data;
        this.repsonse = repsonse;
    }

    public int getValue() {
        return value;
    }

    public VCryptResponse getRepsonse() {
        return repsonse;
    }

    public String toString() {
        return "VCryptIntResponse. " +
                "; value=" + value +
                "; repsonse=" + repsonse +
                ';';
    }

}
