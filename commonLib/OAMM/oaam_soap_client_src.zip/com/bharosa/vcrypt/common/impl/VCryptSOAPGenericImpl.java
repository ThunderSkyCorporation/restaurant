package com.bharosa.vcrypt.common.impl;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.vcrypt.common.intf.VCryptSOAP;
import com.bharosa.vcrypt.common.util.VCryptCommonUtil;
import com.bharosa.common.logger.Logger;

import javax.xml.namespace.QName;
import javax.xml.rpc.Call;
import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceFactory;
import javax.xml.rpc.soap.SOAPFaultException;

/**
 * This provides the generic implementation for VCryptSOAP interface
 *
 * @author bosco
 */

public class VCryptSOAPGenericImpl implements VCryptSOAP {

    static Logger logger = Logger.getLogger(VCryptSOAPGenericImpl.class);

    private Service service = null;

    String serviceName = null;
    String serverUrl = null;
    //URL url = null;

    //String clientWSDD = null;
    //XMLStringProvider clientProvider = null;

    // create service factory
    ServiceFactory factory = null;
    private String userName = null;
    private String userPwd = null;
	private String targetNamespace = null;
    private String arg0Name = BharosaConfig.get("vcrypt.tracker.soap.arg0Name", "arg0");
    private String arg1Name = BharosaConfig.get("vcrypt.tracker.soap.arg1Name", "arg1");
	
    /**
     * constructor
     * @param serverUrl url
     * @param serviceName name of the service
     * @throws Exception error
     */
    public VCryptSOAPGenericImpl(String serverUrl, String serviceName) throws Exception {
        // Setup the global JAX-RPC service factory
        //System.setProperty( "javax.xml.rpc.ServiceFactory", "weblogic.webservice.core.rpc.ServiceFactoryImpl");

        logger.info("Creating VCryptSOAPGenericImpl serverUrl="
                + serverUrl + ", serviceName=" + serviceName);

        if (StringUtil.isEmpty(serverUrl)) {
            logger.fatal("serverUrl is empty");
            throw new Exception("serverUrl is empty");
        }

        if (StringUtil.isEmpty(serviceName)) {
            logger.fatal("serviceName is empty serverUrl=" + serverUrl);
            throw new Exception("serviceName is empty serverUrl="
                    + serverUrl);
        }
        serviceName = serviceName.trim();
        serverUrl = serverUrl.trim();

        if (BharosaConfig.getBoolean("vcrypt.soap.auth", true)) {
            userName = BharosaConfig.get("vcrypt.soap.auth.username");
            if (StringUtil.isEmpty(userName))
                throw new Exception("Authentication credentials mising");
            userPwd = VCryptCommonUtil.getWSAuthUserPassword();
            if (StringUtil.isEmpty(userName))
                throw new Exception("Authentication credentials mising userName=" + userName);
        }
        this.serviceName = serviceName;
        this.serverUrl = serverUrl;
		String targetNamespacePrefix = BharosaConfig.get("vcrypt.tracker.soap.targetnamespace.prefix", "http://jaxws.oracle.com/oaam_ws/services");
		this.targetNamespace =  targetNamespacePrefix+"/"+serviceName;
    }

    public void createService() throws Exception {
        //getting provider's service facotry implementation class
        logger.debug("Service Impl class[" + System.getProperty("javax.xml.rpc.ServiceFactory") + "]");

        if (logger.isDebugEnabled()) {
            logger.debug("Creating service factory");
        }

        factory = ServiceFactory.newInstance();
        QName sName = new QName(targetNamespace, serviceName);

        //clientProvider = new XMLStringProvider(clientWSDD);

        if (logger.isDebugEnabled()) {
            logger.debug("Creating service instance");
        }
        service = factory.createService(sName);
    }

    /**
     * Generic method to invoke any soap request
     *
     * @param requestName  name of the request
     * @param xmlParameter the parameter in the form of string
     * @return the result in XML format
     */
    public String execute(String requestName, String xmlParameter) {
        if (logger.isDebugEnabled())
            logger.debug("execute() requestName[" + requestName
                    + "] xmlParameter" + xmlParameter + "]");

        String cause = null;
        boolean isSuccess = false;
        String resultXml = null;

        //get the properties from configuration
        boolean logSoapCalls = BharosaConfig.getBoolean("vcrypt.soap.logallcalls", false);
        boolean soapDisabled = BharosaConfig.getBoolean("vcrypt.soap.disable", false);
        int timeoutVal = BharosaConfig.getInt("vcrypt.soap.call.timeout", 3000);

        try {

            if (validateBeforeProcess(requestName, xmlParameter)) {
                logger.debug("Validation done. Now preparing for SOAP call...");

                if (service == null) {
                    createService();
                }
                Call call = null;
                try {
                    call = service.createCall();
                } catch (Exception e) {
                    logger.fatal("execute(): service.createCall() failed. requestName="
                            + requestName + ", xmlParameter=" + xmlParameter, e);
                    /*
                         cause = "execute(): service.createCall() failed. requestName="
                             + requestName + ", xmlParameter=" + xmlParameter
                             + ", exception=" + e.toString();
                             */
                }

                if (call != null) {
                    // Update Call Object Timeout
                    updateCallForTimeout(call);

                    if (logger.isDebugEnabled()) logger.debug("execute() requestName=" + requestName
                            + ", setting Target Endpoint Address=" + serverUrl);
					String serviceUrl = serverUrl+"/"+serviceName;
                    call.setTargetEndpointAddress(serviceUrl);
                    if (!StringUtil.isEmpty(userName)) {
                        if (logger.isDebugEnabled())
                            logger.debug("Using userName " + userName + " for SOAP authentication");
                        call.setProperty(Call.USERNAME_PROPERTY, userName);
                    }
                    if (!StringUtil.isEmpty(userPwd)) {
                        if(logger.isDebugEnabled())
                            logger.debug("Using userName " + userName +", Password lenght="+(userPwd.length()) + " for SOAP authentication");
                        call.setProperty(Call.PASSWORD_PROPERTY, userPwd);
                    }
                    call.addParameter(arg0Name,
                            new QName("http://www.w3.org/2001/XMLSchema", "string"),
                            ParameterMode.IN);
                    call.addParameter(arg1Name,
                            new QName("http://www.w3.org/2001/XMLSchema", "string"),
                            ParameterMode.IN);
                    call.setReturnType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
                    setEncodingStyle(call);

                    //call.setMaintainSession(true);
                    try {
                        if (logger.isDebugEnabled()) logger.debug("Calling invoke(). requestName=" + requestName);
                        resultXml = (String) call.invoke(new QName(targetNamespace, "execute"), new Object[]{requestName, xmlParameter});
                        if (logger.isDebugEnabled()) {
                        	logger.debug("Webservice call complete. ResultXML =["+resultXml+"]");
                        }
                        isSuccess = true;
                    } catch (SOAPFaultException sf) {
                        logger.fatal("execute(): Error during soap call for requestName="
                                + requestName + ", xmlParameter=" + xmlParameter
                                + ", serverUrl=" + serverUrl + ", timeoutValue=" + timeoutVal, sf);

                        logger.fatal("Cause for SOAPFaultException: " + sf.getDetail());
                        /*
                              cause = "execute(): Error during soap call for requestName="
                                  + requestName + ", xmlParameter=" + xmlParameter
                                  + ", serverUrl=" + serverUrl + ", timeoutValue=" + timeoutVal
                                  + ", exception=" + sf.toString();
                              */
                    } catch (Exception e) {
                        logger.fatal("execute(): Error during soap call for requestName="
                                + requestName + ", xmlParameter=" + xmlParameter
                                + ", serverUrl=" + serverUrl + ", timeoutValue=" + timeoutVal, e);
                        /*
                              cause = "execute(): Error during soap call for requestName="
                                  + requestName + ", xmlParameter=" + xmlParameter
                                  + ", serverUrl=" + serverUrl + ", timeoutValue=" + timeoutVal
                                  + ", exception=" + e.toString();
                                  */
                    }
                }
            }
        } catch (Exception ex) {
            logger.error("Caught exception: execute() requestName="
                    + requestName + ", serverUrl=" + serverUrl
                    + ", xmlParameter=" + xmlParameter, ex);
            /*
               cause = "Caught exception: execute(). requestName="
                   + requestName + ", xmlParameter=" + xmlParameter
                   + ", exception=" + ex.toString();
                   */
        }

        if (!soapDisabled) {
            if (isSuccess) {
                if (logger.isDebugEnabled()) logger.debug("execute() success for requestName=" + requestName);
            }
            if (logSoapCalls) {
                logger.info("execute(): requestName=" + requestName
                        + ", xmlParameter=" + xmlParameter
                        + ", resultXml=" + resultXml
                        + ", isSuccess=" + isSuccess
                        + ", cause=" + cause);
            }
        }
        return resultXml;
    }

    // By default nothing needs to be done.
    // Impl classes can update Call object for timeout.
    protected void updateCallForTimeout(Call pCall) {
    }

    private boolean validateBeforeProcess(String requestName, String xmlParameter) {

        String cause = null;
        boolean soapDisabled = BharosaConfig.getBoolean("vcrypt.soap.disable", false);
        if (soapDisabled) {
            cause = "All SOAP calls are disabled. requestName=" + requestName;

        } else if (StringUtil.isEmpty(requestName)) {
            cause = "execute() called with empty requestName";

        } else if (StringUtil.isEmpty(xmlParameter)) {
            cause = "execute() called with empty xmlParameter. requestName="
                    + requestName;

        }
        boolean flag = true;

        if (cause != null) {
            logger.error("execute() error. cause=" + cause);
            flag = false;
        }

        return flag;
    }//end validateBeforeProcess

    protected void setEncodingStyle(Call call) {
        logger.debug("setting the encoding type" ) ;
	}

}
