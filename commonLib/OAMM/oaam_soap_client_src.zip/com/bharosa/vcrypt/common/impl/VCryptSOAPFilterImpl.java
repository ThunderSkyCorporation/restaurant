/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

package com.bharosa.vcrypt.common.impl;

import java.lang.reflect.Constructor;
import java.util.Date;

import com.bharosa.common.logger.Logger;

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.vcrypt.common.intf.VCryptSOAP;

/**
 * Filter implementation for SOAP impl.
 * Duty of this wrapper class is to log time taken by impl execution.
 *  
 * @author Kuldeep Shah <kuldeep@nvsoft.com>
 *
 */
public class VCryptSOAPFilterImpl implements VCryptSOAP {

    private static Logger logger = Logger.getLogger(VCryptSOAPFilterImpl.class);

    private VCryptSOAP vcryptSoap = null;
    private long defaultUpperLimit = -1; 

	/**
	 * 
	 */
    public VCryptSOAPFilterImpl(String serverUrl, String serviceName) {
    	if (vcryptSoap == null) {
    		logger.info("Creating new VCryptTracker instance...");
    		try {
    			String className = BharosaConfig.get("vcrypt.common.util.vcryptsoap.impl.classname",
    			"com.bharosa.vcrypt.common.impl.VCryptSOAPAxisImpl");
    			if (!StringUtil.isEmpty(className)) {
    				//Loading instance
    				logger.info("Loading class " + className);
    				Class soapClass = Class.forName(className);
    				Constructor classConstructor =
    					soapClass.getConstructor(new Class[]{String.class, String.class});
    				vcryptSoap = (VCryptSOAP) classConstructor.newInstance(new Object[] {serverUrl, serviceName});
    			} else {
    				logger.error("Class not created. Property 'vcrypt.common.util.vcryptsoap.impl.classname' should be set");
    			}
    		} catch (Exception ex) {
    			logger.error("Error creating VCryptSOAP instance.", ex);
    		}
    	}
    }

	/* (non-Javadoc)
	 * @see com.bharosa.vcrypt.common.intf.VCryptSOAP#execute(java.lang.String, java.lang.String)
	 * Invokes execute method on actual SOAP impl class. Duty of this wrapper method is to log time taken by impl execution.
	 */
	public String execute(String requestName, String xmlParameter) {
        Date beginTime = new Date();
        Date endTime = null;
		String retString = null;
		try {
			retString = vcryptSoap.execute(requestName, xmlParameter);
		} finally {
			endTime = new Date();
			long timeTaken = endTime.getTime() - beginTime.getTime();
            if(logger.isDebugEnabled()) logger.debug("FILTER:execute:" + requestName + ":" + timeTaken);
            long apiUpperLimit = getUpperLimit4API(requestName);
            if (apiUpperLimit < timeTaken) {
            	logger.warn("FILTER:execute:" + requestName + ":" + "TimeTaken:" + timeTaken + ":UpperLimit:" + apiUpperLimit);
            }
        }
		if (retString == null)
			logger.error("FILTER:execute:" + requestName, new Exception().fillInStackTrace());
		return retString;
	}
	
	protected long getDefaultUpperLimit() {
		if (defaultUpperLimit <= 0L) {
			defaultUpperLimit = 
				BharosaConfig.getLong("vcrypt.soap.upperLimit.millis.for.api", 
						BharosaConfig.getLong("vcrypt.soap.call.timeout", 3000L));
		}
		return defaultUpperLimit;
	}

	protected long getUpperLimit4API(String request) {
		return BharosaConfig.getLong("vcrypt.soap.upperLimit.millis.for.api" + "." + request, getDefaultUpperLimit());
	}

}
