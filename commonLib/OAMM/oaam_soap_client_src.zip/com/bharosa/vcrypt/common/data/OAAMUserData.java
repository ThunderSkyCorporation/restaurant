package com.bharosa.vcrypt.common.data;
/** Copyright (c) 2011, 2012, Oracle and/or its affiliates. 
All rights reserved. */

/**
 * This class encapsulates the attributes that are related to the User.
 * All the related attributes are members of this class.
 */

import java.io.Serializable;

public class OAAMUserData implements Serializable {

  /**
   * Login name of the user, that he/she enters on the login screen(s).
   */
  protected String loginName;

  /**
   * Group name to which user is associated. This maps to application Id in the OAAM Server.
   */
  protected String groupName;

  /**
   * UserId of the user, It is the generated id, usually not a meaningful string.
   */
  protected String userId;
    
  public OAAMUserData(String aLoginName, String aGroupName) throws Exception {
    this (aLoginName, aGroupName, null);
  }
  
  public OAAMUserData(String aLoginName, String aGroupName, String aUserId) throws Exception {
    super();
    setLoginName(aLoginName);
    setGroupName(aGroupName);
    setUserId(aUserId);
  }

  /**
   * Method to set the loginName.
   * @param loginName
   */
  private void setLoginName(String loginName) throws Exception {
    if (loginName == null || loginName.trim().length() <=0 ) {
      Exception ex = new Exception("Login name cannot be null or empty");
      throw ex;
    }
    this.loginName = loginName;
  }

  /**
   * @return Returns the loginName.
   */
  public String getLoginName() {
    return loginName;
  }

  /**
   * Method to set the groupName.
   * @param groupName
   */
  private void setGroupName(String groupName) throws Exception {
    if (groupName == null || groupName.trim().length() <=0 ) {
      Exception ex = new Exception("Group name cannot be null or empty");
      throw ex;
    }
    this.groupName = groupName;
  }

  /**
   * @return Returns the groupName. Can be null.
   */
  public String getGroupName() {
    return groupName;
  }

  /**
   * Method to set the userId.
   * @param userId
   */
  private void setUserId(String userId) {
    this.userId = userId;
  }

  /**
   * @return Returns the userId. Can be null.
   */
  public String getUserId() {
    return userId;
  }
  
  public String toString() {
    StringBuffer buf = new StringBuffer(100);
    buf.append("OAAMUserData [");
    buf.append("UoginName=" + loginName);
    buf.append(", GroupName=" + groupName);
    buf.append(", UserId=" + userId);
    buf.append("]");
    return buf.toString();
  }
}
