package com.bharosa.vcrypt.common.data;
/** Copyright (c) 2011, 2012, Oracle and/or its affiliates. 
All rights reserved. */

/**
 * This class encapsulates the attributes that are related to the Session data.
 * All the related attributes are members of this class.
 */
import com.bharosa.common.util.UserDefEnum;

import java.io.Serializable;

public class OAAMSessionData implements Serializable {
  
  static final UserDefEnum authStatusEnum = UserDefEnum.getEnum("auth.status.enum");
  static final UserDefEnum clientTypeEnum = UserDefEnum.getEnum("auth.client.type.enum");
  
  public OAAMSessionData(int aAuthStatus, boolean aRegisterDevice, String aClientApplication, int aClientType, String aClientVersion) throws Exception {
    this(aAuthStatus, aRegisterDevice);
    setClientApplication(aClientApplication);
    setClientType(aClientType);
    setClientVersion(aClientVersion);
  }
  
  public OAAMSessionData(int aAuthStatus) throws Exception {
    this(aAuthStatus, false /*Dont register*/);    
  }

  public OAAMSessionData(int aAuthStatus, boolean aRegisterDevice) throws Exception {
    super();
    setAuthenticationStatus(aAuthStatus);
    setRegisterDevice(aRegisterDevice);
  }
  


  /**
   * Attribute represents the authentication status. (auth.status.enum)
   */
  protected int authenticationStatus;
  
  /**
   * Attribute is flag when true will result in registering the device for the user.
   */
  protected boolean registerDevice;

  /**
   * The client application of the user's session.
   */
  protected String clientApplication;
  
  /**
   * The client type of the user's session. (client.type.enum)
   */
  protected int clientType;
  
  /**
   * Version of the client software / browser / device etc.
   */
  protected String clientVersion;
  
  /**
   * Flag to indicate if autolearnin should be at this point.
   */
  protected boolean analyzePatterns;
  
  /**
   * Exiernal device id if client wants to populate.
   */
  protected String externalDeviceId;

  /**
   * Method to set the authentication status attribute in this object.
   * @param authenticationStatus Should be a integer that represent one of auth.status.enum
   */
  private void setAuthenticationStatus(int authenticationStatus) throws Exception {
    if (authStatusEnum == null || authStatusEnum.getElement(authenticationStatus) == null) {
      Exception ex = new Exception("Auth status not found, status=" + authenticationStatus);
      ex.fillInStackTrace();
      throw ex;
    }
    this.authenticationStatus = authenticationStatus;
  }

  /**
   * @return Returns the authentication status attribute.
   */
  public int getAuthenticationStatus() {
    return authenticationStatus;
  }

  /**
   * To set if the device is registered.
   * @param registerDevice
   */
  private void setRegisterDevice(boolean registerDevice) {
    this.registerDevice = registerDevice;
  }

  /**
   * 
   * @return Returns if device is registered.
   */
  public boolean isRegisterDevice() {
    return registerDevice;
  }

  /**
   * Method to set the client type.
   * @param clientType
   */
  private void setClientType(int clientType) throws Exception {
    if (clientTypeEnum == null || clientTypeEnum.getElement(clientType) == null) {
      Exception ex = new Exception("Client type not found, type=" + clientType);
      ex.fillInStackTrace();
      throw ex;
    }
    this.clientType = clientType;
  }

  /**
   * @return Returne the clientType attribute which will be one of client.type.enum.
   */
  public int getClientType() {
    return clientType;
  }

  /**
   * Method to set the clientCersion attribute.
   * @param clientVersion
   */
  private void setClientVersion(String clientVersion) {
    this.clientVersion = clientVersion;
  }

  /**
   * @return Returns the value of the clientVersion. Can be null.
   */
  public String getClientVersion() {
    return clientVersion;
  }

  /** Method to set analyze pattern attribute.
   * @param analyzePatterns
   */
  public void setAnalyzePatterns(boolean analyzePatterns) {
    this.analyzePatterns = analyzePatterns;
  }

  /**
   * @return Returns the value of analyzePattern Attribute.
   */
  public boolean isAnalyzePatterns() {
    return analyzePatterns;
  }

  private void setClientApplication(String clientApplication) {
    this.clientApplication = clientApplication;
  }

  public String getClientApplication() {
    return clientApplication;
  }
  
  public String toString() {
    StringBuffer buf = new StringBuffer(100);
    buf.append("OAAMSessionData [");
    buf.append("AuthStatus=" + authenticationStatus);
    buf.append(", ClientType=" + clientType);
    buf.append(", ClientVersion=" + clientVersion);
    buf.append(", ClientApplication=" + clientApplication);
    buf.append(", RegisterDevice=" + registerDevice);
    buf.append(", AnalyzePatterns=" + analyzePatterns);
    buf.append(", ExternalDeviceId=" + externalDeviceId);
    buf.append("]");
    return buf.toString();
  }

  public void setExternalDeviceId(String pExternalDeviceId) {
    if (pExternalDeviceId != null && pExternalDeviceId.trim().length() > 256) {
      pExternalDeviceId = pExternalDeviceId.substring(0, 255);
    }
    this.externalDeviceId = pExternalDeviceId;
  }

  public String getExternalDeviceId() {
    return externalDeviceId;
  }
}
