package com.bharosa.vcrypt.common.data;

/** Copyright (c) 2011, 2012, Oracle and/or its affiliates. 
All rights reserved. */

/**
 * This class encapsulates the attributes that are related to the IP Address of the session.
 * All the related attributes are members of this class.
 */


import com.bharosa.common.util.IPUtil;
import com.bharosa.common.util.UserDefEnum;

import java.io.Serializable;

import java.util.Date;


public class OAAMIPData implements Serializable {

  static final UserDefEnum locationAcquireTypeEnum = UserDefEnum.getEnum("location.source.type.enum");
  static final UserDefEnum locationAccuracyUnitsEnum = UserDefEnum.getEnum("location.accuracy.unit.type.enum");
  
  /**
   * This attribute captures the IP address of the session in String format. (A.B.C.D)
   */
  protected String remoteIP;
  
  /**
   * This attribute captures the remote Host machine name from which the request somes in.
   */
  protected String remoteHost;
  
  /**
   * This attribute is the proxy IP address of the session if proxy is present. (in A.B.C.D format)
   */
  protected String proxyIP;
  
  /**
   * The longitude of the location. Min value is -180 (negative values for western hemisphere) and max value is +180 (positive values for eastern hemispehre).
   */
  protected Double longitude;
  
  /**
   * The latitude of the location. Min value is -90 (negative values for sounthern hemisphere) and max value is +90 (positive values for northern hemisphere)
   */
  protected Double latitude;
  
  /**
   * This attribute describes the accuracy of the location information (longitude, latitude pair).
   * This attribute along with location accuracy units will indicate the accuracy.
   * Typical example will be say within 2 meters of the indicated co-ordinates.
   * For this example the value of this attribute will be 2.0 and the value of location accuracy type will be a enumeration pointing to metere.
   */
  protected Double locationAccuracy;
  
  /**
   * This attribute along with locationAccuracy attribute describes the accuracy of the location information (longitude, latitude pair).
   * This attribute along with location accuracy units will indicate the accuracy.
   * Typical example will be say within 2 meters of the indicated co-ordinates.
   * For this example the value of this attribute will be a enumeration pointing to meter and value of locationAccuracy attribute will be 2.0.
   */
  protected int locationAccuracyUnits;
  
  /**
   * This attribute indicates the type / method by which location was acquired by the mobile device.
   * This is enumeration of the type mobile.location.acquire.type.enum.
   * Some of the possible integer values will correspond to gps, asisted gps, wifi hotspot etc.
   */
  protected int locationAcquireType;
  
  /**
   * This date-time field is the time at which mobile device acquired the location co-prdinates.
   */
  protected Date locationAcquireTime;
  
  
  public OAAMIPData(String aRemoteIP, Double aLongitude, Double aLatitude) throws Exception {
    super();
    setRemoteIP(aRemoteIP);
    setLongitude(aLongitude);
    setLatitude(aLatitude);
  }

  /**
   * Method to set the remoteIP.
   * @param remoteIP The remoteIP to be set.
   */
  private void setRemoteIP(String remoteIP) throws Exception {
    if (!IPUtil.isValidIP(remoteIP)) {
      Exception ex = new Exception("Invalid IP Address=" + remoteIP);
      ex.fillInStackTrace();
      throw ex;
    }
    this.remoteIP = remoteIP;

  }

  /**
   * @return Returns the String representing remoteIP attribute. (Can be null)
   */
  public String getRemoteIP() {
    return remoteIP;
  }

  /**
   * Method to set proxyIP.
   * @param proxyIP The proxyIP to be set.
   */
  public void setProxyIP(String proxyIP) throws Exception {
    if (!IPUtil.isValidIP(proxyIP)) {
      Exception ex = new Exception("Invalid IP Address=" + proxyIP);
      ex.fillInStackTrace();
      throw ex;
    }
    this.proxyIP = proxyIP; 
  }

  /**
   * @return Returns String representing proxyIP attribute.
   */
  public String getProxyIP() {
    
    return proxyIP;
  }

  /** 
   * Method to set the longitude attribute.
   * This methods validates the values. Anything less than -180 will be set as -180.0 and anything more than +180 will be set as +180.0
   * @param longitude The longitude value to be set.
   */
  public void setLongitude(Double longitude) {
    if (longitude == null) this.longitude = longitude;
    else if (longitude.doubleValue() < -180.0) this.longitude = -180.00;
    else if (longitude.doubleValue() > 180.0) this.longitude = +180.00;
    else this.longitude = longitude;
  }

  /**
   * @return Returns the value of longitude. (Can be null)
   */
  public Double getLongitude() {
    return longitude;
  }

  /**
   * Method to set the latitude. This method validate the values.
   * If param value is less than -90 then the value will be set to -90.
   * If param value is more than +90 then the value will be set to +90.
   * @param latitude The latitude to be set.
   */
  public void setLatitude(Double latitude) {
    if (latitude == null) this.latitude = latitude;
    else if (latitude.doubleValue() < -90.0 ) this.latitude = -90.0;
    else if (latitude.doubleValue() > 90.0) this.latitude = +90.0;
    else this.latitude = latitude;
  }

  /**
   * @return Returns the value of latitude.
   */
  public Double getLatitude() {
    return latitude;
  }

  /**
   * Method to set the locationAccuracy. This method validates the input.
   * If input is less than 0 then the value is set to 0.
   * @param locationAccuracy
   */
  public void setLocationAccuracy(Double locationAccuracy) {
    if (locationAccuracy == null) this.locationAccuracy = locationAccuracy;
    else if (locationAccuracy.doubleValue() < 0) this.locationAccuracy = 0.0;
    else this.locationAccuracy = locationAccuracy;
  }

  /**
   * @return Returns the locationAccuracy. Can be null.
   */
  public Double getLocationAccuracy() {
    return locationAccuracy;
  }

  /**
   * Method to set the locationAccuracyUnits.
   * @param aLocationAccuracyUnits This should be integere representing location.accuracy.type.enum
   */
  public void setLocationAccuracyUnits(int aLocationAccuracyUnits) throws Exception {
    if (locationAccuracyUnitsEnum == null || locationAccuracyUnitsEnum.getElement(aLocationAccuracyUnits) == null) {
      Exception ex = new Exception("Location accuracy units not found, units=" + locationAccuracyUnits);
      ex.fillInStackTrace();
      throw ex;
    }
    this.locationAccuracyUnits = aLocationAccuracyUnits;
  }

  /**
   * @return Returns the locationAccuracyUnits.
   */
  public int getLocationAccuracyUnits() {
    return locationAccuracyUnits;
  }

  /** Method to set location accuracy type.
   * @param aLocationAcquireType Should be a integer poinint to one of location.acquire.type.enum.
   */
  public void setLocationAcquireType(int aLocationAcquireType)  throws Exception {
    if (locationAcquireTypeEnum == null || locationAcquireTypeEnum.getElement(aLocationAcquireType) == null) {
      Exception ex = new Exception("Location acquire type not found, type=" + aLocationAcquireType);
      ex.fillInStackTrace();
      throw ex;
    }
    this.locationAcquireType = aLocationAcquireType;
  }

  /**
   * @return Returns the value of the location acquire type.
   */
  public int getLocationAcquireType() {
    return locationAcquireType;
  }

  /**
   * Method to set the locationAcquireTime.
   * @param locationAcquireTime
   */
  public void setLocationAcquireTime(Date locationAcquireTime) {
    this.locationAcquireTime = locationAcquireTime;
  }

  /**
   * @return Returns the value of locationAcquireTime. Can be null.
   */
  public Date getLocationAcquireTime() {
    return locationAcquireTime;
  }

  public void setRemoteHost(String remoteHost) {
    this.remoteHost = remoteHost;
  }

  public String getRemoteHost() {
    return remoteHost;
  }
  
  public String toString() {
    StringBuffer buf = new StringBuffer(100);
    buf.append("OAAMIPData [");
    buf.append("RemoteIP=" + remoteIP);
    buf.append(", ProxyIP=" + proxyIP);
    buf.append(", Longitude=" + longitude);
    buf.append(", Latitude=" + latitude);
    buf.append(", LocationAccuracy=" + locationAccuracy);
    buf.append(", LocationAccuracyUnits=" + locationAccuracyUnits);
    buf.append(", LocationAcquireType=" + locationAcquireType);
    buf.append(", LocationAcquireTime=" + locationAcquireTime);
    buf.append(", RemoteHost=" + remoteHost);
    buf.append("]");
    return buf.toString();
  }
}
