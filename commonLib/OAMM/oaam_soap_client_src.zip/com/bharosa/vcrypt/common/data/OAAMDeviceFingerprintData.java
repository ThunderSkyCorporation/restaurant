package com.bharosa.vcrypt.common.data;
/** Copyright (c) 2011, 2012, Oracle and/or its affiliates. 
All rights reserved. */

/**
 * This class encapsulates the Device FingerprintData and related attributes.
 * All the related attributes are members of this class.
 */


import com.bharosa.common.util.UserDefEnum;

import java.io.Serializable;


public class OAAMDeviceFingerprintData implements Serializable {

  static UserDefEnum ckTypeEnum = UserDefEnum.getEnum("vcrypt.fingerprint.type.enum");
  
  /**
   * String that represents the cookie.
   */
  protected String cookie;

  /**
   * String that represents the fingerprint.
   */
  protected String fingerprint;

  /**
   * The cookie type. (tracker.cookie.type.enum)
   */
  protected int cookieType;
    
  public OAAMDeviceFingerprintData(int cookieType, String fingerprint, String cookieValue) throws Exception {
    super();
    setFingerprint(fingerprint);
    setCookieType(cookieType);
    setCookie(cookieValue);
  }
  
  // todo : generate fingerprint methods 
    
  /**
   * Method to set the cookie.
   * @param cookie The cookie that is to be set.
   */
  public void setCookie(String cookie) {
    this.cookie = cookie;
  }

  /**
   * Method to set the cookie attribute of this class.
   * @return Value of the cookie. Can be null.
   */
  public String getCookie() {
    return cookie;
  }

  /**
   * Method to set the fingerprint.
   * @param Fingerprint fingerprint value to be set.
   */
  public void setFingerprint(String Fingerprint) {
    this.fingerprint = Fingerprint;
  }

  /**
   * 
   * @return Returns the value of fingerprint. Can be null.
   */
  public String getFingerprint() {
    return fingerprint;
  }

  /**
   * Method to set the cookie type. Usually set to some value in cookie.type.enum.
   * @param cookieType
   */
  public void setCookieType(int cookieType) throws Exception {
    if (ckTypeEnum == null || ckTypeEnum.getElement(cookieType) == null)
    {
      Exception ex = new Exception("Cookie type not found, cookieType=" + cookieType);
      ex.fillInStackTrace();
      throw ex;
    }
    this.cookieType = cookieType;
  }

  /**
   * @return Returns the integer value of cookie type.
   */
  public int getCookieType() {
    return cookieType;
  }
  
  public String toString() {
    StringBuffer buf = new StringBuffer(100);
    buf.append("OAAMDeviceFingerprintData [");
    buf.append("CookieType=" + cookieType);
    buf.append(", Fingerprint=" + fingerprint);
    buf.append(", Cookie=" + cookie);
    buf.append("]");
    return buf.toString();
  }
}
