/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

package com.bharosa.vcrypt.common.intf;

/**
 * Interface for all SOAP XML classes
 * 
 * @author Kuldeep Shah <kuldeep@nvsoft.com>
 *
 */
public interface VCryptXMLIntf {

	/**
	 * Executes implementation based on the XML request on the server side.
	 * 
	 * @param request
	 * @param xmlParameter
	 * @return
	 */
	public String execute(final String request, final String xmlParameter) ;
}
