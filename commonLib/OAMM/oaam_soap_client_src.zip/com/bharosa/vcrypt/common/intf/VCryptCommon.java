package com.bharosa.vcrypt.common.intf;

import com.bharosa.vcrypt.common.util.VCryptBooleanResponse;
import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.common.util.VCryptStringArrayResponse;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * This provides the common interfaces which are used by all VCrypt products.  List methods do not work for Alert lists.
 *
 * @author bosco
 */

public interface VCryptCommon {

	String REQ_LIST_ELEMENTS = "getListElements";
	String REQ_LIST_BY_TYPE = "getListsByType";
	String REQ_UPDATE_LIST ="updateList";
    String REQ_IS_ELEMENT_IN_LIST = "isElementInList";
    String REQ_CREATE_LIST = "createList";


    /**
     * This is used to check if the server is up and running.
     * @param clientName Name of the client which is calling the server
     * @param clientTimeStamp Time stamp on the client
     * @param nvList List of generic name value list sent to the server.
     * @return Response from the server
     */
    //public VCryptResponse ping(  String clientName, Date clientTimeStamp, Map nvList );

    /**
	 * Get list of members of a group
   * Alert group list is not supported.
	 *
	 * @param requestId Request Identifier
	 * @param listName	Name of the list
	 * @return VCryptGetListsResponse
	 */
	public VCryptStringArrayResponse getListElements(String requestId, String listName);

	/**
	 * Get a list of groups given a group type
	 *
	 * @param requestId Request Identifier
	 * @param listType	list type
	 * @return VCryptGetListsResponse
	 */
	public VCryptStringArrayResponse getLists(String requestId, int listType);

	/**
	 * Updates given list with new elements.
	 * List name should be an existing.
	 * Duplicate and invalid elements in elementsToAdd are ignored.
	 * Non-existing and invalid elements in elementsToRemove are ignored.
   * Update of alert group list is not supported.
	 *
	 * @param requestId Request Identifier
	 * @param listName Name of the list, an existing list.
	 * @param elementsToAdd elements to be added to list
	 * @param elementsToRemove elements to remove from the list
	 * @return VCryptResponse
	 */
	public VCryptResponse updateList(String requestId, String listName, String[] elementsToAdd, String[] elementsToRemove);


    /**
     * This checks whether the element given is in the list.
     * Checks of elements in alert group list are not supported.
     * @param requestId Request Identifier
     * @param listName Name of the list
     * @param elementValue Value of the element to look for. This will be converted to appropriate native type before
     * search.
     * @return Response object with the response value and response status
     */
    public VCryptBooleanResponse isElementInList( String requestId, String listName, String elementValue );

    /**
     * Creates a new List of the give list type
     *
     * @param requestId Request Id
     * @param listName  Name of the list
     * @param listType  Type of the list
     * @return VCryptResponse with the result
     */
    public VCryptResponse createList(String requestId, String listName, int listType);

}
