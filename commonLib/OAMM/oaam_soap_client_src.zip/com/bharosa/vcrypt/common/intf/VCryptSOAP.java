package com.bharosa.vcrypt.common.intf;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */


/**
 * This provides a generic interface to make SOAP calls. The implementations
 * of this class will be specific to the WebSerivces library that is going to
 * be used.
 * @author bosco
 */

public interface VCryptSOAP {

	/**
	 * Generic method to invoke any soap request
	 *
	 * @param requestName name of the request
	 * @param xmlParameter the parameter in the form of string
	 * @return the result in XML format
	 */
	public String execute( String requestName, String xmlParameter );

}
