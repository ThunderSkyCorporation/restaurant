package com.bharosa.vcrypt.servlet.tracker;

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.common.util.UserDefEnum;
import com.bharosa.vcrypt.common.util.VCryptBooleanResponse;
import com.bharosa.vcrypt.common.util.VCryptServletUtil;
import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.tracker.intf.VCryptRulesEngine;
import com.bharosa.vcrypt.tracker.intf.VCryptRulesResult;
import com.bharosa.vcrypt.tracker.intf.VCryptTracker;
import com.bharosa.vcrypt.tracker.util.CookieSet;
import com.bharosa.vcrypt.tracker.util.VCryptTrackerUtil;
import com.bharosa.common.logger.Logger;

import com.bharosa.common.util.FileUtil;
import com.bharosa.common.util.HttpUtil;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.*;

/**
 * This contains the utility methods for tracker operations, which can be called from jsp pages or servlets.
 *
 * @author bosco
 */
public class VCryptServletTrackerUtil {

    static Logger logger = Logger.getLogger(VCryptServletTrackerUtil.class);

    static Object lock = new Object();
    static boolean initDone = false;

    static VCryptTracker tracker = null;
    static VCryptRulesEngine rulesEngine = null;

    /**
     * This method returns the Tracker interface.
     */
    static public VCryptTracker getTrackerInterface(HttpServletRequest request) {
        return getTrackerInterface();
    }

    /**
     * This method returns the Tracker interface.
     */
    static public VCryptTracker getTrackerInterface() {
        if (tracker == null || !initDone) {
            synchronized (lock) {
                initDone = false;
                if (tracker == null) {
                    if (logger.isDebugEnabled()) logger.debug("Creating new instance of VCryptTracker");
                    tracker = VCryptTrackerUtil.getVCryptTrackerInstance();
                }
                initDone = true;
            }
        }
        return tracker;
    }

    /**
     * This method returns the VCryptRulesEngine interface.
     */
    static public VCryptRulesEngine getRulesEngineInterface() {
        if (rulesEngine != null) {
            return rulesEngine;
        }
        synchronized (lock) {
            if (rulesEngine == null) {
                if (logger.isDebugEnabled()) logger.debug("Creating new instance of VCryptRulesEngine");
                rulesEngine = VCryptTrackerUtil.getVCryptRulesEngineInstance();
            }
        }
        return rulesEngine;
    }

    static public String handleFingerPrintCall(HttpServletRequest request,
                                               HttpServletResponse response) {
        String secureCookie = VCryptServletTrackerUtil.getSecureCookie(request);

        int secureCookieClientType =
                UserDefEnum.getElementValue("auth.client.type.enum", "normal");
        String digitalCookie = null;
        int digitalCookieClientType = secureCookieClientType;

        CookieSet cs
                = VCryptServletTrackerUtil.handleTrackerRequest(request, secureCookie,
                secureCookieClientType,
                "1.0", digitalCookie,
                digitalCookieClientType,
                "1.0");

        if (cs == null) {
            //got null cookie set. Nothing we can do here..
            if (logger.isDebugEnabled()) {
                logger.debug("Got null CookieSet from tracker.handleTrackerRequest(). No cookies to be set, some other request has already set it");
            }
            //be carefull using cs object below, we are not returning from here.
        }

        if (cs != null) {
            if (logger.isDebugEnabled()) logger.debug("Setting secure cookie=" + cs.getSecureCookie());
            VCryptServletTrackerUtil.updateSecureCookie(response, cs);
            return cs.getRequestId();
        }
        return null;
    }

    static public String handleFingerPrintDevice(HttpServletRequest request,
                                                 HttpServletResponse response) {
        String returnDigitalCookie = null;
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("fingerPrintDevice() entered: request.getQueryString()="
                        + request.getQueryString());
            }

            String client = request.getParameter("client");
            if (logger.isDebugEnabled()) logger.debug("Client request is: " + client);

            String secureCookie;
            String digitalCookie = request.getParameter("v");
            if (digitalCookie != null) {
                digitalCookie = digitalCookie.trim();
            }
            if (logger.isDebugEnabled()) logger.debug("Got digitalCookie=" + digitalCookie);

            secureCookie = VCryptServletTrackerUtil.getSecureCookie(request);

            int secureCookieClientType =
                    UserDefEnum.getElementValue("auth.client.type.enum", "image_tracker");
            int digitalCookieClientType =
                    UserDefEnum.getElementValue("auth.client.type.enum", "flash_tracker");

            if (client != null && client.equals("vfc")) {
                secureCookieClientType = digitalCookieClientType;
            }

            CookieSet cs
                    = VCryptServletTrackerUtil.handleTrackerRequest(request, secureCookie,
                    secureCookieClientType,
                    "1.0", digitalCookie,
                    digitalCookieClientType,
                    "1.0");
            if (cs == null) {
                //got null cookie set. Nothing we can do here..
                if (logger.isDebugEnabled()) {
                    logger.debug("Got null CookieSet from tracker.handleTrackerRequest(). No cookies to be set, some other request has already set it");
                }
                //be carefull using cs object below, we are not returning from here.
            }

            if (cs != null) {
                if (logger.isDebugEnabled()) logger.debug("Setting secure cookie=" + cs.getSecureCookie());
                VCryptServletTrackerUtil.updateSecureCookie(response, cs);
                returnDigitalCookie = cs.getDigitalCookie();
            }

            if (client == null) { //assume it's an html cookie
                //do nothing
            } else if (client.equals("vfc")) {
                if (!request.isSecure()) {
                    response.setHeader("Cache-Control", "no-cache"); //HTTP 1.1
                    response.setHeader("Pragma", "no-cache"); //HTTP 1.0
                    response.setHeader("Cache-Control", "no-store");
                    response.setDateHeader("Expires", 0); //prevents caching at the proxy server
                }
                PrintWriter out = response.getWriter();
                if (cs != null) {
                    if (logger.isDebugEnabled())
                        logger.debug("Request from flash:New flash cookie=" + cs.getDigitalCookie());
                    out.println("&v=" + cs.getDigitalCookie());
                }
                out.close();

            } else if (client.equals("vsc")) {
                if (logger.isDebugEnabled()) logger.debug("Request for image");
                InputStream ruleStream = null;
                OutputStream os = null;
                BufferedInputStream imageStream = null;
                try {
                    String imageName = BharosaConfig.get("vcrypt.tracker.secureCookie.imageName");
                    if (logger.isDebugEnabled()) logger.debug("Got image name from properties: " + imageName);

                    String contentType = BharosaConfig.get("vcrypt.tracker.secureCookie.imageContentType");
                    if (logger.isDebugEnabled()) logger.debug("Got image content type: " + contentType);

                    ruleStream = VCryptServletTrackerUtil.class.getResourceAsStream(imageName);
                    imageStream = new BufferedInputStream(ruleStream);

                    byte[] input = new byte[1024];

                    response.setContentType("image/png");
                    response.setHeader("Cache-Control", "no-cache"); //HTTP 1.1
                    response.setHeader("Pragma", "no-cache"); //HTTP 1.0
                    response.setHeader("Cache-Control", "no-store");
                    response.setDateHeader("Expires", 0); //prevents caching at the proxy server

                    os = response.getOutputStream();

                    while (imageStream.available() > 0) {
                        if (logger.isDebugEnabled()) logger.debug("Reading from input...");
                        imageStream.read(input);
                        if (logger.isDebugEnabled()) logger.debug("Writing to output...");
                        os.write(input);
                    }
                    if (logger.isDebugEnabled()) logger.debug("Done writing to output stream.");
                } catch (Exception e2) {
                    logger.error("Image request caused exception", e2);
                } finally {
                  FileUtil.closeStream(imageStream);
                  FileUtil.closeStream(ruleStream);
                  FileUtil.closeStream(os);
                }
            }
        } catch (Exception ex) {
            logger.error("Caught exception while finger printing", ex);
        }
        return returnDigitalCookie;
    }


    static public String getFlashData(HttpServletRequest request) {
        Object flashFingerPrintArr[] = VCryptServletUtil.getFlashFingerPrint(request);
        return (String) flashFingerPrintArr[1];
    }

    static public String getFlashCookie(HttpServletRequest request) {
        String digitalCookie = request.getParameter("v");
        if (digitalCookie != null) {
            digitalCookie = digitalCookie.trim();
        }
        return digitalCookie;
    }

    static public String getSecureCookie(HttpServletRequest request) {
        String secureCookie = null;
        // Kuldeep : Added code in try block to make sure
        // that because of Exception in request.getCookies()
        // we are not skipping the request.
        try {
            Cookie[] cookies = request.getCookies();
            if (cookies != null) {
                String secureCookieName = BharosaConfig.get("oaam.secure.cookie.name", "vsc");
                //get secure cookie
                for (int i = 0; i < cookies.length; i++) {
                  if (cookies[i].getName().equals("vsc")) {
                      secureCookie = cookies[i].getValue().trim();
                      if (logger.isDebugEnabled()) logger.debug("Got vsc secureCookie=" + secureCookie);
                      // Backwards compatibility, capture legacy cookie if found but continue to look for new cookie.
                  }
                  if (cookies[i].getName().equals(secureCookieName)) {
                      secureCookie = cookies[i].getValue().trim();
                      if (logger.isDebugEnabled()) logger.debug("Got " + secureCookieName + " secureCookie=" + secureCookie);
                      break;
                  }
                }
            }
        } catch (Exception e) {
            logger.error("Exception while retrieving Secure Cookie String from HTTP Request."
                    + " This Exception would be ignored and null secure cookie would be returned"
                    + " Error Message [" + e.getMessage() + "]");
        }
        return secureCookie;
    }

    static public void updateSecureCookie(HttpServletResponse response, CookieSet cookieSet) {
        if (cookieSet != null) {
            // Kuldeep : Added code in try block to make sure
            // that because of Exception in request.addCookie()
            // we are not skipping the request.
            try {
                //default 1 year
                int maxage = BharosaConfig.getInt("vcrypt.tracker.secureCookie.maxage", 31536000);
                String secureCookieName = BharosaConfig.get("oaam.secure.cookie.name", "vsc");
                Cookie sc = new Cookie(secureCookieName, cookieSet.getSecureCookie());
                sc.setMaxAge(maxage);
                
                String cookiePath = BharosaConfig.get("oaam.secure.cookie.path");
                if (!StringUtil.isEmpty(cookiePath)){
                	sc.setPath(cookiePath);
                }
                
                String cookieDomain = BharosaConfig.get("oaam.secure.cookie.domain");
                if (!StringUtil.isEmpty(cookieDomain)){
                	sc.setDomain(cookieDomain);
                }
                
                HttpUtil.setCookie(response, sc);
            } catch (Exception e) {
                logger.error("Exception while updating Secure Cookie String from HTTP Request."
                        + " This Exception would be ignored and null secure cookie would be returned"
                        + " Error Message [" + e.getMessage() + "]");
            }
        }
    }

    /**
     * Describe <code>handleTrackerRequest</code> method here.
     *
     * @param request              a <code>HttpServletRequest</code> value
     * @param secureCookie         The secure cookie
     * @param secureClientType     secure cookie client type
     * @param secureClientVersion  version of the secure cookie client
     * @param digitalSigCookie     The digital signature cookie
     * @param digitalClientType    digital cookie client type
     * @param digitalClientVersion version of the digital cookie client
     * @return a <code>CookieSet</code> value
     */
    static public CookieSet handleTrackerRequest(HttpServletRequest request, String secureCookie,
                                                 int secureClientType, String secureClientVersion,
                                                 String digitalSigCookie, int digitalClientType,
                                                 String digitalClientVersion) {
        try {
            if (logger.isDebugEnabled()) logger.debug("handleTrackerRequest secureCookie=" + secureCookie
                    + ", secureClientType=" + secureClientType
                    + ", secureClientVersion=" + secureClientVersion
                    + ", digitalSigCookie=" + digitalSigCookie
                    + ", digitalClientType=" + digitalClientType
                    + ", digitalClientVersion=" + digitalClientVersion);

            String ip = VCryptServletUtil.getRemoteIP(request);
            String host = request.getRemoteHost();
            String requestId = VCryptServletUtil.getRequestId(request);

            Object fingerPrintArr[] = VCryptServletUtil.getBrowserFingerPrint(request);
            Object flashFingerPrintArr[] = VCryptServletUtil.getFlashFingerPrint(request);

            CookieSet cookieSet = null;
            VCryptTracker vcryptTracker = getTrackerInterface(request);
            if (vcryptTracker != null) {
                cookieSet = vcryptTracker.handleTrackerRequest(requestId, ip, host,
                        secureCookie, secureClientType,
                        secureClientVersion, digitalSigCookie,
                        digitalClientType, digitalClientVersion,
                        ((Integer) fingerPrintArr[0]).intValue(),
                        (String) fingerPrintArr[1],
                        ((Integer) flashFingerPrintArr[0]).intValue(),
                        (String) flashFingerPrintArr[1]);
            } else {
                logger.error("vcryptTracker is null. handleTrackerRequest() secureCookie=" + secureCookie
                        + ", secureClientType=" + secureClientType
                        + ", secureClientVersion=" + secureClientVersion
                        + ", digitalSigCookie=" + digitalSigCookie
                        + ", digitalClientType=" + digitalClientType
                        + ", digitalClientVersion=" + digitalClientVersion);
            }

            //Please ignore, this ia a hack, for testing non authenticating site.
            if (BharosaConfig.getBoolean("vcrypt.tracker.update.auth.result.on.fingerprint", false)) {
                if (logger.isDebugEnabled()) logger.debug("Force updateLog...");
                String groupId = null;
                String userId = null;
                String loginId = VCryptServletUtil.getRemoteIP(request);
                int result = UserDefEnum.getElementValue("auth.status.enum", "success");
                boolean isSecure = true;
                vcryptTracker.updateLog(requestId, ip, host, secureCookie, digitalSigCookie,
                        groupId, userId, loginId, isSecure, result,
                        secureClientType, secureClientVersion,
                        ((Integer) fingerPrintArr[0]).intValue(),
                        (String) fingerPrintArr[1],
                        ((Integer) flashFingerPrintArr[0]).intValue(),
                        (String) flashFingerPrintArr[1]);
            }
            return cookieSet;
        } catch (Exception ex) {
            logger.error("Caught exception in  handleTrackerRequest() secureCookie=" + secureCookie
                    + ", secureClientType=" + secureClientType
                    + ", secureClientVersion=" + secureClientVersion
                    + ", digitalSigCookie=" + digitalSigCookie
                    + ", digitalClientType=" + digitalClientType
                    + ", digitalClientVersion=" + digitalClientVersion, ex);
        }
        return null;
    }

    static public void updateAuthStatus(HttpServletRequest request, int result, int clientType, String clientVersion) {

        String requestId = VCryptServletUtil.getRequestId(request);
        try {
            if (logger.isDebugEnabled()) logger.debug("updateAuthStatus( requestId=" + requestId
                    + ", result=" + result + ", clientType="
                    + clientType + ", clientVersion=" + clientVersion);

            VCryptTracker vcryptTracker = getTrackerInterface(request);
            if (vcryptTracker != null && requestId != null) {
                VCryptResponse apiResponse = vcryptTracker.updateAuthStatus(requestId, result,
                        clientType, clientVersion);
                if (apiResponse == null || !apiResponse.isSuccess()) {
                    logger.error("Error updateAuthStatus( requestId=" + requestId
                            + ", result=" + result + ", clientType="
                            + clientType + ", clientVersion=" + clientVersion + ", response=" + apiResponse);
                }

            } else {
                logger.error("Error updateAuthStatus( requestId=" + requestId
                        + ", result=" + result + ", clientType="
                        + clientType + ", clientVersion=" + clientVersion);
            }
        } catch (Exception ex) {
            logger.error("Error updateAuthStatus( requestId=" + requestId
                    + ", result=" + result + ", clientType="
                    + clientType + ", clientVersion=" + clientVersion, ex);
        }
    }

    /**
     * This method updates the tracker log with the authentication result.
     *
     * @param request       Servlet request
     * @param response      a <code>HttpServletResponse</code> value
     * @param userId        The userId used by the system.
     * @param loginId       The loginId of the user
     * @param isSecure      whether this node is secure and can be registered
     * @param result        The result of the authentication
     * @param clientType    an <code>int</code> value
     * @param clientVersion a <code>String</code> value
     */
    static public void updateAuthResult(HttpServletRequest request, HttpServletResponse response,
                                        String userId, String loginId, boolean isSecure, int result,
                                        int clientType, String clientVersion) {
        String groupId = null;
        updateAuthResult(request, response, groupId, userId, loginId, isSecure, result, clientType, clientVersion);
    }


    /**
     * This method updates the tracker log with the authentication result.
     *
     * @param request  Servlet request
     * @param groupId  The group Id of the user
     * @param userId   The userId used by the system.
     * @param loginId  The loginId of the user
     * @param isSecure whether this node is secure and can be registered
     * @param result   The result of the authentication
     */
    static public void updateAuthResult(HttpServletRequest request, HttpServletResponse response,
                                        String groupId, String userId,
                                        String loginId, boolean isSecure, int result, int clientType, String clientVersion) {

        String requestId = VCryptServletUtil.getRequestId(request);
        try {
            if (logger.isDebugEnabled()) logger.debug("updateAuthResult( requestId=" + requestId
                    + ", groupId=" + groupId
                    + ", userId=" + userId + ", loginId=" +
                    loginId + ", isSecure=" + isSecure + ", result=" + result + ", clientType="
                    + clientType + ", clientVersion=" + clientVersion);

            String ip = VCryptServletUtil.getRemoteIP(request);
            String host = request.getRemoteHost();

            Object fingerPrintArr[] = VCryptServletUtil. getBrowserFingerPrint(request);
            String secureCookie = getSecureCookie(request);
            VCryptTracker vcryptTracker = getTrackerInterface(request);
            if (vcryptTracker != null) {
                CookieSet cookieSet = vcryptTracker.updateLog(requestId, ip, host, secureCookie, null,
                        groupId, userId, loginId, isSecure, result,
                        clientType, clientVersion,
                        ((Integer) fingerPrintArr[0]).intValue(),
                        (String) fingerPrintArr[1],
                        VCryptServletUtil.digitalFPType.intValue(),
                        null);
                if (cookieSet != null) {
                    if (logger.isDebugEnabled())
                        logger.debug("updateAuthResult() is updating the secure cookies. secureCookie=" + cookieSet.getSecureCookie());
                    updateSecureCookie(response, cookieSet);
                }
            } else {
                logger.error("Can't get vcryptTracker. updateAuthResult( requestId=" + requestId
                        + ", groupId=" + groupId
                        + ", userId=" + userId + ", loginId=" +
                        loginId + ", result=" + result + ", clientType="
                        + clientType + ", clientVersion=" + clientVersion);
            }
        } catch (Exception ex) {
            logger.error("Caught exception updateAuthResult( requestId=" + requestId
                    + ", groupId=" + groupId
                    + ", userId=" + userId + ", loginId=" +
                    loginId + ", result=" + result + ", clientType="
                    + clientType + ", clientVersion=" + clientVersion, ex);
        }
    }


    public static boolean markDeviceSafe(HttpServletRequest request, boolean isSafe) {
        //Make the call to the server
        String requestId = VCryptServletUtil.getRequestId(request);
        return markDeviceSafe(requestId, isSafe);
    }
    
    public static boolean markDeviceSafe(String requestId, boolean isSafe) {
        boolean retVal = false;
    	try {
            if (logger.isDebugEnabled()) logger.debug("markDeviceSafe( requestId=" + requestId
                    + ", isSafe=" + isSafe);
            VCryptTracker vcryptTracker = getTrackerInterface();
            if (vcryptTracker != null) {
                retVal = vcryptTracker.markDeviceSafe(requestId, isSafe);
            } else {
                logger.error("Can't get vcryptTracker. markDeviceSafe( requestId=" + requestId
                        + ", isSafe=" + isSafe);
            }
        } catch (Exception ex) {
            logger.error("Caught exception markDeviceSafe( requestId=" + requestId
                    + ", isSafe=" + isSafe, ex);
        }
        return retVal;
    }

    public static boolean clearSafeDeviceList(HttpServletRequest request) {
        String requestId = VCryptServletUtil.getRequestId(request);
        return clearSafeDeviceList(requestId);
    }

    public static boolean clearSafeDeviceList(String requestId) {
        boolean retVal = false;
        VCryptResponse ret = null;
        try {
            if (logger.isDebugEnabled()) logger.debug("clearSafeDeviceList( requestId=" + requestId);
            VCryptTracker vcryptTracker = getTrackerInterface();
            if (vcryptTracker != null) {
                ret = vcryptTracker.clearSafeDeviceList(requestId);
                if (ret != null && ret.isSuccess()){
                	retVal = true;
                }
            } else {
                logger.error("Can't get vcryptTracker. clearSafeDeviceList( requestId=" + requestId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception clearSafeDeviceList( requestId=" + requestId, ex);
        }
        return retVal;
    }

    public static boolean isDeviceMarkedSafe(HttpServletRequest request) {
        //Make the call to the server
        String requestId = VCryptServletUtil.getRequestId(request);
        return isDeviceMarkedSafe(requestId);
    }

    public static boolean isDeviceMarkedSafe(String requestId) {
        boolean retVal = false;
        VCryptBooleanResponse ret = null;
        try {
            if (logger.isDebugEnabled()) logger.debug("isDeviceMarkedSafe( requestId=" + requestId);
            VCryptTracker vcryptTracker = getTrackerInterface();
            if (vcryptTracker != null) {
                ret = vcryptTracker.IsDeviceMarkedSafe(requestId);
                if (ret != null && ret.getValue()){
                	retVal = true;
                }
            } else {
                logger.error("Can't get vcryptTracker. isDeviceMarkedSafe( requestId=" + requestId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception isDeviceMarkedSafe( requestId=" + requestId, ex);
        }
        return retVal;
    }

    /**
     * This method runs the rule set specified for the user attempting to log in. It is intended to be placed
     * pre-authentication.
     *
     * @return a VCryptRulesResult object containing all actions and alerts that were activated
     */
    public static VCryptRulesResult runPreAuthRules(HttpServletRequest request) {
        String requestId = VCryptServletUtil.getRequestId(request);
        return runPreAuthRules(requestId);
    }

    /**
     * This method runs the rule set specified for the user attempting to log in. It is intended to be placed
     * pre-authentication.
     *
     * @return a VCryptRulesResult object containing all actions and alerts that were activated
     */
    public static VCryptRulesResult runPreAuthRules(String requestId) {
        if (logger.isDebugEnabled()) logger.debug("runPreAuthRules(requestId=" + requestId + ")");

        UserDefEnum profileTypeEnum = UserDefEnum.getEnum("profile.type.enum");

        ArrayList profileTypes = new ArrayList();
        profileTypes.add(new Integer(profileTypeEnum.getElementValue("preauth")));
        return runRuleSets(requestId, profileTypes);
    }


    /**
     * This method runs the rule set specified for the user attempting to log in. It is intended to be placed
     * post-authentication.
     *
     * @return a VCryptRulesResult object containing all actions and alerts that were activated
     */
    public static VCryptRulesResult runPostAuthRules(HttpServletRequest request) {
        String requestId = VCryptServletUtil.getRequestId(request);
        return runPostAuthRules(requestId);
    }

    /**
     * This method runs the rule set specified for the user attempting to log in. It is intended to be placed
     * post-authentication.
     *
     * @return a VCryptRulesResult object containing all actions and alerts that were activated
     */
    public static VCryptRulesResult runPostAuthRules(String requestId) {
        if (logger.isDebugEnabled()) logger.debug("runPostAuthRules(requestId=" + requestId + ")");

        UserDefEnum profileTypeEnum = UserDefEnum.getEnum("profile.type.enum");

        ArrayList profileTypes = new ArrayList();
        profileTypes.add(new Integer(profileTypeEnum.getElementValue("postauth")));
        return runRuleSets(requestId, profileTypes);
    }

    /**
     * This method runs the rules for the given profile type (will be runtime)
     * <p/>
     * This can support all types rules, including in session rules. Creates context map (key-value) based on request
     * parameters. Mostly in session rules operate on the context map.
     *
     * @return a VCryptRulesResult object containing all actions and alerts that were activated
     * @since 3.0
     */
    public static VCryptRulesResult runRules(final HttpServletRequest request, final String[] profileType) {

        if (profileType == null || profileType.length == 0) {
            logger.debug("No profile types specified");
            return null;
        }

        String requestId = VCryptServletUtil.getRequestId(request);
        if (logger.isDebugEnabled())
            logger.debug("requestId [" + requestId + "]");

        // Create a map of request param and values.
        // Note: Currenlty doesn't support multiple values for the parameters.
        Enumeration thisenum = request.getParameterNames();
        Map contextMap = new HashMap();
        while (thisenum.hasMoreElements()) {
            String key = (String) thisenum.nextElement();
            String value = request.getParameter(key);
            contextMap.put(key, value);
        }

        // Profile type look up.
        // Assumption is all user supplied types are valid. There needs to be type safe enumeration
        // or exception handling to support this.
        UserDefEnum profileTypeEnum = UserDefEnum.getEnum("profile.type.enum");
        ArrayList profileTypes = new ArrayList(profileType.length);
        for (int i = 0; i < profileType.length; i++) {
            String profile = profileType[i];
            int elementValue = profileTypeEnum.getElementValue(profile);
            if (elementValue == -1) {
                logger.warn("Invalid profile type [" + profile + "]");
            } else {
                profileTypes.add(new Integer(elementValue));
            }
        }

        return runRuleSets(requestId, profileTypes, contextMap);
    }

    public static VCryptRulesResult runRuleSets(String requestId, List profileTypes) {
        return runRuleSets(requestId, profileTypes, null);
    }

    public static VCryptRulesResult runRuleSets(String requestId, List profileTypes, Map contextMap) {
        if (logger.isDebugEnabled()) logger.debug("In runRuleSets");

        boolean rulesDisabled = BharosaConfig.getBoolean("vcrypt.tracker.rule.disable", false);
        if (rulesDisabled) {
            if (logger.isDebugEnabled()) logger.debug("runRuleSets() all rules disabled");
            return null;
        }
        if (requestId == null) {
            logger.error("requestId is null, that means updateLog or handleRequest had not yet called");
            return null;
        }

        // by passing strings, we can allow the end-user to pass rule types
        VCryptRulesEngine rulesEngine = getRulesEngineInterface();
        if (rulesEngine != null) {
            VCryptRulesResult ruleResult
                    = rulesEngine.processRules(requestId, profileTypes, contextMap);
            if (ruleResult == null) {
                logger.error("runPostAuthRules() null ruleResult for requestId="
                        + requestId);
            } else {
                if (logger.isDebugEnabled()) {
                    if (ruleResult.getAllActions() != null) {
                        logger.debug("Dumping actions for requestId=" + requestId);
                        Iterator iter = ruleResult.getAllActions().iterator();
                        while (iter.hasNext()) {
                            logger.debug("action=" + iter.next().toString());
                        }
                        logger.debug(". Score=" + ruleResult.getScore());
                    }
                }
            }
            return ruleResult;
        } else {
            logger.error("Can not get rule engine.");
            return null;
        }
    }
}
