package com.bharosa.vcrypt.servlet.auth;
/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.*;

import java.io.File;
import java.io.OutputStream;

import java.awt.image.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;

import com.bharosa.common.util.UserDefEnum;

import com.bharosa.vcrypt.common.util.VCryptServletUtil;

import com.bharosa.vcrypt.auth.util.VCryptAuthUtil;
import com.bharosa.vcrypt.auth.intf.VCryptAuth;
import com.bharosa.vcrypt.auth.intf.VCryptAuthResult;
import com.bharosa.vcrypt.auth.intf.VCryptAuthUser;
import com.bharosa.vcrypt.auth.intf.VCryptWheel;
import com.bharosa.vcrypt.auth.intf.VCryptQuestion;
import com.bharosa.vcrypt.auth.keypad.AuthentiConfig;
import com.bharosa.vcrypt.auth.keypad.AuthentiPad;
import com.bharosa.vcrypt.auth.keypad.KeyPadUtil;

import com.bharosa.common.util.BharosaConfig;

import com.bharosa.common.logger.Logger;

/**
This utility class provides a set of methods which provide an easy way to implement the
Bharosa Authenticator api.
*/
public class VCryptServletAuthUtil{

	static Logger logger = Logger.getLogger(VCryptServletAuthUtil.class);

	static Object lock = new Object();
	static boolean initDone = false;

	static VCryptAuth auth = null;

	/**
	 * This method returns the Auth interface.
	 */
	static public VCryptAuth getVCryptAuthInstance( HttpServletRequest request ) {
		if( auth == null || !initDone ) {
			synchronized( lock ) {
				initDone = false;
				if( auth == null ) {
					if(logger.isDebugEnabled()) logger.debug("Creating new instance of VCryptAuth");
					auth = VCryptAuthUtil.getVCryptAuthInstance();
				}
				initDone = true;
			}
		}
		return auth;
	}

	static public void resetAuthSessions( HttpServletRequest request ) {
		try {
			//Get the HTTP session, if required, create a new one.
			HttpSession session = request.getSession(true);

			//Lets reset all the session attributes
			session.removeAttribute("vcrypt_prev_session_id");
		} catch( Exception ex ) {
			logger.error("Exception in resetAuthSessions()", ex );
		}
	}


	/**
	 * This return the user details and preferences with out the password
	 * and pin.
	 *
	 * @param customerId a <code>String</code> value
	 * @return a <code>VCryptAuthUser</code> value
	 */
	static public VCryptAuthUser getUser( HttpServletRequest request, String customerId ) {
		try {
			VCryptAuth auth = getVCryptAuthInstance( request );
			return auth.getUser(customerId );
		} catch( Exception ex ) {
			logger.error("Caught exception getUser() customerId=" + customerId, ex );
		}
		return null;
	}

	/**
	 * This sets the given users password.
	 *
	 * @param loginId a <code>String</code> value
	 * @return a <code>VCryptAuthUser</code> value
	 */
	static public boolean setPassword( HttpServletRequest request, String loginId,
									   String newPassword, int passwordStatus ) {
		try {
			VCryptAuth auth = getVCryptAuthInstance( request );
			return auth.setPassword(loginId, newPassword, passwordStatus );
		} catch( Exception ex ) {
			logger.error("Caught exception setPassword() loginId=" + loginId, ex );
		}

		if (logger.isDebugEnabled()) logger.debug("Returning default value");
		return false;
	}

	/**
	 * This sets the given users pin.
	 *
	 * @param customerId a <code>String</code> value
	 * @return a <code>VCryptAuthUser</code> value
	 */
	static public boolean setPIN(HttpServletRequest request, String customerId,
								 String newPin, int pinStatus ) {
		try {
			VCryptAuth auth = getVCryptAuthInstance( request );
			return auth.setPIN(customerId, newPin, pinStatus );
		} catch( Exception ex ) {
			logger.error("Caught exception setPin() customerId=" + customerId, ex );
		}

		if (logger.isDebugEnabled()) logger.debug("Returning default value");
		return false;
	}

	/**
	 * Describe <code>authenticatePassword</code> method here.
	 *
	 * @param request a <code>HttpServletRequest</code> value
	 * @param authSessionType Reason for authentication
	 * @param clientType Client type used.
	 * @param clientVersion Client version
	 * @return a <code>VCryptAuthResult</code> value
	 */
	static public VCryptAuthResult authenticatePassword(HttpServletRequest request,
														String customerId,
														String password,
														int authSessionType,
														int clientType,
														String clientVersion){
		try {
			if(logger.isDebugEnabled()) logger.debug("authenticatePassword() customerId=" + customerId
						 + ", authSessionType=" + authSessionType
						 + ", clientType=" + clientType + ", clientVersion="
						 + clientVersion);

			if( customerId == null || customerId.trim().length() == 0 ) {
				logger.info("authenticatePassword() customerId is empty");
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","wrong_password" ));
			}
			customerId = customerId.trim();

			if( password == null || password.trim().length() == 0 ) {
				logger.info("authenticatePassword() password is empty for customerId=" + customerId);
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","wrong_password" ));
			}
			password = password.trim();


			HttpSession session = request.getSession(true);

			VCryptAuth auth = getVCryptAuthInstance( request );
			if ( auth == null) {
				logger.error("authenticatePassword() VCryptAuth can't be created. customerId=" + customerId
							 + ", authSessionType=" + authSessionType
							 + ", clientType=" + clientType + ", clientVersion="
							 + clientVersion);
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","system_error" ));
			}


			Object fingerPrintArr[] = VCryptServletUtil. getBrowserFingerPrint( request );

			VCryptAuthResult result = auth.authenticatePassword(customerId, password, authSessionType,
																clientType, clientVersion,
																VCryptServletUtil.getRemoteIP(request),
			((Integer)fingerPrintArr[0]).intValue(),
		    (String) fingerPrintArr[1]);

			if( result != null ) {
				session.setAttribute("vcrypt_prev_session_id", result.getAuthSessionId() );
				if(logger.isDebugEnabled()) logger.debug("Authentication result for customerId=" + customerId
							 + ", result="
							 + UserDefEnum.getElementName("auth.status.enum",result.getCode())
							 + ", authSessionId=" + result.getAuthSessionId());

			} else {
				logger.error("got null result: authenticatePassword() customerId=" + customerId
							 + ", authSessionType=" + authSessionType
							 + ", clientType=" + clientType + ", clientVersion="
							 + clientVersion);
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","system_error" ));
			}

			return result;
		} catch( Exception ex ) {
			logger.error("Caught exception: customerId=" + customerId
						 + ", authSessionType=" + authSessionType
						 + ", clientType=" + clientType + ", clientVersion="
						 + clientVersion, ex );
			return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","system_error" ));
		}
	}



	/**
	 * Generates a new wheel.
	 *
	 * @param request the <code>HttpServletRequest</code> object
	 * @param length the length of the wheel
	 * @param sets the number of set of wheels to be generated
	 * @param authSessionType what type of authentication is this.
	 * @param clientType the client type
	 * @param clientVersion the client version
	 * @return a <code>String</code> value
	 */
	static public String genWheel(HttpServletRequest request, int length, int sets,
								  int authSessionType, int clientType,
								  String clientVersion ) {
		try {
			if(logger.isDebugEnabled()) logger.debug("genWheel() length=" + length + ", sets=" + sets
						 + ", authSessionType=" + authSessionType
						 + ", clientType=" + clientType + ", clientVersion="
						 + clientVersion );

			HttpSession session = request.getSession(true);

			VCryptAuth auth = getVCryptAuthInstance( request );
			if( auth == null ) {
				logger.error("VCryptAuth instance not found in the session. Cannot generate wheel.");
				return null;
			}

			Object fingerPrintArr[] = VCryptServletUtil. getBrowserFingerPrint( request );
			Long prevAuthSessionId = (Long)session.getAttribute("vcrypt_prev_session_id");

			VCryptWheel wheels = auth.genWheel(length, sets, prevAuthSessionId,
											   authSessionType, clientType, clientVersion,
											   VCryptServletUtil.getRemoteIP(request),
			((Integer)fingerPrintArr[0]).intValue(),
		    (String) fingerPrintArr[1] );
			if( wheels != null ) {
				session.setAttribute("vcrypt_prev_session_id", wheels.getAuthSessionId() );
				return wheels.getWheel();
			} else {
				logger.error("Got null VCryptWheel in genWheel() length=" + length + ", sets=" + sets
							 + ", authSessionType=" + authSessionType
							 + ", clientType=" + clientType + ", clientVersion="
							 + clientVersion);
				return null;
			}
		} catch ( Exception ex ) {
			logger.error("Caught execption in genWheel() length=" + length + ", sets=" + sets
						 + ", authSessionType=" + authSessionType
						 + ", clientType=" + clientType + ", clientVersion="
						 + clientVersion, ex );
			return null;
		}
	}


	/**
	 * Authenticates the PIN entered using Slider
	 *
	 * @param request the <code>HttpServletRequest</code> object instance
	 * @return the <code>VCryptAuthResult</code> value
	 */
	static public VCryptAuthResult authenticateSlider( HttpServletRequest request, String loginId ){
		String pin = null;
		return authenticateSlider( request, loginId, pin);
	}

	/**
	 * Authenticates the PIN entered using Slider
	 *
	 * @param request the <code>HttpServletRequest</code> object instance
	 * @return the <code>VCryptAuthResult</code> value
	 */
	static public VCryptAuthResult authenticateSlider( HttpServletRequest request, String loginId, String pin ){
		try {
			if(logger.isDebugEnabled()) logger.debug("authenticateSlider() loginId=" + loginId);

			HttpSession session = request.getSession(true);

			VCryptAuth auth = getVCryptAuthInstance( request );
			if ( auth == null) {
				logger.error("authenticateSlider() VCryptAuth can't be created.");
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","system_error" ));
			}

			return authenticateSlider( auth, request, loginId, pin);
		} catch( Exception ex ) {
			logger.error("Caught exception: loginId=" + loginId, ex );
			return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","system_error" ));
		}
	}


	/**
	 * Authenticates the PIN entered using Slider
	 *
	 * @param request the <code>HttpServletRequest</code> object instance
	 * @return the <code>VCryptAuthResult</code> value
	 */
	static public VCryptAuthResult authenticateSlider( VCryptAuth auth, HttpServletRequest request, String customerId, String pin ){
		try {
			if(logger.isDebugEnabled()) logger.debug("authenticateSlider() customerId=" + customerId);

			HttpSession session = request.getSession(true);

			if ( customerId == null) {
				logger.error("authenticateSlider() customerId is null.");
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","invalid_user" ));
			}

			Object fingerPrintArr[] = VCryptServletUtil. getBrowserFingerPrint( request );

			//Lets get displacements.
			Vector angles = getDisplacements( request );
			if( angles == null ) {
				logger.info("authenticateSlider(): No displacement values for customerId=" + customerId);
				return new VCryptAuthResult(UserDefEnum.getElementValue("auth.status.enum","wrong_pin" ));
			}

			Long prevAuthSessionId = (Long)session.getAttribute("vcrypt_prev_session_id");
			HashMap pinEntryStats = collectStats( request );
			VCryptAuthResult result = null;
			if( pin == null ) {
				//Use PIN stored in Bharosa database
				result = auth.authenticateSlider( customerId, angles,
										 pinEntryStats, prevAuthSessionId,
										 VCryptServletUtil.getRemoteIP(request),
										 ((Integer)fingerPrintArr[0]).intValue(),
										 (String) fingerPrintArr[1]);
			} else {
				//Use PIN supplied by client
				result = auth.authenticateSlider( customerId, pin, angles,
										 pinEntryStats, prevAuthSessionId,
										 VCryptServletUtil.getRemoteIP(request),
										 ((Integer)fingerPrintArr[0]).intValue(),
										 (String) fingerPrintArr[1]);
			}
			if( result != null ) {
				session.setAttribute("vcrypt_prev_session_id", result.getAuthSessionId() );
				if(logger.isDebugEnabled()) logger.debug("Authentication result for customerId=" + customerId
							 + ", result="
							 + UserDefEnum.getElementName("auth.status.enum",result.getCode()));

			} else {
				logger.error("got null result: authenticateSlider() customerId=" + customerId);
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","system_error" ));
			}

			return result;
		} catch( Exception ex ) {
			logger.error("Caught exception: customerId=" + customerId, ex );
			return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","system_error" ));
		}
	}

	/**
	 * This method extracts the Slider input statistics from the request
	 * parameters and creates a HashMap out of it.
	 *
	 * @param request the <code>HttpServletRequest</code> object
	 * @return the <code>HashMap</code> containing the name/value of input metrics.
	 */
	static public HashMap collectStats(HttpServletRequest request) {
		if(logger.isDebugEnabled()) logger.debug("(collectStats()");

		HashMap stats = new HashMap();

		//Lets get the key pressed data
		stats.put("rightpressed", request.getParameter("rightpressed"));
		stats.put("leftpressed", request.getParameter("leftpressed"));
		stats.put("sliderpressed", request.getParameter("sliderpressed"));

		//Lets get the timer values
		stats.put("timer1", request.getParameter("timer1"));
		stats.put("timer2", request.getParameter("timer2"));
		stats.put("timer3", request.getParameter("timer3"));
		stats.put("timer4", request.getParameter("timer4"));
		stats.put("timer5", request.getParameter("timer5"));

		Enumeration e = request.getParameterNames();
		while (e.hasMoreElements()){
			String param = (String)e.nextElement();

			if (param.startsWith("vcrypt_")){
				stats.put(param, request.getParameter(param));
			}
		}
		return stats;
	}

	/**
	 * Gets a secret question for the user
	 * @param loginId The login id of the user to authenticate
	 * @return String secret question to be asked.
	 */
	static public String getSecretQuestion(  HttpServletRequest request, String loginId,
											 int authSessionType, int clientType,
											 String clientVersion  ) {
		try {
			if(logger.isDebugEnabled()) logger.debug("genSecretQuestion() loginId=" + loginId
						 + ", authSessionType=" + authSessionType
						 + ", clientType=" + clientType + ", clientVersion="
						 + clientVersion );

			if( loginId == null || loginId.trim().length() == 0) {
				logger.info("getSecretQuestion(): loginId is null");
				return null;
			}
			loginId = loginId.trim();

			HttpSession session = request.getSession(true);

			VCryptAuth auth = getVCryptAuthInstance( request );
			if( auth == null ) {
				logger.error("VCryptAuth instance not found in the session. Cannot get secretQuestion.");
				return null;
			}

			Object fingerPrintArr[] = VCryptServletUtil. getBrowserFingerPrint( request );
			Long prevAuthSessionId = (Long)session.getAttribute("vcrypt_prev_session_id");

			VCryptQuestion vcryptQuestion = auth.getSecretQuestion(loginId);
			if( vcryptQuestion != null ) {
				session.setAttribute("vcrypt_question", vcryptQuestion );
				session.setAttribute("vcrypt_prev_session_id", vcryptQuestion.getAuthSessionId() );
				return vcryptQuestion.getQuestion();
			} else {
				logger.error("Got null VCryptQuestion in getSecretQuestion() loginId="
							 + loginId);
				return null;
			}
		} catch ( Exception ex ) {
			logger.error("Caught execption in genQuestion() loginId=" + loginId
						 + ", authSessionType=" + authSessionType
						 + ", clientType=" + clientType + ", clientVersion="
						 + clientVersion, ex );
			return null;
		}
	}

	/**
	 * This method authenticates the secret question/answer for the
	 * the user.
	 *
	 * @param loginId a <code>String</code> value
	 * @param request a <code>HttpServletRequest</code> value
	 * @return a <code>VCryptAuthResult</code> value
	 */
	static public VCryptAuthResult authenticateQuestion( HttpServletRequest request,
														 String loginId, String answer ) {
		try {
			if(logger.isDebugEnabled()) logger.debug("authenticateQuestion() loginId=" + loginId);

			if( answer == null || answer.trim().length() == 0 ) {
				logger.info("authenticateAnswer() answer is empty for loginId=" + loginId);
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","wrong_answer" ));
			}
			answer = answer.trim();

			HttpSession session = request.getSession(true);

			VCryptAuth auth = getVCryptAuthInstance( request );
			if ( auth == null) {
				logger.error("authenticateQuestion() VCryptAuth can't be created.");
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","system_error" ));
			}

			if ( loginId == null) {
				logger.error("authenticateQuestion() loginId is null.");
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","invalid_user" ));
			}

			Object fingerPrintArr[] = VCryptServletUtil. getBrowserFingerPrint( request );
			Long prevAuthSessionId = (Long)session.getAttribute("vcrypt_prev_session_id");
			VCryptQuestion vcryptQuestion = (VCryptQuestion)session.getAttribute("vcrypt_question");

			if( vcryptQuestion == null ) {
				logger.info("vcrypt_question not found in session");
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","session_expired" ));
			}

			VCryptAuthResult result =
				auth.authenticateQuestion( loginId, answer );
			if( result != null ) {
				session.setAttribute("vcrypt_prev_session_id", result.getAuthSessionId() );
				if(logger.isDebugEnabled()) logger.debug("Authentication result for loginId=" + loginId
							 + ", result="
							 + UserDefEnum.getElementName("auth.status.enum",result.getCode()));

			} else {
				logger.error("got null result: authenticateQuestion() loginId=" + loginId);
				return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","system_error" ));
			}

			return result;
		} catch( Exception ex ) {
			logger.error("Caught exception: loginId=" + loginId, ex );
			return new VCryptAuthResult( UserDefEnum.getElementValue("auth.status.enum","system_error" ));
		}
	}

	static public void flashRedirect( HttpServletRequest request, String redirectUrl, JspWriter out )
		throws java.io.IOException {
		String redirectResponse = "&redirect=1&urll=" + redirectUrl;
		if(logger.isDebugEnabled()) logger.debug("flashRedirect" + redirectResponse);
		out.println(redirectResponse);
	}

    static Vector getDisplacements( HttpServletRequest request ){
		if(logger.isDebugEnabled()) logger.debug("In getDisplacements");

		//Lets get displacements.
		Vector angles = new Vector();
		for( int i = 1; request.getParameter("angle"+i) != null;  i++) {
			String angle = request.getParameter("angle"+i);
			if( angle!=null && angle.trim().length() != 0){
				try{
					angles.add(new Integer(angle.trim()));
				} catch(NumberFormatException e){
					logger.info("Invalid angle value <" + angle + "> passed for angle" + i );
					return null;
				}
			}
		}
		if(logger.isDebugEnabled()) logger.debug(" Got " + angles.size() + " angles");

		return angles;
	}

	static public void handleAuthentiPadImageRequest( HttpServletRequest request,
											   HttpServletResponse response ) {
		try	{

			response.setHeader("Cache-Control","no-cache"); //HTTP 1.1
			response.setHeader("Pragma","no-cache"); //HTTP 1.0
			//response.setHeader("Cache-Control","no-store");
			//response.setHeader("Cache-Control", "no-cache");
			//response.setHeader("Cache-control", "must-revalidate"); // works in IE and FireFox
			response.setDateHeader ("Expires", 0); //prevents caching at the proxy server
			response.setDateHeader("Max-Age", 0);

			String imageName = request.getParameter("loadImage");
			String padName = request.getParameter("pid");
			if( logger.isDebugEnabled()) logger.debug("imageName=" + imageName + ", padName=" + padName );
			File iconFile = null;
			BufferedImage newSource = null;
			AuthentiPad keyPad = null;
			String outputType = "png";


			OutputStream os = response.getOutputStream();

			HttpSession session = request.getSession();
			keyPad = (AuthentiPad)session.getAttribute(padName);

			String skinDir = BharosaConfig.get("bharosa.authentipad.images.dir", "alphapad_bg");

			if( skinDir == null )
			{
				logger.error("doGet images directory is empty. Property name is bharosa.authentipad.images.dir");
				return;
			}

			if(imageName!=null)
			{
				String imageFilePath = skinDir + File.separator + imageName;

				iconFile = KeyPadUtil.getFile(imageFilePath);

				if( iconFile != null )
				{
					response.setContentType("image/" + outputType );

					os = KeyPadUtil.encryptImageToStream(iconFile, outputType, os);
				}
				else
				{
					logger.error("loadImage iconFile " + imageFilePath + " not found");
					return;
				}
			}
			else
			{
				if( keyPad != null )
				{
					
					AuthentiConfig authConfig = keyPad.getAuthentiConfig();
					outputType = authConfig.getOutputType();

					response.setContentType("image/" + outputType );

					os = KeyPadUtil.encryptImageToStream( keyPad, authConfig, os);

				}
				else
				{
					logger.info("KeyPad was not found in session. The sesion might have got expired or someone might have called the servlet without calling the login page");

					String imageFilePath = skinDir + File.separator + imageName;

					iconFile = KeyPadUtil.getFile(imageFilePath);

					if( iconFile != null )
					{
						os = KeyPadUtil.encryptImageToStream(iconFile, outputType, os);
					}
				}
			}

			os.close();
			return;
		} catch( Exception ex ) {
			logger.error("Error while returning image", ex );
			try {
				String redirect = BharosaConfig.get("bharosa.authentipad.error.redirect");
				if( redirect != null && redirect.length() > 0 ) {
					response.setHeader("Cache-Control","no-cache"); //HTTP 1.1
					response.setHeader("Pragma","no-cache"); //HTTP 1.0
					response.setHeader("Cache-Control","no-store");
					response.setDateHeader ("Expires", 0); //prevents caching at the proxy server

					response.sendRedirect(redirect);
					return;
				} else {
					logger.error("No error redirect page found. Property name is bharosa.authentipad.error.redirect");
					//TBD: Need to handle this
				}
			} catch( Exception ex2 ) {
				logger.error("Exception while handling exception for image return failure", ex2 );
			}
		}
	}

}//end class VCryptServletUtil
