package com.bharosa.vcrypt.customercare.util;

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.common.util.DateUtil;
import com.bharosa.vcrypt.tracker.impl.VCryptRuleDataImpl;
import com.bharosa.vcrypt.tracker.impl.VCryptSessionRuleDataImpl;
import com.bharosa.vcrypt.tracker.impl.VAlertDataImpl;
import com.bharosa.vcrypt.tracker.impl.VCryptRuntimeDataImpl;
import com.bharosa.vcrypt.tracker.intf.VCryptRuntimeData;
import com.bharosa.vcrypt.tracker.intf.VAlertData;
import com.bharosa.vcrypt.tracker.intf.VCryptRuleData;
import com.bharosa.vcrypt.tracker.intf.VCryptSessionRuleData;
import com.bharosa.vcrypt.common.util.VCryptCommonUtil;
import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.common.util.XMLParserFactory;
import com.bharosa.vcrypt.customercare.intf.VCryptCC;

import com.bharosa.common.logger.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import java.io.StringReader;
import java.util.*;

/**
 * Provides utility method to instantiate classes required from Customer Care
 *
 */
public class VCryptCCUtil {

    static private Logger logger = Logger.getLogger(VCryptCCUtil.class);
    static Object lockObject = new Object();
    static int uidCounter = 0;
    static Random rand = new Random();
    private static final String rootNode_GetRuleData = "CCRuleData";
    private static final String rootNode_setTempAllow = "SetTemporaryAllow";
    private static final String rootNode_ResetChallengeFailureCounters = "ResetChallengeFailureCounters";

    private static final String SCORE = "Score";
    private static final String ACTION = "Action";
    private static final String RUNTIME = "Runtime";
    private static final String RUNTIME_ID = "RuntimeId";
    private static final String RUNTIME_NAME = "RuntimeName";
    private static final String ALERT_ID = "AlertId";
    private static final String RULE_ID = "RuleId";
    private static final String MESSAGE = "Message";
    private static final String LEVEL = "Level";
    private static final String TYPE = "Type";
    private static final String ALERT_DATA = "AlertData";
    private static final String NAME = "RuleName";
    private static final String MODEL_ID = "ModelId";
    private static final String MODEL_NAME = "ModelName";
    private static final String RULE_DATA = "RuleData";
    public static final String REQUEST_ID = "RequestId";
    public static final String QUESTION_ID = "QuestionId";
    public static final String TEMP_ALLOW_TYPE = "TemporaryAllowType";
    public static final String EXP_DATE = "ExpirationDate";
    public static final String CUSTOMER_ID = "CustomerId";
    public static final String ACTION_ENUM_ID = "ActionEnumId";
    public static final String ACTION_COUNT = "ActionCount";

    private static VCryptCC vCryptCC = null;

    public static String toXmlSetTemporaryAllow(String customerId, int tempAllowType, Date expirationDate) {
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(CUSTOMER_ID, customerId));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(TEMP_ALLOW_TYPE, tempAllowType));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(EXP_DATE, expirationDate));
        return VCryptCommonUtil.getXmlElement(rootNode_setTempAllow, xmlBuffer).toString();
    }

    public static Map fromXmlSetTemporaryAllow(String xmlString) {
        if (logger.isDebugEnabled()) logger.debug("fromXmlSetTemporaryAllow Xml=" + xmlString);

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("fromXmlSetTemporaryAllow null xmlString");
            return null;
        }

        String rootNode = rootNode_setTempAllow;
        try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));
            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                logger.error("fromXmlSetTemporaryAllow No root node=" + rootNode + " in Xml=" + xmlString);
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            Map map = new TreeMap();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase(CUSTOMER_ID))
                {
                    map.put(CUSTOMER_ID, valueNode.getNodeValue().trim());
                }
                else if (nodeName.equalsIgnoreCase(TEMP_ALLOW_TYPE))
                {
                    map.put(TEMP_ALLOW_TYPE, new Integer(valueNode.getNodeValue()));
                }
                else if (nodeName.equalsIgnoreCase(EXP_DATE))
                {
                    map.put(EXP_DATE, DateUtil.getDate(valueNode.getNodeValue()));
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            if (logger.isDebugEnabled())
                logger.debug("fromXmlSetTemporaryAllow Xml=" + xmlString + ", retVal=" + map);
            return map;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }

    public static String toXmlResetChallengeFailureCounters(final String requestId, final String customerId, final Long questionId) {
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(CUSTOMER_ID, customerId));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(QUESTION_ID,questionId));
        return VCryptCommonUtil.getXmlElement(rootNode_ResetChallengeFailureCounters, xmlBuffer).toString();
    }

    public static Map fromXmlResetChallengeFailureCounters(String xmlString) {
        
        if (logger.isDebugEnabled()) logger.debug("fromXmlResetChallengeFailureCounters Xml=" + xmlString);

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("fromXmlResetChallengeFailureCounters null xmlString");
            return null;
        }

        String rootNode = rootNode_ResetChallengeFailureCounters;
        try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));
            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++) {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode)) {
                    root = node;
                    break;
                }
            }

            if (root == null) {
                logger.error("fromXmlResetChallengeFailureCounters No root node=" + rootNode + " in Xml=" + xmlString);
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            Map map = new TreeMap();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null) {
                    continue;
                }
                if (nodeName.equalsIgnoreCase(CUSTOMER_ID)) {
                    map.put(CUSTOMER_ID, valueNode.getNodeValue().trim());
                } else if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
                    map.put(REQUEST_ID, valueNode.getNodeValue().trim());
                } else if (nodeName.equalsIgnoreCase(QUESTION_ID)) {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                        map.put(QUESTION_ID, new Long(value.trim()));
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            if (logger.isDebugEnabled())
                logger.debug("fromXmlResetChallengeFailureCounters Xml=" + xmlString + ", retVal=" + map);
            return map;
        } catch (Exception ex) {
            logger.error("fromXmlResetChallengeFailureCounters xml =" + xmlString, ex);
            return null;
        }
    }

    public static String toXmlVCryptSessionRuleData(VCryptSessionRuleData sessionData) {
        if (sessionData == null)
            return null;
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, sessionData.getRequestId()));
        xmlBuffer.append(VCryptCommonUtil.toVCryptResponseXml(sessionData.getResponse()));
        Map map = sessionData.getRuntimeDataMap();
        if (map != null) {
            Iterator itr = map.keySet().iterator();
            while (itr.hasNext()) {
                Integer runtime = (Integer) itr.next();
                List list = (List) map.get(runtime);
                if (list != null && !list.isEmpty()) {
                    for (int i = 0; i < list.size(); i++) {
                        xmlBuffer.append(getRuntimeXml((VCryptRuntimeData) list.get(i)));
                    }
                }
            }
        }
        return VCryptCommonUtil.getXmlElement(rootNode_GetRuleData, xmlBuffer).toString();
    }

    private static String getRuntimeXml(VCryptRuntimeData runtimeData) {
        if (runtimeData == null) return "";
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(RUNTIME_ID, runtimeData.getRuntime()));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(RUNTIME_NAME, runtimeData.getRuntimeName()));
        Iterator itr = runtimeData.getRuleDataList().iterator();
        while (itr.hasNext())
            xmlBuffer.append(toXmlRuleDataXml((VCryptRuleData) itr.next()));

        itr = runtimeData.getActionList().iterator();
        while (itr.hasNext())
            xmlBuffer.append(VCryptCommonUtil.getXmlElement(ACTION, itr.next()));

        itr = runtimeData.getAlertList().iterator();
        while (itr.hasNext())
            xmlBuffer.append(toXmlVAlertDataXml((VAlertData) itr.next()));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(SCORE, runtimeData.getFinalScore()));
        return VCryptCommonUtil.getXmlElement(RUNTIME, xmlBuffer).toString();
    }

    private static String toXmlVAlertDataXml(VAlertData vAlertData) {
        if (vAlertData == null) return "";
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(ALERT_ID, vAlertData.getId()));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(MESSAGE, vAlertData.getMessage()));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(LEVEL, vAlertData.getLevel()));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(TYPE, vAlertData.getType()));
        return VCryptCommonUtil.getXmlElement(ALERT_DATA, xmlBuffer).toString();
    }


    private static String toXmlRuleDataXml(VCryptRuleData ruleData) {
        if (ruleData == null) return "";
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(NAME, ruleData.getRuleInstanceName()));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(MODEL_NAME, ruleData.getModelName()));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(RULE_ID, ruleData.getRuleInstanceId()));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(MODEL_ID, ruleData.getModelId()));
        return VCryptCommonUtil.getXmlElement(RULE_DATA, xmlBuffer).toString();
    }
    
    public static String toXmlActionCount(String requestId, String customerId, Integer actionEnumId) {
        StringBuffer xmlBuffer = new StringBuffer(500);
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(CUSTOMER_ID, customerId));
        xmlBuffer.append(VCryptCommonUtil.getXmlElement(ACTION_ENUM_ID, actionEnumId));
        return VCryptCommonUtil.getXmlElement(ACTION_COUNT, xmlBuffer).toString();
    }

    public static Map fromXmlActionCount(String xmlString) {
         if (logger.isDebugEnabled()) logger.debug("fromXmlActionCount Xml=" + xmlString);

         if (StringUtil.isEmpty(xmlString)) {
             logger.warn("fromXmlActionCount empty xmlString");
             return null;
         }

         String rootNode = ACTION_COUNT;
         try
         {
             final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
             Document document = builder.parse(new InputSource(new StringReader(xmlString)));
             Node root = null;
             NodeList rootList = document.getChildNodes();
             for (int i = 0; i < rootList.getLength(); i++)
             {
                 Node node = rootList.item(i);
                 if (node.getNodeName().equalsIgnoreCase(rootNode))
                 {
                     root = node;
                     break;
                 }
             }

             if (root == null)
             {
                 logger.error("fromXmlActionCount No root node=" + rootNode + " in Xml=" + xmlString);
                 return null;
             }

             NodeList nodeList = root.getChildNodes();
             Map map = new TreeMap();
             for (int i = 0; i < nodeList.getLength(); i++)
             {
                 Node node = nodeList.item(i);
                 String nodeName = node.getNodeName();
                 Node valueNode = node.getFirstChild();
                 if (valueNode == null)
                 {
                     continue;
                 }
                 if (nodeName.equalsIgnoreCase(CUSTOMER_ID))
                 {
                     map.put(CUSTOMER_ID, valueNode.getNodeValue().trim());
                 }
                 else if (nodeName.equalsIgnoreCase(REQUEST_ID))
                 {
                     map.put(REQUEST_ID, valueNode.getNodeValue().trim());
                 }
                 else if (nodeName.equalsIgnoreCase(ACTION_ENUM_ID))
                 {
                     map.put(ACTION_ENUM_ID, new Integer(valueNode.getNodeValue()));
                 }
                 else if (!nodeName.startsWith("#"))
                 {
                     logger.error("fromXmlActionCount Invalid element name <" + nodeName + "> in xml " + xmlString);
                 }
             }
             if (logger.isDebugEnabled())
                 logger.debug("fromXmlActionCount Xml=" + xmlString + ", retVal=" + map);
             return map;
         } catch (Exception ex) {
             logger.error("fromXmlActionCount Exception while parsing xml =" + xmlString, ex);
             return null;
         }
     } // end fromXmlActionCount

    public static VCryptSessionRuleData fromXmlVCryptSessionRuleData(String xmlString) {
        if (logger.isDebugEnabled()) logger.debug("fromXmlVCryptSessionRuleData Xml=" + xmlString);

        if (StringUtil.isEmpty(xmlString)) {
            logger.warn("null xmlString");
            return null;
        }

        String rootNode = rootNode_GetRuleData;
        try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));
            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            VCryptSessionRuleData sessionData = null;
            if (root == null)
            {
                logger.error(
                        "fromXmlVCryptSessionRuleData No root node=" + rootNode_GetRuleData + " in Xml=" + xmlString);
                return sessionData;
            }

            NodeList nodeList = root.getChildNodes();
            Map map = new TreeMap();
            VCryptResponse response = null;
            String requestId = null;
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase(REQUEST_ID))
                {
                    requestId = valueNode.getNodeValue();
                }
                else if (nodeName.equalsIgnoreCase(VCryptCommonUtil.rootNode_vCryptResponse))
                {
                    response = VCryptCommonUtil.getVCryptResponse(node);
                }
                else if (nodeName.equalsIgnoreCase(RUNTIME))
                {
                    VCryptRuntimeData runtimeData = fromXmlRuntimeData(node);
                    if (runtimeData == null)
                    {
                        logger.error("Invalid runtimedata xml=" + xmlString);
                    }
                    else
                    {
                        Integer runtime = runtimeData.getRuntime();
                        List runtimeDataList = (List) map.get(runtime);
                        if (runtimeDataList == null)
                        {
                            runtimeDataList = new ArrayList();
                            map.put(runtime, runtimeDataList);
                        }
                        runtimeDataList.add(runtimeData);
                    }
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            sessionData = new VCryptSessionRuleDataImpl(requestId, response, map);
            if (logger.isDebugEnabled())
                logger.debug("fromXmlVCryptSessionRuleData Xml=" + xmlString + ", retVal=" + sessionData);
            return sessionData;
        } catch (Exception ex) {
            logger.error("Exception while parsing xml =" + xmlString, ex);
            return null;
        }
    }

    private static VCryptRuntimeData fromXmlRuntimeData(Node root) {
        VCryptRuntimeDataImpl runtimeData = new VCryptRuntimeDataImpl();
        List alertList = new ArrayList();
        List actionList = new ArrayList();
        List ruleDataList = new ArrayList();
        NodeList nodeList = root.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            String nodeName = node.getNodeName();
            Node valueNode = node.getFirstChild();
            if (valueNode != null) {
                if (nodeName.equalsIgnoreCase(SCORE)) {
                    runtimeData.setFinalScore(Integer.parseInt(valueNode.getNodeValue()));
                } else if (nodeName.equalsIgnoreCase(ALERT_DATA)) {
                    alertList.add(fromXmlAlertData(node));
                } else if (nodeName.equalsIgnoreCase(ACTION)) {
                    actionList.add(valueNode.getNodeValue());
                } else if (nodeName.equalsIgnoreCase(RUNTIME_ID)) {
                    if (!StringUtil.isEmpty(valueNode.getNodeValue()))
                        runtimeData.setRuntime(new Integer(valueNode.getNodeValue()));
                } else if (nodeName.equalsIgnoreCase(RUNTIME_NAME)) {
                    runtimeData.setRuntimeName(valueNode.getNodeValue());
                } else if (nodeName.equalsIgnoreCase(RULE_DATA)) {
                    ruleDataList.add(fromRuleDataXml(node));
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" + nodeName + ">");
                }
            }
        }
        runtimeData.setAlertList(alertList);
        runtimeData.setActionList(actionList);
        runtimeData.setRuleDataList(ruleDataList);
        return runtimeData;
    }

    private static VCryptRuleData fromRuleDataXml(Node root) {
        VCryptRuleDataImpl ruleData = new VCryptRuleDataImpl();
        NodeList nodeList = root.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            String nodeName = node.getNodeName();
            Node valueNode = node.getFirstChild();
            if (valueNode != null) {
                if (nodeName.equalsIgnoreCase(RULE_ID)) {
                    ruleData.setRuleInstanceId(new Long(valueNode.getNodeValue()));
                } else if (nodeName.equalsIgnoreCase(NAME)) {
                    ruleData.setRuleInstanceName(valueNode.getNodeValue());
                } else if (nodeName.equalsIgnoreCase(MODEL_ID)) {
                    ruleData.setModelId(new Long(valueNode.getNodeValue()));
                } else if (nodeName.equalsIgnoreCase(MODEL_NAME)) {
                    ruleData.setModelName(valueNode.getNodeValue());
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" + nodeName + ">");
                }
            }
        }
        return ruleData;
    }

    private static VAlertData fromXmlAlertData(Node root) {
        VAlertDataImpl alertData = new VAlertDataImpl();
        NodeList nodeList = root.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            String nodeName = node.getNodeName();
            Node valueNode = node.getFirstChild();
            if (valueNode != null) {
                if (nodeName.equalsIgnoreCase(ALERT_ID)) {
                    alertData.setId(new Long(valueNode.getNodeValue()));
                } else if (nodeName.equalsIgnoreCase(MESSAGE)) {
                    alertData.setMessage(valueNode.getNodeValue());
                } else if (nodeName.equalsIgnoreCase(LEVEL)) {
                    String nodeValue = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(nodeValue))
                        alertData.setLevel(nodeValue.trim());
                } else if (nodeName.equalsIgnoreCase(TYPE)) {
                    String nodeValue = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(nodeValue))
                        alertData.setType(nodeValue.trim());
                } else if (!nodeName.startsWith("#")) {
                    logger.error("Invalid element name <" + nodeName + ">");
                }
            }
        }
        return alertData;
    }

    public static VCryptCC getVCryptCCInstance() {
        if (vCryptCC != null) {
            return vCryptCC;
        }
        synchronized (VCryptCCUtil.class) {
            if (vCryptCC == null) {
                logger.info("Creating new VCryptCC instance...");
                try {
                    vCryptCC = newVCryptCCInstance();
                } catch (Exception ex) {
                    logger.error("Error creating VCryptCC instance.", ex);
                }
            }
        }
        return vCryptCC;
    } // getInstance

    /**
     * This methods instantiates a *new instance of VCryptCC  class.
     *
     * @return Returns new instance of VCryptCC class. It will return null
     *         if the instance could not be created.
     */
    static private VCryptCC newVCryptCCInstance() {
        if (logger.isDebugEnabled()) logger.debug("Creating new VCryptCC instance...");
        try {
            boolean useSoap = BharosaConfig.getBoolean("vcrypt.tracker.soap.useSOAPServer", false);
            String kls = BharosaConfig.get("vcrypt.cc.util.classname");
            if (StringUtil.isEmpty(kls)) {
                if (useSoap) {
                    kls = BharosaConfig.get("vcrypt.cc.util.soap.classname", "com.bharosa.vcrypt.customercare.impl.VCryptCCSOAPImpl");
                } else {
                    kls = BharosaConfig.get("vcrypt.cc.util.static.classname", "com.bharosa.vcrypt.customercare.impl.VCryptCCMonitorImpl");
                }
            }
            return (VCryptCC) Class.forName(kls).newInstance();
        } catch (Exception ex) {
            logger.error("Error creating VCryptCC instance.", ex);
            return null;
        }
    }

}
