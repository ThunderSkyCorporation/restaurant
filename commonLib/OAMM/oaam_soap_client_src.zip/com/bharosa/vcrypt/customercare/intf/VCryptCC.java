package com.bharosa.vcrypt.customercare.intf;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.common.util.VCryptIntResponse;
import com.bharosa.vcrypt.tracker.intf.VCryptSessionRuleData;

import java.util.Date;

/**
 * Provides methods for Customer Care Functionality.
 * This inteface provides functionality specific to customer care only.
 * Some other customer care funcationality overlaps with Auth API is from VCryptAuth
 */
public interface VCryptCC {

    String REQ_FINAL_AUTH_STATUS = "getFinalAuthStatus";
    String REQ_RULES_DATA_LAST_SESSION = "getRulesDataForLastSession";
    String REQ_RULES_DATA = "getRulesData";
    String REQ_TEMP_ALLOW = "setTemporaryAllow";
    String REQ_CANCEL_TEMP_ALLOW = "cancelAllTemporaryAllows";
    String REQ_RESET_USER = "resetUser";
    String REQ_RESET_CHALLENGE_FAILURE_COUNTERS = "resetChallengeFailureCounters";
    String REQ_ACTION_COUNT = "actionCount";

    /**
     * Return the final authentication status of an user given the user id of the user.
     * This method can only go back upto 30 days.
     *
     * @param requestId requestId for tracking purpose
     * @param userId unique identifier to the user, can't be null
     * @return VCryptIntResponse auth status, -1 if no data,
     * Check for VCryptIntResponse.getResponse().isSuccess() to see if the request is succesful before using the value
     */
    public VCryptIntResponse getFinalAuthStatus(String requestId, String userId);

    /**
     * This call sets a temporary allow for the user.
     *
     * @param customerId     Id of the customer
     * @param tempAllowType  Type of the temporary allow. The User Defined Enum for this type is
     *                       customercare.case.tempallow.level.enum
     * @param expirationDate Expiration date if the tempAllowType is "userset". Otherwise it can be null or empty.
     * @return The response from the server
     */
    public VCryptResponse setTemporaryAllow(String customerId, int tempAllowType, Date expirationDate);

    /**
     * Cancels all the unused temporary for the user.
     *
     * @param customerId Customer Id of the user
     * @return The response from the server
     */
    public VCryptResponse cancelAllTemporaryAllows(String customerId);

    /**
     * Reset all profiles set for the user. This includes registration, questions, images and phrases
     * <p/>
     * selected or assigned to the user
     *
     * @param customerId Customer Id of the user.
     * @return The response from the server.
     */
    public VCryptResponse resetUser(String customerId);

    /**
     * Reset Challenge failure counters for the given customerid
     * @param requestId to track the request
     * @param customerId external customer id required and used to identify customer uniquely, it is not login Id
     * @param questionId optional, if sent, failure counters for the given question id are reset 
     * @return The response from the server. check isSuccess() for success
     */
    public VCryptResponse resetChallengeFailureCounters(final String requestId, final String customerId, final Long questionId);

    /**
     * Return all the rules excuted for the given session Id, provides basic information of what rules got triggered.
     * Doesn't provide complete hierarchy information.
     * Rules execution data is persisted asynchrously and may not be available immediately.
     *
     * @param requestId sessionId
     * @return VCryptSessionRuleData
     */
    public VCryptSessionRuleData getRulesData(String requestId);

    /**
     * Return all the rules excuted for the given customerId for past session, provides basic information of
     * what rules got triggered.
     * Doesn't provide complete hierarchy information.
     * Rules execution data is persisted asynchrously and may not be available immediately.
     *
     * @param customerId Customer Id of the user.
     * @return VCryptSessionRuleData
     */
    public VCryptSessionRuleData getRulesDataForLastSession(String customerId);

    /**
     * Get the action count for the given actionEnumId, consult your configuration for available action enums
     * The property [rule.action.enum.<actionName>.incrementCacheCounter] is to be set to true to increment the counter for the action corresponding to <actionName>.
     * If it is not set or set to false, the method returns successfully, the value which is present in the cache, but this value may not reflect the exact action count.
     *
     * @param requestId requestId for logging and tracing with client requests in case of errors
     * @param customerId unique identifier to the user, required
     * @param actionEnumId actionEnum, required, rule.action.enum to be counted
     * @return VCryptIntResponse with int count if action count enum is enabled
     * Check for VCryptIntResponse.getResponse().isSuccess() to see if the request is succesful before using the value
     * Few possibe
     * <nl>VCryptResponse.INVALID_DATA, if actionEnumId is null
     * <nl>VCryptResponse.APPLICATION_ERROR, if cache count is not enabled for the specified enum, contact application support
     * <nl>VCryptResponse.UNEXPECTED_ERROR, in case of unexpected error, contact application support
     */
    public VCryptIntResponse getActionCount(String requestId, String customerId, Integer actionEnumId);
    
}
