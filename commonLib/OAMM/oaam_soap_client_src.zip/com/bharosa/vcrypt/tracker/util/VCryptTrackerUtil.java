package com.bharosa.vcrypt.tracker.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.io.IOException;
import java.io.StringReader;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import com.bharosa.common.logger.Logger;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.bharosa.common.exception.BharosaException;

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.DateUtil;
import com.bharosa.common.util.IBharosaConstants;
import com.bharosa.common.util.LiteXMLUtil;
import com.bharosa.common.util.StringUtil;

import com.bharosa.common.util.UserDefEnum;
import com.bharosa.common.util.UserDefEnumElement;
import com.bharosa.vcrypt.common.data.OAAMDeviceFingerprintData;
import com.bharosa.vcrypt.common.data.OAAMIPData;
import com.bharosa.vcrypt.common.data.OAAMSessionData;
import com.bharosa.vcrypt.common.data.OAAMUserData;
import com.bharosa.vcrypt.common.util.VCryptCommonUtil;
import com.bharosa.vcrypt.common.util.VCryptObjectResponse;
import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.common.util.XMLParserFactory;

import com.bharosa.vcrypt.tracker.data.TransactionCreateRequestData;
import com.bharosa.vcrypt.tracker.data.TransactionUpdateRequestData;
import com.bharosa.vcrypt.tracker.impl.VCryptRulesResultImpl;
import com.bharosa.vcrypt.tracker.intf.NameValueProfile;
import com.bharosa.vcrypt.tracker.intf.VCryptRulesEngine;
import com.bharosa.vcrypt.tracker.intf.VCryptRulesResult;
import com.bharosa.vcrypt.tracker.intf.VCryptTracker;
import com.bharosa.vcrypt.tracker.transaction.data.EntityData;
import com.bharosa.vcrypt.tracker.transaction.data.EntityHeader;


/**
 * Provides utility method to instantiate classes required from VCryptTracker
 */

public class VCryptTrackerUtil {

  private static Logger logger = Logger.getLogger(VCryptTrackerUtil.class);
  private static int truncateCookieLength = BharosaConfig.getInt("vcrypt.cookie.truncate.length", 128);
  private static final Object lock = new Object();
  private static VCryptTracker vcryptTracker = null;
  private static VCryptRulesEngine vcryptRulesEngine = null;

  private static final String rootNode_updateAuthStatus = "UpdateAuthStatusRequest";
  private static final String rootNode_updateTransactionStatus = "UpdateTransactionStatus";
  private static final String rootNode_fingerPrintRequest = "FingerPrintRequest";
  private static final String rootnode_fingerPrintResponse = "FingerPrintResponse";
  public static final String rootNode_generateOTP = "GenerateOTP";
  public static final String rootNode_getOTPCode = "GetOTPCode";
  public static final String rootNode_validateOTPCode = "ValidateOTPCode";
  public static final String rootNode_resetOTPCounter = "ResetOTPCounter";
  public  static final String rootNode_incrementOTPCounter = "IncrementOTPCounter";

  private static final String rootNode_createTransaction = "CreateTransaction";
  private static final String rootNode_updateTransaction = "UpdateTransaction";
  public static final String rootNode_createOAAMSession = "CreateOAAMSesson";

  public static final String TRANSACTION_KEY = "transactionDefKey";
  public static final String EXT_TRANSACTION_ID = "extTransactionId";
  public static final String REQUEST_TIME = "requestTime";
  public static final String REQUEST_ID = "requestId";
  public static final String TRANSACTION_ID = "transactionId";
  public static final String STATUS = "status";
  public static final String CONTEXTS = "contexts";
  public static final String TRANSACTION_TYPE = "transactionType";
  public static final String ANALYZE_PATTERNS = "analyzePatterns";
  public static final String OTP_CHALLENGE_TYPE = "otpChallengeType";
  public static final String APPLICATION_ID = "appId";
  public static final String OVER_WRITE_IF_EXISTS = "overwriteIfExists";
  public static final String OTP_CODE = "otpCode";
  public static final String OTP_VALIDATE_RESULT = "otpValidateResult";

  public static final String TRANSACTION_LOG_ID = "transactionLogId";
  private static final String RISK_SCORE = "riskScore";
  private static final String ACTION_RESULT = "actionResult";
  private static final String ALERT_LIST = "alertList";
  private static final String ACTION_LIST = "actionList";
  private static final String RUNTIME = "runtime";
  private static final String PROCESS_RULES_RESPONSE = "ProcessRulesResponse";
  private static final String RUNTIME_RESULT_LIST = "runtimeResultList";
  private static final String RUNTIME_RESULT = "runtimeResult";
  private static final String SECURE_COOKIE = "secureCookie";
  private static final String DIGITAL_COOKIE = "digitalCookie";
  private static final String rootNode_UpdateAuthResult = "UpdateAuthResultRequest";
  private static final String USER_ID = "userId";
  private static final String LOGIN_ID = "loginId";
  private static final String FINGER_PRINT_TYPE = "fingerPrintType";
  private static final String FINGER_PRINT = "fingerPrint";
  private static final String FINGER_PRINT_TYPE2 = "fingerPrintType2";
  private static final String FINGER_PRINT2 = "fingerPrint2";
  private static final String GROUP_ID = "groupId";
  private static final String RESULT = "result";
  private static final String CLIENT_TYPE = "clientType";
  private static final String CLIENT_VERSION = "clientVersion";
  private static final String REMOTE_IPADDR = "remoteIPAddr";
  private static final String REMOTE_HOST = "remoteHost";
  private static final String IS_SECURE = "isSecure";
  private static final String SECURE_CLIENT_TYPE = "secureClientType";
  private static final String SECURE_CLIENT_VERSION = "secureClientVersion";
  private static final String DIGITAL_CLIENT_TYPE = "digitalClientType";
  private static final String DIGITAL_CLIENT_VERSION = "digitalClientVersion";
  private static final String rootNode_TransactionLog = "TransactionLogRequest";
  public static final String PROFILE_TYPE_LIST = "profileTypeList";
  private static final String CONTEXT = "context";
  private static final String NAME = "name";
  private static final String VALUE = "value";
  private static final String rootNode_processRules = "ProcessRulesRequest";
  private static final String PROFILE_TYPE = "profileType";
  private static final String INVALID_ELEMENT_START = "#";
  private static final String PROCESS_PATTERN_ANALYSIS = "ProcessPatternAnalysis";
  private static final String DEVICE_ID = "deviceId";
  
  public static final String IS_REPLACE_ENTITY= "isReplaceEntity";
  public static final String COMMIT_BATCH_SIZE= "commitBatchSize";
  public static final String ENTITY_DATA_LIST = "EntityDataList";
  public static final String rootNode_createOrUpdateEntities= "CreateOrUpdateEntities";
  public static final String rootNode_searchEntity= "SearchEntity";
  private static final String CREATE_TIME = "createTime";
  private static final String UPDATE_TIME = "updateTime";
  private static final String ENTITY_NAME = "entityName";
  private static final String ENTITY_TYPE = "entityType";
  private static final String ENTITY_DEF_ID ="entityDefId";
  private static final String ENTITY_KEY = "entityKey";
  public static final String  rootNode_entityData= "EntityData";
  private static final String ENTITY_ID = "EntityId";
  private static final String ENTITY_IDS= "EntityIds";
  public static final String ENTITY_HEADER="EntityHeader";
  
  
  public static final String USER_DATA="UserData";
  public static final String IP_DATA="IpData";
  private static final String PROXY_IP="proxyIp";
  private static final String LONGITUDE="longitude";
  private static final String LATITUDE="latitude";
  private static final String LOCATION_ACCURACY="locationAccuracy";
  private static final String LOCATION_ACCURACY_UNITS="locationAccuracyUnits";
  private static final String LOCATION_SOURCE_TYPE="locationSourceType";
  private static final String LOCATION_ACQUIRE_TIME="locationAcquireTime";
  
  public static final String COOKIE_LIST="CookieList";
  private static final String COOKIE_DATA="CookieData";
  private static final String COOKIE_TYPE="cookieType";
  private static final String COOKIE="cookie";
  
  public static final String SESSION_DATA="SessionData";
  private static final String REGISTER_DEVICE="registerDevice";
  private static final String CLIENT_APPLICATION="clientApplication";
  public static final String LINKED_ENTITY="linkedEntity";
  public static final String LINKED_ENTITIES_MAP="linkedEntitiesMap";
  public static final String EXTERNAL_DEVICE_ID="externalDeviceId";
  public static final String DATA_MAP="dataMap";
  /** 
   * This methods returns an instance of VCryptTracker class.
   *
   * @return Returns instance of VCryptTracker class
   */
  static public VCryptTracker getVCryptTrackerInstance() {
    if (vcryptTracker != null) {
      return vcryptTracker;
    }
    synchronized (lock) {
      if (vcryptTracker == null) {
        logger.info("Creating new VCryptTracker instance...");
        try {
          boolean useSoap = BharosaConfig.getBoolean("vcrypt.tracker.soap.useSOAPServer", false);
          String trackerClassName = BharosaConfig.get("vcrypt.tracker.impl.classname");
          if (trackerClassName == null || trackerClassName.trim().equals("")) {
            if (useSoap) {
              trackerClassName =
                  BharosaConfig.get("vcrypt.tracker.util.soap.classname", "com.bharosa.vcrypt.tracker.impl.VCryptTrackerSOAPImpl");
            } else {
              trackerClassName =
                  BharosaConfig.get("vcrypt.tracker.util.static.classname", "com.bharosa.vcrypt.tracker.impl.VCryptTrackerImpl");
            }
          }
          //Loading instance
          logger.info("Loading class " + trackerClassName);
          vcryptTracker = (VCryptTracker)Class.forName(trackerClassName).newInstance();
        } catch (Exception ex) {
          logger.error("Error creating VCryptTracker instance.", ex);
        }
      }
    }
    return vcryptTracker;
  }

  /**
   * This method return an instance of VCryptRulesEngine class.
   *
   * @return Returns instance of VCryptRulesEngine class
   */
  static public VCryptRulesEngine getVCryptRulesEngineInstance() {
    if (vcryptRulesEngine != null) {
      return vcryptRulesEngine;
    }
    synchronized (lock) {
      if (vcryptRulesEngine == null) {
        try {
          logger.info("Creating new VCryptRulesEngine instance...");
          boolean useSoap = BharosaConfig.getBoolean("vcrypt.tracker.soap.useSOAPServer", false);
          String rulesEngineClassName = BharosaConfig.get("vcrypt.rules.engine.impl.classname");
          if (rulesEngineClassName == null || rulesEngineClassName.trim().equals("")) {
            if (useSoap) {
              rulesEngineClassName =
                  BharosaConfig.get("vcrypt.rules.engine.soap.classname", "com.bharosa.vcrypt.tracker.impl.VCryptRulesEngineSOAPImpl");
            } else {
              rulesEngineClassName =
                  BharosaConfig.get("vcrypt.rules.engine.static.classname", "com.bharosa.vcrypt.tracker.impl.VCryptRulesEngineMonitorImpl");
            }
          }
          //Loading instance
          logger.info("Loading class " + rulesEngineClassName);
          vcryptRulesEngine = (VCryptRulesEngine)Class.forName(rulesEngineClassName).newInstance();
        } catch (Exception ex) {
          logger.error("Error creating VCryptRulesEngine instance.", ex);
        }
      }
    }
    return vcryptRulesEngine;

  }

  static public String getTransactionDefKey(Map pContextMap) {
    String retTrxDefKey = null;
    if (pContextMap != null) {
      Object tranTypeObj = pContextMap.get(TRANSACTION_TYPE);
      if (tranTypeObj instanceof String) {
        retTrxDefKey = (String)tranTypeObj;
      }
    }
    return retTrxDefKey;
  }

  static public String toXMLFingerPrintRequest(String requestId, Date requestTime, String remoteIPAddr,
                                               String remoteHost, String secureCookie, int secureClientType,
                                               String secureClientVersion, String digitalCookie, int digitalClientType,
                                               String digitalClientVersion, int fingerPrintType, String fingerPrint,
                                               int fingerPrintType2, String fingerPrint2) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLFingerPrintRequest() enter()");
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_TIME, requestTime));
    xmlString.append(VCryptCommonUtil.getXmlElement(REMOTE_IPADDR, remoteIPAddr));
    xmlString.append(VCryptCommonUtil.getXmlElement(REMOTE_HOST, remoteHost));
    xmlString.append(VCryptCommonUtil.getXmlElement(SECURE_COOKIE, validateCookie(secureCookie)));
    xmlString.append(VCryptCommonUtil.getXmlElement(SECURE_CLIENT_TYPE, secureClientType));
    xmlString.append(VCryptCommonUtil.getXmlElement(SECURE_CLIENT_VERSION, secureClientVersion));
    xmlString.append(VCryptCommonUtil.getXmlElement(DIGITAL_COOKIE, validateCookie(digitalCookie)));
    xmlString.append(VCryptCommonUtil.getXmlElement(DIGITAL_CLIENT_TYPE, digitalClientType));
    xmlString.append(VCryptCommonUtil.getXmlElement(DIGITAL_CLIENT_VERSION, digitalClientVersion));
    xmlString.append(VCryptCommonUtil.getXmlElement(FINGER_PRINT_TYPE, fingerPrintType));
    xmlString.append(VCryptCommonUtil.getXmlElement(FINGER_PRINT, fingerPrint));
    xmlString.append(VCryptCommonUtil.getXmlElement(FINGER_PRINT_TYPE2, fingerPrintType2));
    xmlString.append(VCryptCommonUtil.getXmlElement(FINGER_PRINT2, fingerPrint2));
    return VCryptCommonUtil.getXmlElement(rootNode_fingerPrintRequest, xmlString).toString();
  }

  static public Map fromXMLFingerPrintRequest(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLFingerPrintRequest() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLFingerPrintRequest() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = rootNode_fingerPrintRequest;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(REQUEST_TIME)) {
          String value = valueNode.getNodeValue();
          Date dateValue = DateUtil.getDate(value);
          nvList.put(REQUEST_TIME, dateValue);
        } else if (nodeName.equalsIgnoreCase(REMOTE_IPADDR)) {
          String value = valueNode.getNodeValue();
          nvList.put(REMOTE_IPADDR, value);
        } else if (nodeName.equalsIgnoreCase(REMOTE_HOST)) {
          String value = valueNode.getNodeValue();
          nvList.put(REMOTE_HOST, value);
        } else if (nodeName.equalsIgnoreCase(SECURE_COOKIE)) {
          String value = valueNode.getNodeValue();
          nvList.put(SECURE_COOKIE, value);
        } else if (nodeName.equalsIgnoreCase(SECURE_CLIENT_TYPE)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(SECURE_CLIENT_TYPE, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(SECURE_CLIENT_VERSION)) {
          String value = valueNode.getNodeValue();
          nvList.put(SECURE_CLIENT_VERSION, value);
        } else if (nodeName.equalsIgnoreCase(DIGITAL_COOKIE)) {
          String value = valueNode.getNodeValue();
          nvList.put(DIGITAL_COOKIE, value);
        } else if (nodeName.equalsIgnoreCase(DIGITAL_CLIENT_TYPE)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(DIGITAL_CLIENT_TYPE, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(DIGITAL_CLIENT_VERSION)) {
          String value = valueNode.getNodeValue();
          nvList.put(DIGITAL_CLIENT_VERSION, value);
        } else if (nodeName.equalsIgnoreCase(FINGER_PRINT_TYPE)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(FINGER_PRINT_TYPE, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(FINGER_PRINT)) {
          String value = valueNode.getNodeValue();
          nvList.put(FINGER_PRINT, value);
        } else if (nodeName.equalsIgnoreCase(FINGER_PRINT_TYPE2)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(FINGER_PRINT_TYPE2, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(FINGER_PRINT2)) {
          String value = valueNode.getNodeValue();
          nvList.put(FINGER_PRINT2, value);
        } else if (!nodeName.startsWith(INVALID_ELEMENT_START)) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  }

  static public String toXMLFingerPrintResponse(CookieSet cookieSet) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLFingerPrintResponse() enter()");
    if (cookieSet == null) {
      return null;
    }
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, cookieSet.getRequestId()));
    xmlString.append(VCryptCommonUtil.getXmlElement(SECURE_COOKIE, validateCookie(cookieSet.getSecureCookie())));
    xmlString.append(VCryptCommonUtil.getXmlElement(DIGITAL_COOKIE, validateCookie(cookieSet.getDigitalCookie())));
    xmlString.append(VCryptCommonUtil.toVCryptResponseXml(cookieSet.getVCryptResponse()));
    return VCryptCommonUtil.getXmlElement(rootnode_fingerPrintResponse, xmlString).toString();
  }

  static public CookieSet fromXMLFingerPrintResponse(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLFingerPrintResponse() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      if (logger.isDebugEnabled())
        logger.debug("fromXMLFingerPrintResponse() got null xmlString");
      CookieSet cookieSet = new CookieSet(null, null, null);
      return cookieSet.setVCryptResponse(new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "Empty XML."));
    }

    CookieSet retVal = new CookieSet();
    String rootNode = rootnode_fingerPrintResponse;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        CookieSet cookieSet = new CookieSet(null, null, null);
        return cookieSet.setVCryptResponse(new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "Invalid XML."));
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          retVal.setRequestId(valueNode.getNodeValue());
        } else if (nodeName.equalsIgnoreCase(SECURE_COOKIE)) {
          retVal.setSecureCookie(valueNode.getNodeValue());
        } else if (nodeName.equalsIgnoreCase(DIGITAL_COOKIE)) {
          retVal.setDigitalCookie(valueNode.getNodeValue());
        } else if (nodeName.equalsIgnoreCase(VCryptCommonUtil.rootNode_vCryptResponse)) {
          retVal.setVCryptResponse(VCryptCommonUtil.getVCryptResponse(node));
        } else if (!nodeName.startsWith(INVALID_ELEMENT_START)) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return retVal;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      CookieSet cookieSet = new CookieSet(null, null, null);
      return cookieSet.setVCryptResponse(new VCryptResponse(VCryptResponse.UNEXPECTED_ERROR, "Data Error."));
    }
  }

  static public String toXMLUpdateAuthResultRequest(String requestId, Date requestTime, String remoteIPAddr,
                                                    String remoteHost, String secureCookie, String digitalCookie,
                                                    String groupId, String userId, String loginId, boolean isSecure,
                                                    int result, int clientType, String clientVersion,
                                                    int fingerPrintType, String fingerPrint, int fingerPrintType2,
                                                    String fingerPrint2) {

    if (logger.isDebugEnabled())
      logger.debug("toXMLUpdateAuthResultRequest() enter()");
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_TIME, requestTime));
    xmlString.append(VCryptCommonUtil.getXmlElement(USER_ID, userId));
    xmlString.append(VCryptCommonUtil.getXmlElement(LOGIN_ID, loginId));
    xmlString.append(VCryptCommonUtil.getXmlElement(IS_SECURE, isSecure));
    xmlString.append(VCryptCommonUtil.getXmlElement(GROUP_ID, groupId));
    xmlString.append(VCryptCommonUtil.getXmlElement(RESULT, result));
    xmlString.append(VCryptCommonUtil.getXmlElement(SECURE_COOKIE, validateCookie(secureCookie)));
    xmlString.append(VCryptCommonUtil.getXmlElement(DIGITAL_COOKIE, validateCookie(digitalCookie)));
    xmlString.append(VCryptCommonUtil.getXmlElement(CLIENT_TYPE, clientType));
    xmlString.append(VCryptCommonUtil.getXmlElement(CLIENT_VERSION, clientVersion));
    xmlString.append(VCryptCommonUtil.getXmlElement(REMOTE_IPADDR, remoteIPAddr));
    xmlString.append(VCryptCommonUtil.getXmlElement(REMOTE_HOST, remoteHost));
    xmlString.append(VCryptCommonUtil.getXmlElement(FINGER_PRINT_TYPE, fingerPrintType));
    xmlString.append(VCryptCommonUtil.getXmlElement(FINGER_PRINT, fingerPrint));
    xmlString.append(VCryptCommonUtil.getXmlElement(FINGER_PRINT_TYPE2, fingerPrintType2));
    xmlString.append(VCryptCommonUtil.getXmlElement(FINGER_PRINT2, fingerPrint2));
    return VCryptCommonUtil.getXmlElement(rootNode_UpdateAuthResult, xmlString).toString();
  }

  static public Map fromXMLUpdateAuthResultRequest(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLUpdateAuthResultRequest() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLUpdateAuthResultRequest() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = rootNode_UpdateAuthResult;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(REQUEST_TIME)) {
          String value = valueNode.getNodeValue();
          Date dateValue = DateUtil.getDate(value);
          nvList.put(REQUEST_TIME, dateValue);
        } else if (nodeName.equalsIgnoreCase(USER_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(USER_ID, value);
        } else if (nodeName.equalsIgnoreCase(LOGIN_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(LOGIN_ID, value);
        } else if (nodeName.equalsIgnoreCase(IS_SECURE)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(IS_SECURE, Boolean.valueOf(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(GROUP_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(GROUP_ID, value);
        } else if (nodeName.equalsIgnoreCase(RESULT)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(RESULT, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(SECURE_COOKIE)) {
          String value = valueNode.getNodeValue();
          nvList.put(SECURE_COOKIE, value);
        } else if (nodeName.equalsIgnoreCase(DIGITAL_COOKIE)) {
          String value = valueNode.getNodeValue();
          nvList.put(DIGITAL_COOKIE, value);
        } else if (nodeName.equalsIgnoreCase(CLIENT_TYPE)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(CLIENT_TYPE, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(CLIENT_VERSION)) {
          String value = valueNode.getNodeValue();
          nvList.put(CLIENT_VERSION, value);
        } else if (nodeName.equalsIgnoreCase(REMOTE_IPADDR)) {
          String value = valueNode.getNodeValue();
          nvList.put(REMOTE_IPADDR, value);
        } else if (nodeName.equalsIgnoreCase(REMOTE_HOST)) {
          String value = valueNode.getNodeValue();
          nvList.put(REMOTE_HOST, value);
        } else if (nodeName.equalsIgnoreCase(FINGER_PRINT_TYPE)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(FINGER_PRINT_TYPE, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(FINGER_PRINT)) {
          String value = valueNode.getNodeValue();
          nvList.put(FINGER_PRINT, value);
        } else if (nodeName.equalsIgnoreCase(FINGER_PRINT_TYPE2)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(FINGER_PRINT_TYPE2, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(FINGER_PRINT2)) {
          String value = valueNode.getNodeValue();
          nvList.put(FINGER_PRINT2, value);
        } else if (!nodeName.startsWith(INVALID_ELEMENT_START)) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  }

  static public String toXMLTransactionLogRequest(String requestId, Date requestTime, Integer transactionStatus,
                                                  Map[] contextMap) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLTransactionLogRequest() enter() requestId=" + requestId);

    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_TIME, requestTime));
    xmlString.append(VCryptCommonUtil.getXmlElement(STATUS, transactionStatus));
    if (contextMap != null) {
      for (int i = 0; i < contextMap.length; i++) {
        if (contextMap[i] != null) {
          xmlString.append("<contexts>");
          Iterator iter = contextMap[i].keySet().iterator();
          while (iter.hasNext()) {
            String name = (String)iter.next();
            String value = (String)contextMap[i].get(name);
            if (value != null) {
              xmlString.append("<context>");
              xmlString.append(VCryptCommonUtil.getXmlElement("name", name));
              xmlString.append(VCryptCommonUtil.getXmlElement("value", value));
              xmlString.append("</context>");
            }
          }
          xmlString.append("</contexts>");
        }
      }
    }
    return VCryptCommonUtil.getXmlElement(rootNode_TransactionLog, xmlString).toString();
  }

  static public Map fromXMLTransationLogRequest(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLTransactionLogRequest() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLTransactionLogRequest() got null xmlString");
      return null;
    }

    HashMap retVal = new HashMap();
    String rootNode = rootNode_TransactionLog;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      ArrayList contextList = new ArrayList();
      retVal.put("contextList", contextList);
      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          retVal.put(REQUEST_ID, valueNode.getNodeValue());
        } else if (nodeName.equalsIgnoreCase(REQUEST_TIME)) {
          String value = valueNode.getNodeValue();
          Date dateValue = DateUtil.getDate(value);
          retVal.put(REQUEST_TIME, dateValue);
        } else if (nodeName.equalsIgnoreCase(STATUS)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            retVal.put(STATUS, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(PROFILE_TYPE_LIST)) {
          ArrayList profileTypeList = new ArrayList();
          NodeList profileTypeNodeList = node.getChildNodes();
          for (int r = 0; r < profileTypeNodeList.getLength(); r++) {
            Node profileTypeNode = profileTypeNodeList.item(r);
            String profileTypeNodeName = profileTypeNode.getNodeName();
            Node valueProfileTypeNode = profileTypeNode.getFirstChild();
            if (valueProfileTypeNode == null) {
              continue;
            }
            if (profileTypeNodeName.equalsIgnoreCase(PROFILE_TYPE)) {
              profileTypeList.add(new Integer(valueProfileTypeNode.getNodeValue().trim()));
            } else if (!profileTypeNodeName.startsWith(INVALID_ELEMENT_START)) {
              logger.error("Invalid element name <" + profileTypeNodeName + "> in profileTypeList element xml " +
                           xmlString, new Throwable().fillInStackTrace());
            }
          }
          retVal.put(PROFILE_TYPE_LIST, profileTypeList);
        } else if (nodeName.equalsIgnoreCase(CONTEXTS)) {
          HashMap contexts = new HashMap();
          //Lets the the metriceter element
          NodeList contextsNode = node.getChildNodes();
          for (int p = 0; p < contextsNode.getLength(); p++) {
            Node context = contextsNode.item(p);
            String contextName = context.getNodeName();
            Node valueContext = context.getFirstChild();
            if (valueContext == null) {
              continue;
            }
            if (contextName.equalsIgnoreCase(CONTEXT)) {
              //Lets the name value
              String name = null;
              String value = null;
              NodeList contextNVList = context.getChildNodes();
              for (int n = 0; n < contextNVList.getLength(); n++) {
                Node nv = contextNVList.item(n);
                String nvName = nv.getNodeName();
                Node valueNv = nv.getFirstChild();
                if (valueNv == null) {
                  continue;
                }
                if (nvName.equalsIgnoreCase(NAME)) {
                  name = valueNv.getNodeValue();
                } else if (nvName.equalsIgnoreCase(VALUE)) {
                  value = valueNv.getNodeValue();
                } else if (!nvName.startsWith(INVALID_ELEMENT_START)) {
                  logger.error("Invalid element name <" + nvName + "> in context element xml " + xmlString,
                               new Throwable().fillInStackTrace());
                }
              }
              if (!StringUtil.isEmpty(name) && !StringUtil.isEmpty(value)) {
                contexts.put(name, value);
              }
            } else if (!contextName.startsWith(INVALID_ELEMENT_START)) {
              logger.error("Invalid element name <" + contextName + "> in contexts element xml " + xmlString,
                           new Throwable().fillInStackTrace());
            }
          }
          contextList.add(contexts);
        } else if (!nodeName.startsWith(INVALID_ELEMENT_START)) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return retVal;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  }

  static public String toXMLProcessRulesRequest(String requestId, Long transactionId, String extTransactionId,
                                                Date requestTime, List profileTypeList, Map contexts) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLProcessRulesRequest() enter() requestId=" + requestId);

    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_TIME, requestTime));
    xmlString.append(VCryptCommonUtil.getXmlElement(TRANSACTION_LOG_ID, transactionId));
    xmlString.append(VCryptCommonUtil.getXmlElement(EXT_TRANSACTION_ID, extTransactionId));

    StringBuffer profileTypeBuf = new StringBuffer();
    if (profileTypeList != null) {
      Iterator iter = profileTypeList.iterator();
      while (iter.hasNext())
        profileTypeBuf.append(VCryptCommonUtil.getXmlElement(PROFILE_TYPE, iter.next().toString()));
    }
    xmlString.append(VCryptCommonUtil.getXmlElement(PROFILE_TYPE_LIST, profileTypeBuf));

    StringBuffer contextsBuf = new StringBuffer();
    if (contexts != null) {
      Iterator iter = contexts.keySet().iterator();
      while (iter.hasNext()) {
        String name = (String)iter.next();
        String value = (String)contexts.get(name);
        if (value != null) {
          StringBuffer element = VCryptCommonUtil.getXmlElement(NAME, name);
          element.append(VCryptCommonUtil.getXmlElement(VALUE, value));
          contextsBuf.append(VCryptCommonUtil.getXmlElement(CONTEXT, element));
        }
      }
    }
    xmlString.append(VCryptCommonUtil.getXmlElement(CONTEXTS, contextsBuf));
    return VCryptCommonUtil.getXmlElement(rootNode_processRules, xmlString).toString();
  }

  static public Map fromXMLProcessRulesRequest(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLProcessRulesRequest() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLProcessRulesRequest() got null xmlString");
      return null;
    }

    HashMap retVal = new HashMap();
    String rootNode = rootNode_processRules;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          retVal.put(REQUEST_ID, valueNode.getNodeValue());
        } else if (nodeName.equalsIgnoreCase(TRANSACTION_LOG_ID)) {
          final String string = valueNode.getNodeValue();
          if (string != null)
            retVal.put(TRANSACTION_LOG_ID, Long.valueOf(string));
        } else if (nodeName.equalsIgnoreCase(EXT_TRANSACTION_ID)) {
          retVal.put(EXT_TRANSACTION_ID, valueNode.getNodeValue());
        } else if (nodeName.equalsIgnoreCase(REQUEST_TIME)) {
          String value = valueNode.getNodeValue();
          Date dateValue = DateUtil.getDate(value);
          retVal.put(REQUEST_TIME, dateValue);
        } else if (nodeName.equalsIgnoreCase(PROFILE_TYPE_LIST)) {
          ArrayList profileTypeList = new ArrayList();
          NodeList profileTypeNodeList = node.getChildNodes();
          for (int r = 0; r < profileTypeNodeList.getLength(); r++) {
            Node profileTypeNode = profileTypeNodeList.item(r);
            String profileTypeNodeName = profileTypeNode.getNodeName();
            Node valueProfileTypeNode = profileTypeNode.getFirstChild();
            if (valueProfileTypeNode == null) {
              continue;
            }
            if (profileTypeNodeName.equalsIgnoreCase(PROFILE_TYPE)) {
              profileTypeList.add(new Integer(valueProfileTypeNode.getNodeValue().trim()));
            } else if (!profileTypeNodeName.startsWith(INVALID_ELEMENT_START)) {
              logger.error("Invalid element name <" + profileTypeNodeName + "> in profileTypeList element xml " +
                           xmlString, new Throwable().fillInStackTrace());
            }
          }
          retVal.put(PROFILE_TYPE_LIST, profileTypeList);
        } else if (nodeName.equalsIgnoreCase(CONTEXTS)) {
          Map contexts = new HashMap();
          //Lets the the metriceter element
          NodeList contextsNode = node.getChildNodes();
          for (int p = 0; p < contextsNode.getLength(); p++) {
            Node context = contextsNode.item(p);
            String contextName = context.getNodeName();
            Node valueContext = context.getFirstChild();
            if (valueContext == null) {
              continue;
            }
            if (contextName.equalsIgnoreCase(CONTEXT)) {
              //Lets the name value
              String name = null;
              String value = null;
              NodeList contextNVList = context.getChildNodes();
              for (int n = 0; n < contextNVList.getLength(); n++) {
                Node nv = contextNVList.item(n);
                String nvName = nv.getNodeName();
                Node valueNv = nv.getFirstChild();
                if (valueNv == null) {
                  continue;
                }

                if (nvName.equalsIgnoreCase(NAME)) {
                  name = valueNv.getNodeValue();
                } else if (nvName.equalsIgnoreCase(VALUE)) {
                  value = valueNv.getNodeValue();
                } else if (!nvName.startsWith(INVALID_ELEMENT_START)) {
                  logger.error("Invalid element name <" + nvName + "> in context element xml " + xmlString,
                               new Throwable().fillInStackTrace());
                }
              }
              if (!StringUtil.isEmpty(name) && !StringUtil.isEmpty(value)) {
                contexts.put(name, value);
              }
            } else if (!contextName.startsWith(INVALID_ELEMENT_START)) {
              logger.error("Invalid element name <" + contextName + "> in contexts element xml " + xmlString,
                           new Throwable().fillInStackTrace());
            }
          }
          retVal.put(CONTEXTS, contexts);
        } else if (!nodeName.startsWith(INVALID_ELEMENT_START)) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return retVal;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  }

  static public String toXMLProcessRulesResponse(VCryptRulesResult rulesResult) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLProcessRulesResponse() enter() actionResult=" + rulesResult.getResult());
    StringBuffer xmlBuf = new StringBuffer(500);
    xmlBuf.append(VCryptCommonUtil.getXmlElement(ACTION_RESULT, rulesResult.getResult()));
    List list = rulesResult.getAlertMessageList();
    if (list != null && !list.isEmpty()) {
      StringBuffer buf = new StringBuffer();
      for (int i = 0; i < list.size(); i++) {
        buf.append(VCryptCommonUtil.getXmlElement("Value", list.get(i)));
      }
      xmlBuf.append(VCryptCommonUtil.getXmlElement(ALERT_LIST, buf));
    }
    list = rulesResult.getAllActions();
    if (list != null && !list.isEmpty()) {
      StringBuffer buf = new StringBuffer();
      for (int i = 0; i < list.size(); i++) {
        buf.append(VCryptCommonUtil.getXmlElement("Value", list.get(i)));
      }
      xmlBuf.append(VCryptCommonUtil.getXmlElement(ACTION_LIST, buf));
    }
    xmlBuf.append(VCryptCommonUtil.getXmlElement(RISK_SCORE, rulesResult.getScore()));
    xmlBuf.append(VCryptCommonUtil.getXmlElement(TRANSACTION_LOG_ID, rulesResult.getTransactionLogId()));
    if (rulesResult.getDeviceId() != null) {
      xmlBuf.append(VCryptCommonUtil.getXmlElement(DEVICE_ID, rulesResult.getDeviceId()));
    }
    xmlBuf.append(VCryptCommonUtil.toVCryptResponseXml(rulesResult.getVCryptResponse()));

    Map map = rulesResult.getResultMap();
    if (!map.isEmpty()) {
      Iterator itr = map.keySet().iterator();
      xmlBuf.append("<").append(RUNTIME_RESULT_LIST).append(">");
      while (itr.hasNext()) {
        Integer runtime = (Integer)itr.next();
        VCryptRulesResult result = (VCryptRulesResult)map.get(runtime);
        xmlBuf.append("<").append(RUNTIME_RESULT).append(">");
        xmlBuf.append(VCryptCommonUtil.getXmlElement(RUNTIME, runtime));
        xmlBuf.append(VCryptCommonUtil.getXmlElement(ACTION_RESULT, result.getResult()));
        xmlBuf.append(VCryptCommonUtil.getXmlElement(RISK_SCORE, result.getScore()));
        xmlBuf.append("</").append(RUNTIME_RESULT).append(">");
      }
      xmlBuf.append("</").append(RUNTIME_RESULT_LIST).append(">");
    }
    return VCryptCommonUtil.getXmlElement(PROCESS_RULES_RESPONSE, xmlBuf).toString();
  }

  static public VCryptRulesResult fromXMLProcessRulesResponse(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLProcessRulesResponse() enter()");

    VCryptRulesResultImpl retVal = new VCryptRulesResultImpl();

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLProcessRulesResponse() got null xmlString");
      VCryptResponse response =
        new VCryptResponse(VCryptResponse.UNEXPECTED_ERROR, "Empty response. SOAP call failed. Check for timeout message.");
      retVal.setVCryptResponse(response);
      return retVal;
    }

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(PROCESS_RULES_RESPONSE)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return retVal;
      }

      Map responseMap = new HashMap();
      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(ACTION_RESULT)) {
          retVal.setResult(valueNode.getNodeValue());
        } else if (nodeName.equalsIgnoreCase(ALERT_LIST)) {
          List list = new ArrayList();
          NodeList alertList = node.getChildNodes();
          for (int j = 0; j < alertList.getLength(); j++) {
            Node alertNode = alertList.item(j);
            if (alertNode.getNodeName().equalsIgnoreCase("Value")) {
              list.add(alertNode.getFirstChild().getNodeValue());
            } // value
          } // end for
          retVal.setAlertMessageList(list);
        } else if (nodeName.equalsIgnoreCase(ACTION_LIST)) {
          List list = new ArrayList();
          NodeList actionList = node.getChildNodes();
          for (int j = 0; j < actionList.getLength(); j++) {
            Node actionNode = actionList.item(j);
            if (actionNode.getNodeName().equalsIgnoreCase("Value")) {
              list.add(actionNode.getFirstChild().getNodeValue());
            } // value
          } // end for
          retVal.setAllActions(list);
        } else if (nodeName.equalsIgnoreCase(RUNTIME)) {
          retVal.setRuntimeType(new Integer(valueNode.getNodeValue().trim()));
        } else if (nodeName.equalsIgnoreCase(RISK_SCORE)) {
          retVal.setScore(Integer.parseInt(valueNode.getNodeValue().trim()));
        } else if (nodeName.equalsIgnoreCase(TRANSACTION_LOG_ID)) {
          String nm = valueNode.getNodeValue().trim();
          if (!StringUtil.isEmpty(nm)) {
            retVal.setTransactionLogId(new Long(nm));
          }
        } else if (nodeName.equalsIgnoreCase(DEVICE_ID)) {
          String nm = valueNode.getNodeValue().trim();
          if (!StringUtil.isEmpty(nm)) {
            retVal.setDeviceId(new Long(nm));
          }
        } else if (nodeName.equalsIgnoreCase(RUNTIME_RESULT_LIST)) {
          NodeList runtimeResultList = node.getChildNodes();
          for (int j = 0; j < runtimeResultList.getLength(); j++) {
            Node runtimeResult = runtimeResultList.item(j);
            if (runtimeResult.getNodeName().equalsIgnoreCase(RUNTIME_RESULT)) {
              VCryptRulesResultImpl result = new VCryptRulesResultImpl();
              Integer runtimeType = null;
              NodeList runtimeList = runtimeResult.getChildNodes();
              for (int k = 0; k < runtimeList.getLength(); k++) {
                Node runtime = runtimeList.item(k);
                Node runtimeValueNode = runtime.getFirstChild();
                if (runtime.getNodeName().equalsIgnoreCase(ACTION_RESULT)) {
                  if (runtimeValueNode != null)
                    result.setResult(runtimeValueNode.getNodeValue());
                } else if (runtime.getNodeName().equalsIgnoreCase(RISK_SCORE)) {
                  result.setScore(Integer.parseInt(runtimeValueNode.getNodeValue().trim()));
                } else if (runtime.getNodeName().equalsIgnoreCase(RUNTIME)) {
                  runtimeType = new Integer(Integer.parseInt(runtimeValueNode.getNodeValue().trim()));
                  result.setRuntimeType(runtimeType);
                } else if (runtime.getNodeName().equalsIgnoreCase(TRANSACTION_LOG_ID)) {
                  String nm = runtimeValueNode.getNodeValue().trim();
                  if (!StringUtil.isEmpty(nm)) {
                    result.setTransactionLogId(new Long(nm));
                  }
                } else if (runtime.getNodeName().equalsIgnoreCase(DEVICE_ID)) {
                  String nm = runtimeValueNode.getNodeValue().trim();
                  if (!StringUtil.isEmpty(nm)) {
                    result.setDeviceId(new Long(nm));
                  }
                }
              } // handle untime elements
              if (runtimeType != null)
                responseMap.put(runtimeType, result);
            } // end runtime
          } // end for
        } else if (nodeName.equalsIgnoreCase(VCryptCommonUtil.rootNode_vCryptResponse)) {
          retVal.setVCryptResponse(VCryptCommonUtil.getVCryptResponse(node));
        } else if (!nodeName.startsWith(INVALID_ELEMENT_START)) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }

      if (!responseMap.isEmpty())
        retVal.setResultMap(responseMap);

      return retVal;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return retVal;
    }
  }

  static public String toXMLUpdateAuthStatus(String requestId, Date requestTime, int result, int clientType,
                                             String clientVersion, boolean analyzePatterns) {

    if (logger.isDebugEnabled())
      logger.debug("toXMLUpdateAuthStatus");
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_TIME, requestTime));
    xmlString.append(VCryptCommonUtil.getXmlElement(RESULT, result));
    xmlString.append(VCryptCommonUtil.getXmlElement(CLIENT_TYPE, clientType));
    xmlString.append(VCryptCommonUtil.getXmlElement(CLIENT_VERSION, clientVersion));
    xmlString.append(VCryptCommonUtil.getXmlElement(ANALYZE_PATTERNS, analyzePatterns));
    return VCryptCommonUtil.getXmlElement(rootNode_updateAuthStatus, xmlString).toString();
  }

  static public Map fromXMLUpdateAuthStatus(String xmlString) {

    if (logger.isDebugEnabled())
      logger.debug("fromXMLUpdateAuthStatus");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLUpdateAuthStatus got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = rootNode_updateAuthStatus;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(REQUEST_TIME)) {
          String value = valueNode.getNodeValue();
          Date dateValue = DateUtil.getDate(value);
          nvList.put(REQUEST_TIME, dateValue);
        } else if (nodeName.equalsIgnoreCase(RESULT)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(RESULT, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(CLIENT_TYPE)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(CLIENT_TYPE, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(CLIENT_VERSION)) {
          String value = valueNode.getNodeValue();
          nvList.put(CLIENT_VERSION, value);
        } else if (nodeName.equalsIgnoreCase(ANALYZE_PATTERNS)) {
          String value = valueNode.getNodeValue();
          Boolean patternAnalysys = Boolean.valueOf(value);
          nvList.put(ANALYZE_PATTERNS, patternAnalysys);
        } else if (!nodeName.startsWith(INVALID_ELEMENT_START)) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  } // end fromXMLUpdateAuthStatus

  public static String toXMLUpdateTransactionStatus(String requestId, Date requestTime, long transactionId, int status,
                                                    boolean analyzePatterns) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLUpdateTransactionStatus");
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_TIME, requestTime));
    xmlString.append(VCryptCommonUtil.getXmlElement(TRANSACTION_ID, transactionId));
    xmlString.append(VCryptCommonUtil.getXmlElement(STATUS, status));
    xmlString.append(VCryptCommonUtil.getXmlElement(ANALYZE_PATTERNS, analyzePatterns));
    return VCryptCommonUtil.getXmlElement(rootNode_updateTransactionStatus, xmlString).toString();
  }

  public static String toXMLUpdateTransactionStatus(String requestId, Date requestTime, long transactionId, int status,
                                                    Map[] contextMap, boolean analyzePatterns) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLUpdateTransactionStatus");
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_TIME, requestTime));
    xmlString.append(VCryptCommonUtil.getXmlElement(TRANSACTION_ID, transactionId));
    xmlString.append(VCryptCommonUtil.getXmlElement(STATUS, status));
    xmlString.append(VCryptCommonUtil.getXmlElement(ANALYZE_PATTERNS, analyzePatterns));
    if (contextMap != null) {
      for (int i = 0; i < contextMap.length; i++) {
        if (contextMap[i] != null) {
          xmlString.append("<contexts>");
          Iterator iter = contextMap[i].keySet().iterator();
          while (iter.hasNext()) {
            String name = (String)iter.next();
            String value = (String)contextMap[i].get(name);
            if (value != null) {
              xmlString.append("<context>");
              xmlString.append(VCryptCommonUtil.getXmlElement("name", name));
              xmlString.append(VCryptCommonUtil.getXmlElement("value", value));
              xmlString.append("</context>");
            }
          }
          xmlString.append("</contexts>");
        }
      }
    }
    return VCryptCommonUtil.getXmlElement(rootNode_updateTransactionStatus, xmlString).toString();
  }

  public static Map fromXMLUpdateTransactionStatus(String xmlString) {

    if (logger.isDebugEnabled())
      logger.debug("fromXMLUpdateTransactionStatus");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLUpdateTransactionStatus got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = rootNode_updateTransactionStatus;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      ArrayList contextList = new ArrayList();
      nvList.put("contextList", contextList);
      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(REQUEST_TIME)) {
          String value = valueNode.getNodeValue();
          Date dateValue = DateUtil.getDate(value);
          nvList.put(REQUEST_TIME, dateValue);
        } else if (nodeName.equalsIgnoreCase(TRANSACTION_ID)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(TRANSACTION_ID, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(STATUS)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(STATUS, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(ANALYZE_PATTERNS)) {
          String value = valueNode.getNodeValue();
          Boolean patternAnalysys = Boolean.valueOf(value);
          nvList.put(ANALYZE_PATTERNS, patternAnalysys);
        } else if (nodeName.equalsIgnoreCase(CONTEXTS)) {
          HashMap contexts = new HashMap();
          //Lets the the metriceter element
          NodeList contextsNode = node.getChildNodes();
          for (int p = 0; p < contextsNode.getLength(); p++) {
            Node context = contextsNode.item(p);
            String contextName = context.getNodeName();
            Node valueContext = context.getFirstChild();
            if (valueContext == null) {
              continue;
            }
            if (contextName.equalsIgnoreCase(CONTEXT)) {
              //Lets the name value
              String name = null;
              String value = null;
              NodeList contextNVList = context.getChildNodes();
              for (int n = 0; n < contextNVList.getLength(); n++) {
                Node nv = contextNVList.item(n);
                String nvName = nv.getNodeName();
                Node valueNv = nv.getFirstChild();
                if (valueNv == null) {
                  continue;
                }
                if (nvName.equalsIgnoreCase(NAME)) {
                  name = valueNv.getNodeValue();
                } else if (nvName.equalsIgnoreCase(VALUE)) {
                  value = valueNv.getNodeValue();
                } else if (!nvName.startsWith(INVALID_ELEMENT_START)) {
                  logger.error("Invalid element name <" + nvName + "> in context element xml " + xmlString,
                               new Throwable().fillInStackTrace());
                }
              }
              if (!StringUtil.isEmpty(name) && !StringUtil.isEmpty(value)) {
                contexts.put(name, value);
              }
            } else if (!contextName.startsWith(INVALID_ELEMENT_START)) {
              logger.error("Invalid element name <" + contextName + "> in contexts element xml " + xmlString,
                           new Throwable().fillInStackTrace());
            }
          }
          contextList.add(contexts);
        } else if (!nodeName.startsWith(INVALID_ELEMENT_START)) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  }

  static public String toXMLMarkDeviceSafeRequest(String requestId, boolean isSafe) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLMarkDeviceSafeRequest() enter()");
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append("<MarkDeviceSafeRequest>");
    xmlString.append(VCryptCommonUtil.getXmlElement("requestId", requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement("isSafe", isSafe));
    xmlString.append("</MarkDeviceSafeRequest>");
    return xmlString.toString();
  }

  static public Map fromXMLMarkDeviceSafeRequest(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLMarkDeviceSafeRequest() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLMarkDeviceSafeRequest() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = "MarkDeviceSafeRequest";

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase("requestId")) {
          String value = valueNode.getNodeValue();
          nvList.put("requestId", value);
        } else if (nodeName.equalsIgnoreCase("isSafe")) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put("isSafe", Boolean.valueOf(value.trim()));
          }
        } else if (!nodeName.startsWith("#")) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  }

  static public String toXMLIsDeviceMarkedSafe(String requestId) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLIsDeviceMarkedSafe() enter()");
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append("<IsDeviceMarkedSafe>");
    xmlString.append(VCryptCommonUtil.getXmlElement("requestId", requestId));
    xmlString.append("</IsDeviceMarkedSafe>");
    return xmlString.toString();
  }


  static public Map fromXMLIsDeviceMarkedSafe(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLIsDeviceMarkedSafe() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLIsDeviceMarkedSafe() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = "IsDeviceMarkedSafe";

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase("requestId")) {
          String value = valueNode.getNodeValue();
          nvList.put("requestId", value);
        } else if (!nodeName.startsWith("#")) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  }

  static public String toXMLClearSafeDeviceList(String requestId) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLClearSafeDeviceList() enter()");
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append("<ClearSafeDeviceList>");
    xmlString.append(VCryptCommonUtil.getXmlElement("requestId", requestId));
    xmlString.append("</ClearSafeDeviceList>");
    return xmlString.toString();
  }

  static public Map fromXMLClearSafeDeviceList(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLClearSafeDeviceList() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLClearSafeDeviceList() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = "ClearSafeDeviceList";

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase("requestId")) {
          String value = valueNode.getNodeValue();
          nvList.put("requestId", value);
        } else if (!nodeName.startsWith("#")) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  }

  /**
   * @param cookie cookie Validate
   * @return cookie
   */
  public static String validateCookie(String cookie) {
    if (cookie != null) {
      cookie = cookie.trim();
      if (cookie.length() > truncateCookieLength) {
        logger.info("Cookie=" + cookie + " is greater than " + truncateCookieLength + ", so truncating it");
        cookie = cookie.substring(0, truncateCookieLength);
      } else if (cookie.length() == 0) {
        return null;
      }
    }
    return cookie;
  }

  public static String toXMLProcessPatternAnalysis(String requestId, long transactionId, int status,
                                                   String transactionType) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLProcessPatternAnalysis");
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(TRANSACTION_ID, transactionId));
    xmlString.append(VCryptCommonUtil.getXmlElement(STATUS, status));
    xmlString.append(VCryptCommonUtil.getXmlElement(TRANSACTION_TYPE, transactionType));
    return VCryptCommonUtil.getXmlElement(PROCESS_PATTERN_ANALYSIS, xmlString).toString();
  }

  static public Map fromXMLProcessPatternAnalysis(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLProcessPatternAnalysis");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLProcessPatternAnalysis got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = PROCESS_PATTERN_ANALYSIS;

    try {
      Document document = getDocument(xmlString);

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(TRANSACTION_ID)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(TRANSACTION_ID, new Long(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(STATUS)) {
          String value = valueNode.getNodeValue();
          if (!StringUtil.isEmpty(value)) {
            nvList.put(STATUS, new Integer(value.trim()));
          }
        } else if (nodeName.equalsIgnoreCase(TRANSACTION_TYPE)) {
          String value = valueNode.getNodeValue();
          nvList.put(TRANSACTION_TYPE, value);
        } else if (!nodeName.startsWith(INVALID_ELEMENT_START)) {
          logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  } // end of function fromXMLProcessTransactionAnalyis

  public static Document getDocument(String xmlString)
    throws IOException, SAXException, ParserConfigurationException {
    final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
    return builder.parse(new InputSource(new StringReader(xmlString)));
  }

  public static String toXMLCreateTransactionList(TransactionCreateRequestData[] transactionCreateRequestData) {
    String result = "<CreateTransactionList>";
    for (int i = 0; i < transactionCreateRequestData.length; i++) {
      try {
			result += toXMLCreateTransaction(transactionCreateRequestData[i]);
		} catch (Exception e) {
			result += VCryptCommonUtil.getXmlElement(rootNode_createTransaction, " ");
			logger.error("Exception serializing Transaction " + transactionCreateRequestData[i] + " at index " + i, e);
		}
    }
    return result + "</CreateTransactionList>";
  }

  public static String toXMLCreateTransaction(TransactionCreateRequestData transactionCreateRequestData) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLCreateTransaction");
    StringBuffer xmlString = new StringBuffer(500);
    if (transactionCreateRequestData == null) {
      logger.warn("toXMLCreateTransaction got null transactionCreateRequestData");
      return VCryptCommonUtil.getXmlElement(rootNode_createTransaction, xmlString).toString();
    }
    
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, transactionCreateRequestData.getRequestId()));
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_TIME, transactionCreateRequestData.getRequestTime()));
    xmlString.append(VCryptCommonUtil.getXmlElement(TRANSACTION_KEY,
                                                    transactionCreateRequestData.getTransactionKey()));
    xmlString.append(VCryptCommonUtil.getXmlElement(EXT_TRANSACTION_ID,
                                                    transactionCreateRequestData.getExternalTransactionId()));
    xmlString.append(VCryptCommonUtil.getXmlElement(STATUS, transactionCreateRequestData.getStatus()));
    Boolean shouldAnalyzePatterns = transactionCreateRequestData.shouldAnalyzePatterns();
	 if (shouldAnalyzePatterns != null) xmlString.append(VCryptCommonUtil.getXmlElement(ANALYZE_PATTERNS, shouldAnalyzePatterns));
    Map contextMap = transactionCreateRequestData.getContextMap();
    if (contextMap != null) {
      xmlString.append("<contexts>");
      Iterator iter = contextMap.keySet().iterator();
      while (iter.hasNext()) {
        String name = (String)iter.next();
        String value = (String)contextMap.get(name);
        if (value != null) {
          xmlString.append("<context>");
          xmlString.append(VCryptCommonUtil.getXmlElement("name", name));
          xmlString.append(VCryptCommonUtil.getXmlElement("value", value));
          xmlString.append("</context>");
        }
      }
      xmlString.append("</contexts>");
    }
    return VCryptCommonUtil.getXmlElement(rootNode_createTransaction, xmlString).toString();
  }

  public static TransactionCreateRequestData[] fromXMLCreateTransactionList(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLCreateTransactionList enter()");
    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLCreateTransactionList got null xmlString");
      return null;
    }
    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));
      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase("CreateTransactionList")) {
          root = node;
          break;
        }
      }

      if (root == null) {
        logger.warn("fromXMLCreateTransactionList got null xmlString Invalid Xml Missing: CreateTransactionList, xmlString=" +
                    xmlString);
        return null;
      }

      List updates = new ArrayList();
      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();

        if (nodeName.equalsIgnoreCase(rootNode_createTransaction)) {
          try {
			  TransactionCreateRequestData reqData = fromNodeCreateTransaction(xmlString, node);
			  VCryptResponse response = new VCryptResponse();
			  response.setSuccess(true);
				updates.add(reqData);
			} catch (Exception e) {
			  VCryptResponse response = new VCryptResponse(VCryptResponse.INVALID_DATA, "Transaction data is invalid or null");
			  response.setSuccess(false);
			  TransactionCreateRequestData reqData = new TransactionCreateRequestData(response);
				updates.add(reqData);
				logger.error("Exception deserializing transaction from node " + node.getNodeName() + " at index " + i, e);
			}
        }
      }

      TransactionCreateRequestData[] result = new TransactionCreateRequestData[updates.size()];
      return (TransactionCreateRequestData[])updates.toArray(result);
    } catch (Exception ex) {
      logger.error("fromXMLCreateTransactionList Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  }

  public static TransactionCreateRequestData fromXMLCreateTransaction(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLCreateTransaction enter()");
    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLCreateTransaction got null xmlString");
      return null;
    }

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));
      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode_createTransaction)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        logger.warn("fromXMLCreateTransaction got null xmlString Invalid Xml Missing :" + rootNode_createTransaction +
                    ", xmlString=" + xmlString);
        return null;
      }

      return fromNodeCreateTransaction(xmlString, root);
    } catch (Exception ex) {
      logger.error("fromXMLCreateTransaction Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  } // end fromXMLCreateTransaction

  static TransactionCreateRequestData fromNodeCreateTransaction(String xmlString, Node root)
    throws BharosaException {
    HashMap retVal = new HashMap();
    String requestId = null;
    Date requestTime = null;
    String trxKey = null;
    String extTrxId = null;
    Integer status = null;
    Boolean analyzePatterns = Boolean.valueOf(BharosaConfig.getBoolean(IBharosaConstants.PROP_ANALYZE_TRANSACTION_PATTERNS, false));
    Map contextMap = null;
    ArrayList contextList = new ArrayList();
    retVal.put(VCryptTrackerUtil.CONTEXTS, contextList);
    NodeList nodeList = root.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null)
        continue;

      if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
        requestId = valueNode.getNodeValue();
      } else if (nodeName.equalsIgnoreCase(REQUEST_TIME)) {
        String value = valueNode.getNodeValue();
        Date dateValue = DateUtil.getDate(value);
        requestTime = dateValue;
      } else if (nodeName.equalsIgnoreCase(TRANSACTION_KEY)) {
        String nodeValue = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(nodeValue))
          trxKey = nodeValue;
      } else if (nodeName.equalsIgnoreCase(EXT_TRANSACTION_ID)) {
        String nodeValue = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(nodeValue))
          extTrxId = nodeValue;
      } else if (nodeName.equalsIgnoreCase(STATUS)) {
        String value = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(value))
          status = new Integer(value.trim());
      } else if (nodeName.equalsIgnoreCase(ANALYZE_PATTERNS)) {
         String value = valueNode.getNodeValue();
         if (!StringUtil.isEmpty(value))
           analyzePatterns = Boolean.valueOf(value);
      } else if (nodeName.equalsIgnoreCase(CONTEXTS)) {
        contextMap = new HashMap();
        NodeList contextsNode = node.getChildNodes();
        for (int p = 0; p < contextsNode.getLength(); p++) {
          Node context = contextsNode.item(p);
          String contextName = context.getNodeName();
          Node valueContext = context.getFirstChild();
          if (valueContext == null)
            continue;
          if (contextName.equalsIgnoreCase(CONTEXT)) {
            String name = null;
            String value = null;
            NodeList contextNVList = context.getChildNodes();
            for (int n = 0; n < contextNVList.getLength(); n++) {
              Node nv = contextNVList.item(n);
              String nvName = nv.getNodeName();
              Node valueNv = nv.getFirstChild();
              if (valueNv == null)
                continue;

              if (nvName.equalsIgnoreCase(NAME)) {
                name = valueNv.getNodeValue();
              } else if (nvName.equalsIgnoreCase(VALUE)) {
                value = valueNv.getNodeValue();
              } else if (!nvName.startsWith(INVALID_ELEMENT_START)) {
                logger.error("fromXMLCreateTransaction Invalid element name <" + nvName + "> in context element xml " +
                             xmlString, new Throwable().fillInStackTrace());
              }
            }

            if (!StringUtil.isEmpty(name) && !StringUtil.isEmpty(value))
              contextMap.put(name, value);

          } else if (!contextName.startsWith(INVALID_ELEMENT_START)) {
            logger.error("fromXMLCreateTransaction Invalid element name <" + contextName +
                         "> in contexts element xml " + xmlString, new Throwable().fillInStackTrace());
          }
        }
      } else if (!nodeName.startsWith(INVALID_ELEMENT_START)) {
        logger.error("fromXMLCreateTransaction Invalid element name <" + nodeName + "> in xml " + xmlString,
                     new Throwable().fillInStackTrace());
      }
    }
    return new TransactionCreateRequestData(requestId, requestTime, trxKey, extTrxId, status, contextMap, analyzePatterns);
  }

  public static String toXMLUpdateTransactionList(TransactionUpdateRequestData[] transactionUpdateRequestData) {
    String result = "<UpdateTransactionList>";
    for (int i = 0; i < transactionUpdateRequestData.length; i++) {
      try {
			result += toXMLUpdateTransaction(transactionUpdateRequestData[i]);
		} catch (Exception e) {
			result += VCryptCommonUtil.getXmlElement(rootNode_createTransaction, " ");
			logger.error("Exception serializing Transaction " + transactionUpdateRequestData[i] + " at index " + i, e);
		}
    }
    return result + "</UpdateTransactionList>";
  }

  public static String toXMLUpdateTransaction(TransactionUpdateRequestData transactionUpdateRequestData) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLUpdateTransaction");
    StringBuffer xmlString = new StringBuffer(500);
    if (transactionUpdateRequestData == null) {
      logger.warn("toXMLUpdateTransaction got null transactionUpdateRequestData");
      return VCryptCommonUtil.getXmlElement(rootNode_updateTransaction, xmlString).toString();
    }
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, transactionUpdateRequestData.getRequestId()));
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_TIME, transactionUpdateRequestData.getRequestTime()));
    xmlString.append(VCryptCommonUtil.getXmlElement(TRANSACTION_ID, transactionUpdateRequestData.getTransactionId()));
    xmlString.append(VCryptCommonUtil.getXmlElement(EXT_TRANSACTION_ID,
                                                    transactionUpdateRequestData.getExternalTransactionId()));
    xmlString.append(VCryptCommonUtil.getXmlElement(STATUS, transactionUpdateRequestData.getStatus()));
    Boolean shouldAnalyzePatterns = transactionUpdateRequestData.shouldAnalyzePatterns();
	 if (shouldAnalyzePatterns != null) xmlString.append(VCryptCommonUtil.getXmlElement(ANALYZE_PATTERNS,
                                                    shouldAnalyzePatterns));
    Map contextMap = transactionUpdateRequestData.getContextMap();
    if (contextMap != null) {
      xmlString.append("<contexts>");
      Iterator iter = contextMap.keySet().iterator();
      while (iter.hasNext()) {
        String name = (String)iter.next();
        String value = (String)contextMap.get(name);
        if (value != null) {
          xmlString.append("<context>");
          xmlString.append(VCryptCommonUtil.getXmlElement("name", name));
          xmlString.append(VCryptCommonUtil.getXmlElement("value", value));
          xmlString.append("</context>");
        }
      }
      xmlString.append("</contexts>");
    }
    return VCryptCommonUtil.getXmlElement(rootNode_updateTransaction, xmlString).toString();
  } // end toXMLUpdateTransaction

  public static TransactionUpdateRequestData[] fromXMLUpdateTransactionList(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLUpdateTransactionList enter()");
    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLUpdateTransactionList got null xmlString");
      return null;
    }
    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));
      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase("UpdateTransactionList")) {
          root = node;
          break;
        }
      }

      if (root == null) {
        logger.warn("fromXMLUpdateTransactionList got null xmlString Invalid Xml Missing: UpdateTransactionList, xmlString=" +
                    xmlString);
        return null;
      }

      List updates = new ArrayList();
      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null)
          continue;

        if (nodeName.equalsIgnoreCase(rootNode_updateTransaction)) {
          try {
			  TransactionUpdateRequestData reqData = fromNodeUpdateTransaction(xmlString, node);
			  VCryptResponse response = new VCryptResponse();
			  response.setSuccess(true); 
				updates.add(reqData);
			} catch (Exception e) {			  
			  VCryptResponse response = new VCryptResponse(VCryptResponse.INVALID_DATA, "Transaction data is invalid or null");
			  response.setSuccess(false);
			  TransactionUpdateRequestData reqData = new TransactionUpdateRequestData(response);
			  updates.add(reqData);
				logger.error("Exception deserializing transaction from node " + node.getNodeName() + " at index " + i, e);
			}
        }
      }

      TransactionUpdateRequestData[] result = new TransactionUpdateRequestData[updates.size()];
      return (TransactionUpdateRequestData[])updates.toArray(result);
    } catch (Exception ex) {
      logger.error("fromXMLUpdateTransactionList Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  }

  public static TransactionUpdateRequestData fromXMLUpdateTransaction(String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLUpdateTransaction enter()");
    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLUpdateTransaction got null xmlString");
      return null;
    }
    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));
      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode_updateTransaction)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        logger.warn("fromXMLUpdateTransaction got null xmlString Invalid Xml Missing :" + rootNode_updateTransaction +
                    ", xmlString=" + xmlString);
        return null;
      }

      return fromNodeUpdateTransaction(xmlString, root);
    } catch (Exception ex) {
      logger.error("fromXMLUpdateTransaction Exception while parsing xml =" + xmlString, ex);
      return null;
    }
  } // end fromXMLUpdateTransaction

  static TransactionUpdateRequestData fromNodeUpdateTransaction(String xmlString, Node root)
    throws BharosaException {
    String requestId = null;
    Date requestTime = null;
    Long trxId = null;
    String extTrxId = null;
    Integer status = null;
    Boolean analyzePatterns = Boolean.valueOf(BharosaConfig.getBoolean(IBharosaConstants.PROP_ANALYZE_TRANSACTION_PATTERNS, false));
    HashMap contextMap = null;
    NodeList nodeList = root.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null)
        continue;

      if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
        requestId = valueNode.getNodeValue();
      } else if (nodeName.equalsIgnoreCase(REQUEST_TIME)) {
        String value = valueNode.getNodeValue();
        Date dateValue = DateUtil.getDate(value);
        requestTime = dateValue;
      } else if (nodeName.equalsIgnoreCase(TRANSACTION_ID)) {
        trxId = new Long(valueNode.getNodeValue());
      } else if (nodeName.equalsIgnoreCase(EXT_TRANSACTION_ID)) {
        String nodeValue = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(nodeValue))
          extTrxId = nodeValue;
      } else if (nodeName.equalsIgnoreCase(STATUS)) {
        String value = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(value))
          status = new Integer(value.trim());
      } else if (nodeName.equalsIgnoreCase(ANALYZE_PATTERNS)) {
        String value = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(value))
          analyzePatterns = Boolean.valueOf(value);
      } else if (nodeName.equalsIgnoreCase(CONTEXTS)) {
        contextMap = new HashMap();
        NodeList contextsNode = node.getChildNodes();
        for (int p = 0; p < contextsNode.getLength(); p++) {
          Node context = contextsNode.item(p);
          String contextName = context.getNodeName();
          Node valueContext = context.getFirstChild();
          if (valueContext == null)
            continue;

          if (contextName.equalsIgnoreCase(CONTEXT)) {
            String name = null;
            String value = null;
            NodeList contextNVList = context.getChildNodes();
            for (int n = 0; n < contextNVList.getLength(); n++) {
              Node nv = contextNVList.item(n);
              String nvName = nv.getNodeName();
              Node valueNv = nv.getFirstChild();
              if (valueNv == null)
                continue;

              if (nvName.equalsIgnoreCase(NAME)) {
                name = valueNv.getNodeValue();
              } else if (nvName.equalsIgnoreCase(VALUE)) {
                value = valueNv.getNodeValue();
              } else if (!nvName.startsWith(INVALID_ELEMENT_START)) {
                logger.error("fromXMLUpdateTransaction Invalid element name <" + nvName + "> in context element xml " +
                             xmlString, new Throwable().fillInStackTrace());
              }
            }

            if (!StringUtil.isEmpty(name) && !StringUtil.isEmpty(value))
              contextMap.put(name, value);

          } else if (!contextName.startsWith(INVALID_ELEMENT_START)) {
            logger.error("fromXMLUpdateTransaction Invalid element name <" + contextName +
                         "> in contexts element xml " + xmlString, new Throwable().fillInStackTrace());
          }
        }
      } else if (!nodeName.startsWith(INVALID_ELEMENT_START)) {
        logger.error("fromXMLUpdateTransaction Invalid element name <" + nodeName + "> in xml " + xmlString,
                     new Throwable().fillInStackTrace());
      }
    }

    TransactionUpdateRequestData trxUpdData;
    if (StringUtil.isEmpty(extTrxId))
      trxUpdData =
          new TransactionUpdateRequestData(requestId, requestTime, trxId, status, contextMap, analyzePatterns);
    else
      trxUpdData =
          new TransactionUpdateRequestData(requestId, requestTime, extTrxId, status, contextMap, analyzePatterns);
    return trxUpdData;
  }

  public static String toXMLGetNameValueProfileRequest(String entityType, Long entityId, String requestId) {
    return "<GetNameValueProfileRequest><entityType>" + entityType + "</entityType><entityId>" + entityId +
      "</entityId><requestId>" + LiteXMLUtil.encodeSpecialCharacters(requestId) +
      "</requestId></GetNameValueProfileRequest>";
  }

  public static Map fromXMLGetNameValueProfileReqest(String xmlString) {
    HashMap<String, Object> nvList = new HashMap<String, Object>();
    try {
      DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));
      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase("GetNameValueProfileRequest")) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase("entityType")) {
          String entityType = valueNode.getNodeValue();
          nvList.put("entityType", entityType);
        }
        if (nodeName.equalsIgnoreCase("entityId")) {
          Long entityId = new Long(valueNode.getNodeValue());
          nvList.put("entityId", entityId);
        }
        if (nodeName.equalsIgnoreCase("requestId")) {
          String requestId = LiteXMLUtil.decodeSpecialCharacters(valueNode.getNodeValue());
          nvList.put("requestId", requestId);
        }
      }
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
    return nvList;
  }

  public static Map fromXMLGenerateOTP(final String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLGenerateOTP() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLGenerateOTP() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = rootNode_generateOTP;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null)
        return null;

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(OTP_CHALLENGE_TYPE)) {
          String value = valueNode.getNodeValue();
          nvList.put(OTP_CHALLENGE_TYPE, value);
        } else if (nodeName.equalsIgnoreCase(APPLICATION_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(APPLICATION_ID, value);
        } else {
          logger.error("fromXMLGenerateOTPInvalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("fromXMLGenerateOTPxml =" + xmlString, ex);
      return null;
    }
  }

  public static String toXMLGenerateOTP(final String requestId, final String otpChallengeType, final String appId) {
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(OTP_CHALLENGE_TYPE, otpChallengeType));
    xmlString.append(VCryptCommonUtil.getXmlElement(APPLICATION_ID, appId));
    return VCryptCommonUtil.getXmlElement(rootNode_generateOTP, xmlString).toString();
  }

  public static String toXMLGetOTPCode(final String requestId, final String otpChallengeType, final Boolean overwriteIfExists) {
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(OTP_CHALLENGE_TYPE, otpChallengeType));
    xmlString.append(VCryptCommonUtil.getXmlElement(OVER_WRITE_IF_EXISTS, overwriteIfExists));
    return VCryptCommonUtil.getXmlElement(rootNode_getOTPCode, xmlString).toString();
  }

  public static Map fromXMLGetOTPCode(final String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLGetOTPCode() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLGetOTPCode() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = rootNode_getOTPCode;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null)
        return null;

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(OTP_CHALLENGE_TYPE)) {
          String value = valueNode.getNodeValue();
          nvList.put(OTP_CHALLENGE_TYPE, value);
        } else if (nodeName.equalsIgnoreCase(OVER_WRITE_IF_EXISTS)) {
          String value = valueNode.getNodeValue();
          nvList.put(OVER_WRITE_IF_EXISTS, Boolean.parseBoolean(value));
        } else {
          logger.error("fromXMLGenerateOTPInvalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("fromXMLGenerateOTPxml =" + xmlString, ex);
      return null;
    }
  }

  public static String toXMLValidateOTPCode(final String requestId, final String otpChallengeType, final String otpCode) {
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(OTP_CHALLENGE_TYPE, otpChallengeType));
    xmlString.append(VCryptCommonUtil.getXmlElement(OTP_CODE, otpCode));
    return VCryptCommonUtil.getXmlElement(rootNode_validateOTPCode, xmlString).toString();
  }

  public static Map fromXMLValidateOTPCode(final String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLValiateOTPCode() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLValiateOTPCode() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = rootNode_validateOTPCode;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null)
        return null;

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(OTP_CHALLENGE_TYPE)) {
          String value = valueNode.getNodeValue();
          nvList.put(OTP_CHALLENGE_TYPE, value);
        } else if (nodeName.equalsIgnoreCase(OTP_CODE)) {
          String value = valueNode.getNodeValue();
          nvList.put(OTP_CODE, value);
        } else {
          logger.error("fromXMLGenerateOTPInvalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("fromXMLGenerateOTPxml =" + xmlString, ex);
      return null;
    }
  }
  public static Map fromXMLSearchEntity(final String xmlString){
    if (logger.isDebugEnabled())
      logger.debug("fromXMLSearchEntity() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLSearchEntity() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode =rootNode_searchEntity;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));
      Node root = null;      
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null)
        return null;
      Node node  = root.getFirstChild();
      EntityData entityData= fromXMLEntityData(node);
      nvList.put(rootNode_entityData,entityData);
    } catch (Exception ex) {
      logger.error("fromXMLCreateOrUpdateEntities =" + xmlString, ex);
      return null;
    }
    return nvList;
  }
  public static Map fromXMLCreateOrUpdateEntities(final String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLCreateOrUpdateEntities() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLCreateOrUpdateEntitiese() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode =rootNode_createOrUpdateEntities;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null)
        return null;

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(IS_REPLACE_ENTITY)) {
          String value = valueNode.getNodeValue();
          nvList.put(IS_REPLACE_ENTITY, value);
        } else if (nodeName.equalsIgnoreCase(COMMIT_BATCH_SIZE)) {
          String value = valueNode.getNodeValue();
          nvList.put(COMMIT_BATCH_SIZE, value);
        } else if (nodeName.equalsIgnoreCase(ENTITY_DATA_LIST)){
          EntityData[] entityRequestData = fromXMLEntityDataList(node);
          nvList.put(ENTITY_DATA_LIST,entityRequestData);
        } else {
          logger.error("fromXMLCreateOrUpdateEntities element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("fromXMLCreateOrUpdateEntities =" + xmlString, ex);
      return null;
    }
  }
  public static EntityData[] fromXMLEntityDataList(Node root){
    NodeList nodeList = root.getChildNodes();
    List<EntityData> retList = new ArrayList<EntityData>();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null) {
        continue;
      }
      if (nodeName.equalsIgnoreCase(rootNode_entityData)) {
        EntityData entityData= fromXMLEntityData(node);
        if(entityData!=null)
          retList.add(entityData);
      }
      else{
          logger.error("fromXMLEntityDataList element name <" + nodeName + "> in xml " + root.getNodeName(),
                               new Throwable().fillInStackTrace());
      }
    }
    return (EntityData[])retList.toArray(new EntityData[retList.size()]);
  }
  public static EntityData fromXMLEntityData(Node root){
    Date createTime=null;
    Date updateTime=null;
    String entityName=null; 
    Map<String,String> dataMap = null;
    Map<String,List<Long>> unlinkEntitiesMap= null;
    NodeList nodeList = root.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null) {
        continue;
      }
      if (nodeName.equalsIgnoreCase(CREATE_TIME)) {
       createTime= DateUtil.getDate(valueNode.getNodeValue());
       continue;
      }
      if(nodeName.equalsIgnoreCase(UPDATE_TIME)){
         updateTime = DateUtil.getDate(valueNode.getNodeValue()); 
         continue;
      }
      if(nodeName.equalsIgnoreCase(ENTITY_NAME)){
        entityName = valueNode.getNodeValue(); 
        continue;
      }
      if(nodeName.equalsIgnoreCase("contexts")){
         dataMap = fromXMLDataMap(node);
         continue;
      }
      if(nodeName.equalsIgnoreCase("unlinkEntitiesMap")){
        unlinkEntitiesMap=  fromXMLUnlinkEntitiesMap(node);
        continue;
      }
      else{
          logger.error("fromXMLEntityData element name <" + nodeName + "> in xml " + root.getNodeName(),
                               new Throwable().fillInStackTrace());
      }
    }
    EntityData entityData =null;
    if(entityName!=null && dataMap!=null){
      entityData= new EntityData(entityName,dataMap);
      if(createTime!=null){
        entityData.setCreateTime(createTime);
      }
      if(createTime!=null){
        entityData.setUpdateTime(updateTime);
      }
      if(unlinkEntitiesMap!= null){
        entityData.setUnLinkEntities(unlinkEntitiesMap);
      }
    }
    return entityData;
  }
  public static Map<String,String> fromXMLDataMap(Node root){
    Map<String,String> dataMap= new HashMap<String,String>();
    NodeList nodeList = root.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null) {
        continue;
      }
      if (nodeName.equalsIgnoreCase("context")) {
        String[] nameAndValue = getNameAndValue(node);
        if (nameAndValue[0] != null) {
          dataMap.put(nameAndValue[0], nameAndValue[1]);
        }
      }       
      else{
          logger.error("fromXMLDataMap element name <" + nodeName + "> in xml " + root.getNodeName(),
                               new Throwable().fillInStackTrace());
      }      
    }
    return dataMap;
  }
  public static Map<String,List<Long>> fromXMLUnlinkEntitiesMap(Node root){
    Map<String,List<Long>> unlinkEntitiesMap= new HashMap<String,List<Long>>();
    NodeList nodeList = root.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null) {
        continue;
      }
      if (nodeName.equalsIgnoreCase("unlinkEntity")) {
        Object[] relationshipNameAndEntityList = getRelationshipNameAndEntityList(node);
        if (relationshipNameAndEntityList [0] != null) {
          unlinkEntitiesMap.put(relationshipNameAndEntityList [0].toString(),(List<Long>)relationshipNameAndEntityList [1]);
        }
      }       
      else{
          logger.error("fromXMLDataMap element name <" + nodeName + "> in xml " + root.getNodeName(),
                               new Throwable().fillInStackTrace());
      }      
    }
    return unlinkEntitiesMap;
  }
  public static String toXMLResetOTPCounter(final String requestId, final String otpChallengeType) {
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(OTP_CHALLENGE_TYPE, otpChallengeType));
    return VCryptCommonUtil.getXmlElement(rootNode_resetOTPCounter, xmlString).toString();
  }

  public static Map fromXMLResetOTPCounter(final String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLResetOTPCounter() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLResetOTPCounter() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = rootNode_resetOTPCounter;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null)
        return null;

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(OTP_CHALLENGE_TYPE)) {
          String value = valueNode.getNodeValue();
          nvList.put(OTP_CHALLENGE_TYPE, value);
        } else {
          logger.error("fromXMLResetOTPCounter Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("fromXMLResetOTPCounter xml =" + xmlString, ex);
      return null;
    }
  }

  public static String toXMLIncrementOTPCounter(final String requestId, final String otpChallengeType) {
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(OTP_CHALLENGE_TYPE, otpChallengeType));
    return VCryptCommonUtil.getXmlElement(rootNode_incrementOTPCounter, xmlString).toString();
  }

  public static Map fromXMLIncrementOTPCounter(final String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLIncrementOTPCounter() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLIncrementOTPCounter() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode = rootNode_incrementOTPCounter;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null)
        return null;

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(OTP_CHALLENGE_TYPE)) {
          String value = valueNode.getNodeValue();
          nvList.put(OTP_CHALLENGE_TYPE, value);
        } else {
          logger.error("fromXMLIncrementOTPCounter Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("fromXMLIncrementOTPCounter xml =" + xmlString, ex);
      return null;
    }
  }

  public static String toXMLNameValueProfile(NameValueProfile profile) {
    StringBuffer result =
      new StringBuffer("<NameValueProfile><entityType>").append(profile.getEntityType()).append("</entityType><entityId>").append(profile.getEntityId()).append("</entityId><requestId>").append(LiteXMLUtil.encodeSpecialCharacters(profile.getRequestId())).append("</requestId><response>").append(VCryptCommonUtil.toVCryptResponseXml(profile.getResponse())).append("</response><originalStringValues>");
    for (Iterator iter = profile.getOriginalStringValues().entrySet().iterator(); iter.hasNext(); ) {
      Map.Entry each = (Map.Entry)iter.next();
      result.append("<nameValuePair><name>").append(LiteXMLUtil.encodeSpecialCharacters(String.valueOf(each.getKey()))).append("</name><value>").append(LiteXMLUtil.encodeSpecialCharacters(String.valueOf(each.getValue()))).append("</value></nameValuePair>");
    }
    result.append("</originalStringValues><originalLongValues>");
    for (Iterator iter = profile.getOriginalLongValues().entrySet().iterator(); iter.hasNext(); ) {
      Map.Entry each = (Map.Entry)iter.next();
      result.append("<nameValuePair><name>").append(LiteXMLUtil.encodeSpecialCharacters(String.valueOf(each.getKey()))).append("</name><value>").append(LiteXMLUtil.encodeSpecialCharacters(String.valueOf(each.getValue()))).append("</value></nameValuePair>");
    }
    result.append("</originalLongValues><alteredStringValues>");
    for (Iterator iter = profile.getAlteredStringValues().entrySet().iterator(); iter.hasNext(); ) {
      Map.Entry each = (Map.Entry)iter.next();
      result.append("<nameValuePair><name>").append(LiteXMLUtil.encodeSpecialCharacters(String.valueOf(each.getKey()))).append("</name><value>").append(LiteXMLUtil.encodeSpecialCharacters(String.valueOf(each.getValue()))).append("</value></nameValuePair>");
    }
    result.append("</alteredStringValues><alteredLongValues>");
    for (Iterator iter = profile.getAlteredLongValues().entrySet().iterator(); iter.hasNext(); ) {
      Map.Entry each = (Map.Entry)iter.next();
      result.append("<nameValuePair><name>").append(LiteXMLUtil.encodeSpecialCharacters(String.valueOf(each.getKey()))).append("</name><value>").append(LiteXMLUtil.encodeSpecialCharacters(String.valueOf(each.getValue()))).append("</value></nameValuePair>");
    }
    result.append("</alteredLongValues></NameValueProfile>");
    return result.toString();
  }

  public static NameValueProfile fromXMLNameValueProfile(String xmlString) {
    String entityType = null;
    Long entityId = null;
    String requestId = null;
    VCryptResponse response = null;
    Map originalStrings = new HashMap();
    Map alteredStrings = new HashMap();
    Map originalLongs = new HashMap();
    Map alteredLongs = new HashMap();
    try {
      DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));
      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase("NameValueProfile")) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase("entityType")) {
          entityType = valueNode.getNodeValue();
        }
        if (nodeName.equalsIgnoreCase("entityId") && !StringUtil.isEmpty(valueNode.getNodeValue())) {
          entityId = new Long(valueNode.getNodeValue());
        }
        if (nodeName.equalsIgnoreCase("requestId")) {
          requestId = LiteXMLUtil.decodeSpecialCharacters(valueNode.getNodeValue());
        }
        if (nodeName.equalsIgnoreCase("response")) {
          response = VCryptCommonUtil.getVCryptResponse(valueNode);
        }
        if (nodeName.equalsIgnoreCase("originalStringValues")) {
          readStringValues(node, originalStrings);
        }
        if (nodeName.equalsIgnoreCase("originalLongValues")) {
          readLongValues(node, originalLongs);
        }
        if (nodeName.equalsIgnoreCase("alteredStringValues")) {
          readStringValues(node, alteredStrings);
        }
        if (nodeName.equalsIgnoreCase("alteredLongValues")) {
          readLongValues(node, alteredLongs);
        }
      }
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
    if (StringUtil.isEmpty(entityType) || entityId == null || StringUtil.isEmpty(requestId)) {
      logger.error("Missing required element(s).  entityType=" + entityType + ", entityId=" + entityId +
                   ", requestId=" + requestId + ", xml=" + xmlString);
      return null;
    }
    NameValueProfile profile = new NameValueProfile(entityType, entityId, requestId, originalStrings, originalLongs);
    if (!alteredStrings.isEmpty())
      profile.getAlteredStringValues().putAll(alteredStrings);
    if (!alteredLongs.isEmpty())
      profile.getAlteredLongValues().putAll(alteredLongs);
    if (response != null)
      profile.setResponse(response);
    return profile;
  }
  public static EntityHeader fromXMLEntityHeader(String xmlString) {
    Long entityId =null;
    String entityName = null ;
    String entityKey = null ;
    int entityType = 0;
    Long entityDefId = null;
    Map<String,String> dataMap = new HashMap<String,String>();
    Map<String,List<Long>> linkedEntities = new HashMap<String,List<Long>>();
    try {
      DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));
      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(ENTITY_HEADER)) {
          root = node;
          break;
        }
      }

      if (root == null) {
        return null;
      }

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(ENTITY_TYPE)) {
          entityType = Integer.parseInt(valueNode.getNodeValue());
        }
        if (nodeName.equalsIgnoreCase(ENTITY_NAME)) {
          entityName = valueNode.getNodeValue();
        }
        if (nodeName.equalsIgnoreCase(ENTITY_KEY)){
          entityName = valueNode.getNodeValue();
        }
        if (nodeName.equalsIgnoreCase(ENTITY_ID)) {
          entityId = new Long(valueNode.getNodeValue());
        }
        if (nodeName.equalsIgnoreCase(ENTITY_DEF_ID)) {
          entityDefId = new Long(valueNode.getNodeValue());
        }
        if (nodeName.equalsIgnoreCase(DATA_MAP)) {
          readDataMap(node, dataMap);
        }
        if (nodeName.equalsIgnoreCase(LINKED_ENTITIES_MAP)) {
          readLinkedEntities(node, linkedEntities);
        }
       
      }
    } catch (Exception ex) {
      logger.error("Exception while parsing xml =" + xmlString, ex);
      return null;
    }
    if (entityId == null) {
      logger.error("Missing required element entityId=" + entityId );
      return null;
    }
    EntityHeader entityHeader = new EntityHeader( entityId);
    if (!dataMap.isEmpty())
      entityHeader.setDataMap(dataMap);
    if (!linkedEntities.isEmpty())
      entityHeader.setLinkedEntities(linkedEntities);   
    entityHeader.setEntityType(entityType);
    if(entityName!=null)
      entityHeader.setEntityName(entityName);
    if(entityKey!=null)
      entityHeader.setEntityKey(entityKey);
    if(entityDefId!=null)
      entityHeader.setEntityDefId(entityDefId);
    return entityHeader;
  }
  
  public static String toXMLOTPCode(final String otpCode) {
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(OTP_CODE, otpCode));
    return VCryptCommonUtil.getXmlElement(rootNode_getOTPCode, xmlString).toString();
  }

  public static String fromXMLOTPCode(final String xmlString) {
    String rootNode = rootNode_getOTPCode;
    String value = null;
    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null)
        return null;

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(OTP_CODE)) {
          value = valueNode.getNodeValue();
        } else {
          logger.error("fromXMLOTPCode Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
    } catch (Exception ex) {
      logger.error("fromXMLOTPCode xml =" + xmlString, ex);
    }
    return value;
  }
  
  public static String toXMLOTPValidateResult(final String otpValidationResult) {
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(OTP_VALIDATE_RESULT, otpValidationResult));
    return VCryptCommonUtil.getXmlElement(rootNode_validateOTPCode, xmlString).toString();
  }
  public static String toXMLCreateOrUpdateEntities(VCryptObjectResponse<EntityHeader>[] response){
    StringBuffer xmlString = new StringBuffer(500);
    for(int i= 0; i < response.length; i++){
      response[i].setXmlValue(toXMLEntityHeader(response[i].getObject()));
      xmlString.append(VCryptCommonUtil.toVCryptObjectResponseXml(response[i]));
    }
   return xmlString.toString();
  }
  public static String toXMLSearchEntity(EntityHeader entityHeader){
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(toXMLEntityHeader(entityHeader));
    return xmlString.toString();
  }
  public static String toXMLEntityHeader(EntityHeader entityHeader){
    StringBuffer xmlString = new StringBuffer(500);
    if(entityHeader!=null){
      xmlString.append(VCryptCommonUtil.getXmlElement(ENTITY_ID,entityHeader.getEntityId()));
      xmlString.append(VCryptCommonUtil.getXmlElement(ENTITY_NAME, entityHeader.getEntityName()));
      xmlString.append(VCryptCommonUtil.getXmlElement(ENTITY_TYPE,entityHeader.getEntityType()));
      xmlString.append(VCryptCommonUtil.getXmlElement(ENTITY_DEF_ID,entityHeader.getEntityDefId()));      
      xmlString.append(VCryptCommonUtil.getXmlElement(ENTITY_KEY,entityHeader.getEntityKey())); 
      Map dataMap =entityHeader.getDataMap();
      if (dataMap!= null) {
           xmlString.append("<dataMap>");
           Iterator iter = dataMap.keySet().iterator();
           while (iter.hasNext()) {
             String name = (String)iter.next();
             String value = (String)dataMap.get(name);
             if (value != null) {
               xmlString.append("<context>");
               xmlString.append(VCryptCommonUtil.getXmlElement("name", name));
               xmlString.append(VCryptCommonUtil.getXmlElement("value", value));
               xmlString.append("</context>");
             }
           }
           xmlString.append("</dataMap>");
      }
      Map linkedEntities = entityHeader.getLinkedEntities();
      if (linkedEntities!= null) {
         xmlString.append("<linkedEntitiesMap>");
         Iterator iter = linkedEntities.keySet().iterator();
         while (iter.hasNext()) {
           String relationshipName = (String)iter.next();
           List<Long> unlinkEntitiesList= (List<Long>)linkedEntities.get(relationshipName);
           if (unlinkEntitiesList != null) {
             xmlString.append("<linkedEntity>");
             xmlString.append(VCryptCommonUtil.getXmlElement("relationshipName",relationshipName));
             
             
               Iterator iter1 = unlinkEntitiesList.iterator();
             StringBuffer unlinkEntitiesBuf = new StringBuffer();
             while (iter1.hasNext()){
                 unlinkEntitiesBuf .append(VCryptCommonUtil.getXmlElement(ENTITY_ID, iter1.next().toString()));
             }
             xmlString.append(VCryptCommonUtil.getXmlElement(ENTITY_IDS,unlinkEntitiesBuf));
             xmlString.append("</linkedEntity>");
           }
         }
         xmlString.append("</linkedEntitiesMap>");
       }
    }
    return VCryptCommonUtil.getXmlElement(ENTITY_HEADER, xmlString).toString();
  }
  public static String toXMLCreateOrUpdateEntity(VCryptObjectResponse<EntityHeader> response){
    StringBuffer xmlString = new StringBuffer(500);
    
    return VCryptCommonUtil.getXmlElement(rootNode_createOrUpdateEntities, xmlString).toString();
  }
  public static String fromXMLOTPValidateResult(final String xmlString) {
    String rootNode = rootNode_validateOTPCode;
    String value = null;
    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null)
        return null;

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(OTP_VALIDATE_RESULT)) {
          value = valueNode.getNodeValue();
        } else {
          logger.error("fromXMLOTPCode Invalid element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
    } catch (Exception ex) {
      logger.error("fromXMLOTPCode xml =" + xmlString, ex);
    }
    return value;
  }
  static void readStringValues(Node root, Map map) {
    NodeList nodeList = root.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      if (nodeName.equalsIgnoreCase("nameValuePair")) {
        String[] nameAndValue = getNameAndValue(node);
        if (nameAndValue[0] != null) {
          map.put(nameAndValue[0], nameAndValue[1]);
        }
      }
    }
  }

  static void readLongValues(Node root, Map map) {
    NodeList nodeList = root.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      if (nodeName.equalsIgnoreCase("nameValuePair")) {
        String[] nameAndValue = getNameAndValue(node);
        if (nameAndValue[0] != null) {
          map.put(nameAndValue[0], new Long(nameAndValue[1]));
        }
      }
    }
  }
  static void readDataMap(Node root, Map map) {
    NodeList nodeList = root.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      if (nodeName.equalsIgnoreCase("context")) {
        String[] nameAndValue = getNameAndValue(node);
        if (nameAndValue[0] != null) {
          map.put(nameAndValue[0], nameAndValue[1]);
        }
      }
    }
  }
  static void readLinkedEntities(Node root, Map map) {
    NodeList nodeList = root.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      if (nodeName.equalsIgnoreCase(LINKED_ENTITY)) {
        Object[] nameAndValue = getRelationshipNameAndEntityList(node);
        if (nameAndValue[0] != null) {
          map.put(nameAndValue[0], (List<Long>)(nameAndValue[1]));
        }
      }
    }
  }
  
  static Object[] getRelationshipNameAndEntityList(Node root) {
    Object[] nameAndValue = new Object[2];
    NodeList nodeList = root.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null)
        continue;
      if (nodeName.equalsIgnoreCase("relationshipName")) {
        nameAndValue[0] = valueNode.getNodeValue();
      }
      if (nodeName.equalsIgnoreCase("entityIds")) {
        List<Long> entityIdList= new ArrayList<Long>();
        NodeList entityIdNodeList = node.getChildNodes(); 
        for(int j=0;j< entityIdNodeList.getLength(); j++){
          Node entityIdNode = entityIdNodeList.item(j);
          String entityIdNodeName =entityIdNode.getNodeName();
          Node entityIdValueNode= entityIdNode.getFirstChild();
          if(entityIdValueNode == null){
             continue;
          }
          if(entityIdNodeName.equalsIgnoreCase("entityId")){
            entityIdList.add(new Long(entityIdValueNode.getNodeValue()));    
          }
        }
        nameAndValue[1] = entityIdList;
      }
    }
    return nameAndValue;
  }
  static String[] getNameAndValue(Node root) {
    String[] nameAndValue = new String[2];
    NodeList nodeList = root.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null)
        continue;
      if (nodeName.equalsIgnoreCase("name")) {
        nameAndValue[0] = valueNode.getNodeValue();
      }
      if (nodeName.equalsIgnoreCase("value")) {
        nameAndValue[1] = valueNode.getNodeValue();
      }
    }
    return nameAndValue;
  }
  public static String toXMLSearchEntity(EntityData entityData){
    StringBuffer xmlString =new StringBuffer(500);
    xmlString.append(toXMLEntityData(entityData));
    return VCryptCommonUtil.getXmlElement(rootNode_searchEntity,xmlString).toString();
  }
  public static String toXMLCreateOrUpdateEntities(EntityData[] entityRequestData,boolean isReplaceEntity, int commitBatchSize, String requestId) {
    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(IS_REPLACE_ENTITY, isReplaceEntity));
    xmlString.append(VCryptCommonUtil.getXmlElement(COMMIT_BATCH_SIZE, commitBatchSize));
    xmlString.append(VCryptTrackerUtil.toXMLEntityDataList(entityRequestData));
    return VCryptCommonUtil.getXmlElement(rootNode_createOrUpdateEntities, xmlString).toString();
  }
  public static String toXMLEntityDataList(EntityData[] entityRequestData) {
    StringBuffer xmlString = new StringBuffer(500);
    for (int i = 0; i < entityRequestData.length; i++) {
      xmlString.append(toXMLEntityData(entityRequestData[i]));
    }
    return VCryptCommonUtil.getXmlElement(ENTITY_DATA_LIST,xmlString).toString();
  }
  public static String toXMLEntityData(EntityData entityData) {
      if (logger.isDebugEnabled())
        logger.debug("toXMLEntityData");
      StringBuffer xmlString = new StringBuffer(500);
      xmlString.append(VCryptCommonUtil.getXmlElement(CREATE_TIME, entityData.getCreateTime()));
      xmlString.append(VCryptCommonUtil.getXmlElement(UPDATE_TIME, entityData.getUpdateTime()));
      xmlString.append(VCryptCommonUtil.getXmlElement(ENTITY_NAME,
                                                      entityData.getEntityName()));
      
      Map<String,List<Long>> unLinkEntitiesMap = entityData.getUnLinkEntities();
      if (unLinkEntitiesMap != null) {
        xmlString.append("<unlinkEntitiesMap>");
        Iterator iter = unLinkEntitiesMap.keySet().iterator();
        while (iter.hasNext()) {
          String relationshipName = (String)iter.next();
          List<Long> unlinkEntitiesList= (List<Long>)unLinkEntitiesMap.get(relationshipName);
          if (unlinkEntitiesList != null) {
            xmlString.append("<unlinkEntity>");
            xmlString.append(VCryptCommonUtil.getXmlElement("relationshipName",relationshipName));
            
            
              Iterator iter1 = unlinkEntitiesList.iterator();
            StringBuffer unlinkEntitiesBuf = new StringBuffer();
            while (iter1.hasNext()){
                unlinkEntitiesBuf .append(VCryptCommonUtil.getXmlElement(ENTITY_ID, iter1.next().toString()));
            }
            xmlString.append(VCryptCommonUtil.getXmlElement(ENTITY_IDS,unlinkEntitiesBuf));
            xmlString.append("</unlinkEntity>");
          }
        }
        xmlString.append("</unlinkEntitiesMap>");
      }
      
      Map contextMap = entityData.getEntityDataMap();
      if (contextMap != null) {
        xmlString.append("<contexts>");
        Iterator iter = contextMap.keySet().iterator();
        while (iter.hasNext()) {
          String name = (String)iter.next();
          String value = (String)contextMap.get(name);
          if (value != null) {
            xmlString.append("<context>");
            xmlString.append(VCryptCommonUtil.getXmlElement("name", name));
            xmlString.append(VCryptCommonUtil.getXmlElement("value", value));
            xmlString.append("</context>");
          }
        }
        xmlString.append("</contexts>");
      }
      return VCryptCommonUtil.getXmlElement(rootNode_entityData, xmlString).toString();
    }

  static public String toXMLCreateOAAMSessionRequest(String requestId, Date requestTime, OAAMUserData user, OAAMIPData ip, 
                                            List<OAAMDeviceFingerprintData> cookieList, OAAMSessionData sessionData) {
    if (logger.isDebugEnabled())
      logger.debug("toXMLCreateOAAMSessionRequest() enter: requestId=" + requestId);

    StringBuffer xmlString = new StringBuffer(500);
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_ID, requestId));
    xmlString.append(VCryptCommonUtil.getXmlElement(REQUEST_TIME, requestTime));

    appendUserDataToString(user, xmlString);
    appendIpDataToString(ip, xmlString);
    appendSessionDataToString(sessionData, xmlString);
    appendCookieListToString(cookieList, xmlString);

    return VCryptCommonUtil.getXmlElement(rootNode_createOAAMSession, xmlString).toString();
  }
  
  private static void appendSessionDataToString(OAAMSessionData sessionData, StringBuffer xmlString) {
    if(sessionData != null) {
      xmlString.append("<"+VCryptTrackerUtil.SESSION_DATA+">");
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.STATUS, sessionData.getAuthenticationStatus()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.REGISTER_DEVICE, sessionData.isRegisterDevice()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.CLIENT_APPLICATION, sessionData.getClientApplication()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.CLIENT_TYPE, sessionData.getClientType()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.CLIENT_VERSION, sessionData.getClientVersion()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.ANALYZE_PATTERNS, sessionData.isAnalyzePatterns()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.EXTERNAL_DEVICE_ID, sessionData.getExternalDeviceId()));
      xmlString.append("</"+VCryptTrackerUtil.SESSION_DATA+">");
    }
  }
    
  private static void appendCookieListToString(List<OAAMDeviceFingerprintData> cookieList, StringBuffer xmlString) {      
    if (cookieList != null && cookieList.size() > 0) {
      xmlString.append("<"+VCryptTrackerUtil.COOKIE_LIST+">");
      for (Iterator<OAAMDeviceFingerprintData> it = cookieList.iterator(); it.hasNext(); ) {
        OAAMDeviceFingerprintData fpData = it.next();
        if (fpData != null) {
          xmlString.append("<"+VCryptTrackerUtil.COOKIE_DATA+">");
          xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.COOKIE_TYPE, fpData.getCookieType()));
          xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.COOKIE, fpData.getCookie()));
          xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.FINGER_PRINT, fpData.getFingerprint()));
          xmlString.append("</"+VCryptTrackerUtil.COOKIE_DATA+">");
        }
      }
      xmlString.append("</"+VCryptTrackerUtil.COOKIE_LIST+">");
    }
  }
  
  private static void appendIpDataToString(OAAMIPData ip, StringBuffer xmlString) {
    if (ip != null) {
      xmlString.append("<"+VCryptTrackerUtil.IP_DATA+">");
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.REMOTE_IPADDR, ip.getRemoteIP()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.REMOTE_HOST, ip.getRemoteHost()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.PROXY_IP, ip.getProxyIP()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.PROXY_IP, ip.getProxyIP()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.LONGITUDE, ip.getLongitude()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.LATITUDE, ip.getLatitude()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.LOCATION_ACCURACY, ip.getLocationAccuracy()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.LOCATION_ACCURACY_UNITS, ip.getLocationAccuracyUnits()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.LOCATION_SOURCE_TYPE, ip.getLocationAcquireType()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.LOCATION_ACQUIRE_TIME, ip.getLocationAcquireTime()));
      xmlString.append("</"+VCryptTrackerUtil.IP_DATA+">");
    }
  }

  private static void appendUserDataToString(OAAMUserData user, StringBuffer xmlString)  {
    if (user != null) {
      xmlString.append("<"+VCryptTrackerUtil.USER_DATA+">");
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.LOGIN_ID, user.getLoginName()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.GROUP_ID, user.getGroupName()));
      xmlString.append(VCryptCommonUtil.getXmlElement(VCryptTrackerUtil.USER_ID, user.getUserId()));
      xmlString.append("</"+VCryptTrackerUtil.USER_DATA+">");
    }
  }
  
  public static Map fromXMLCreateOAAMSession(final String xmlString) {
    if (logger.isDebugEnabled())
      logger.debug("fromXMLCreateOAAMSession() enter()");

    if (StringUtil.isEmpty(xmlString)) {
      logger.warn("fromXMLCreateOAAMSession() got null xmlString");
      return null;
    }

    HashMap<String, Object> nvList = new HashMap<String, Object>();
    String rootNode =rootNode_createOAAMSession;

    try {
      final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
      Document document = builder.parse(new InputSource(new StringReader(xmlString)));

      Node root = null;
      NodeList rootList = document.getChildNodes();
      for (int i = 0; i < rootList.getLength(); i++) {
        Node node = rootList.item(i);
        if (node.getNodeName().equalsIgnoreCase(rootNode)) {
          root = node;
          break;
        }
      }

      if (root == null)
        return null;

      NodeList nodeList = root.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
        Node node = nodeList.item(i);
        String nodeName = node.getNodeName();
        Node valueNode = node.getFirstChild();
        if (valueNode == null) {
          continue;
        }
        if (nodeName.equalsIgnoreCase(REQUEST_ID)) {
          String value = valueNode.getNodeValue();
          nvList.put(REQUEST_ID, value);
        } else if (nodeName.equalsIgnoreCase(REQUEST_TIME)) {
          String value = valueNode.getNodeValue();
          Date dateValue = DateUtil.getDate(value);
          nvList.put(REQUEST_TIME, dateValue);
        } else if (nodeName.equalsIgnoreCase(IP_DATA)) {
          // read IP data
          OAAMIPData ipData = fromXMLIpData(node);
          nvList.put(IP_DATA, ipData);
        } else if (nodeName.equalsIgnoreCase(USER_DATA)){
          // read User Data
          OAAMUserData userData = fromXMLUserData(node);
          nvList.put(USER_DATA,userData);
        }  else if (nodeName.equalsIgnoreCase(SESSION_DATA)){
          // read Session Data
          OAAMSessionData sessionData = fromXMLSessionData(node);
          nvList.put(SESSION_DATA,sessionData);
        }  else if (nodeName.equalsIgnoreCase(COOKIE_LIST)){
          // read cookie List
          List<OAAMDeviceFingerprintData> fpDataList = fromXMLCookieList(node);
          nvList.put(COOKIE_LIST,fpDataList);
        } 
        else {
          logger.error("fromXMLCreateOAAMSession element name <" + nodeName + "> in xml " + xmlString,
                       new Throwable().fillInStackTrace());
        }
      }
      return nvList;
    } catch (Exception ex) {
      logger.error("fromXMLCreateOAAMSession =" + xmlString, ex);
      return null;
    }
  }

  public static List<OAAMDeviceFingerprintData> fromXMLCookieList(Node root){
    NodeList nodeList = root.getChildNodes();
    List<OAAMDeviceFingerprintData> retList = new ArrayList<OAAMDeviceFingerprintData>();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null) {
        continue;
      }
      if (nodeName.equalsIgnoreCase(COOKIE_DATA)) {
        OAAMDeviceFingerprintData fpData= fromXMLCookieData(node);
        if(fpData!=null)
          retList.add(fpData);
      }
      else{
          logger.error("fromXMLEntityDataList element name <" + nodeName + "> in xml " + root.getNodeName(),
                               new Throwable().fillInStackTrace());
      }
    }
    return retList;
  }
  public static OAAMDeviceFingerprintData fromXMLCookieData(Node root){
    NodeList nodeList = root.getChildNodes();
    int cookieType = 0;
    String browserCookie = null;
    String flashCookie = null;
    
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null) {
        continue;
      }
      if(nodeName.equalsIgnoreCase(COOKIE_TYPE)){
        String nodeValue = valueNode.getNodeValue();
        try{
        cookieType = StringUtil.isEmpty(nodeValue) ? 0 : Integer.parseInt(nodeValue.trim());
        }
        catch (Exception e) {
          logger.error ("Error parsing cookie type, nodeValue=" + nodeValue, e);
        }
        continue;
      } else if(nodeName.equalsIgnoreCase(COOKIE)){
         flashCookie = valueNode.getNodeValue();
         continue;
      } else if(nodeName.equalsIgnoreCase(FINGER_PRINT)){
          browserCookie = valueNode.getNodeValue();
          continue;
      }
      else{
          logger.error("fromXMLEntityData element name <" + nodeName + "> in xml " + root.getNodeName(),
                               new Throwable().fillInStackTrace());
      }
    }
    OAAMDeviceFingerprintData fpData = null;
    try {
      fpData =
          new OAAMDeviceFingerprintData(cookieType, browserCookie, flashCookie);
    } catch (Exception e) {
      logger.error("fromXMLEntityData OAAMDeviceFingerprintData could not be created",
                           new Throwable().fillInStackTrace());
    }
    return fpData;
  }

  public static OAAMSessionData fromXMLSessionData(Node root){
    NodeList nodeList = root.getChildNodes();
    int authenticationStatus = 0;
    boolean registerDevice = false;
    String clientApplication = null;
    int clientType = 0;
    String clientVersion = null;
    boolean analyzePatterns = false;
    String externalDeviceId = null;
    
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null) {
        continue;
      }
      if(nodeName.equalsIgnoreCase(STATUS)){
        String nodeValue = valueNode.getNodeValue();
        try{
        authenticationStatus = StringUtil.isEmpty(nodeValue) ? 0 : Integer.parseInt(nodeValue.trim());
        }
        catch (Exception e) {
          logger.error ("Error parsing status, nodeValue=" + nodeValue, e);
        }
        continue;
      }
      else if(nodeName.equalsIgnoreCase(REGISTER_DEVICE)){
        String value = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(value))
          registerDevice = Boolean.valueOf(value);
         continue;
      } else if(nodeName.equalsIgnoreCase(CLIENT_APPLICATION)){
          clientApplication = valueNode.getNodeValue();
          continue;
      }
      else if(nodeName.equalsIgnoreCase(CLIENT_TYPE)){
        String nodeValue = valueNode.getNodeValue();
        try{
        clientType = StringUtil.isEmpty(nodeValue) ? 0 : Integer.parseInt(nodeValue.trim());
        }
        catch (Exception e) {
          logger.error ("Error parsing clientType, nodeValue=" + nodeValue, e);
        }
        continue;
      } else if(nodeName.equalsIgnoreCase(CLIENT_VERSION)){
          clientVersion = valueNode.getNodeValue();
          continue;
      } else if(nodeName.equalsIgnoreCase(EXTERNAL_DEVICE_ID)) {
          externalDeviceId = valueNode.getNodeValue();
          continue;
      } else if(nodeName.equalsIgnoreCase(ANALYZE_PATTERNS)){
        String value = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(value))
          analyzePatterns = Boolean.valueOf(value);
         continue;
      }
      else{
          logger.error("fromXMLEntityData element name <" + nodeName + "> in xml " + root.getNodeName(),
                               new Throwable().fillInStackTrace());
      }
    }
    OAAMSessionData sessionData = null;
    try {
      sessionData =
          new OAAMSessionData(authenticationStatus, registerDevice, clientApplication,
                              clientType, clientVersion);
      sessionData.setAnalyzePatterns(analyzePatterns);
      sessionData.setExternalDeviceId(externalDeviceId);
    } catch (Exception e) {
      logger.error("fromXMLEntityData element name could not create SessionData",
                           new Throwable().fillInStackTrace());;
    }
    return sessionData;
  }
  
  public static OAAMUserData fromXMLUserData(Node root){
    NodeList nodeList = root.getChildNodes();

    String loginName = null;
    String groupName = null;
    String userId = null;

    
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null) {
        continue;
      }
      if(nodeName.equalsIgnoreCase(LOGIN_ID)){
          loginName = valueNode.getNodeValue();
          continue;
      }  else if(nodeName.equalsIgnoreCase(GROUP_ID)){
         groupName = valueNode.getNodeValue();
         continue;
      }
      else if(nodeName.equalsIgnoreCase(USER_ID)){
             userId = valueNode.getNodeValue();
             continue;
      }
      else{
          logger.error("fromXMLEntityData element name <" + nodeName + "> in xml " + root.getNodeName(),
                               new Throwable().fillInStackTrace());
      }
    }
    OAAMUserData user = null;
    try {
      user = new OAAMUserData(loginName, groupName, userId);
    } catch (Exception e) {
      logger.error("fromXMLEntityData: Error creating user data", new Throwable().fillInStackTrace());
    }
    return user;
  }
  
  public static OAAMIPData fromXMLIpData(Node root){
    NodeList nodeList = root.getChildNodes();
    
    String remoteIP = null;
    String remoteHost = null;
    String proxyIP = null;
 
    Double longitude = null;
    Double latitude = null;

    Double locationAccuracy = null;
    int locationAccuracyUnits = 0;
    int locationAcquireType = 0;
    Date locationAcquireTime = null;


    
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      String nodeName = node.getNodeName();
      Node valueNode = node.getFirstChild();
      if (valueNode == null) {
        continue;
      }
      if(nodeName.equalsIgnoreCase(REMOTE_IPADDR)){
          remoteIP = valueNode.getNodeValue();
          continue;
      }  else if(nodeName.equalsIgnoreCase(REMOTE_HOST)){
         remoteHost = valueNode.getNodeValue();
         continue;
      }
      else if(nodeName.equalsIgnoreCase(PROXY_IP)){
          proxyIP = valueNode.getNodeValue();
          continue;
      }
      else if(nodeName.equalsIgnoreCase(LONGITUDE)){
        String value = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(value))
          longitude = Double.valueOf(value);
         continue;
      }
      else if(nodeName.equalsIgnoreCase(LATITUDE)){
        String value = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(value))
          latitude = Double.valueOf(value);
         continue;
      }
      else if(nodeName.equalsIgnoreCase(LOCATION_ACCURACY)){
        String value = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(value))
          locationAccuracy = Double.valueOf(value);
         continue;
      }
      else if(nodeName.equalsIgnoreCase(LOCATION_ACCURACY_UNITS)){
        String value = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(value))
          locationAccuracyUnits = Integer.valueOf(value);
         continue;
      }
      else if(nodeName.equalsIgnoreCase(LOCATION_SOURCE_TYPE)){
        String value = valueNode.getNodeValue();
        if (!StringUtil.isEmpty(value))
          locationAcquireType = Integer.valueOf(value);
         continue;
      }
      else if (nodeName.equalsIgnoreCase(LOCATION_ACQUIRE_TIME)) {
          String value = valueNode.getNodeValue();
          locationAcquireTime = DateUtil.getDate(value);
          continue;
      }
      else {
          logger.error("fromXMLEntityData element name <" + nodeName + "> in xml " + root.getNodeName(),
                               new Throwable().fillInStackTrace());
      }
    }
    OAAMIPData ipData= null;
    try {
      ipData = new OAAMIPData(remoteIP, longitude, latitude);
      ipData.setLocationAccuracy(locationAccuracy);
      ipData.setLocationAccuracyUnits(locationAccuracyUnits);
      ipData.setLocationAcquireTime(locationAcquireTime);
      ipData.setLocationAcquireType(locationAcquireType);
      ipData.setProxyIP(proxyIP);
      ipData.setRemoteHost(remoteHost);
    } catch (Exception e) {
      logger.error("fromXMLEntityData : could not create IP Data",
                           new Throwable().fillInStackTrace());
    }
    return ipData;
  }
  
  public static boolean compareValuesBasedOnEnum(Number num1, Number num2, UserDefEnumElement compareEnum) {
    final String funcName = "compareValuesBasedOnEnum():";
    if (logger.isDebugEnabled()) {
      logger.debug(funcName + "num1=" + num1 + ", num2=" + num2 + ", compareEnum=" + compareEnum);
    }
    
    boolean retValue = false;

    if (!(num1 != null && num1 != null) )
    {
      return retValue;
    }
    if (compareEnum == null) {
      return retValue;
    }
    
    if (compareEnum.getStrValue().equalsIgnoreCase("more_than_equal_to")) {
         retValue = num1.floatValue() >= num2.floatValue();
    }
    else if (compareEnum.getStrValue().equalsIgnoreCase("more_than")) {
      retValue = num1.floatValue() > num2.floatValue();
    }
    else if (compareEnum.getStrValue().equalsIgnoreCase("equal_to")) {
      retValue = num1.floatValue() == num2.floatValue();
      
    } 
    else if (compareEnum.getStrValue().equalsIgnoreCase("less_than")) {
      retValue = num1.floatValue() < num2.floatValue();
    }
    else if (compareEnum.getStrValue().equalsIgnoreCase("less_than_equal_to")) {
      retValue = num1.floatValue() <= num2.floatValue();
    }
    else if (compareEnum.getStrValue().equalsIgnoreCase("not_equal_to")) {
      retValue = num1.floatValue() != num2.floatValue();
    }
    
    if (logger.isDebugEnabled()) {
      logger.debug(funcName + ": Exiting, returnValue= " + retValue);
    }
    return retValue;
  }
}

