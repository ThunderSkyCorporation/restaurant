package com.bharosa.vcrypt.tracker.util;

import com.bharosa.vcrypt.common.util.VCryptResponse;

/**
 * This is a bean class which contains the Cookies to be returned to the browser.
 */
public class CookieSet implements java.io.Serializable {

  private String requestId = null;
  private String digitalCookie = null;
  private String secureCookie = null;
  private VCryptResponse reponse = null;

  /**
   * Default constructor which creates an empty shell
   * @exclude Constrcucor not meant for external use
   */
  public CookieSet() {
  }

  /**
   * Constructor which takes all the class attributes as parameters.
   *
   * @param requestId		This it the id for the login session. The same Id should be used for all the calls to
   *                     Bharosa API for the login session.
   * @param flashCookie	The flash cookie
   * @param secureCookie The secure cookie.
   */
  public CookieSet(String requestId, String flashCookie, String secureCookie) {
    this.requestId = requestId;
    this.digitalCookie = flashCookie;
    this.secureCookie = secureCookie;
  }

  /**
   * Returns the digital cookie (used by flash or similar client technology)
   *
   * @return the digital cookie
   */
  public String getDigitalCookie() {
    return digitalCookie;
  }

  /**
   * @deprecated use getDigitalCookie
   * @return the digital cookie
   */
  public String getFlashCookie() {
    return getDigitalCookie();
  }

  /**
   * Returns the new secure / browser cookie to be set on client browser
   *
   * @return the secure cookie
   */
  public String getSecureCookie() {
    return secureCookie;
  }

  /**
   * Returns the requestId, unique id used for each client session
   *
   * @return the requestId
   */
  public String getRequestId() {
    return requestId;
  }

  /**
   * Sets the digital cookie that is used by flash or similar technology on the client side
   *
   * @param digitalCookie the Digital cookie
   */
  public void setDigitalCookie(String digitalCookie) {
    this.digitalCookie = digitalCookie;
  }

  public void setFlashCookie(String flashCookie) {
    setDigitalCookie(flashCookie);
  }

  /**
   * Sets the secure cookie
   *
   * @param secureCookie the Secure Cookie
   */

  public void setSecureCookie(String secureCookie) {
    this.secureCookie = secureCookie;
  }

  /**
   * Sets the requestId
   *
   * @param requestId the RequestId
   */
  public void setRequestId(String requestId) {
    this.requestId = requestId;
  }

  /**
   * Get Response codes
   *
   * Ensure a successful repsonse by calling VCryptResponse.isSuccess()
   * before using this object
   *
   * @return VCryptResponse
   */
  public VCryptResponse getVCryptResponse() {
    return reponse;
  }

  /**
   * @exclude meant for internal usage
   * @param reponse
   * @return
   */
  public CookieSet setVCryptResponse(VCryptResponse reponse) {
    this.reponse = reponse;
    return this;
  }

  /**
   *
   * @return String representation of the object, for logging
   */
  public String toString() {
    return "CookieSet{" + "requestId='" + requestId + "'" +
      ", digitalCookie='" + digitalCookie + "'" + ", secureCookie='" +
      secureCookie + "'" + ", reponse=" + reponse + "}";
  }
}
