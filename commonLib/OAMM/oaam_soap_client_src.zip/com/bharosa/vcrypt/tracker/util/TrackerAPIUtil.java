package com.bharosa.vcrypt.tracker.util;

/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;


import com.bharosa.vcrypt.tracker.intf.VCryptTracker;
import com.bharosa.vcrypt.tracker.intf.VCryptRulesEngine;
import com.bharosa.vcrypt.tracker.intf.VCryptRulesResult;
import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.BharosaPropertyBoolean;
import com.bharosa.common.util.IBharosaConstants;
import com.bharosa.common.util.StringUtil;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * APIs for calling Tracker
 *
 * @author bosco
 */

public class TrackerAPIUtil {
    static Logger logger = Logger.getLogger(TrackerAPIUtil.class);

    static private final Object lock = new Object();
    static private TrackerAPIUtil instance = null;

    static VCryptTracker tracker = null;
    static VCryptRulesEngine rulesEngine = null;

    static boolean createFingerPrintAuto = BharosaConfig.getBoolean("bharosa.client.fingerprint.auto", false);
    static BharosaPropertyBoolean useAuthStatusForPatternAnalysis = new BharosaPropertyBoolean(IBharosaConstants.AUTOLEARN_USE_AUTH_STATUS, false);
    
    static public TrackerAPIUtil getInstance() {
        if (instance == null) {
            synchronized (lock) {
                if (instance == null) {
                    instance = new TrackerAPIUtil();
                }
            }
        }
        if (instance == null) {
            logger.fatal("Error creating TrackerAPIUtil.", new Exception().fillInStackTrace());
        }
        return instance;
    }

    private TrackerAPIUtil() {
        logger.info("Constructing singleton TrackerAPIUtil...");
        //Construct the interfaces
        tracker = VCryptTrackerUtil.getVCryptTrackerInstance();
        rulesEngine = VCryptTrackerUtil.getVCryptRulesEngineInstance();
    }

//    public CookieSet fingerPrintDevice(String requestId, Date requestTime, String remoteIPAddr, String remoteHost, String secureCookie,
//                                       int secureClientType, String secureClientVersion,
//                                       String digitalSigCookie, int digitalClientType,
//                                       String digitalClientVersion, int fingerPrintType,
//                                       String fingerPrint, int fingerPrintType2,
//                                       String fingerPrint2) {
//        return tracker.handleTrackerRequest(requestId, requestTime, remoteIPAddr, remoteHost, secureCookie,
//                secureClientType, secureClientVersion,
//                digitalSigCookie, digitalClientType,
//                digitalClientVersion, fingerPrintType,
//                fingerPrint, fingerPrintType2,
//                fingerPrint2);
//    }

    public CookieSet updateAuthResultAndFingerPrint(String requestId, Date requestTime, String remoteIPAddr, String remoteHost,
                                                    String secureCookie, String digitalCookie, String groupId, String userId,
                                                    String loginId, boolean isSecure, int result,
                                                    int clientType, String clientVersion,
                                                    int fingerPrintType, String fingerPrint,
                                                    int fingerPrintType2, String fingerPrint2) {

        CookieSet cookieSet = tracker.updateLog(requestId, requestTime, remoteIPAddr, remoteHost, secureCookie, digitalCookie, groupId,
                userId, loginId, isSecure, result, clientType, clientVersion, fingerPrintType, fingerPrint,
                fingerPrintType2, fingerPrint2);
        
        //Analyze patterns for auto-learning 
        if (useAuthStatusForPatternAnalysis.getValue()) {
			// this will happen asynchronously
        	tracker.processPatternAnalysis(requestId, 0, result, "auth");
		}
	
        return cookieSet;
        
    }

    public VCryptRulesResult processRules(String requestId, Date requestTime, List runTimeList, Map contextMap) {
        return rulesEngine.processRules(requestId, requestTime, runTimeList, contextMap);
    }

    public CookieSet updateAuthResultAndFingerPrint(String requestId, Date requestTime, String remoteIPAddr,
                                                    String secureCookie, String userId, int result, String fingerPrint) {
        String remoteHost = remoteIPAddr;
        String digitalCookie = null;
        String groupId = "ra";
        String loginId = userId;
        boolean isSecure = false;
        int clientType = 1;
        String clientVersion = "1";
        int fingerPrintType = 1;
        int fingerPrintType2 = 2;
        String fingerPrint2 = null;
        if (createFingerPrintAuto) {
            fingerPrint = getFingerPrintFromUserAgent(fingerPrint);
        }
        return tracker.updateLog(requestId, requestTime, remoteIPAddr, remoteHost, secureCookie, digitalCookie, groupId,
                userId, loginId, isSecure, result, clientType, clientVersion, fingerPrintType, fingerPrint,
                fingerPrintType2, fingerPrint2);
    }

    public String getFingerPrintFromUserAgent(String userAgent) {
        if (StringUtil.isEmpty(userAgent)) {
            return StringUtil.concat(new String[]{"unknown","unknown"});
        }
        String HTTP_HEADER_USER_AGENT = "user-agent";

        return StringUtil.concat(new String[]{HTTP_HEADER_USER_AGENT, userAgent});
    }

    public static enum OTPValidationResult {
      OTP_CODE_MATCHED(0),
      OTP_CODE_NOT_MATCHED(1),
      OTP_CODE_EXPIRED(2),
      OTP_CODE_DOESNOT_EXISTS(3),
      OTP_CODE_INVALIDATED(4)
        ;
      private final int result;
      OTPValidationResult(int result) {
        this.result = result;
      }
      public int getResult() {
        return this.result;
      }
    }
}
