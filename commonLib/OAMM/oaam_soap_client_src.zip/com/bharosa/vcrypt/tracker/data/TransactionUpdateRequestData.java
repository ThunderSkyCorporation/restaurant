package com.bharosa.vcrypt.tracker.data;

import com.bharosa.common.exception.BharosaException;
import com.bharosa.common.util.StringUtil;

import com.bharosa.vcrypt.common.util.VCryptResponse;

import java.util.Date;
import java.util.Map;

public class TransactionUpdateRequestData {
    private String requestId;
    private Date requestTime;
    private Long transactionId;
    private String externalTransactionId;
    private Integer status;
    private Map contextMap;
    private Boolean analyzePatterns;
    private VCryptResponse response;

    /**
     * Transaction Update Request Data
     * @param requestId required to identify the user session
     * @param requestTime request time, if null uses the current time
     * @param transactionId id of the previously created transaction
     * @param status of the transaction
     * @param contextMap data map
     * @throws BharosaException if fails validations
     */
    public TransactionUpdateRequestData(String requestId, Date requestTime, Long transactionId, Integer status, Map contextMap)
            throws BharosaException {
   	 this(requestId, requestTime, transactionId, status, contextMap, null);
    }

    /**
     * Transaction Update Request Data
     * @param requestId required to identify the user session
     * @param requestTime request time, if null uses the current time
     * @param transactionId id of the previously created transaction
     * @param status of the transaction
     * @param contextMap data map
     * @param analyzePatterns if true triggers pattern analysis
     * @throws BharosaException if fails validations
     */
    public TransactionUpdateRequestData(String requestId, Date requestTime, Long transactionId, Integer status, Map contextMap, Boolean analyzePatterns)
            throws BharosaException {
        if (StringUtil.isEmpty(requestId) || transactionId == null)
            throw new BharosaException("Required fields missing " + requestId + ", transactionId=" + transactionId);
        this.requestId = requestId;
        this.requestTime = requestTime;
        this.transactionId = transactionId;
        this.status = status;
        this.contextMap = contextMap;
        this.analyzePatterns = analyzePatterns;
    }
    
    public TransactionUpdateRequestData(VCryptResponse response)  {
      this.response = response;
    }

    /**
     *
     * @param requestId required to identify the user session
     * @param requestTime request time, if null uses the current time
     * @param externalTransactionId external transaction id, should be same as the id provided during transaction creation
     * @param status of the transaction
     * @param contextMap key value map
     * @throws BharosaException if fails validations
     */
    public TransactionUpdateRequestData(String requestId, Date requestTime, String externalTransactionId, Integer status, Map contextMap)
            throws BharosaException {
   	 this(requestId, requestTime, externalTransactionId, status, contextMap, null);
       }

    /**
     *
     * @param requestId required to identify the user session
     * @param requestTime request time, if null uses the current time
     * @param externalTransactionId external transaction id, should be same as the id provided during transaction creation
     * @param status of the transaction
     * @param contextMap key value map
     * @param analyzePatterns if true triggers pattern analysis
     * @throws BharosaException if fails validations
     */
    public TransactionUpdateRequestData(String requestId, Date requestTime, String externalTransactionId, Integer status, Map contextMap, Boolean analyzePatterns)
            throws BharosaException {
        if (StringUtil.isEmpty(requestId) || StringUtil.isEmpty(externalTransactionId))
            throw new BharosaException("Required fields missing " + requestId + ", externalTransactionId=" + externalTransactionId);
        this.requestId = requestId;
        this.requestTime = requestTime;
        this.externalTransactionId = externalTransactionId;
        this.status = status;
        this.contextMap = contextMap;
        this.analyzePatterns = analyzePatterns != null && analyzePatterns.booleanValue();
    }

    public String getRequestId() {
        return requestId;
    }

    public Date getRequestTime() {
        return requestTime;
    }

    public Long getTransactionId() {
        return transactionId;
    }

    public String getExternalTransactionId() {
        return externalTransactionId;
    }

    public Integer getStatus() {
        return status;
    }

    public Map getContextMap() {
        return contextMap;
    }

    public boolean isAnalyzePatterns() {
		return analyzePatterns != null && analyzePatterns.booleanValue();
	}

	public Boolean shouldAnalyzePatterns() {
        return analyzePatterns;
    }

    public String toString() {
        return "requestId=" + requestId + ", requestTime=" + requestTime + ", status=" + status + ", transactionId=" + transactionId
                + ", externalTransactionId=" + externalTransactionId  +",analyzePatterns="+analyzePatterns + ", contextMap size=" + (contextMap == null ? 0 : contextMap.size());
    }

    public void setResponse(VCryptResponse response) {
        this.response = response;
    }

    public VCryptResponse getResponse() {
        return response;
    }
}
