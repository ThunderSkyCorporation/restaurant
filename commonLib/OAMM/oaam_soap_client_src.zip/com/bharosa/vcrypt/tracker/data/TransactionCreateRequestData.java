package com.bharosa.vcrypt.tracker.data;

import com.bharosa.common.exception.BharosaException;
import com.bharosa.common.util.StringUtil;

import com.bharosa.vcrypt.common.util.VCryptResponse;

import java.util.Date;
import java.util.Map;

public class TransactionCreateRequestData {
    
    private String requestId;
    private Date requestTime;
    private String transactionKey;
    private String externalTransactionId;
    private Integer status;
    private Map contextMap;
    private Boolean analyzePatterns;
    private VCryptResponse response;


    /**
     * Data Object to create a Transaction
     * @param requestId required to identify the user session
     * @param requestTime request time, if null uses the current time
     * @param transactionKey required data, key to transaction definition
     * @param externalTransactionId optional, if there is external transaction, can be used to later to update the transaction.
     * @param status status of the transaction can be null
     * @param contextMap context data
     * @throws BharosaException if fails validations
     */
    public TransactionCreateRequestData(String requestId, Date requestTime, String transactionKey, String externalTransactionId, Integer status, Map contextMap) throws BharosaException {
        this(requestId, requestTime, transactionKey, externalTransactionId, status, contextMap, null);
    }

    /**
     * Data Object to create a Transaction
     * @param requestId required to identify the user session
     * @param requestTime request time, if null uses the current time
     * @param transactionKey required data, key to transaction definition
     * @param externalTransactionId optional, if there is external transaction, can be used to later to update the transaction.
     * @param status status of the transaction can be null
     * @param contextMap context data
     * @param analyzePatterns true if patterns should be analyzed
     * @throws BharosaException if fails validations
     */
    public TransactionCreateRequestData(String requestId, Date requestTime, String transactionKey, String externalTransactionId, Integer status, Map contextMap, Boolean analyzePatterns)
            throws BharosaException {
        if (StringUtil.isEmpty(requestId) || StringUtil.isEmpty(transactionKey) || contextMap == null || contextMap.size() == 0 )
            throw new BharosaException("Required fields missing " + requestId + ", transactionKey=" + transactionKey + ", contextMap Empty? "+(contextMap == null || contextMap.size() == 0) );
        this.requestId = requestId;
        this.requestTime = requestTime;
        this.externalTransactionId = externalTransactionId;
        this.transactionKey = transactionKey;
        this.status = status;
        this.contextMap = contextMap;
        this.analyzePatterns = analyzePatterns;
    }
    
    public TransactionCreateRequestData(VCryptResponse response)  {
      this.response = response;
    }

    public String getRequestId() {
        return requestId;
    }

    public Date getRequestTime() {
        return requestTime;
    }

    public Integer getStatus() {
        return status;
    }

    public Map getContextMap() {
        return contextMap;
    }

    public String getTransactionKey() {
        return transactionKey;
    }

    public String getExternalTransactionId() {
        return externalTransactionId;
    }
    
    public Boolean shouldAnalyzePatterns() {
   	 return analyzePatterns;
    }

    public String toString() {
        return "requestId="+requestId +", requestTime=" +requestTime +", status=" +status +", transactionKey=" +transactionKey
                + ", externalTransactionId="+externalTransactionId + ", contextMap size=" + (contextMap  ==null?0:contextMap.size()); 
    }

    public void setResponse(VCryptResponse response) {
        this.response = response;
    }

    public VCryptResponse getResponse() {
        return response;
    }
}
