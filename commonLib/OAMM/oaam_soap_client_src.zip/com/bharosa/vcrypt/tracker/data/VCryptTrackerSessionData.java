package com.bharosa.vcrypt.tracker.data;

import com.bharosa.vcrypt.tracker.intf.VCryptRulesResult;
import com.bharosa.vcrypt.common.util.VCryptResponse;

import java.util.List;
import java.util.Map;

/**
 * Data object for Tracker Session 
 */
public class VCryptTrackerSessionData {
	
	private String requestId;
	private Map responseMap; /* Map of runtime and list of results for runtime*/
	private VCryptResponse respone;


	public VCryptTrackerSessionData(String requestId, Map responseMap) {
		this.requestId = requestId;
		this.responseMap = responseMap;
	}

	/**
	 * @return requestId
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * Get latest rule result for the given runtime.
	 * If the there are multiple results, return the latest result
	 * @param runtime runtime
	 * @return VCryptRulesResult
	 */
	public VCryptRulesResult getRuleResult(Integer runtime) {
		List list = getRuleResultList(runtime);
		return (VCryptRulesResult)list.get(0);
	}

	/**
	 * @param runtime runtime
	 * @return List list of results for the given runtime
	 */
	public List getRuleResultList(Integer runtime) {
		return (List)responseMap.get(runtime);
	}


	public VCryptResponse getRespone() {
		return respone;
	}

	public void setRespone(VCryptResponse respone) {
		this.respone = respone;
	}

	/**
	 * @return true if post auth returned block
	 */
	public boolean isPostAuthBlock() {
		return false;
	}

	/**
	 * @return ture if challenge runrime returned block
	 */
	public boolean isChallengeBlock() {
		return false;
	}

	/**
	 * @param runtime runtime
	 * @return true if returned block
	 */
	public boolean isBlock(Integer runtime) {
		return false;
	}

}

