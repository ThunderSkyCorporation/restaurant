/* $Header: oaam/apps/oaam_core/src/com/bharosa/vcrypt/tracker/transaction/data/EntityHeader.java /main/1 2011/06/08 10:47:37 nagsrini Exp $ */

/* Copyright (c) 2011, Oracle and/or its affiliates. All rights reserved. */

package com.bharosa.vcrypt.tracker.transaction.data;


import java.util.List;
import java.util.Map;
/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jrastogi    03/17/11 - creation
    jrastogi    03/17/11 - Creation
 */

/**
 *  @version $Header: EntityHeader.java 17-mar-2011.00:48:22 jrastogi Exp $
 *  @author  jrastogi
 *  @since   release specific (what release of product did this appear in)
 */

 /**
 * entityId: Id of the created/updated/searched entity
 * dataMap: Map containing the attribute-value pairs of the entity 
 * linkedEntities: Map containing a list of relationship name vs List of linked entityIds
 * entityName: Name of the entity
 * entityKey: Key of the entity
 * entityType: Type of the entity
 * entityDefId: Id for the entity type
**/


public class EntityHeader {
    private Long entityId;
    private Map<String,String> dataMap;
    private Map<String,List<Long>> linkedEntities;
    private String entityName;
    private String entityKey;
    private int entityType; 
    private Long entityDefId;
    
    public EntityHeader(Long entityId){
      this.entityId= entityId;
    }

    public void setEntityid(Long entityId) {
        this.entityId = entityId;
    }

    public Long getEntityId() {
        return entityId;
    }

    public void setDataMap(Map<String, String> dataMap) {
        this.dataMap = dataMap;
    }

    public Map<String, String> getDataMap() {
        return dataMap;
    }

    public void setLinkedEntities(Map<String, List<Long>> linkedEntities) {
        this.linkedEntities = linkedEntities;
    }

    public Map<String, List<Long>> getLinkedEntities() {
        return linkedEntities;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityKey(String entityKey) {
        this.entityKey = entityKey;
    }

    public String getEntityKey() {
        return entityKey;
    }

    public void setEntityType(int entityType) {
        this.entityType = entityType;
    }

    public int getEntityType() {
        return entityType;
    }

    public void setEntityDefId(Long entityDefId) {
        this.entityDefId = entityDefId;
    }

    public Long getEntityDefId() {
        return entityDefId;
    }
}
