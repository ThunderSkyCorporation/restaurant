 package com.bharosa.vcrypt.tracker.transaction.data;

 import java.io.Serializable;

 import java.util.Date;
import java.util.List;
import java.util.Map;
 /* $Header: oaam/apps/oaam_core/src/com/bharosa/vcrypt/tracker/transaction/data/EntityData.java /main/2 2011/06/08 10:47:37 nagsrini Exp $ */

/* Copyright (c) 2011, Oracle and/or its affiliates. All rights reserved. */
 /*
 DESCRIPTION
 <short description of component this file declares/defines>

 PRIVATE CLASSES
 <list of private classes defined - with one-line descriptions>

 NOTES
 <other useful comments, qualifications, etc.>

 MODIFIED (MM/DD/YY)
 jrastogi 02/14/11 - Creation.
 jrastogi 02/14/11 - Creation
 */

 /**
 * @version $Header: EntityData.java 14-feb-2011.04:40:51 jrastogi Exp $
 * @author jrastogi
 * @since release specific (what release of product did this appear in)
 */

 public class EntityData implements Serializable{
 /**
 * createTime: It will be set by client. If the client does not set any value then we will generate createTime using current date
 * updateTime: It will be set by client. If the client does not set any value then we will generate updateTime using current date
 * entityName: Field which uniquely identifies entity type
 * entityDataMap: It contains the key value pairs of entity attributes and their values. The instructions to populate the entityDataMap for variuos use cases are given below with examples:
 * unLinkEntities: It is a map that should contain relationshipName vs List of entityIds of the linked entities to be unlinked for that relationshipName
 
 Instructions to populate entityDataMap:
-----------------------------------------------------
The values in <> are variables.
For all the examples below assume that 'patient' is a type of entity and it is linked to 'address' entity with relationShipNames as billing and shipping.
-----------------------------------------------------
CASE-1:
  To create a simple entity that does not have any related entities

 entityDataMap:
 Key: <attributeName1>      Value: <attributeValue1>
 Key: <attributeName2>      Value: <attributeValue2>
 Key: <attributeName3>      Value: <attributeValue3>

 Example: create a patient entity that does not have any related entity
 entityDataMap:
 Key: first name            Value: Mark
 Key: last name             Value: Henry
 Key: email                 Value: x@y.com
 Key: mobile                Value: 9876543210
--------------------------------------------------------
Case-2:
  To update some attributes of an existing entity using the entityId

 entityDataMap:
 Key: $id$                  Value: <EntityId>
 Key: <attributeName1>      Value: <attributeValue1>
 Key: <attributeName2>      Value: <attributeValue2>

 Example: update the email id of a patient entity with entityId = 101 
 entityDataMap:
 Key: $id$                  Value: 101
 Key: email                 Value: a@b.com
--------------------------------------------------------
Case-3 :
  To erase value of some attributes of an existing entity using the entityId

  entityDataMap:
  Key: $id$                  Value: <EntityId>
  Key: <attributeName1>      Value: 
  Key: <attributeName2>      Value:

  Example: erase the email id of a patient entity with entityId = 101 
  entityDataMap:
  Key: $id$                  Value: 101
  Key: email                 Value: 
  
  isReplaceEntity(In createOrUpdateEntity in VcryptTracker) = true; 
--------------------------------------------------------
Case-4 :
  To create an entity that has related entities with complete data of both top-level entity and related entities, 

  entityDataMap:
  Key: <attributeName1>                             Value: <attributeValue1>
  Key: <attributeName2>                             Value: <attributeValue2>
  Key: <attributeName3>                             Value: <attributeValue3>
  Key: <relationshipName1>.<attributeName1>         Value: <linkedEnt1AttributeValue1>
  Key: <relationshipName1>.<attributeName2>         Value: <linkedEnt1AttributeValue2>
  Key: <relationshipName2>.<attributeName1>         Value: <linkedEnt2AttributeValue1>

  Example: to create a pateint entiy with linked address entities with relationshipNames as shipping and billing
  
  entityDataMap:
  Key: first name                                   Value: Mark
  Key: last name                                    Value: Henry
  Key: email                                        Value: x@y.com
  Key: shipping.addr_line1                          Value: #1, Lex residence
  Key: shipping.addr_line2                          Value: Redmond street
  Key: billing.addr_line1                           Value: #2, Lex residence
---------------------------------------------------------------
Case-5 : 
 To create an entity that has related entities(with multiple instances of single relationships) with complete data of both top-level entity and related entities

  entityDataMap:
  Key: <attributeName1>                                 Value: <attributeValue1>
  Key: <attributeName2>                                 Value: <attributeValue2>
  Key: <attributeName3>                                 Value: <attributeValue3>
  Key: <relationshipName1>[<index1>].<attributeName1>   Value: <linkedEnt1AttributeValue1>
  Key: <relationshipName1>[<index1>].<attributeName2>   Value: <linkedEnt1AttributeValue2>
  Key: <relationshipName1>[<index2>].<attributeName1>   Value: <linkedEnt2AttributeValue1>
  Key: <relationshipName1>[<index2>].<attributeName2>   Value: <linkedEnt2AttributeValue2>
  Key: <relationshipName2>.<attributeName1>             Value: <linkedEnt3AttributeValue1>

  Example: to create a patient entiy with linked address entities with relationshipNames as shipping and billing with two instance of shipping.
  
  entityDataMap:
  Key: first name                                   Value: Mark
  Key: last name                                    Value: Henry
  Key: email                                        Value: x@y.com
  Key: shipping[0].addr_line1                       Value: #1, Lex residence
  Key: shipping[0].addr_line2                       Value: Redmond street
  Key: shipping[1].addr_line1                       Value: #3, Lex residence
  Key: shipping[1].addr_line2                       Value: Redwood street
  Key: billing.addr_line1                           Value: #2, Lex residence
----------------------------------------------------------------
Case-6 : 
 To create an entity that has related entities with complete data of top-level entity and entity Ids of one or more related entities
 
  entityDataMap:
  Key: <attributeName1>                                 Value: <attributeValue1>
  Key: <attributeName2>                                 Value: <attributeValue2>
  Key: <attributeName3>                                 Value: <attributeValue3>
  Key: <relationshipName1>[<index1>].<attributeName1>   Value: <linkedEnt1AttributeValue1>
  Key: <relationshipName1>[<index1>].<attributeName2>   Value: <linkedEnt1AttributeValue2>
  Key: <relationshipName1>[<index2>].$id$               Value: <linkedEnt2EntityId>
  Key: <relationshipName2>.<attributeName1>             Value: <linkedEnt3AttributeValue1>

  Example: to create a patient entity with linked address entities with relationshipNames as shipping and billing with two instance of shipping. One of the shipping address entity already exists with entityId=102
  
  entityDataMap:
  Key: first name                                   Value: Mark
  Key: last name                                    Value: Henry
  Key: email                                        Value: x@y.com
  Key: shipping[0].addr_line1                       Value: #1, Lex residence
  Key: shipping[0].addr_line2                       Value: Redmond street
  Key: shipping[1].$id$                             Value: 102
  Key: billing.addr_line1                           Value: #2, Lex residence
----------------------------------------------------------------
Case-7 :
 To update related entities of an entity with entity Ids of related entities

  entityDataMap:
  Key: <attributeName1>                                 Value: <attributeValue1>
  Key: <attributeName2>                                 Value: <attributeValue2>
  Key: <relationshipName1>.$id$                         Value: <linkedEnt1EntityId>
  Key: <relationshipName1>.<attributeName1>             Value: <linkedEnt1AttributeValue1>
  
  (Note : One can also pass parent entityId instead of attributes for the parent entity here)

  Example: to update the city to 'Chicago' in billing address for patient Mark Henry. The billing address already exists with entityId= 103
  
  entityDataMap:
  Key: first name                                   Value: Mark
  Key: last name                                    Value: Henry
  Key: billing.$id$                                 Value: 103
  Key: billing.city                                 Value: Chicago
------------------------------------------------------------------
Case-8 : 
 Unlink one or more related entities from the parent entity

 unLinkEntities: List of mapId's of relationships to be deleted. The mapIds can be fetched from list of VTEntityOneMap objects returned as linkedEntities in Entity object.

 */
 private static final long serialVersionUID = 1L;
 private Date createTime;
 private Date updateTime;
 private String entityName;
 private Map entityDataMap;
 private Map<String,List<Long>> unLinkEntities;

 public EntityData(Date createTime, Date updateTime, String entityName, Map entityDataMap){
 this.createTime= createTime;
 this.updateTime= updateTime;
 this.entityName= entityName;
 this.entityDataMap= entityDataMap;
 }

 public EntityData( String entityName, Map entityDataMap ){
 this(new Date(), new Date(),entityName,entityDataMap);
 }
 
 public EntityData(Date createTime, Date updateTime, String entityName, Map entityDataMap,Map<String,List<Long>> unLinkEntities){
   this.createTime= createTime;
   this.updateTime= updateTime;
   this.entityName= entityName;
   this.entityDataMap= entityDataMap;
   this.unLinkEntities= unLinkEntities;
 }

 public EntityData( String entityName, Map entityDataMap,Map<String,List<Long>> unLinkEntities ){
   this(new Date(), new Date(),entityName,entityDataMap,unLinkEntities);
 }
 
 public void setUnLinkEntities(Map<String,List<Long>> unLinkEntities) {
   this.unLinkEntities = unLinkEntities;
 }

 public Map<String,List<Long>> getUnLinkEntities() {
     return this.unLinkEntities;
 }
 
 public void setCreateTime(Date createTime) {
 this.createTime = createTime;
 }

 public Date getCreateTime() {
 return createTime;
 }

 public void setUpdateTime(Date updateTime) {
 this.updateTime = updateTime;
 }

 public Date getUpdateTime() {
 return updateTime;
 }

 public void setEntityName(String entityName) {
 this.entityName = entityName;
 }

 public String getEntityName() {
 return entityName;
 }

 public void setEntityDataMap(Map entityDataMap) {
 this.entityDataMap = entityDataMap;
 }

 public Map getEntityDataMap() {
 return entityDataMap;
 }

 public String toString() {
   return "EntityData:" + 
       " entityName [" + this.entityName + "]";
 }
 }
