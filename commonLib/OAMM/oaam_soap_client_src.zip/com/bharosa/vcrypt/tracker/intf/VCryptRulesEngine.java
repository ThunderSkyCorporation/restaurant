package com.bharosa.vcrypt.tracker.intf;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.Map;
import java.util.List;
import java.util.Date;

/**
 * This class provides the interface to process rules.
 */

public interface VCryptRulesEngine {

    public static final String REQ_PROCESS_RULES = "processRules";

    /**
     * This method runs the rules and returns rules result
     *
     * The attribute 'reponse' in VCryptRulesResult returns a success VCryptResponse with no session set by default.
     * The attribute 'alertIdList' is null if the rules fired have no corresponding alerts
     * The 'transactionLogId' attribute is set if the property vcrypt.tracker.rule.process.autoTransactionLog.disable is set to false.
     *
     * @param requestId    Id for the request
     * @param checkpointList List of Integer objects with checkpoints to be run, can't be null or empty
     * @param contextMap   List of name value pairs to be used by the rules
     * @return The <code>VCryptRulesResult</code>
     */
    public VCryptRulesResult processRules(String requestId, List checkpointList, Map contextMap);

    /**
     * This method runs the rules and returns rules result.
     * 
     * The attribute 'reponse' in VCryptRulesResult returns a success VCryptResponse with no session set by default.
     * The attribute 'alertIdList' is null if the rules fired have no corresponding alerts
     * The 'transactionLogId' attribute is set if the property vcrypt.tracker.rule.process.autoTransactionLog.disable is set to false.
     *
     * @param requestId    Id for the request
     * @param requestTime  Time when this rule was run
     * @param checkpointList List of Integer objects with checkpoints to be run, can't be null or empty
     * @param contextMap   List of name value pairs to be used by the rules
     * @return The <code>VCryptRulesResult</code>
     */
    public VCryptRulesResult processRules(String requestId, Date requestTime, List checkpointList, Map contextMap);

    /**
     * This method runs the rules and returns rules result
     *
     * The attribute 'reponse' in VCryptRulesResult returns a success VCryptResponse with no session set by default.
     * The attribute 'alertIdList' is null if the rules fired have no corresponding alerts
     * The 'transactionLogId' attribute is set if the property vcrypt.tracker.rule.process.autoTransactionLog.disable is set to false.
     *
     * @param requestId    Id for the request
     * @param transactionId current transactionId
     * @param extTransactionId external transaction Id, used only when transactionId is null
     * @param requestTime  Time when this rule was run
     * @param checkpointList List of Integer objects with checkpoints to be run, can't be null or empty
     * @param contextMap   List of name value pairs to be used by the rules
     * @return The <code>VCryptRulesResult</code>
     */
    public VCryptRulesResult processRules(String requestId, Long transactionId, String extTransactionId, Date requestTime, List checkpointList, Map contextMap);

}
