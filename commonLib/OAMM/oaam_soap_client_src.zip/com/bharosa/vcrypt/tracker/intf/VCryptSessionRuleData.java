package com.bharosa.vcrypt.tracker.intf;

import com.bharosa.vcrypt.common.util.VCryptResponse;

import java.util.List;
import java.util.Map;

public interface VCryptSessionRuleData {

    /**
     * @return requestId of the session
     */
    String getRequestId();

    /**
     * @return VCryptResponse with error / success status
     */
    VCryptResponse getResponse();

    /**
     * @param runtime runtime
     * @return list of com.bharosa.vcrypt.auth.intf.VCryptRuntimeData
     * response return list is ordered by execution time with recent excecution first
     * @throws RuntimeException if this method is caled when getResponse().isSuccess() is false
     * @see VCryptRuntimeData
     */
    List getRuntimeDataList(Integer runtime);

    Map getRuntimeDataMap();
}
