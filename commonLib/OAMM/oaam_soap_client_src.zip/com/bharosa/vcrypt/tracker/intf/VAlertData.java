package com.bharosa.vcrypt.tracker.intf;

public interface VAlertData {
    Long getId();

    String getMessage();

    String getType();

    String getLevel();
}
