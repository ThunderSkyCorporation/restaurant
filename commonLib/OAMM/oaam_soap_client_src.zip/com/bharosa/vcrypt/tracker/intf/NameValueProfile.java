/* $Header: oaam/apps/oaam_core/src/com/bharosa/vcrypt/tracker/intf/NameValueProfile.java /main/1 2009/12/02 01:00:52 bodurai Exp $ */

/* Copyright (c) 2009, Oracle and/or its affiliates. All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jpdavis     04/06/09 - Creation
 */

/**
 *  @version $Header: oaam/apps/oaam_core/src/com/bharosa/vcrypt/tracker/intf/NameValueProfile.java /main/1 2009/12/02 01:00:52 bodurai Exp $
 *  @author  jpdavis
 *  @since   11g
 */

package com.bharosa.vcrypt.tracker.intf;

import java.io.Serializable;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import com.bharosa.vcrypt.common.util.VCryptResponse;

public class NameValueProfile implements Serializable {
	private static final long	serialVersionUID	= 1L;
	final String entityDefKey;
   final Long extEntityId;
   final String requestId;
   final Map originalStringValues;
   final Map originalLongValues;
   Map alteredStringValues = new LinkedHashMap();
   Map alteredLongValues = new LinkedHashMap();
   
   VCryptResponse response;
   
   public NameValueProfile(String anEntityType, Long anEntityId, String aRequestId, Map stringValues, Map longValues) {
      entityDefKey = anEntityType;
      extEntityId = anEntityId;
      requestId = aRequestId;
      originalStringValues = Collections.unmodifiableMap(stringValues);
      originalLongValues = Collections.unmodifiableMap(longValues);
   }
   public NameValueProfile(Throwable ex) {
      this(new VCryptResponse(VCryptResponse.APPLICATION_ERROR, ex.toString()));
   }

   public NameValueProfile(VCryptResponse aResponse) {
      this(null, null, null, Collections.EMPTY_MAP, Collections.EMPTY_MAP);
      response = aResponse;
   }
   /**
    * Returns the String value associated with this name.
    * @param aName
    * @return String
    */
   public String getValue(String aName) {
      if (alteredStringValues.containsKey(aName)) return (String) alteredStringValues.get(aName);
      return (String) originalStringValues.get(aName);
   }
   /**
    * Returns the Long value associated with this name.
    * @param aName
    * @return Long
    */
   public Long getLongValue(String aName) {
      if (alteredLongValues.containsKey(aName))
         return (Long) alteredLongValues.get(aName);
      return (Long) originalLongValues.get(aName);
   }
   /**
    * Sets the new value for this name.
    * @param aName
    * @param aValue
    * @return the old value, or null if previously unset.
    */
   public String setValue(String aName, String aValue) {
      String oldValue = (String) alteredStringValues.put(aName, aValue);
      if (oldValue == null) oldValue = (String) originalStringValues.get(aName);
      return oldValue;
   }
   /**
    * Sets the new value for this name.
    * @param aName
    * @param aValue
    * @return the old value, or null if previously unset.
    */
   public Long setLongValue(String aName, Long aValue) {
      Long oldValue = (Long) alteredLongValues.put(aName, aValue);
      if (oldValue == null)
         oldValue = (Long) originalLongValues.get(aName);
      return oldValue;
   }
   public String toString() {
      Map mergedValues = new LinkedHashMap();
      mergedValues.putAll(originalStringValues);
      mergedValues.putAll(alteredStringValues);
      mergedValues.putAll(originalLongValues);
      mergedValues.putAll(alteredLongValues);
      return "Profile {Entity["+ entityDefKey + "," + extEntityId + "], Request[" + requestId + "], Values=" + mergedValues + "}";
   }

   public String getEntityType() {
      return entityDefKey;
   }

   public Long getEntityId() {
      return extEntityId;
   }

   public String getRequestId() {
      return requestId;
   }

   public void setResponse(VCryptResponse response) {
      this.response = response;
   }

   public VCryptResponse getResponse() {
      return response;
   }

   public Map getOriginalStringValues() {
      return originalStringValues;
   }

   public Map getOriginalLongValues() {
      return originalLongValues;
   }

   public Map getAlteredStringValues() {
      return alteredStringValues;
   }

   public Map getAlteredLongValues() {
      return alteredLongValues;
   }
}
