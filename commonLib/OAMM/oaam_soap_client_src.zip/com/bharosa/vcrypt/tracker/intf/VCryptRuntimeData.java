package com.bharosa.vcrypt.tracker.intf;

import java.util.List;

public interface VCryptRuntimeData {

    public Integer getRuntime();

    public String getRuntimeName();
    
    public int getFinalScore();

    public List getActionList();

    public List getAlertList();

    public List getRuleDataList();

}
