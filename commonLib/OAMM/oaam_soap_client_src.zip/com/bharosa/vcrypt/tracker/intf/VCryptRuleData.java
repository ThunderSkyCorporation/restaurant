package com.bharosa.vcrypt.tracker.intf;

public interface VCryptRuleData {

    /**
     * @return rule instance name
     */
    public String getRuleInstanceName();

    /**
     * @return rule instance id
     */
    public Long getRuleInstanceId();

    /**
     * @return model Id this rule is part of
     */
    public Long getModelId();

    /**
     * @return name of the model this rule is part of
     */
    public String getModelName();
}
