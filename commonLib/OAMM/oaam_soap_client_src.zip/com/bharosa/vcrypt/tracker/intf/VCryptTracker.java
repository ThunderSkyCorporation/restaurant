package com.bharosa.vcrypt.tracker.intf;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.vcrypt.common.data.OAAMDeviceFingerprintData;
import com.bharosa.vcrypt.common.data.OAAMIPData;
import com.bharosa.vcrypt.common.data.OAAMSessionData;
import com.bharosa.vcrypt.common.data.OAAMUserData;
import com.bharosa.vcrypt.common.util.VCryptBooleanResponse;
import com.bharosa.vcrypt.common.util.VCryptObjectResponse;
import com.bharosa.vcrypt.common.util.VCryptResponse;

import com.bharosa.vcrypt.tracker.util.CookieSet;
import com.bharosa.vcrypt.tracker.data.TransactionUpdateRequestData;
import com.bharosa.vcrypt.tracker.data.TransactionCreateRequestData;

import com.bharosa.vcrypt.tracker.transaction.data.EntityData;

import com.bharosa.vcrypt.tracker.transaction.data.EntityHeader;

import com.bharosa.vcrypt.tracker.util.TrackerAPIUtil;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * This interface provides methods for finger printing the device and also updating the tracker database with
 * authentication status and transaction logs.
 */

public interface VCryptTracker {

  static String REQUEST_TRACKER_INIT = "trackerInit";
  static String REQUEST_UPDATE_TRANSACTION = "updateTransaction";
  static String REQUEST_CREATE_TRANSACTION = "createTransaction";

  /**
   * Initialize or warmup server. Will load necessary caches. Call this method when appserver is first started.
   *
   * @param requestId Request
   * @return VCryptResponse object
   */
  public VCryptResponse init(String requestId);

  /**
   * This creates the signatures required to finger print the device.
   *
   * @param requestId            This it the id for the login session. The same Id should be used for all the calls to
   *                             Bharosa API for the login session.
   * @param remoteIPAddr         The IP from where the request came in. This is extracted from the HTTP request.
   * @param remoteHost           The host name from where the request came in. This is optional.
   * @param secureCookie         The secure cookie. This is passed only if it is received from the browser
   * @param secureClientType     secure cookie client type. This is an enum value defined to identify the client used
   *                             for authentication.
   * @param secureClientVersion  version of the secure cookie client. This is an optional parameter to specify the
   *                             version of the client used.
   * @param digitalCookie        The digital signature cookie. This could be the flash cookie. This parameter is sent
   *                             only it is sent by the browser.
   * @param digitalClientType    digital cookie client type. The type of flash client used. If not available, please
   *                             use the value 0.
   * @param digitalClientVersion version of the digital cookie client. The version of the flash client.
   * @param fingerPrintType      Type of finger printing. The value for defined in the properties file.
   * @param fingerPrint          Finger print. If it is browser characteristics, then the header is parsed into this
   *                             string. This is the name value representation of the browser header information.
   * @param fingerPrintType2     This in case the same request can have multipe finger prints. Like flash request. The
   *                             value is defined in the properties file.
   * @param fingerPrint2         The second finger print value. If it is from the flash, then it is passed as it is.
   *                             This is an optional parameter.
   * @return a <code>CookieSet</code> value
   */
  public CookieSet handleTrackerRequest(String requestId, String remoteIPAddr, String remoteHost, String secureCookie,
                                        int secureClientType, String secureClientVersion, String digitalCookie,
                                        int digitalClientType, String digitalClientVersion, int fingerPrintType,
                                        String fingerPrint, int fingerPrintType2, String fingerPrint2);


  /**
   * This creates the signatures required to finger print the device. This method takes the requestTime as input.
   *
   * @param requestId            This it the id for the request
   * @param requestTime          Time when this request was made. Used by simulator.
   * @param remoteIPAddr         The IP from where the request came in
   * @param remoteHost           The host name from where the request came in
   * @param secureCookie         The secure cookie
   * @param secureClientType     secure cookie client type
   * @param secureClientVersion  version of the secure cookie client
   * @param digitalSigCookie     The digital signature cookie
   * @param digitalClientType    digital cookie client type
   * @param digitalClientVersion version of the digital cookie client
   * @param fingerPrintType      Type of finger printing
   * @param fingerPrint          Finger print
   * @param fingerPrintType2     This in case the same request can have multipe finger prints. Like flash request.
   * @param fingerPrint2         The second finger print value
   * @return a <code>CookieSet</code> value
   */
  public CookieSet handleTrackerRequest(String requestId, Date requestTime, String remoteIPAddr, String remoteHost,
                                        String secureCookie, int secureClientType, String secureClientVersion,
                                        String digitalSigCookie, int digitalClientType, String digitalClientVersion,
                                        int fingerPrintType, String fingerPrint, int fingerPrintType2,
                                        String fingerPrint2);


  /**
   * This creates the signatures required to finger print the device.
   *
   * @param requestId  This it the id for the login session. The same Id should be used for all the calls to Bharosa
   *                   API for the login session.
   * @param contextMap array of contextMap
   * @return VCryptResponse to see if the request is successfully processed.
   * @deprecated Will be removed in future releases, use createTransaction
   * @see #createTransaction(com.bharosa.vcrypt.tracker.data.TransactionCreateRequestData)
   */
  public VCryptResponse handleTransactionLog(String requestId, Map[] contextMap);

  /**
   * This creates the signatures required to finger print the transaction
   *
   * @param requestId   This it the id for the request
   * @param requestTime Time for this transaction
   * @param contextMap  array of context data maps
   * @return VCryptResponse
   * @deprecated Will be removed in future releases, use createTransaction
   * @see #createTransaction(com.bharosa.vcrypt.tracker.data.TransactionCreateRequestData)
   */
  public VCryptResponse handleTransactionLog(String requestId, Date requestTime, Map[] contextMap);

  /**
   * This creates the signatures required to finger print the transaction
   *
   * @param requestId   This it the id for the request
   * @param requestTime Time for this transaction
   * @param status transaction status for this transaction
   * @param contextMap  array of context data maps
   * @return VCryptResponse
   * @deprecated Will be removed in future releases, use createTransaction
   * @see #createTransaction(com.bharosa.vcrypt.tracker.data.TransactionCreateRequestData)
   */
  public VCryptResponse handleTransactionLog(String requestId, Date requestTime, Integer status, Map[] contextMap);

  /**
   * Update given transaction status.
   *
   * @param requestId     Request Identifier
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @return VCryptResponse
   * @deprecated Will be removed in future releases, use updateTransaction
   * @see #updateTransaction(com.bharosa.vcrypt.tracker.data.TransactionUpdateRequestData)
   */
  public VCryptResponse updateTransactionStatus(String requestId, long transactionId, int status);

  /**
   * Update given transaction status.
   * <p>AnalyzePatterns param is used by auto-learning.
   *
   * @param requestId     Request Identifier
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @param analyzePatterns Boolean to indicate if the pattern analysis should be done.
   * <p> When passed in as true the pattern analysis is done for this transaction.
   * @return VCryptResponse
   * @deprecated Will be removed in future releases, use updateTransaction
   * @see #updateTransaction(com.bharosa.vcrypt.tracker.data.TransactionUpdateRequestData)
   */
  public VCryptResponse updateTransactionStatus(String requestId, long transactionId, int status,
                                                boolean analyzePatterns);

  /**
   * Update given transaction status.
   *
   * @param requestId     Request Identifier
   * @param requestTime   Time of the update
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @return VCryptResponse
   * @deprecated Will be removed in future releases, use updateTransaction
   * @see #updateTransaction(com.bharosa.vcrypt.tracker.data.TransactionUpdateRequestData)
   */
  public VCryptResponse updateTransactionStatus(String requestId, Date requestTime, long transactionId, int status);

  /**
   * Update given transaction status.
   *
   * @param requestId     Request Identifier
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @param contextMap array of contextMap
   * @return VCryptResponse
   * @deprecated Will be removed in future releases, use updateTransaction
   * @see #updateTransaction(com.bharosa.vcrypt.tracker.data.TransactionUpdateRequestData)
   */
  public VCryptResponse updateTransactionStatus(String requestId, long transactionId, int status, Map[] contextMap);

  /**
   * Update given transaction status.
   *
   * @param requestId     Request Identifier
   * @param requestTime   Time of the update
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @param contextMap array of contextMap
   * @return VCryptResponse
   * @deprecated Will be removed in future releases, use updateTransaction
   * @see #updateTransaction(com.bharosa.vcrypt.tracker.data.TransactionUpdateRequestData)
   */
  public VCryptResponse updateTransactionStatus(String requestId, Date requestTime, long transactionId, int status,
                                                Map[] contextMap);

  /**
   * Update given transaction status.
   * <p>AnalyzePatterns param is used by auto-learning.
   * @param requestId     Request Identifier
   * @param requestTime   Time of the update
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @param contextMap array of contextMap
   * @param analyzePatterns Boolean to indicate if the pattern analysis should be done.
   * @return VCryptResponse
   * @deprecated Will be removed in future releases, use updateTransaction
   * @see #updateTransaction(com.bharosa.vcrypt.tracker.data.TransactionUpdateRequestData)
   */
  public VCryptResponse updateTransactionStatus(String requestId, Date requestTime, long transactionId, int status,
                                                Map[] contextMap, boolean analyzePatterns);

  /**
   * Updates the user node log. And if required, it creates the CookieSet also.
   *
   * @param requestId          This it the id for the login session. The same Id should be used for all the calls to
   *                           Bharosa API for the login session.
   * @param remoteIPAddr       The IP from where the request came in. This is extracted from the HTTP request.
   * @param remoteHost         The host name from where the request came in. This is optional.
   * @param secureCookie       The secure cookie. This is passed only if it is received from the browser
   * @param digitalCookie      The Digital cookie. Can be flash cookie
   * @param groupId            the groupId of this user. This is the primary group to which this user belongs to.
   * @param userId             id of the user. This is the primary key id of the user. It should be null for user who
   *                           are invalid.
   * @param loginId            the loginId used by the user for login in. This is mandatory parameter.
   * @param isSecure           whether this node is secure and can be registered. This is to indicate the login is
   *                           from a secure or registered device. If there is no concept of device, then send false
   *                           value for this parameter.
   * @param result             The authentication result. This is the enumeration value of the authentication result.
   * @param clientType         This is an enum value defined to identify the client type used for authentication.
   * @param clientVersion      the version of the client. This is an optional parameter to specify the version of the
   *                           client used.
   * @param fingerPrintType    Type of finger printing. The value for defined in the properties file.
   * @param fingerPrint        If it is browser characteristics, then the header is parsed into this string. This is
   *                           the name value representation of the browser header information.
   * @param digFingerPrintType Type of the Digital finger printing
   * @param digFingerPrint     Digital fingerprint
   * @return a <code>CookieSet</code> value
   */
  public CookieSet updateLog(String requestId, String remoteIPAddr, String remoteHost, String secureCookie,
                             String digitalCookie, String groupId, String userId, String loginId, boolean isSecure,
                             int result, int clientType, String clientVersion, int fingerPrintType, String fingerPrint,
                             int digFingerPrintType, String digFingerPrint);

  /**
   * Updates the user node log. And if required, it creates the CookieSet also.
   *
   * @param requestId        requestId for the request
   * @param requestTime      Time when this request was make. Used primarily by the simulator
   * @param remoteIPAddr     The IP from where the request came in
   * @param remoteHost       The host name from where the request came in
   * @param secureCookie     The secure cookie
   * @param digitalCookie    the secure cookie, can be flash cookie
   * @param groupId          the groupId of this user.
   * @param userId           id of the user
   * @param loginId          the loginId used by the user for login in
   * @param isSecure         whether this node is secure and can be registered
   * @param result           The authentication result.
   * @param clientType       the type of the client used for authentication
   * @param clientVersion    the version of the client
   * @param fingerPrintType  Type of finger printing
   * @param fingerPrint      Finger print
   * @param fingerPrintType2 Type of the Digital finger printing
   * @param fingerPrint2     Digital fingerprint
   * @return a <code>CookieSet</code> value
   */
  public CookieSet updateLog(String requestId, Date requestTime, String remoteIPAddr, String remoteHost,
                             String secureCookie, String digitalCookie, String groupId, String userId, String loginId,
                             boolean isSecure, int result, int clientType, String clientVersion, int fingerPrintType,
                             String fingerPrint, int fingerPrintType2, String fingerPrint2);

  /**
   * This function will replace updateLog.
   * It should be used to create OAAM session information.
   * This API should be used only once for creating the OAAM session.
   * If it is used more than one time with the same request number error will be returned.
   *
   * @param requestId requestId for the request. If not populated will be generated in the server and returned in the response.
   * @param requestTime The date-time stamp on the request. (If not populated then will be generated in the server)
   * @param user User Data associated with this session.
   * @param ip IP Address data assocuated with this session.
   * @param fingerprintDataList List of device fingerprints.
   * @param sessionData Session data associated with this session.
   * @return a <code>VCryptObjectResponse</code> that contains <code>CookieSet</code>
   */
  public VCryptObjectResponse<CookieSet> createOAAMSession(String requestId, Date requestTime, OAAMUserData user, OAAMIPData ip, 
                                            List<OAAMDeviceFingerprintData> fingerprintDataList, OAAMSessionData sessionData);

  /**
   * This function will replace the updateAuthStatus method with other signatures.
   * It is used to update the authentication status for the given request.
   * All the params should have valid values for this function to work correctly.
   * @param requestId It is a mandatory attribute and without this being a proper valid value, the function will return error.
   * @param sessionData Session data that needs to be updated for this request.
   * @return Returns a response code based on the results of the processing.
   */
  public VCryptResponse updateAuthStatus(String requestId, OAAMSessionData sessionData);  


  /**
   * Updates User node log auth status
   *
   * @param requestId     request Id
   * @param resultStatus  The authentication result. This is the enumeration value of the authentication result.
   * @param clientType    This is an enum value defined to identify the client type used for authentication.
   * @param clientVersion Optional parameter to specify the version of the client used.
   * @return VCryptResponse
   * @deprecated use updateAuthStatus(String requestId, OAAMSessionData sessionData);  
   */
  public VCryptResponse updateAuthStatus(String requestId, int resultStatus, int clientType, String clientVersion);

  /**
   * Updates User node log auth status
   * <p>AnalyzePatterns param is used by auto-learning.
   * @since 10.1.4.5
   * @param requestId     request Id
   * @param resultStatus  The authentication result. This is the enumeration value of the authentication result.
   * @param clientType    This is an enum value defined to identify the client type used for authentication.
   * @param clientVersion Optional parameter to specify the version of the client used.
   * @param analyzePatterns Boolean to indicate if the pattern analysis should be done.
   * <p> When passed in as true the pattern analysis is done for this transaction.
   * @return VCryptResponse
   */
  public VCryptResponse updateAuthStatus(String requestId, int resultStatus, int clientType, String clientVersion,
                                         boolean analyzePatterns);

  /**
   * Updates User node log auth status
   * <p>AnalyzePatterns param is used by auto-learning.
   * @param requestId    request Id
   * @param requestTime  Time of update
   * @param resultStatus The authentication result. This is the enumeration value of the authentication result.
   * @param clientType client Type
   * @param clientVersion version of the client
   * @param analyzePatterns Boolean to indicate if the pattern analysis should be done.
   * @return VCryptResponse to see if the request is successfully processed.
   */
  public VCryptResponse updateAuthStatus(String requestId, Date requestTime, int resultStatus, int clientType,
                                         String clientVersion, boolean analyzePatterns);

  /**
   * Updates User node log auth status
   *
   * @param requestId    request Id
   * @param requestTime  Time of update
   * @param resultStatus The authentication result. This is the enumeration value of the authentication result.
   * @param clientType client Type
   * @param clientVersion version of the client
   * @return VCryptResponse to see if the request is successfully processed.
   */
  public VCryptResponse updateAuthStatus(String requestId, Date requestTime, int resultStatus, int clientType,
                                         String clientVersion);

  /**
   * Method to trigger the pattern data processing for auto-learning.
   * <p> This method does not do any other activity other than auto-learning pattern analysis.
   * @since 10.1.4.5
   * @param requestId	Request Identifier
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status New Status
   * @param transactionType String that indicates the type of transaction. Has to be "auth" for authentication type. For other types it can be "bill_pay, ....",; basically the type name of the transaction.
   * @return VCryptResponse to see if the request is successfully processed.
   */
  public VCryptResponse processPatternAnalysis(String requestId, long transactionId, int status,
                                               String transactionType);

  /**
   * This marks the device as safe for the user.
   *
   * @param requestId requestId for the request
   * @param isSafe    is this device safe for the user
   * @return status of the operation
   */
  public boolean markDeviceSafe(String requestId, boolean isSafe);

  /**
   * Checks to see the device associated with this requiest is safe
   * @param requestId requesId
   * @return VCryptBooleanResponse, Check VCryptBooleanResponse.getRepsonse() to see if the request is successfully processed.
   */
  public VCryptBooleanResponse IsDeviceMarkedSafe(String requestId);

  /**
   * Clear safe device list of the user associated with this request
   * @param requestId requesId
   * @return VCryptResponse to see if the request is successfully processed.
   */
  public VCryptResponse clearSafeDeviceList(String requestId);

  /**
   * API To create a Transaction
   *
   * @param transactionCreateRequestData requestId / Session Id, required
   * @return VCryptResponse make sure to check isSuccess
   * @since 10.1.4.5.1
   */
  public VCryptResponse createTransaction(TransactionCreateRequestData transactionCreateRequestData);

  /**
   * API To create a Transactions in bulk
   * Return response object for each create request
   *
   * @param transactionCreateRequestData requestId / Session Id, required
   * @return VCryptResponse Array of response objects. Each request will have corresponding response. Check isSuccess on each response object
   * @since 10.1.4.5.2
   */
  public VCryptResponse[] createTransactions(TransactionCreateRequestData[] transactionCreateRequestData);

  /**
   * API to update previously created Transaction
   *
   * Updates given transaction
   * @param transactionUpdateRequestData update Request
   * @return VCryptResponse make sure to check isSuccess
   * @since 10.1.4.5.1
   */
  public VCryptResponse updateTransaction(TransactionUpdateRequestData transactionUpdateRequestData);

  /**
   * API to update Transactions in bulk
   * If there are errors in any update, will proceed with next transaction and return response for each request
   *
   * @param transactionUpdateRequestData array of update Request object
   * @return VCryptResponse Array of response objects. Each request will have corresponding response. Check isSuccess on each response object
   * @since 10.1.4.5.2
   */
  public VCryptResponse[] updateTransactions(TransactionUpdateRequestData[] transactionUpdateRequestData);

  /**
   * Returns the NameValueProfile for an entity and request.
   * @param entityDefKey
   * @param entityId
   * @param requestId
   * @return NameValueProfile
   * @deprecated
   */
  public NameValueProfile getNameValueProfile(String entityDefKey, Long entityId, String requestId);

  /**
   * Saves the changes made to the profile.
   * @param profile
   * @return the refreshed NameValueProfile
   * @deprecated
   */
  public NameValueProfile saveNameValueProfile(NameValueProfile profile);

  /**
   * Resets the values of the profile to the latest from the database.
   * @param profile
   * @return the refreshed NameValueProfile
   * @deprecated
   */
  public NameValueProfile refreshNameValueProfile(NameValueProfile profile);

  /**
   * @param requestId 
   * @param challengeType challenge type
   * @param appId application id
   * @return OTP Code
   */
  public String generateOTP(final String requestId, final String challengeType, final String appId);

  /**
   * @param challengeType challenge type
   * @return success ore failure
   */
  public VCryptResponse resetChallengeCounter(final String requestId, final String challengeType);

  /**
   * @param challengeType challenge type
   * @return success ore failure
   */
  public VCryptResponse incrementChallengeCounter(final String requestId, final String challengeType);
  
  /**
   * Method to get the OTP Code based on the challenge type.
   * <p> This method can be called 'n' number of time to get OTP Code for given request identifier.
   * If there is no OTP Code exists for the given request identifier then new OTPCode will be generated
   * If OTP Code exists for the given request identifier and overwriteIfexists is true then new OTPCode will be generated
   * If OTP Code exists and OTP Code is not expired, then same OTP Code will be returned by renewing the expiry else new OTP Code will be returned.
   * 
   * The OTP Code can be retrieved from the VCryptObjectResponse object as follows 
   *        String otpCode = (String) vcryptResponseObj.getObject();
   * 
   * @param requestId             Request Identifier
   * @param challengeType         Challenge type. This should be one of the OTP enabled enumeration element of Enumeratioin 'bharosa.uio.default.challenge.type.enum'
   * @param overwriteIfExists     If overwriteIfExists is true then new OTP Code will be returned by, ignoring the presence of any existing OTPCode for the given request identifier else existing OTPCode will be returned if exists else new one will be generated.
   * @return VCryptObjectResponse On successful response, OTPCode will be returned or failure error message with reason will be returned
   */
  public VCryptObjectResponse getOTPCode(final String requestId, final String challengeType, final Boolean overwriteIfExists);
  
  /**
   * Method to validate OTPCode for the given request identifier and challenge type.
   * <p> This method can be called 'n' number of time to validate the OTP Code for given request identifier.
   * If the OTPCode exists and not expired and given OTP Code matches the existing OTP Code then returns response with OTP_CODE_MATCHED value
   * If the OTPCode exists and not expired and given OTP Code does not matches the existing OTP Code then returns response with OTP_CODE_NOT_MATCHED value
   * If the OTPCode exists and expired then returns response with OTP_CODE_EXPIRED value
   * If the OTPCode does not exists then returns OTP_CODE_DOESNOT_EXISTS
   * 
   * The OTP validation result can be retrieved from the VCryptObjectResponse object as follows 
   *    TrackerAPIUtil.OTPValidationResult otpCode = (TrackerAPIUtil.OTPValidationResult) vcryptResponseObj.getObject();
   * 
   * @param requestId Request identifier
   * @param challengeType Challenge type. This should be one of the OTP enabled enumeration element of Enumeratioin 'bharosa.uio.default.challenge.type.enum'
   * @param otpcode OTP Code to validate
   * @return VCryptObjectResponse On successful response, OTP_CODE_MATCHED/OTP_CODE_NOT_MATCHED/OTP_CODE_EXPIRED/OTP_CODE_DOESNOT_EXISTS will be returned or failure error message with reason will be returned
   */
  public VCryptObjectResponse validateOTPCode(final String requestId, final String challengeType,  final String otpcode);
  
   /**  
   * Creates or updates entities.  
   * @param entityRequestData : array of EntityData objects. An EntityData object contains the information  
                                required to create one entity. See EntityData.java for more details  
   * @param isReplaceEntity : flag to determine replacement or merging of attributes on updation of entity.  
                               Default value : FALSE which denotes merge.  
   * @param commitBatchSize : determines the number of entities which have to be comitted together.Default  
                              and Min value = 1  
   * @param requestId : Value to identify the session.The value will be sent by client.If the client does not  
                         set this value then we generate a dummy number  
   * @return VCryptObjectResponse: SUCCESS on successfull excecution of API(there is no db or connection  
                                   error) and atleast one entity is created. ERROR if no entity is created.  
                                  On SUCCESS : response.getObject() returns Array object containing VCryptObjectResponse for individual
                                 entities. Each such response object contains Entity object on SUCCESS and Error message on ERROR  
   */
  
   public VCryptObjectResponse<VCryptObjectResponse<EntityHeader>[]> createOrUpdateEntities(EntityData[] entityRequestData,boolean isReplaceEntity, int commitBatchSize, String requestId);

   /** 
   * Finds entity on the basis of its key attributes
   * @See EntityData
   * @param entityData : EntityData object with entityName and entityDataMap containing key(s) and value(s)  
                         of primary key attributes of the entity to be searched based on the id scheme  
   * @return VCryptObjectResponse : containing Entity object which is the entity object on SUCCESS or error  
                         message on ERROR  
   */
  
   public VCryptObjectResponse<EntityHeader> searchEntityByKey(EntityData entityData); 
}
