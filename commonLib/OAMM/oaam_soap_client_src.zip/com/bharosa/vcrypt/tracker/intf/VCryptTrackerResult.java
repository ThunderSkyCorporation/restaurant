package com.bharosa.vcrypt.tracker.intf;


/**
 * Provides information about a tracker nodes status
 * @author Luke
 */

public interface VCryptTrackerResult{

	// 0-99 for various types of unrated nodes
	public static int RATE_UNRATED = 0;
	public static int RATE_NEW_NODE = 1;

	// 100-199 for untrusted ratings
	public static int RATE_UNTRUSTED_LEVEL0 = 100;
	public static int RATE_UNTRUSTED_LEVEL1 = 101;

	// 200-299 for trusted ratings
	public static int RATE_TRUSTED_LEVEL0 = 200;
	public static int RATE_TRUSTED_LEVEL1 = 201;
	public static int RATE_TRUSTED_LEVEL2 = 202;

	/**
	* Returns the status code of a tracker result
	* @return integer describing tracker status
	*/
	public int getCode();

}

