package com.bharosa.vcrypt.tracker.intf;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.tracker.util.CookieSet;

import java.util.List;
import java.util.Map;


/**
 * This class contains the result of the rules processing.
 */

public interface VCryptRulesResult {


    /**
	 * This method returns the list of actions.
	 *
	 * @return List with String objects.
	 */
	public List getAllActions();

	/**
	 * This is the action to be taken. This action is the
	 * after applying the processing rule on the list of
	 * actions returned by the rule engine
	 *
	 * @return Action string.
	 */
	public String getResult();

	/**
	 * Method to get the score after running the rules
	 *
	 * @return score risk score based on all policies and pluggable scoring engines used
	 */
	public int getScore();

	/**
	 * Get the transaction log id
	 *
	 * @return Long transaction Id, null if none available
	 */
	public Long getTransactionLogId();

	/**
	 * Return response code for the transaction
	 *
	 * @return VCryptResponse response object with error code
	 */
	public VCryptResponse getVCryptResponse();

	/**
	 * Use this to get result of each requested runtime
	 * @return Map of runTime (Integer), VCryptRulesResult
	 */
	public Map getResultMap();

    /**
     * Returns the CookieSet, if fingerprint is also done as part of running rules.
     * @return CookieSet
     *
     */
    public CookieSet getCookieSet( );

    public List getAlertMessageList();
    
    public Integer getRuntimeType();

	/**
	 * Returns the associated Device Id.
	 *
	 * @return associated device id.
	 */
	public Long getDeviceId();
}
