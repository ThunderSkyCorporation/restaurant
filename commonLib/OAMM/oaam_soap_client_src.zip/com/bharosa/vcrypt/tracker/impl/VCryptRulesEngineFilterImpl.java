package com.bharosa.vcrypt.tracker.impl;

import com.bharosa.vcrypt.tracker.intf.VCryptRulesEngine;
import com.bharosa.vcrypt.tracker.intf.VCryptRulesResult;
import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;

import java.util.List;
import java.util.Map;
import java.util.Date;

import com.bharosa.common.logger.Logger;
/*
 * Copyright (c) 2006 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * Description Date: Oct 10, 2006
 *
 * @author bosco
 */
public class VCryptRulesEngineFilterImpl implements VCryptRulesEngine {
    private static Logger logger = Logger.getLogger(VCryptTrackerFilterImpl.class);

    final static Object lock = new Object();
    static VCryptRulesEngine rulesEngine = null;

    public VCryptRulesEngineFilterImpl() {
        synchronized (lock) {
            if (rulesEngine == null) {
                logger.info("Creating new VCryptRulesEngine instance...");
                try {
                    String rulesEngineClassName = BharosaConfig.get("vcrypt.rules.engine.filter.impl.classname");
                    if (rulesEngineClassName == null || rulesEngineClassName.trim().equals("")) {
                        boolean useSoap = BharosaConfig.getBoolean("vcrypt.tracker.soap.useSOAPServer", false);
                        if (useSoap) {
                            rulesEngineClassName = BharosaConfig.get("vcrypt.rules.engine.soap.classname",
                                    "com.bharosa.vcrypt.tracker.impl.VCryptRulesEngineSOAPImpl");
                        } else {
                            rulesEngineClassName = BharosaConfig.get("vcrypt.rules.engine.static.classname",
                                    "com.bharosa.vcrypt.tracker.impl.VCryptRulesEngineMonitorImpl");
                        }
                    }
                    if (!StringUtil.isEmpty(rulesEngineClassName)) {
                        //Loading instance
                        logger.info("Loading class " + rulesEngineClassName);
                        rulesEngine = (VCryptRulesEngine) Class.forName(rulesEngineClassName).newInstance();
                    } else {
                        logger.error("Class not created. vcrypt.rules.engine.filter.impl.classname should be set");
                    }
                } catch (Exception ex) {
                    logger.error("Error creating VCryptRulesEngine instance.", ex);
                }
            }
        }
    }

    /**
     * This method runs the rules and returns rules result.
     *
     * @param requestId    Id for the request.
     * @param checkpointList List of Integer objects with checkpoints to be run, can't be null or empty.
     * @param contextMap   List of name value pairs to be used by the rules
     * @return The <code>VCryptRulesResult</code>
     */
    public VCryptRulesResult processRules(String requestId, List checkpointList, Map contextMap) {
        Date beginTime = new Date();
        VCryptRulesResult vCryptRulesResult = null;
        try {
            vCryptRulesResult = rulesEngine.processRules(requestId, checkpointList, contextMap);
        } finally {
            if (logger.isDebugEnabled())
                logger.debug("FILTER:processRules:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
        }
        if (vCryptRulesResult == null) {
            logger.error("processRules returned null. requestId=" + requestId + ", checkpoint List=" + checkpointList + ", contextMap=" + contextMap);
        }
        return vCryptRulesResult;
    }

    /**
     * This method runs the rules and returns rules result.
     *
     * @param requestId    Id for the request.
     * @param requestTime  Time when this rule was run.
     * @param checkpointList List of Integer objects with checkpoints to be run, can't be null or empty.
     * @param contextMap   List of name value pairs to be used by the rules
     * @return The <code>VCryptRulesResult</code>
     */
    public VCryptRulesResult processRules(String requestId, Date requestTime, List checkpointList, Map contextMap) {
        Date beginTime = new Date();
        VCryptRulesResult vCryptRulesResult = null;
        try {
            vCryptRulesResult = rulesEngine.processRules(requestId, requestTime, checkpointList, contextMap);
        } finally {
            if (logger.isDebugEnabled())
                logger.debug("FILTER:processRules:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
        }

        if (vCryptRulesResult == null) {
            logger.error("processRules returned null. requestId=" + requestId + ", requestTime=" + requestTime + ", checkpoint List=" + checkpointList + ", contextMap=" + contextMap);
        }
        return vCryptRulesResult;
    }

    public VCryptRulesResult processRules(String requestId, Long transactionId, String extTransactionId, Date requestTime, List checkpointList, Map contextMap) {
        Date beginTime = new Date();
        VCryptRulesResult vCryptRulesResult = null;
        try {
            vCryptRulesResult = rulesEngine.processRules(requestId, transactionId, extTransactionId,  requestTime, checkpointList, contextMap);
        } finally {
            if (logger.isDebugEnabled())
                logger.debug("FILTER:processRules:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
        }

        if (vCryptRulesResult == null) {
            logger.error("processRules returned null. requestId=" + requestId + ", transactionId=" +transactionId
                   +", extTransactionId =" +extTransactionId + ", requestTime=" + requestTime + ", checkpoint List=" + checkpointList + ", contextMap=" + contextMap);
        }
        return vCryptRulesResult;
    }
}
