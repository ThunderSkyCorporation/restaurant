package com.bharosa.vcrypt.tracker.impl;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.vcrypt.common.util.VCryptObjectResponse;

import java.util.Arrays;
import java.util.Map;
import java.util.ArrayList;
import java.util.Date;

import com.bharosa.common.logger.Logger;

import com.bharosa.vcrypt.common.intf.VCryptSOAP;
import com.bharosa.vcrypt.common.util.VCryptCommonUtil;
import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.common.util.VCryptBooleanResponse;

import com.bharosa.vcrypt.tracker.intf.NameValueProfile;
import com.bharosa.vcrypt.tracker.intf.VCryptTracker;
import com.bharosa.vcrypt.tracker.util.VCryptTrackerUtil;
import com.bharosa.vcrypt.tracker.util.CookieSet;
import com.bharosa.vcrypt.tracker.data.TransactionCreateRequestData;
import com.bharosa.vcrypt.tracker.data.TransactionUpdateRequestData;

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
//import com.bharosa.vcrypt.tracker.transaction.data.Entity;
import com.bharosa.vcrypt.common.data.OAAMDeviceFingerprintData;
import com.bharosa.vcrypt.common.data.OAAMIPData;
import com.bharosa.vcrypt.common.data.OAAMSessionData;
import com.bharosa.vcrypt.common.data.OAAMUserData;
import com.bharosa.common.util.UserDefEnum;
import com.bharosa.common.util.UserDefEnumElement;
import com.bharosa.vcrypt.tracker.transaction.data.EntityData;
import com.bharosa.vcrypt.tracker.transaction.data.EntityHeader;
import com.bharosa.vcrypt.tracker.util.TrackerAPIUtil;

import java.util.List;

/**
 * Provides various methods for fingerprinting and identifying computers.
 *
 * @author Luke
 */

public class VCryptTrackerSOAPImpl implements VCryptTracker {

  static Logger logger = Logger.getLogger(VCryptTrackerSOAPImpl.class);

  static final Object lock = new Object();
  static boolean initDone = false;

  /**
   * Use accessMethod to get this object.
   */
  static ArrayList vcryptSoapList = null;
  static int totalServers = 0;

  /**
   * Default constructer.
   */
  public VCryptTrackerSOAPImpl() {
    if (logger.isDebugEnabled())
      logger.debug("VCryptTrackerSOAPImpl() constructor");
  }

  /**
   * This is important to use this method for getting the VCryptSOAP, because if server is not up when the client
   * comes up and if the connection is not established, then we might have retry issues.
   * @param requestId requestId
   * @return VCryptSOAP Object
   */
  VCryptSOAP getVCryptSOAP(String requestId) {
    if (vcryptSoapList == null || !initDone) {
      synchronized (lock) {
        initDone = false;
        if (vcryptSoapList == null) {
          String serverUrl = BharosaConfig.get("vcrypt.tracker.soap.url");
          String serviceName = BharosaConfig.get("vcrypt.tracker.soap.trackerServiceName");
          if (StringUtil.isEmpty(serverUrl)) {
            logger.fatal("SOAP url not given. Please set vcrypt.tracker.soap.url property");
            return null;
          }
          vcryptSoapList = new ArrayList();
          String urls[] = serverUrl.trim().split(",");
          for (int i = 0; i < urls.length; i++) {
            VCryptSOAP vcryptSoap = VCryptCommonUtil.newVCryptSOAPInstance(urls[i].trim(), serviceName);
            vcryptSoapList.add(vcryptSoap);
          }
          totalServers = vcryptSoapList.size();
        }
        initDone = true;
      }
    }
    if (totalServers != 0) {
      int index = 0;
      char[] charArray = requestId.toCharArray();

      for (int i = 0; i < charArray.length; i++) {
        index += (int)charArray[i];
      }
      index = index % totalServers;
      return (VCryptSOAP)vcryptSoapList.get(index);
    } else {
      return null;
    }

  }

  /**
   * Initialize or warmup server. Will load necessary caches. Call this method when appserver is first started.
   *
   * @return VCryptResponse object
   */
  public VCryptResponse init(String requestId) {
    try {

      if (logger.isDebugEnabled())
        logger.debug("start init");

      String xmlParameter = VCryptCommonUtil.toXMLString(requestId);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(VCryptTracker.REQUEST_TRACKER_INIT, xmlParameter);
        return VCryptCommonUtil.fromVCryptResponseXml(xmlReturn);
      } else {
        logger.error("init. VCryptSOAP not created yet.");
      }

    } catch (Exception ex) {
      logger.error("init. requestId=" + requestId, ex);
    }

    return VCryptResponse.getUnexpectedErrorResponse();
  }

  /**
   * This creates the signatures required to finger print the device. This method takes the requestTime as input.
   *
   * @param requestId            This it the id for the request
   * @param requestTime          Time when this request was made. Used by simulator.
   * @param remoteIPAddr         The IP from where the request came in
   * @param remoteHost           The host name from where the request came in
   * @param secureCookie         The secure cookie
   * @param secureClientType     secure cookie client type
   * @param secureClientVersion  version of the secure cookie client
   * @param digitalCookie        The digital signature cookie
   * @param digitalClientType    digital cookie client type
   * @param digitalClientVersion version of the digital cookie client
   * @param fingerPrintType      Type of finger printing
   * @param fingerPrint          Finger print
   * @param fingerPrintType2     This in case the same request can have multipe finger prints. Like flash request.
   * @param fingerPrint2         The second finger print value
   * @return a <code>CookieSet</code> value
   */
  public CookieSet handleTrackerRequest(String requestId, Date requestTime, String remoteIPAddr, String remoteHost,
                                        String secureCookie, int secureClientType, String secureClientVersion,
                                        String digitalCookie, int digitalClientType, String digitalClientVersion,
                                        int fingerPrintType, String fingerPrint, int fingerPrintType2,
                                        String fingerPrint2) {

    CookieSet retVal = null;
    try {
      if (logger.isDebugEnabled())
        logger.debug("handleTrackerRequest() requestId=" + requestId + ", remoteIPAddr=" + remoteIPAddr +
                     ", remoteHost=" + remoteHost + ", secureCookie=" + secureCookie + ", secureClientType=" +
                     secureClientType + ", secureClientVersion=" + secureClientVersion + ", digitalCookie=" +
                     digitalCookie + ", digitalClientType=" + digitalClientType + ", digitalClientVersion=" +
                     digitalClientVersion);

      String requestName = "handleTrackerRequest";
      String xmlParameter =
        VCryptTrackerUtil.toXMLFingerPrintRequest(requestId, requestTime, remoteIPAddr, remoteHost, secureCookie,
                                                  secureClientType, secureClientVersion, digitalCookie,
                                                  digitalClientType, digitalClientVersion, fingerPrintType,
                                                  fingerPrint, fingerPrintType2, fingerPrint2);

      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
        retVal = VCryptTrackerUtil.fromXMLFingerPrintResponse(xmlReturn);
      } else {
        logger.error("VCryptSOAP not created yet. No action take for handleTrackerRequest() requestId=" + requestId +
                     ", remoteIPAddr=" + remoteIPAddr + ", remoteHost=" + remoteHost + ", secureCookie=" +
                     secureCookie + ", secureClientType=" + secureClientType + ", secureClientVersion=" +
                     secureClientVersion + ", digitalCookie=" + digitalCookie + ", digitalClientType=" +
                     digitalClientType + ", digitalClientVersion=" + digitalClientVersion + ", fingerPrint=" +
                     fingerPrint);
      }
    } catch (Exception ex) {
      logger.error("Caught exception. handleTrackerRequest() requestId=" + requestId + ", remoteIPAddr=" +
                   remoteIPAddr + ", remoteHost=" + remoteHost + ", secureCookie=" + secureCookie +
                   ", secureClientType=" + secureClientType + ", secureClientVersion=" + secureClientVersion +
                   ", digitalCookie=" + digitalCookie + ", digitalClientType=" + digitalClientType +
                   ", digitalClientVersion=" + digitalClientVersion + ", fingerPrint=" + fingerPrint, ex);
    }
    return retVal;

  }

  /**
   * This creates the signatures required to finger print the device.
   *
   * @param requestId            This it the id for the request
   * @param remoteIPAddr         The IP from where the request came in
   * @param remoteHost           The host name from where the request came in
   * @param secureCookie         The secure cookie
   * @param secureClientType     secure cookie client type
   * @param secureClientVersion  version of the secure cookie client
   * @param digitalCookie        The digital signature cookie
   * @param digitalClientType    digital cookie client type
   * @param digitalClientVersion version of the digital cookie client
   * @param fingerPrintType      Type of finger printing
   * @param fingerPrint          Finger print
   * @param fingerPrintType2     This in case the same request can have multipe finger prints. Like flash request.
   * @param fingerPrint2         The second finger print value
   * @return a <code>CookieSet</code> value
   */
  public CookieSet handleTrackerRequest(String requestId, String remoteIPAddr, String remoteHost, String secureCookie,
                                        int secureClientType, String secureClientVersion, String digitalCookie,
                                        int digitalClientType, String digitalClientVersion, int fingerPrintType,
                                        String fingerPrint, int fingerPrintType2, String fingerPrint2) {
    Date requestTime = null;
    return handleTrackerRequest(requestId, requestTime, remoteIPAddr, remoteHost, secureCookie, secureClientType,
                                secureClientVersion, digitalCookie, digitalClientType, digitalClientVersion,
                                fingerPrintType, fingerPrint, fingerPrintType2, fingerPrint2);
  }

  /**
   * This creates the signatures required to finger print the device.
   *
   * @param requestId   This it the id for the request
   * @param requestTime Time for this transaction
   * @param contextMap  array of context data maps
   * @return VCryptResponse
   */
  public VCryptResponse handleTransactionLog(String requestId, Date requestTime, Map[] contextMap) {
    return handleTransactionLog(requestId, requestTime, null, contextMap);

  }

  /**
   * This creates the signatures required to finger print the device.
   *
   * @param requestId   This it the id for the request
   * @param requestTime Time for this transaction
   * @param contextMap  array of context data maps
   * @return VCryptResponse
   */
  public VCryptResponse handleTransactionLog(String requestId, Date requestTime, Integer transactionStatus,
                                             Map[] contextMap) {
    try {
      if (logger.isDebugEnabled())
        logger.debug("Updating transactionLog requestId=" + requestId);

      String requestName = "handleTransactionLog";
      String xmlParameter =
        VCryptTrackerUtil.toXMLTransactionLogRequest(requestId, requestTime, transactionStatus, contextMap);

      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlResult = vcryptSOAP.execute(requestName, xmlParameter);
        if (logger.isDebugEnabled())
          logger.debug("Response xml=" + xmlResult);
        return VCryptCommonUtil.fromVCryptResponseXml(xmlResult);
      } else {
        logger.error("VCryptSOAP not created yet. No action take for handleTransactionLog() requestId=" + requestId);
        return new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "No SOAP Transport.");
      }
    } catch (Exception ex) {
      logger.error("Caught exception. handleTransactionLog() requestId=" + requestId, ex);
      return VCryptResponse.getUnexpectedErrorResponse();
    }

  }

  /**
   * This creates the signatures required to finger print the device.
   *
   * @param requestId  This it the id for the request
   * @param contextMap Array of context map
   * @return VCryptResponse trackerResponse data
   */
  public VCryptResponse handleTransactionLog(String requestId, Map[] contextMap) {
    Date requestTime = null;
    return handleTransactionLog(requestId, requestTime, contextMap);
  }

  /**
   * Updates the user node log. And if required, it creates the CookieSet also.
   *
   * @param requestId        requestId for the request
   * @param requestTime      Time when this request was make. Used primarily by the simulator
   * @param remoteIPAddr     The IP from where the request came in
   * @param remoteHost       The host name from where the request came in
   * @param secureCookie     The secure cookie
   * @param digitalCookie    the secure cookie, can be flash cookie
   * @param groupId          the groupId of this user.
   * @param userId           id of the user
   * @param loginId          the loginId used by the user for login in
   * @param isSecure         whether this node is secure and can be registered
   * @param result           The authentication result.
   * @param clientType       the type of the client used for authentication
   * @param clientVersion    the version of the client
   * @param fingerPrintType  Type of finger printing
   * @param fingerPrint      Finger print
   * @param fingerPrintType2 Type of the Digital finger printing
   * @param fingerPrint2     Digital fingerprint
   * @return a <code>CookieSet</code> value
   */
  public CookieSet updateLog(String requestId, Date requestTime, String remoteIPAddr, String remoteHost,
                             String secureCookie, String digitalCookie, String groupId, String userId, String loginId,
                             boolean isSecure, int result, int clientType, String clientVersion, int fingerPrintType,
                             String fingerPrint, int fingerPrintType2, String fingerPrint2) {
    try {
      if (logger.isDebugEnabled())
        logger.debug("Updating users result status requestId=" + requestId + ", remoteIPAddr=" + remoteIPAddr +
                     ", remoteHost=" + remoteHost + ", groupId=" + groupId + ", userId=" + userId + ", loginId=" +
                     loginId + ", isSecure=" + isSecure + ", result=" + result + ", clientType=" + clientType +
                     ", clientVersion=" + clientVersion + ", fingerPrint=" + fingerPrint + ", fingerPrint2=" +
                     fingerPrint2);

      String requestName = "updateLog";
      String xmlParameter =
        VCryptTrackerUtil.toXMLUpdateAuthResultRequest(requestId, requestTime, remoteIPAddr, remoteHost, secureCookie,
                                                       digitalCookie, groupId, userId, loginId, isSecure, result,
                                                       clientType, clientVersion, fingerPrintType, fingerPrint,
                                                       fingerPrintType2, fingerPrint2);

      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
        return VCryptTrackerUtil.fromXMLFingerPrintResponse(xmlReturn);
      } else {
        logger.error("VCryptSOAP not created yet. No action take for updateLog() requestId=" + requestId +
                     ", remoteIPAddr=" + remoteIPAddr + ", remoteHost=" + remoteHost + ", groupId=" + groupId +
                     ", userId=" + userId + ", loginId=" + loginId + ", isSecure=" + isSecure + ", result=" + result +
                     ", clientType=" + clientType + ", clientVersion=" + clientVersion + ", fingerPrint=" +
                     fingerPrint + ", fingerPrint2=" + fingerPrint2);
        CookieSet cookieSet = new CookieSet(requestId, null, null);
        return cookieSet.setVCryptResponse(new VCryptResponse(VCryptResponse.APPLICATION_ERROR,
                                                              "SOAP Service not available"));
      }
    } catch (Exception ex) {
      logger.error("Caught exception. updateLog() requestId=" + requestId + ", remoteIPAddr=" + remoteIPAddr +
                   ", remoteHost=" + remoteHost + ", groupId=" + groupId + ", userId=" + userId + ", loginId=" +
                   loginId + ", result=" + result + ", clientType=" + clientType + ", clientVersion=" + clientVersion +
                   ", fingerPrint=" + fingerPrint + ", fingerPrint2=" + fingerPrint2, ex);
      CookieSet cookieSet = new CookieSet(requestId, null, null);
      return cookieSet.setVCryptResponse(new VCryptResponse(VCryptResponse.UNEXPECTED_ERROR, ex.getMessage()));
    }

  }

  /**
   * Updates the user node log. And if required, it creates the CookieSet also.
   *
   * @param requestId       requestId for the request
   * @param remoteIPAddr    The IP from where the request came in
   * @param remoteHost      The host name from where the request came in
   * @param secureCookie    The secure cookie
   * @param digitalCookie   digital cookie from flash
   * @param groupId         the groupId of this user.
   * @param userId          id of the user
   * @param loginId         the loginId used by the user for login in
   * @param isSecure        whether this node is secure and can be registered
   * @param result          The authentication result.
   * @param clientType      the type of the client used for authentication
   * @param clientVersion   the version of the client
   * @param fingerPrintType Type of finger printing
   * @param fingerPrint     Finger print
   * @return a <code>CookieSet</code> value
   */
  public CookieSet updateLog(String requestId, String remoteIPAddr, String remoteHost, String secureCookie,
                             String digitalCookie, String groupId, String userId, String loginId, boolean isSecure,
                             int result, int clientType, String clientVersion, int fingerPrintType, String fingerPrint,
                             int fingerPrintType2, String fingerPrint2) {
    Date requestTime = null;
    return updateLog(requestId, requestTime, remoteIPAddr, remoteHost, secureCookie, digitalCookie, groupId, userId,
                     loginId, isSecure, result, clientType, clientVersion, fingerPrintType, fingerPrint,
                     fingerPrintType2, fingerPrint2);
  }

  /**
   * Updates User node log auth status
   *
   * @param requestId    request Id
   * @param requestTime  Time of update
   * @param resultStatus The authentication result. This is the enumeration value of the authentication result.
   * @return VCryptResponse
   */
  public VCryptResponse updateAuthStatus(String requestId, Date requestTime, int resultStatus, int clientType,
                                         String clientVersion) {
    return updateAuthStatus(requestId, requestTime, resultStatus, clientType, clientVersion, false);
  }

  /**
   * Updates User node log auth status
   *
   * @param requestId    request Id
   * @param requestTime  Time of update
   * @param resultStatus The authentication result. This is the enumeration value of the authentication result.
   * @param analyzePatterns Boolean to indicate if the pattern analysis should be done.
   * <p> When passed in as true the pattern analysis is done for this transaction.
   * @return VCryptResponse
   */
  public VCryptResponse updateAuthStatus(String requestId, Date requestTime, int resultStatus, int clientType,
                                         String clientVersion, boolean analyzePatterns) {
    String requestName = "updateAuthStatus";
    try {
      String xmlParameter =
        VCryptTrackerUtil.toXMLUpdateAuthStatus(requestId, requestTime, resultStatus, clientType, clientVersion,
                                                analyzePatterns);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
        return VCryptCommonUtil.fromVCryptResponseXml(xmlReturn);
      } else {
        logger.error("VCryptSOAP not created yet. No action take for updateLog() requestId=" + requestId +
                     ", remoteIPAddr=, resultStatus=" + resultStatus + ", clientType=" + clientType +
                     ", clientVersion=" + clientVersion);
        return new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "No SOAP Transport.");
      }
    } catch (Exception ex) {
      logger.error("Caught exception. updateLog() requestId=" + requestId + ", remoteIPAddr=, resultStatus=" +
                   resultStatus + ", clientType=" + clientType + ", clientVersion=" + clientVersion, ex);
      return VCryptResponse.getUnexpectedErrorResponse();
    }
  }

  /**
   * Updates User node log auth status
   *
   * @param requestId     request Id
   * @param resultStatus  The authentication resultStatus. This is the enumeration value of the authentication
   *                      resultStatus.
   * @param clientType    This is an enum value defined to identify the client type used for authentication.
   * @param clientVersion Optional parameter to specify the version of the client used.
   * @return VCryptResponse
   */
  public VCryptResponse updateAuthStatus(String requestId, int resultStatus, int clientType, String clientVersion) {
    Date requestTime = null;
    return updateAuthStatus(requestId, requestTime, resultStatus, clientType, clientVersion);
  }

  /**
   * Updates User node log auth status
   * <p>AnalyzePatterns param is used by auto-learning.
   * @since 10.1.4.5
   * @param requestId     request Id
   * @param resultStatus  The authentication result. This is the enumeration value of the authentication result.
   * @param clientType    This is an enum value defined to identify the client type used for authentication.
   * @param clientVersion Optional parameter to specify the version of the client used.
   * @param analyzePatterns Boolean to indicate if the pattern analysis should be done.
   * <p> When passed in as true the pattern analysis is done for this transaction.
   * @return VCryptResponse
   */
  public VCryptResponse updateAuthStatus(String requestId, int resultStatus, int clientType, String clientVersion,
                                         boolean analyzePatterns) {
    Date requestTime = null;
    return updateAuthStatus(requestId, requestTime, resultStatus, clientType, clientVersion, analyzePatterns);
  }

  /**
   * Update given transaction status.
   *
   * @param requestId     Request Identifier
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, long transactionId, int status) {
    return updateTransactionStatus(requestId, transactionId, status, false);
  }

  /**
   * Update given transaction status.
   * <p>AnalyzePatterns param is used by auto-learning.
   * @since 10.1.4.5
   * @param requestId     Request Identifier
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @param analyzePatterns Boolean to indicate if the pattern analysis should be done.
   * <p> When passed in as true the pattern analysis is done for this transaction.
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, long transactionId, int status,
                                                boolean analyzePatterns) {
    Date requestTime = null;
    return updateTransactionStatus(requestId, requestTime, transactionId, status, false);
  }

  /**
   * Update given transaction status.
   *
   * @param requestId     Request Identifier
   * @param requestTime   Time of the update
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, Date requestTime, long transactionId, int status) {
    return updateTransactionStatus(requestId, requestTime, transactionId, status, false);
  }

  /**
   * Update given transaction status.
   *
   * @param requestId     Request Identifier
   * @param requestTime   Time of the update
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @param analyzePatterns Boolean to indicate if the pattern analysis should be done.
   * <p> When passed in as true the pattern analysis is done for this transaction.
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, Date requestTime, long transactionId, int status,
                                                boolean analyzePatterns) {
    String requestName = "updateTransactionStatus";
    try {
      String xmlParameter =
        VCryptTrackerUtil.toXMLUpdateTransactionStatus(requestId, requestTime, transactionId, status, analyzePatterns);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
        return VCryptCommonUtil.fromVCryptResponseXml(xmlReturn);
      } else {
        logger.error("VCryptSOAP not created yet. No action take for updateLog() requestId=" + requestId +
                     ", remoteIPAddr=, transactionId=" + transactionId + ", status=" + status);
        return new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "No SOAP Transport.");
      }
    } catch (Exception ex) {
      logger.error("VCryptSOAP not created yet. No action take for updateLog() requestId=" + requestId +
                   ", remoteIPAddr=, transactionId=" + transactionId + ", status=" + status, ex);
      return VCryptResponse.getUnexpectedErrorResponse();
    }
  }


  /**
   * Update given transaction status.
   *
   * @param requestId     Request Identifier
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @param contextMap array of contextMap
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, long transactionId, int status, Map[] contextMap) {
    Date requestTime = null;
    return updateTransactionStatus(requestId, requestTime, transactionId, status, contextMap);
  }

  /**
   * Update given transaction status.
   *
   * @param requestId     Request Identifier
   * @param requestTime   Time of the update
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @param contextMap array of contextMap
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, Date requestTime, long transactionId, int status,
                                                Map[] contextMap) {
    return updateTransactionStatus(requestId, requestTime, transactionId, status, contextMap, false);
  }

  /**
   * Update given transaction status.
   *
   * @param requestId     Request Identifier
   * @param requestTime   Time of the update
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status        New Status
   * @param contextMap array of contextMap
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, Date requestTime, long transactionId, int status,
                                                Map[] contextMap, boolean analyzePatterns) {
    String requestName = "updateTransactionStatus";
    try {
      String xmlParameter =
        VCryptTrackerUtil.toXMLUpdateTransactionStatus(requestId, requestTime, transactionId, status, contextMap,
                                                       analyzePatterns);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
        return VCryptCommonUtil.fromVCryptResponseXml(xmlReturn);
      } else {
        logger.error("VCryptSOAP not created yet. No action take for updateLog() requestId=" + requestId +
                     ", remoteIPAddr=, transactionId=" + transactionId + ", status=" + status);
        return new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "No SOAP Transport.");
      }
    } catch (Exception ex) {
      logger.error("VCryptSOAP not created yet. No action take for updateLog() requestId=" + requestId +
                   ", remoteIPAddr=, transactionId=" + transactionId + ", status=" + status, ex);
      return VCryptResponse.getUnexpectedErrorResponse();
    }
  }

  /**
   * This marks the device as safe for the user.
   *
   * @param requestId requestId for the request
   * @param isSafe is safe
   */
  public boolean markDeviceSafe(String requestId, boolean isSafe) {
    boolean retVal = false;
    try {
      if (logger.isDebugEnabled())
        logger.debug("markDeviceSafe requestId=" + requestId + ", isSafe=" + isSafe);

      String requestName = "markDeviceSafe";
      String xmlParameter = VCryptTrackerUtil.toXMLMarkDeviceSafeRequest(requestId, isSafe);

      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
        Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
        if (boolVal != null) {
          retVal = boolVal.booleanValue();
        } else {
          logger.error("markDeviceSafe didn't return any value. requestId=" + requestId + ", isSafe=" + isSafe);
        }
      } else {
        logger.error("VCryptSOAP not created yet. No action take for markDeviceSafe() requestId=" + requestId +
                     ", isSafe=" + isSafe);
      }
    } catch (Exception ex) {
      logger.error("Caught exception. markDeviceSafe() requestId=" + requestId + ", isSafe=" + isSafe, ex);
    }
    return retVal;
  }


  public VCryptBooleanResponse IsDeviceMarkedSafe(String requestId) {
    VCryptBooleanResponse response = null;
    try {
      if (logger.isDebugEnabled())
        logger.debug("IsDeviceMarkedSafe requestId=" + requestId);

      String requestName = "isDeviceMarkedSafe";
      String xmlParameter = VCryptTrackerUtil.toXMLIsDeviceMarkedSafe(requestId);

      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
        response = VCryptCommonUtil.fromVCryptBooleanResponseXml(xmlReturn);
        if (response == null) {
          logger.error("isDeviceMarkedSafe didn't return any value. requestId=" + requestId);
        }
      } else {
        logger.error("VCryptSOAP not created yet. No action take for isDeviceMarkedSafe() requestId=" + requestId);
      }
    } catch (Exception ex) {
      logger.error("Caught exception. isDeviceMarkedSafe() requestId=" + requestId, ex);
    }
    return response;
  }

  public VCryptResponse clearSafeDeviceList(String requestId) {
    VCryptResponse response = null;
    try {
      if (logger.isDebugEnabled())
        logger.debug("clearSafeDeviceList requestId=" + requestId);

      String requestName = "clearSafeDeviceList";
      String xmlParameter = VCryptTrackerUtil.toXMLClearSafeDeviceList(requestId);

      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
        response = VCryptCommonUtil.fromVCryptResponseXml(xmlReturn);
        if (response == null) {
          logger.error("clearSafeDeviceList didn't return any value. requestId=" + requestId);
        }
      } else {
        logger.error("VCryptSOAP not created yet. No action take for clearSafeDeviceList() requestId=" + requestId);
      }
    } catch (Exception ex) {
      logger.error("Caught exception. clearSafeDeviceList() requestId=" + requestId, ex);
    }
    return response;
  }

  /**
   * Method to trigger the pattern data processing for auto-learning.
   * <p> This method does not do any other activity other than auto-learning pattern analysis.
   * @since 10.1.4.5
   * @param requestId	Request Identifier
   * @param transactionId Transaction Id to be updated. See #handleTrackerRequest, #handleTransactionLog
   * @param status New Status
   * @param transactionType String that indicates the type of transaction. Has to be "auth" for authentication type. For other types it can be "bill_pay, ....",; basically the type name of the transaction.
   * @return VCryptResponse to see if the request is successfully processed.
   */
  public VCryptResponse processPatternAnalysis(String requestId, long transactionId, int status,
                                               String transactionType) {
    Date beginTime = new Date();
    VCryptResponse response = null;
    if (logger.isDebugEnabled()) {
      logger.debug("VCryptTrackerSOAPImpl:processPatternAnalysis(Entering):" + requestId + ": transactionId: " +
                   transactionId + ": status: " + status + ": transactionType:" + transactionType + ": beginTime:" +
                   beginTime.getTime());
    }
    try {
      String requestName = "processPatternAnalysis";
      String xmlParameter =
        VCryptTrackerUtil.toXMLProcessPatternAnalysis(requestId, transactionId, status, transactionType);

      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
        response = VCryptCommonUtil.fromVCryptResponseXml(xmlReturn);
        if (response == null) {
          logger.error("processPatternAnalysis didn't return any value. requestId=" + requestId);
        }
      } else {
        logger.error("VCryptSOAP not created yet. No action take for processPatternAnalysis() requestId=" + requestId);
      }

    } catch (Exception ex) {
      logger.error("Caught exception. processPatternAnalysis() requestId=" + requestId, ex);
    } finally {
      if (logger.isDebugEnabled()) {
        logger.debug("VCryptTrackerSOAPImpl:processPatternAnalysis(Exiting):" + requestId + ":" +
                     (new Date().getTime() - beginTime.getTime()));
      }
    }
    return response;
  }

  public VCryptResponse createTransaction(final TransactionCreateRequestData transactionCreateRequestData) {
    try {
      if (transactionCreateRequestData == null) {
        logger.error("createTransaction transactionCreateRequestData is null");
        return new VCryptResponse(VCryptResponse.NO_DATA, "Missing required parameters.");
      }
      String xmlParameter = VCryptTrackerUtil.toXMLCreateTransaction(transactionCreateRequestData);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(transactionCreateRequestData.getRequestId());
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(VCryptTracker.REQUEST_CREATE_TRANSACTION, xmlParameter);
        return VCryptCommonUtil.fromVCryptResponseXml(xmlReturn);
      } else {
        logger.error("createTransaction VCryptSOAP not created yet. No action taken transactionCreateRequestData=," +
                     transactionCreateRequestData);
        return new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "No SOAP Transport.");
      }
    } catch (Exception ex) {
      logger.error("createTransaction VCryptSOAP not created yet. No action taken transactionCreateRequestData=," +
                   transactionCreateRequestData, ex);
      return VCryptResponse.getUnexpectedErrorResponse();
    }
  }

  public VCryptResponse[] createTransactions(TransactionCreateRequestData[] transactionCreateRequestData) {
    try {
      if (transactionCreateRequestData == null || transactionCreateRequestData.length==0) {
        logger.error("createTransactions transactionCreateRequestData is null");
        return new VCryptResponse[] { new VCryptResponse(VCryptResponse.INVALID_DATA, "input data is empty") };
      }
      String xmlParameter = VCryptTrackerUtil.toXMLCreateTransactionList(transactionCreateRequestData);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(String.valueOf(transactionCreateRequestData.hashCode()));
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute("createTransactions", xmlParameter);
        return VCryptCommonUtil.fromVCryptResponseListXml(xmlReturn);
      } else {
        logger.error("createTransaction VCryptSOAP not created yet. No action taken transactionCreateRequestData=," +
                     transactionCreateRequestData);
        return createErrorResponseList(new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "No SOAP Transport."),
                                       transactionCreateRequestData.length);
      }
    } catch (Exception ex) {
      logger.error("createTransaction VCryptSOAP not created yet. No action taken transactionCreateRequestData=," +
                   transactionCreateRequestData, ex);
      return createErrorResponseList(VCryptResponse.getUnexpectedErrorResponse(), transactionCreateRequestData.length);
    }
  }

  private VCryptResponse[] createErrorResponseList(VCryptResponse response, int length) {
    VCryptResponse[] responseList = new VCryptResponse[length];
    Arrays.fill(responseList, response);
    return responseList;
  }

  public VCryptResponse updateTransaction(final TransactionUpdateRequestData transactionUpdateRequestData) {
    try {
      if (transactionUpdateRequestData == null) {
        logger.error("updateTransaction transactionUpdateRequestData is null");
        return new VCryptResponse(VCryptResponse.NO_DATA, "Missing required parameters.");
      }
      String xmlParameter = VCryptTrackerUtil.toXMLUpdateTransaction(transactionUpdateRequestData);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(transactionUpdateRequestData.getRequestId());
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(VCryptTracker.REQUEST_UPDATE_TRANSACTION, xmlParameter);
        return VCryptCommonUtil.fromVCryptResponseXml(xmlReturn);
      } else {
        logger.error("updateTransaction VCryptSOAP not created yet. No action taken transactionUpdateRequestData=" +
                     transactionUpdateRequestData);
        return new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "No SOAP Transport.");
      }
    } catch (Exception ex) {
      logger.error("updateTransaction VCryptSOAP not created yet. No action taken transactionUpdateRequestData=" +
                   transactionUpdateRequestData, ex);
      return VCryptResponse.getUnexpectedErrorResponse();
    }
  }

  public VCryptResponse[] updateTransactions(TransactionUpdateRequestData[] transactionUpdateRequestData) {
    try {
      if (transactionUpdateRequestData == null || transactionUpdateRequestData.length == 0) {
        logger.error("updateTransactions transactionUpdateRequestData is null");
        return new VCryptResponse[] { new VCryptResponse(VCryptResponse.INVALID_DATA, "input data is empty") };
      }
      String xmlParameter = VCryptTrackerUtil.toXMLUpdateTransactionList(transactionUpdateRequestData);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(String.valueOf(transactionUpdateRequestData.hashCode()));
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute("updateTransactions", xmlParameter);
        return VCryptCommonUtil.fromVCryptResponseListXml(xmlReturn);
      } else {
        logger.error("updateTransaction VCryptSOAP not created yet. No action taken transactionUpdateRequestData=" +
                     transactionUpdateRequestData);
        return createErrorResponseList(new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "No SOAP Transport."),
                                       transactionUpdateRequestData.length);
      }
    } catch (Exception ex) {
      logger.error("updateTransaction VCryptSOAP not created yet. No action taken transactionUpdateRequestData=" +
                   transactionUpdateRequestData, ex);
      return createErrorResponseList(VCryptResponse.getUnexpectedErrorResponse(), transactionUpdateRequestData.length);
    }
  }

  public NameValueProfile getNameValueProfile(String entityDefKey, Long entityId, String requestId) {
    try {
      if (logger.isDebugEnabled())
        logger.debug("getNameValueProfile() entityDefKey=" + entityDefKey + ", entityId=" + entityId +
                     ", requestId=" + requestId);
      String requestName = "getNameValueProfile";
      String xmlParameter = VCryptTrackerUtil.toXMLGetNameValueProfileRequest(entityDefKey, entityId, requestId);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlResult = vcryptSOAP.execute(requestName, xmlParameter);
        return VCryptTrackerUtil.fromXMLNameValueProfile(xmlResult);
      } else {
        logger.error("VCryptSOAP not created yet.  No action taken for getNameValueProfile() entityDefKey=" +
                     entityDefKey + ", entityId=" + entityId + ", requestId=" + requestId);
      }
    } catch (Exception ex) {
      logger.error("Exception in getNameValueProfile() entityDefKey=" + entityDefKey + ", entityId=" + entityId +
                   ", requestId=" + requestId, ex);
      return new NameValueProfile(ex);
    }
    return null;
  }

  public NameValueProfile saveNameValueProfile(NameValueProfile profile) {
    try {
      if (logger.isDebugEnabled())
        logger.debug("saveNameValueProfile() profile=" + profile);
      String requestName = "saveNameValueProfile";
      String xmlParameter = VCryptTrackerUtil.toXMLNameValueProfile(profile);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(profile.getRequestId());
      if (vcryptSOAP != null) {
        String xmlResult = vcryptSOAP.execute(requestName, xmlParameter);
        return VCryptTrackerUtil.fromXMLNameValueProfile(xmlResult);
      } else {
        logger.error("VCryptSOAP not created yet.  No action taken for saveNameValueProfile() profile=" + profile);
      }
    } catch (Exception ex) {
      logger.error("Exception in saveNameValueProfile() profile=" + profile, ex);
      return new NameValueProfile(ex);
    }
    return null;
  }

  public NameValueProfile refreshNameValueProfile(NameValueProfile profile) {
    try {
      if (logger.isDebugEnabled())
        logger.debug("refreshNameValueProfile() profile=" + profile);
      String requestName = "refreshNameValueProfile";
      String xmlParameter = VCryptTrackerUtil.toXMLNameValueProfile(profile);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(profile.getRequestId());
      if (vcryptSOAP != null) {
        String xmlResult = vcryptSOAP.execute(requestName, xmlParameter);
        return VCryptTrackerUtil.fromXMLNameValueProfile(xmlResult);
      } else {
        logger.error("VCryptSOAP not created yet.  No action taken for refreshNameValueProfile() profile=" + profile);
      }
    } catch (Exception ex) {
      logger.error("Exception in refreshNameValueProfile() profile=" + profile, ex);
      return new NameValueProfile(ex);
    }
    return null;
  }

  /**
   * @param requestId 
   * @param challengeType challenge type
   * @param appId application id
   * @return OTP Code
   */
  public String generateOTP(final String requestId, final String challengeType, final String appId){
    try {
      if (logger.isDebugEnabled())
        logger.debug("generateOTP requestId=" + requestId + ", otpChallengeType=" + challengeType + ", appId=" + appId);
      String xmlParameter = VCryptTrackerUtil.toXMLGenerateOTP(requestId, challengeType, appId);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlResult = vcryptSOAP.execute(VCryptTrackerUtil.rootNode_generateOTP, xmlParameter);
        return VCryptCommonUtil.fromXMLString(xmlResult);
      } else {
        logger.error("VCryptSOAP not created yet. No action taken for generateOTP requestId=" + requestId + ", otpChallengeType=" + challengeType + ", appId=" + appId);
      }
    } catch (Exception ex) {
      logger.error("generateOTP requestId=" + requestId + ", otpChallengeType=" + challengeType + ", appId=" + appId, ex);
    }
    return null;
  }

  public VCryptResponse resetChallengeCounter(final String requestId, final String challengeType) {
    try {
      if (logger.isDebugEnabled())
        logger.debug("resetOTPCounter requestId=" + requestId + ", otpChallengeType=" + challengeType);

      if (StringUtil.isEmpty(requestId))
        return new VCryptResponse(VCryptResponse.INVALID_DATA, "requestId Required");
      if (StringUtil.isEmpty(challengeType))
        return new VCryptResponse(VCryptResponse.INVALID_DATA, "challengeType Required");

      String xmlParameter = VCryptTrackerUtil.toXMLResetOTPCounter(requestId, challengeType);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlResult = vcryptSOAP.execute(VCryptTrackerUtil.rootNode_resetOTPCounter, xmlParameter);
        return VCryptCommonUtil.fromVCryptResponseXml(xmlResult);
      } else {
        logger.error("VCryptSOAP not created yet. No action taken for resetOTPCounter requestId=" + requestId + ", otpChallengeType=" + challengeType);
      }
    } catch (Exception ex) {
      logger.error("resetOTPCounter requestId=" + requestId + ", otpChallengeType=" + challengeType, ex);
    }
    return VCryptResponse.getUnexpectedErrorResponse();
  } // end resetOTPCounter

  public VCryptResponse incrementChallengeCounter(final String requestId, final String challengeType){
    try {
      if (logger.isDebugEnabled())
        logger.debug("incrementOTPCounter requestId=" + requestId + ", otpChallengeType=" + challengeType);
      
      if (StringUtil.isEmpty(requestId))
        return new VCryptResponse(VCryptResponse.INVALID_DATA, "requestId Required");
      if (StringUtil.isEmpty(challengeType))
        return new VCryptResponse(VCryptResponse.INVALID_DATA, "challengeType Required");
      
      String xmlParameter = VCryptTrackerUtil.toXMLIncrementOTPCounter(requestId, challengeType);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlResult = vcryptSOAP.execute(VCryptTrackerUtil.rootNode_incrementOTPCounter, xmlParameter);
        return VCryptCommonUtil.fromVCryptResponseXml(xmlResult);
      } else {
        logger.error("VCryptSOAP not created yet. No action taken for incrementOTPCounter requestId=" + requestId + ", otpChallengeType=" + challengeType);
      }
    } catch (Exception ex) {
      logger.error("incrementOTPCounter requestId=" + requestId + ", otpChallengeType=" + challengeType, ex);
    }
    return VCryptResponse.getUnexpectedErrorResponse();
  } // end incrementOTPCounter

    public VCryptObjectResponse getOTPCode(String requestId, String challengeType,
                                       Boolean overwriteIfExists) {
      try {
        if (logger.isDebugEnabled())
          logger.debug("getOTPCode requestId=" + requestId + ", otpChallengeType=" + challengeType + ", overwriteIfExists=" + overwriteIfExists);
        String xmlParameter = VCryptTrackerUtil.toXMLGetOTPCode(requestId, challengeType, overwriteIfExists);
        VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
        if (vcryptSOAP != null) {
          String xmlResult = vcryptSOAP.execute(VCryptTrackerUtil.rootNode_getOTPCode, xmlParameter);
          VCryptObjectResponse response = VCryptCommonUtil.fromVCryptObjectResponseXml(xmlResult);
          response.setObject(VCryptTrackerUtil.fromXMLOTPCode(response.getXmlValue()));
          return response;
        } else {
          logger.error("VCryptSOAP not created yet. No action taken for generateOTP requestId=" + requestId + ", otpChallengeType=" + challengeType + ", overwriteIfExists=" + overwriteIfExists);
        }
      } catch (Exception ex) {
        logger.error("generateOTP requestId=" + requestId + ", otpChallengeType=" + challengeType + ", overwriteIfExists=" + overwriteIfExists, ex);
      }
      return null;
    }

    public VCryptObjectResponse validateOTPCode(String requestId,
                                           String challengeType,
                                           String otpCode) {
        if (StringUtil.isEmpty(requestId)) {
          return new VCryptObjectResponse(null, VCryptObjectResponse.INVALID_DATA, "requestId Required");
        }
        if (StringUtil.isEmpty(otpCode)) {
          return new VCryptObjectResponse(null, VCryptObjectResponse.INVALID_DATA, "OTP Code required");
        }
      try {
        if (logger.isDebugEnabled())
          logger.debug("valiateOTPCode requestId=" + requestId + ", otpChallengeType=" + challengeType + ", otpCode=" + otpCode);
        String xmlParameter = VCryptTrackerUtil.toXMLValidateOTPCode(requestId, challengeType, otpCode);
        VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
        if (vcryptSOAP != null) {
          String xmlResult = vcryptSOAP.execute(VCryptTrackerUtil.rootNode_validateOTPCode, xmlParameter);
          VCryptObjectResponse response = VCryptCommonUtil.fromVCryptObjectResponseXml(xmlResult);
          String otpValidationResult = VCryptTrackerUtil.fromXMLOTPValidateResult(response.getXmlValue());          
          response.setObject(TrackerAPIUtil.OTPValidationResult.valueOf(otpValidationResult));
          return response;
        } else {
          logger.error("VCryptSOAP not created yet. No action taken for validateOTPCode requestId=" + requestId + ", otpChallengeType=" + challengeType + ", otpCode=" + otpCode);
            return new VCryptObjectResponse(null, VCryptObjectResponse.UNEXPECTED_ERROR, "Error in validating OTP");
        }
      } catch (Exception ex) {
        logger.error("validateOTPCode requestId=" + requestId + ", otpChallengeType=" + challengeType + ", otpCode=" + otpCode, ex);
          return new VCryptObjectResponse(null, VCryptObjectResponse.UNEXPECTED_ERROR, "Error in validating OTP");
      }      
    } 
  public VCryptObjectResponse<VCryptObjectResponse<EntityHeader>[]> createOrUpdateEntities(EntityData[] 
      entityRequestData,boolean isReplaceEntity, int commitBatchSize, String requestId) {
        VCryptObjectResponse response= new VCryptObjectResponse();
        
        try {
          if(commitBatchSize<=0){
              response.setErrorMessage("Invalid value for commitBatchSize. Value should be a positive integer");
              response.setSuccess(false);
              if (logger.isDebugEnabled()) {
                        logger.error("Invalid value for commitBatchSize. Value should be a positive integer, returning error response ["+ response + "]");
              }
              return response; 
          }
          if(entityRequestData==null){
            response.setErrorMessage("EntityData cannot be null");
            response.setSuccess(false);
            if (logger.isDebugEnabled()) {
                      logger.error("EntityData cannot be null, returning error response ["+ response + "]");
            }
            return response; 
          }
          
          if (StringUtil.isEmpty(requestId)){
            requestId= VCryptCommonUtil.generateUID(null);
          }
          if (logger.isDebugEnabled())
            logger.debug("createOrUpdateEntities requestId=" + requestId );
      String xmlParameter= VCryptTrackerUtil.toXMLCreateOrUpdateEntities(entityRequestData,isReplaceEntity,commitBatchSize,requestId);
      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
          String xmlResult = vcryptSOAP.execute(VCryptTrackerUtil.rootNode_createOrUpdateEntities, xmlParameter);
          response = VCryptCommonUtil.fromVCryptObjectResponseXml(xmlResult);
          VCryptObjectResponse[] responses = VCryptCommonUtil.fromVCryptObjectResponsesXml(response.getXmlValue());
          for(int i=0;i<responses.length;i++){
            EntityHeader entityHeader = VCryptTrackerUtil.fromXMLEntityHeader(responses[i].getXmlValue());
            responses[i].setObject(entityHeader);
          }
          response.setObject(responses);
          return response;  
      } else {
        logger.error("VCryptSOAP not created yet. No action taken for createOrUpdateEntities requestId=" + requestId);
        response.setErrorMessage("Error in entity creation/update");
        response.setSuccess(false);
      }
      } catch (Exception ex) {
      logger.error("createOrUpdateEntities requestId=" + requestId );
      response.setErrorMessage("Error in entity creation/update");
      response.setSuccess(false);
      }
      return response;
    }
    public VCryptObjectResponse<EntityHeader> searchEntityByKey(EntityData entityData){
        String requestId= VCryptCommonUtil.generateUID(null);
        VCryptObjectResponse response= new VCryptObjectResponse();
        try {              
            if(entityData==null){
                response.setErrorMessage("EntityData cannot be null");
                response.setSuccess(false);
                return response;
            }
            if (logger.isDebugEnabled())
              logger.debug("createOrUpdateEntities requestId=" + requestId );      
            String xmlParameter= VCryptTrackerUtil.toXMLSearchEntity(entityData);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
            if (vcryptSOAP != null) {
              String xmlResult = vcryptSOAP.execute(VCryptTrackerUtil.rootNode_searchEntity, xmlParameter);
              response = VCryptCommonUtil.fromVCryptObjectResponseXml(xmlResult);
              EntityHeader entityHeader = VCryptTrackerUtil.fromXMLEntityHeader(response.getXmlValue());
              response.setObject(entityHeader);
              return response;
            } else {
              logger.error("VCryptSOAP not created yet. No action taken for createOrUpdateEntities requestId=" + requestId);
              response.setErrorMessage("Error while searching entity");
              response.setSuccess(false);
            }
        } catch (Exception ex) {
          logger.error("createOrUpdateEntities requestId=" + requestId );
           response.setErrorMessage("Error while searching entity");
           response.setSuccess(false);
          }
      return response;
    }
  /**
   * This function will replace updateLog.
   * It should be used to create or update the OAAM session information.
   * @param requestId requestId for the request(If not populated will be generated in the server)
   * @param requestTime The date-time stamp on the request. (If not populated then will be generated in the server)
   * @param user User Data associated with this session.
   * @param ip IP Address data assocuated with this session.
   * @param cookieList List of device fingerprints.
   * @param sessionData Session data associated with this session.
   * @return a <code>CookieSet</code> value
   */
  public final VCryptObjectResponse<CookieSet> createOAAMSession(String requestId, Date requestTime, OAAMUserData user, OAAMIPData ip, 
                                            List<OAAMDeviceFingerprintData> cookieList, OAAMSessionData sessionData) {
    final String funcName = "createOAAMSession(" + requestId + ")";
    try {
      if (logger.isDebugEnabled())
        logger.debug(funcName + ": Entering, requestTime=" + requestTime + ", user=" + user
                     + ", cookieList=" + cookieList + ", sessionData=" + sessionData);

      String requestName = "createOAAMSession";
      String xmlParameter =
        VCryptTrackerUtil.toXMLCreateOAAMSessionRequest(requestId, requestTime, user, ip, cookieList, sessionData);

      VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
      if (vcryptSOAP != null) {
        String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
        VCryptObjectResponse<CookieSet> response = VCryptCommonUtil.fromVCryptObjectResponseXml(xmlReturn);
        CookieSet cookieSet = VCryptTrackerUtil.fromXMLFingerPrintResponse(response.getXmlValue());
        response.setObject(cookieSet);
        return response;

      } else {
        logger.error(funcName + ": VCryptSOAP not created yet. No action taken"
                              + ", requestTime=" + requestTime + ", user=" + user
                              + ", cookieList=" + cookieList + ", sessionData=" + sessionData);
        return  
          new VCryptObjectResponse<CookieSet>(new CookieSet(requestId, null, null), requestId, 
                                              VCryptResponse.APPLICATION_ERROR, "SOAP Service not available");
      }
    } catch (Exception ex) {
      logger.error(funcName + ": Caught exception. createOAAMSession()"
                      + ", requestTime=" + requestTime + ", user=" + user
                      + ", cookieList=" + cookieList + ", sessionData=" + sessionData, ex);
      return  
        new VCryptObjectResponse<CookieSet>(new CookieSet(requestId, null, null), requestId, 
                                            VCryptResponse.UNEXPECTED_ERROR, ex.getMessage());
    }
  }

  /**
   * This function will replace the updateAuthStatus method.
   * It is used to update the authentication status for the given request.
   * @param requestId It is a mandatory attribute and without this being a proper valid value, the function will return error.
   * @param sessionData Session data that needs to be updated for this request.
   * @return Returns a response code based on the results of the processing.
   */
  public VCryptResponse updateAuthStatus(String requestId, OAAMSessionData sessionData) {
    if (sessionData == null)
    return new VCryptResponse(VCryptResponse.INVALID_DATA, "sessionData Required");
    return updateAuthStatus(requestId, sessionData.getAuthenticationStatus(), sessionData.getClientType(), sessionData.getClientVersion(), sessionData.isAnalyzePatterns());
  }
}
