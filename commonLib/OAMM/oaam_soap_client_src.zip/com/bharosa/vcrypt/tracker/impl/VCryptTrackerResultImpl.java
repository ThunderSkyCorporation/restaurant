package com.bharosa.vcrypt.tracker.impl;

import com.bharosa.vcrypt.tracker.intf.VCryptTrackerResult;

/**
 * Provides information about tracker results
 * @author Luke
 */

public class VCryptTrackerResultImpl implements VCryptTrackerResult, java.io.Serializable{

	private int resultCode;

	public VCryptTrackerResultImpl(){
		resultCode = 10;
	}

	public VCryptTrackerResultImpl(int rcode){
		resultCode = rcode;
	}

	public int getCode(){ return resultCode; }

}
