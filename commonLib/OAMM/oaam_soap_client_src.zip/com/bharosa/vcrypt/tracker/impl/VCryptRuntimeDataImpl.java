package com.bharosa.vcrypt.tracker.impl;

import com.bharosa.vcrypt.tracker.intf.VCryptRuntimeData;

import java.util.Collections;
import java.util.List;

public class VCryptRuntimeDataImpl implements VCryptRuntimeData {

    int finalScore;
    List actionList;
    List alertList;
    List ruleDataList;
    private Integer runtime;
    private String runtimeName;

    public int getFinalScore() {
        return finalScore;
    }

    public void setFinalScore(int finalScore) {
        this.finalScore = finalScore;
    }

    public List getActionList() {
        return actionList == null ? Collections.EMPTY_LIST : actionList;
    }

    public void setActionList(List actionList) {
        this.actionList = actionList;
    }

    public List getAlertList() {
        return alertList == null ? Collections.EMPTY_LIST : alertList;
    }

    public void setAlertList(List alertList) {
        this.alertList = alertList;
    }

    public List getRuleDataList() {
        return ruleDataList == null ? Collections.EMPTY_LIST : ruleDataList;
    }

    public void setRuleDataList(List ruleDataList) {
        this.ruleDataList = ruleDataList;
    }

    public Integer getRuntime() {
        return runtime;
    }

    public void setRuntime(Integer runtime) {
        this.runtime = runtime;
    }

    public String getRuntimeName() {
        return runtimeName;
    }

    public void setRuntimeName(String strValue) {
        this.runtimeName=strValue;
    }

    public String toString() {
        return "VCryptRuntimeDataImpl{" +
                ", finalScore=" + finalScore +
                ", actionList=" + getActionList() +
                ", alertList=" + getAlertList() +
                ", ruleDataList=" + getRuleDataList() +
                ", runtime=" + runtime +
                ", runtimeName=" + runtimeName +
                '}';
    }

}
