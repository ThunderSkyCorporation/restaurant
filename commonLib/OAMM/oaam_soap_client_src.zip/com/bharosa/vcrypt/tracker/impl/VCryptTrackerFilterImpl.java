package com.bharosa.vcrypt.tracker.impl;

import com.bharosa.vcrypt.common.util.VCryptObjectResponse;

import java.util.Date;
import java.util.Map;

import com.bharosa.common.logger.Logger;

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;

import com.bharosa.vcrypt.common.data.OAAMDeviceFingerprintData;
import com.bharosa.vcrypt.common.data.OAAMIPData;
import com.bharosa.vcrypt.common.data.OAAMSessionData;
import com.bharosa.vcrypt.common.data.OAAMUserData;
import com.bharosa.vcrypt.common.util.VCryptBooleanResponse;
import com.bharosa.vcrypt.common.util.VCryptResponse;

import com.bharosa.vcrypt.tracker.data.TransactionCreateRequestData;
import com.bharosa.vcrypt.tracker.data.TransactionUpdateRequestData;
import com.bharosa.vcrypt.tracker.intf.NameValueProfile;
import com.bharosa.vcrypt.tracker.intf.VCryptTracker;
import com.bharosa.vcrypt.tracker.transaction.data.EntityData;
import com.bharosa.vcrypt.tracker.transaction.data.EntityHeader;
import com.bharosa.vcrypt.tracker.util.CookieSet;

import java.util.List;

/*
 * Copyright (c) 2006 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * Description Date: Oct 10, 2006
 *
 * @author bosco
 */
public class VCryptTrackerFilterImpl implements VCryptTracker {

  private static Logger logger = Logger.getLogger(VCryptTrackerFilterImpl.class);

  final static Object lock = new Object();
  static VCryptTracker vcryptTracker = null;

  public VCryptTrackerFilterImpl() {
    synchronized (lock) {
      if (vcryptTracker == null) {
        logger.info("Creating new VCryptTracker instance...");
        try {
          String trackerClassName = BharosaConfig.get("vcrypt.tracker.filter.impl.classname");
          if (trackerClassName == null || trackerClassName.trim().equals("")) {
            boolean useSoap = BharosaConfig.getBoolean("vcrypt.tracker.soap.useSOAPServer", false);
            if (useSoap) {
              trackerClassName =
                  BharosaConfig.get("vcrypt.tracker.util.soap.classname", "com.bharosa.vcrypt.tracker.impl.VCryptTrackerSOAPImpl");
            } else {
              trackerClassName =
                  BharosaConfig.get("vcrypt.tracker.util.static.classname", "com.bharosa.vcrypt.tracker.impl.VCryptTrackerMonitorImpl");
            }
          }
          if (!StringUtil.isEmpty(trackerClassName)) {
            // Loading instance
            logger.info("Loading class " + trackerClassName);
            vcryptTracker = (VCryptTracker)Class.forName(trackerClassName).newInstance();
          } else {
            logger.error("Class not created. vcrypt.tracker.filter.impl.classname should be set");
          }
        } catch (Exception ex) {
          logger.error("Error creating VCryptTracker instance.", ex);
        }
      }
    }
  }

  /**
   * Initialize or warmup server. Will load necessary caches. Call this method
   * when appserver is first started.
   *
   * @return VCryptResponse object
   */
  public VCryptResponse init(String requestId) {
    Date beginTime = new Date();
    VCryptResponse vCryptResponse = null;
    try {
      vCryptResponse = vcryptTracker.init(requestId);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:init:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }
    if (vCryptResponse == null)
      logger.error("FILTER:init:" + requestId, new Exception().fillInStackTrace());
    return vCryptResponse;
  }

  /**
   * This creates the signatures required to finger print the device.
   *
   * @param requestId
   *           This it the id for the login session. The same Id should be used
   *           for all the calls to Bharosa API for the login session.
   * @param remoteIPAddr
   *           The IP from where the request came in. This is extracted from
   *           the HTTP request.
   * @param remoteHost
   *           The host name from where the request came in. This is optional.
   * @param secureCookie
   *           The secure cookie. This is passed only if it is received from
   *           the browser
   * @param secureClientType
   *           secure cookie client type. This is an enum value defined to
   *           identify the client used for authentication.
   * @param secureClientVersion
   *           version of the secure cookie client. This is an optional
   *           parameter to specify the version of the client used.
   * @param digitalCookie
   *           The digital signature cookie. This could be the flash cookie.
   *           This parameter is sent only it is sent by the browser.
   * @param digitalClientType
   *           digital cookie client type. The type of flash client used. If
   *           not available, please use the value 0.
   * @param digitalClientVersion
   *           version of the digital cookie client. The version of the flash
   *           client.
   * @param fingerPrintType
   *           Type of finger printing. The value for defined in the properties
   *           file.
   * @param fingerPrint
   *           Finger print. If it is browser characteristics, then the header
   *           is parsed into this string. This is the name value
   *           representation of the browser header information.
   * @param fingerPrintType2
   *           This in case the same request can have multipe finger prints.
   *           Like flash request. The value is defined in the properties file.
   * @param fingerPrint2
   *           The second finger print value. If it is from the flash, then it
   *           is passed as it is. This is an optional parameter.
   * @return a <code>CookieSet</code> value
   */
  public CookieSet handleTrackerRequest(String requestId, String remoteIPAddr, String remoteHost, String secureCookie,
                                        int secureClientType, String secureClientVersion, String digitalCookie,
                                        int digitalClientType, String digitalClientVersion, int fingerPrintType,
                                        String fingerPrint, int fingerPrintType2, String fingerPrint2) {
    Date beginTime = new Date();
    CookieSet cookieSet = null;
    try {
      cookieSet =
          vcryptTracker.handleTrackerRequest(requestId, remoteIPAddr, remoteHost, secureCookie, secureClientType,
                                             secureClientVersion, digitalCookie, digitalClientType,
                                             digitalClientVersion, fingerPrintType, fingerPrint, fingerPrintType2,
                                             fingerPrint2);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:handleTrackerRequest:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }
    if (cookieSet == null)
      logger.error("FILTER:handleTrackerRequest:" + requestId + ", remoteIPAddr=" + remoteIPAddr + ", remoteHost=" +
                   remoteHost + ", secureCookie=" + secureCookie + ", secureClientType=" + secureClientType +
                   ", secureClientVersion=" + secureClientVersion + ", digitalSigCookie=" + digitalCookie +
                   ", digitalClientType=" + digitalClientType + ", digitalClientVersion=" + digitalClientVersion,
                   new Exception().fillInStackTrace());
    return cookieSet;
  }

  /**
   * This creates the signatures required to finger print the device. This
   * method takes the requestTime as input.
   *
   * @param requestId
   *           This it the id for the request
   * @param requestTime
   *           Time when this request was made. Used by simulator.
   * @param remoteIPAddr
   *           The IP from where the request came in
   * @param remoteHost
   *           The host name from where the request came in
   * @param secureCookie
   *           The secure cookie
   * @param secureClientType
   *           secure cookie client type
   * @param secureClientVersion
   *           version of the secure cookie client
   * @param digitalSigCookie
   *           The digital signature cookie
   * @param digitalClientType
   *           digital cookie client type
   * @param digitalClientVersion
   *           version of the digital cookie client
   * @param fingerPrintType
   *           Type of finger printing
   * @param fingerPrint
   *           Finger print
   * @param fingerPrintType2
   *           This in case the same request can have multipe finger prints.
   *           Like flash request.
   * @param fingerPrint2
   *           The second finger print value
   * @return a <code>CookieSet</code> value
   */
  public CookieSet handleTrackerRequest(String requestId, Date requestTime, String remoteIPAddr, String remoteHost,
                                        String secureCookie, int secureClientType, String secureClientVersion,
                                        String digitalSigCookie, int digitalClientType, String digitalClientVersion,
                                        int fingerPrintType, String fingerPrint, int fingerPrintType2,
                                        String fingerPrint2) {
    Date beginTime = new Date();
    CookieSet cookieSet = null;
    try {
      cookieSet =
          vcryptTracker.handleTrackerRequest(requestId, requestTime, remoteIPAddr, remoteHost, secureCookie, secureClientType,
                                             secureClientVersion, digitalSigCookie, digitalClientType,
                                             digitalClientVersion, fingerPrintType, fingerPrint, fingerPrintType2,
                                             fingerPrint2);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:handleTrackerRequest:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }
    if (cookieSet == null)
      logger.error("FILTER:handleTrackerRequest:" + requestId + ", remoteIPAddr=" + remoteIPAddr + ", remoteHost=" +
                   remoteHost + ", secureCookie=" + secureCookie + ", secureClientType=" + secureClientType +
                   ", secureClientVersion=" + secureClientVersion + ", digitalSigCookie=" + digitalSigCookie +
                   ", digitalClientType=" + digitalClientType + ", digitalClientVersion=" + digitalClientVersion,
                   new Exception().fillInStackTrace());
    return cookieSet;
  }

  /**
   * This creates the signatures required to finger print the device.
   *
   * @param requestId
   *           This it the id for the login session. The same Id should be used
   *           for all the calls to Bharosa API for the login session.
   * @param contextMap
   *           array of contextMap
   */
  public VCryptResponse handleTransactionLog(String requestId, Map[] contextMap) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.handleTransactionLog(requestId, contextMap);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:handleTransactionLog:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }
  }

  /**
   * This creates the signatures required to finger print the device.
   *
   * @param requestId
   *           This it the id for the request
   * @param requestTime
   *           Time for this transaction
   * @param contextMap
   *           array of context data maps
   * @return VCryptResponse
   */
  public VCryptResponse handleTransactionLog(String requestId, Date requestTime, Map[] contextMap) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.handleTransactionLog(requestId, requestTime, contextMap);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:handleTransactionLog:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }
  }

  /**
   * This creates the signatures required to finger print the device.
   *
   * @param requestId
   *           This it the id for the request
   * @param requestTime
   *           Time for this transaction
   * @param transactionStatus
   *           transaction status for this transaction
   * @param contextMap
   *           array of context data maps
   * @return VCryptResponse
   */
  public VCryptResponse handleTransactionLog(String requestId, Date requestTime, Integer transactionStatus,
                                             Map[] contextMap) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.handleTransactionLog(requestId, requestTime, transactionStatus, contextMap);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:handleTransactionLog:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }
  }

  /**
   * Update given transaction status.
   *
   * @param requestId
   *           Request Identifier
   * @param transactionId
   *           Transaction Id to be updated. See #handleTrackerRequest,
   *           #handleTransactionLog
   * @param status
   *           New Status
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, long transactionId, int status) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.updateTransactionStatus(requestId, transactionId, status);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:updateTransactionStatus:" + requestId + ":" +
                     (new Date().getTime() - beginTime.getTime()));
    }
  }

  /**
   * Update given transaction status.
   * <p>
   * AnalyzePatterns param is used by auto-learning.
   *
   * @since 10.1.4.5
   * @param requestId
   *           Request Identifier
   * @param transactionId
   *           Transaction Id to be updated. See #handleTrackerRequest,
   *           #handleTransactionLog
   * @param status
   *           New Status
   * @param analyzePatterns
   *           Boolean to indicate if the pattern analysis should be done.
   *           <p>
   *           When passed in as true the pattern analysis is done for this
   *           transaction.
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, long transactionId, int status,
                                                boolean analyzePatterns) {
    Date beginTime = new Date();
    if (logger.isDebugEnabled()) {
      logger.debug("VCryptTrackerFilterImpl:updateTransactionStatus(Entering):" + requestId + ": transactionId: " +
                   transactionId + ": status: " + status + ": analyzePatterns:" + analyzePatterns + ": beginTime:" +
                   beginTime.getTime());
    }
    try {
      return vcryptTracker.updateTransactionStatus(requestId, transactionId, status, analyzePatterns);
    } finally {
      if (logger.isDebugEnabled()) {
        logger.debug("VCryptTrackerFilterImpl:updateTransactionStatus(Exiting):" + requestId + ":" +
                     (new Date().getTime() - beginTime.getTime()));
      }
    }
  }

  /**
   * Update given transaction status.
   *
   * @param requestId
   *           Request Identifier
   * @param requestTime
   *           Time of the update
   * @param transactionId
   *           Transaction Id to be updated. See #handleTrackerRequest,
   *           #handleTransactionLog
   * @param status
   *           New Status
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, Date requestTime, long transactionId, int status) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.updateTransactionStatus(requestId, requestTime, transactionId, status);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:updateTransactionStatus:" + requestId + ":" +
                     (new Date().getTime() - beginTime.getTime()));
    }
  }

  /**
   * Update given transaction status.
   *
   * @param requestId
   *           Request Identifier
   * @param transactionId
   *           Transaction Id to be updated. See #handleTrackerRequest,
   *           #handleTransactionLog
   * @param status
   *           New Status
   * @param contextMap
   *           array of contextMap
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, long transactionId, int status, Map[] contextMap) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.updateTransactionStatus(requestId, transactionId, status, contextMap);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:updateTransactionStatus:" + requestId + ":" +
                     (new Date().getTime() - beginTime.getTime()));
    }
  }

  /**
   * Update given transaction status.
   *
   * @param requestId
   *           Request Identifier
   * @param requestTime
   *           Time of the update
   * @param transactionId
   *           Transaction Id to be updated. See #handleTrackerRequest,
   *           #handleTransactionLog
   * @param status
   *           New Status
   * @param contextMap
   *           array of contextMap
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, Date requestTime, long transactionId, int status,
                                                Map[] contextMap) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.updateTransactionStatus(requestId, requestTime, transactionId, status, contextMap);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:updateTransactionStatus:" + requestId + ":" +
                     (new Date().getTime() - beginTime.getTime()));
    }
  }

  /**
   * Update given transaction status.
   *
   * @param requestId
   *           Request Identifier
   * @param requestTime
   *           Time of the update
   * @param transactionId
   *           Transaction Id to be updated. See #handleTrackerRequest,
   *           #handleTransactionLog
   * @param status
   *           New Status
   * @param contextMap
   *           array of contextMap
   * @return VCryptResponse
   */
  public VCryptResponse updateTransactionStatus(String requestId, Date requestTime, long transactionId, int status,
                                                Map[] contextMap, boolean analyzePatterns) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.updateTransactionStatus(requestId, requestTime, transactionId, status, contextMap,
                                                   analyzePatterns);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:updateTransactionStatus:" + requestId + ":" +
                     (new Date().getTime() - beginTime.getTime()));
    }
  }

  /**
   * Updates the user node log. And if required, it creates the CookieSet also.
   *
   * @param requestId
   *           This it the id for the login session. The same Id should be used
   *           for all the calls to Bharosa API for the login session.
   * @param remoteIPAddr
   *           The IP from where the request came in. This is extracted from
   *           the HTTP request.
   * @param remoteHost
   *           The host name from where the request came in. This is optional.
   * @param secureCookie
   *           The secure cookie. This is passed only if it is received from
   *           the browser
   * @param digitalCookie
   *           The Digital cookie. Can be flash cookie
   * @param groupId
   *           the groupId of this user. This is the primary group to which
   *           this user belongs to.
   * @param userId
   *           id of the user. This is the primary key id of the user. It
   *           should be null for user who are invalid.
   * @param loginId
   *           the loginId used by the user for login in. This is mandatory
   *           parameter.
   * @param isSecure
   *           whether this node is secure and can be registered. This is to
   *           indicate the login is from a secure or registered device. If
   *           there is no concept of device, then send false value for this
   *           parameter.
   * @param result
   *           The authentication result. This is the enumeration value of the
   *           authentication result.
   * @param clientType
   *           This is an enum value defined to identify the client type used
   *           for authentication.
   * @param clientVersion
   *           the version of the client. This is an optional parameter to
   *           specify the version of the client used.
   * @param fingerPrintType
   *           Type of finger printing. The value for defined in the properties
   *           file.
   * @param fingerPrint
   *           If it is browser characteristics, then the header is parsed into
   *           this string. This is the name value representation of the
   *           browser header information.
   * @param digFingerPrintType
   *           Type of the Digital finger printing
   * @param digFingerPrint
   *           Digital fingerprint
   * @return a <code>CookieSet</code> value
   */
  public CookieSet updateLog(String requestId, String remoteIPAddr, String remoteHost, String secureCookie,
                             String digitalCookie, String groupId, String userId, String loginId, boolean isSecure,
                             int result, int clientType, String clientVersion, int fingerPrintType, String fingerPrint,
                             int digFingerPrintType, String digFingerPrint) {
    Date beginTime = new Date();
    CookieSet cookieSet = null;
    try {
      cookieSet =
          vcryptTracker.updateLog(requestId, remoteIPAddr, remoteHost, secureCookie, digitalCookie, groupId, userId,
                                  loginId, isSecure, result, clientType, clientVersion, fingerPrintType, fingerPrint,
                                  digFingerPrintType, digFingerPrint);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:updateLog:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }
    if (cookieSet == null)
      logger.error("FILTER:updateLog:" + requestId + ", remoteIPAddr=" + remoteIPAddr + ", remoteHost=" + remoteHost +
                   ", secureCookie=" + secureCookie + ", digitalSigCookie=" + digitalCookie + ", groupId=" + groupId +
                   ", userId=" + userId + ", loginId=" + loginId + ", isSecure=" + isSecure + ", result=" + result +
                   ", clientType=" + clientType + ", clientVersion=" + clientVersion,
                   new Exception().fillInStackTrace());
    return cookieSet;
  }

  /**
   * Updates the user node log. And if required, it creates the CookieSet also.
   *
   * @param requestId
   *           requestId for the request
   * @param requestTime
   *           Time when this request was make. Used primarily by the simulator
   * @param remoteIPAddr
   *           The IP from where the request came in
   * @param remoteHost
   *           The host name from where the request came in
   * @param secureCookie
   *           The secure cookie
   * @param digitalCookie
   *           the secure cookie, can be flash cookie
   * @param groupId
   *           the groupId of this user.
   * @param userId
   *           id of the user
   * @param loginId
   *           the loginId used by the user for login in
   * @param isSecure
   *           whether this node is secure and can be registered
   * @param result
   *           The authentication result.
   * @param clientType
   *           the type of the client used for authentication
   * @param clientVersion
   *           the version of the client
   * @param fingerPrintType
   *           Type of finger printing
   * @param fingerPrint
   *           Finger print
   * @param fingerPrintType2
   *           Type of the Digital finger printing
   * @param fingerPrint2
   *           Digital fingerprint
   * @return a <code>CookieSet</code> value
   */
  public CookieSet updateLog(String requestId, Date requestTime, String remoteIPAddr, String remoteHost,
                             String secureCookie, String digitalCookie, String groupId, String userId, String loginId,
                             boolean isSecure, int result, int clientType, String clientVersion, int fingerPrintType,
                             String fingerPrint, int fingerPrintType2, String fingerPrint2) {
    Date beginTime = new Date();
    CookieSet cookieSet = null;
    try {
      cookieSet =
          vcryptTracker.updateLog(requestId, requestTime, remoteIPAddr, remoteHost, secureCookie, digitalCookie,
                                  groupId, userId, loginId, isSecure, result, clientType, clientVersion,
                                  fingerPrintType, fingerPrint, fingerPrintType2, fingerPrint2);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:updateLog:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }
    if (cookieSet == null)
      logger.error("FILTER:updateLog:" + requestId + ", remoteIPAddr=" + remoteIPAddr + ", remoteHost=" + remoteHost +
                   ", secureCookie=" + secureCookie + ", digitalSigCookie=" + digitalCookie + ", groupId=" + groupId +
                   ", userId=" + userId + ", loginId=" + loginId + ", isSecure=" + isSecure + ", result=" + result +
                   ", clientType=" + clientType + ", clientVersion=" + clientVersion,
                   new Exception().fillInStackTrace());
    return cookieSet;
  }

  /**
   * Updates User node log auth status
   *
   * @param requestId
   *           request Id
   * @param resultStatus
   *           The authentication result. This is the enumeration value of the
   *           authentication result.
   * @param clientType
   *           This is an enum value defined to identify the client type used
   *           for authentication.
   * @param clientVersion
   *           Optional parameter to specify the version of the client used.
   * @return VCryptResponse
   */
  public VCryptResponse updateAuthStatus(String requestId, int resultStatus, int clientType, String clientVersion) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.updateAuthStatus(requestId, resultStatus, clientType, clientVersion);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:updateAuthStatus:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }
  }

  /**
   * Updates User node log auth status
   *
   * @param requestId
   *           request Id
   * @param requestTime
   *           Time of update
   * @param resultStatus
   *           The authentication result. This is the enumeration value of the
   *           authentication result.
   * @return VCryptResponse
   */
  public VCryptResponse updateAuthStatus(String requestId, Date requestTime, int resultStatus, int clientType,
                                         String clientVersion) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.updateAuthStatus(requestId, requestTime, resultStatus, clientType, clientVersion);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:updateAuthStatus:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }

  }

  /**
   * Updates User node log auth status
   *
   * @param requestId
   *           request Id
   * @param requestTime
   *           Time of update
   * @param resultStatus
   *           The authentication result. This is the enumeration value of the
   *           authentication result.
   * @return VCryptResponse
   */
  public VCryptResponse updateAuthStatus(String requestId, Date requestTime, int resultStatus, int clientType,
                                         String clientVersion, boolean analyzePatterns) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.updateAuthStatus(requestId, requestTime, resultStatus, clientType, clientVersion,
                                            analyzePatterns);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:updateAuthStatus:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }
  }

  /**
   * Updates User node log auth status
   * <p>
   * AnalyzePatterns param is used by auto-learning.
   *
   * @since 10.1.4.5
   * @param requestId
   *           request Id
   * @param resultStatus
   *           The authentication result. This is the enumeration value of the
   *           authentication result.
   * @param clientType
   *           This is an enum value defined to identify the client type used
   *           for authentication.
   * @param clientVersion
   *           Optional parameter to specify the version of the client used.
   * @param analyzePatterns
   *           Boolean to indicate if the pattern analysis should be done.
   *           <p>
   *           When passed in as true the pattern analysis is done for this
   *           transaction.
   * @return VCryptResponse
   */
  public VCryptResponse updateAuthStatus(String requestId, int resultStatus, int clientType, String clientVersion,
                                         boolean analyzePatterns) {
    Date beginTime = new Date();
    if (logger.isDebugEnabled()) {
      logger.debug("VCryptTrackerFilterImpl:updateAuthStatus(entering):" + requestId + ": resultStatus: " +
                   resultStatus + ": clientType: " + clientType + ": analyzePatterns:" + analyzePatterns +
                   ": beginTime:" + beginTime.getTime());
    }
    try {
      return vcryptTracker.updateAuthStatus(requestId, resultStatus, clientType, clientVersion, analyzePatterns);
    } finally {
      if (logger.isDebugEnabled()) {
        logger.debug("VCryptTrackerFilterImpl:updateAuthStatus(Exiting):" + requestId + ":" +
                     (new Date().getTime() - beginTime.getTime()));
      }
    }
  }

  /**
   * This marks the device as safe for the user.
   *
   * @param requestId
   *           requestId for the request
   * @param isSafe
   *           is this device safe for the user
   * @return status of the operation
   */
  public boolean markDeviceSafe(String requestId, boolean isSafe) {
    Date beginTime = new Date();
    try {
      return vcryptTracker.markDeviceSafe(requestId, isSafe);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:markDeviceSafe:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
    }
  }

  public VCryptBooleanResponse IsDeviceMarkedSafe(String requestId) {
    try {
      return vcryptTracker.IsDeviceMarkedSafe(requestId);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:IsDeviceMarkedSafe:" + requestId);
    }
  }

  public VCryptResponse clearSafeDeviceList(String requestId) {
    try {
      return vcryptTracker.clearSafeDeviceList(requestId);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:clearSafeDeviceList:" + requestId);
    }
  }

  /**
   * Method to trigger the pattern data processing for auto-learning.
   * <p>
   * This method does not do any other activity other than auto-learning
   * pattern analysis.
   *
   * @since 10.1.4.5
   * @param requestId
   *           Request Identifier
   * @param transactionId
   *           Transaction Id to be updated. See #handleTrackerRequest,
   *           #handleTransactionLog
   * @param status
   *           New Status
   * @param transactionType
   *           String that indicates the type of transaction. Has to be "auth"
   *           for authentication type. For other types it can be "bill_pay,
   *           ....",; basically the type name of the transaction.
   * @return VCryptResponse to see if the request is successfully processed.
   */
  public VCryptResponse processPatternAnalysis(String requestId, long transactionId, int status,
                                               String transactionType) {
    Date beginTime = new Date();
    if (logger.isDebugEnabled()) {
      logger.debug("VCryptTrackerFilterImpl:processPatternAnalysis(Entering):" + requestId + ": transactionId: " +
                   transactionId + ": status: " + status + ": transactionType:" + transactionType + ": beginTime:" +
                   beginTime.getTime());
    }
    try {
      return vcryptTracker.processPatternAnalysis(requestId, transactionId, status, transactionType);
    } finally {
      if (logger.isDebugEnabled()) {
        logger.debug("VCryptTrackerFilterImpl:processPatternAnalysis(Exiting):" + requestId + ":" +
                     (new Date().getTime() - beginTime.getTime()));
      }
    }
  }

  public VCryptResponse[] createTransactions(TransactionCreateRequestData[] transactionCreateRequestData) {
    Date beginTime = new Date();
    if (logger.isDebugEnabled()) {
      logger.debug("VCryptTrackerFilterImpl:createTransactions(Entering):" + transactionCreateRequestData +
                   ": beginTime:" + beginTime.getTime());
    }
    try {
      return vcryptTracker.createTransactions(transactionCreateRequestData);
    } finally {
      if (logger.isDebugEnabled()) {
        logger.debug("VCryptTrackerFilterImpl:createTransactions(Exiting):" + transactionCreateRequestData + ":" +
                     (new Date().getTime() - beginTime.getTime()));
      }
    }
  }

  public VCryptResponse createTransaction(TransactionCreateRequestData transactionCreateRequestData) {
    Date beginTime = new Date();
    if (logger.isDebugEnabled()) {
      logger.debug("VCryptTrackerFilterImpl:createTransaction(Entering):" + transactionCreateRequestData +
                   ": beginTime:" + beginTime.getTime());
    }
    try {
      return vcryptTracker.createTransaction(transactionCreateRequestData);
    } finally {
      if (logger.isDebugEnabled()) {
        logger.debug("VCryptTrackerFilterImpl:createTransaction(Exiting):" + transactionCreateRequestData + ":" +
                     (new Date().getTime() - beginTime.getTime()));
      }
    }
  }

  public VCryptResponse[] updateTransactions(TransactionUpdateRequestData[] transactionUpdateRequestData) {
    Date beginTime = new Date();
    if (logger.isDebugEnabled()) {
      logger.debug("VCryptTrackerFilterImpl:updateTransactions(Entering):" + transactionUpdateRequestData +
                   ": beginTime:" + beginTime.getTime());
    }
    try {
      return vcryptTracker.updateTransactions(transactionUpdateRequestData);
    } finally {
      if (logger.isDebugEnabled()) {
        logger.debug("VCryptTrackerFilterImpl:updateTransactions(Exiting):" + transactionUpdateRequestData + ":" +
                     (new Date().getTime() - beginTime.getTime()));
      }
    }
  }

  public VCryptResponse updateTransaction(TransactionUpdateRequestData transactionUpdateRequestData) {
    Date beginTime = new Date();
    if (logger.isDebugEnabled()) {
      logger.debug("VCryptTrackerFilterImpl:updateTransaction(Entering):" + transactionUpdateRequestData +
                   ": beginTime:" + beginTime.getTime());
    }
    try {
      return vcryptTracker.updateTransaction(transactionUpdateRequestData);
    } finally {
      if (logger.isDebugEnabled()) {
        logger.debug("VCryptTrackerFilterImpl:updateTransaction(Exiting):" + transactionUpdateRequestData + ":" +
                     (new Date().getTime() - beginTime.getTime()));
      }
    }
  }

  public NameValueProfile getNameValueProfile(String entityDefKey, Long extEntityId, String requestId) {
    long beginTime = System.currentTimeMillis();
    NameValueProfile profile = null;
    try {
      profile = vcryptTracker.getNameValueProfile(entityDefKey, extEntityId, requestId);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:getNameValueProfile:" + (System.currentTimeMillis() - beginTime));
    }
    if (profile == null) {
      logger.error("getNameValueProfile returned null. entityDefKey=" + entityDefKey + ", extEntityId=" + extEntityId +
                   ", requestId=" + requestId);
    }
    return profile;
  }

  public NameValueProfile saveNameValueProfile(NameValueProfile aProfile) {
    long beginTime = System.currentTimeMillis();
    NameValueProfile profile = null;
    try {
      profile = vcryptTracker.saveNameValueProfile(aProfile);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:save:" + (System.currentTimeMillis() - beginTime));
    }
    if (profile == null) {
      logger.error("save returned null. profile=" + aProfile);
    }
    return profile;
  }

  public NameValueProfile refreshNameValueProfile(NameValueProfile aProfile) {
    long beginTime = System.currentTimeMillis();
    NameValueProfile profile = null;
    try {
      profile = vcryptTracker.saveNameValueProfile(aProfile);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:save:" + (System.currentTimeMillis() - beginTime));
    }
    if (profile == null) {
      logger.error("save returned null. profile=" + aProfile);
    }
    return profile;
  }

  public VCryptResponse resetChallengeCounter(String requestId, String challengeType) {
    long beginTime = System.currentTimeMillis();
    VCryptResponse response = null;
    try {
      response = vcryptTracker.resetChallengeCounter(requestId, challengeType);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:resetChallengeCounter:" + (System.currentTimeMillis() - beginTime));
    }
    return response;
  }

  public VCryptResponse incrementChallengeCounter(String requestId, String challengeType) {
    long beginTime = System.currentTimeMillis();
    VCryptResponse response = null;
    try {
      response = vcryptTracker.incrementChallengeCounter(requestId, challengeType);
    } finally {
      if (logger.isDebugEnabled())
        logger.debug("FILTER:incrementChallengeCounter:" + (System.currentTimeMillis() - beginTime));
    }
    return response;
  }

    public String generateOTP(String requestId, String challengeType,
                              String appId) {
      long beginTime = System.currentTimeMillis();
      String response = null;
      try {
        response = vcryptTracker.generateOTP(requestId, challengeType, appId);
      } finally {
        if (logger.isDebugEnabled())
          logger.debug("FILTER:generateOTP:" + (System.currentTimeMillis() - beginTime));
      }
      return response;
    }

    public VCryptObjectResponse getOTPCode(final String requestId, final String challengeType,
                                       final Boolean overwriteIfExists) {
      long beginTime = System.currentTimeMillis();
      VCryptObjectResponse response = null;
      try {
        response = vcryptTracker.getOTPCode(requestId, challengeType, overwriteIfExists);
      } finally {
        if (logger.isDebugEnabled())
          logger.debug("FILTER:getOTPCode:" + (System.currentTimeMillis() - beginTime));
      }
      return response;
    }

    public VCryptObjectResponse validateOTPCode(String requestId,
                                           String challengeType,
                                           String otpcode) {
      long beginTime = System.currentTimeMillis();
      VCryptObjectResponse response = null;
      try {
        response = vcryptTracker.validateOTPCode(requestId, challengeType, otpcode);
      } finally {
        if (logger.isDebugEnabled())
          logger.debug("FILTER:valiateOTPCode:" + (System.currentTimeMillis() - beginTime));
      }
      return response;
    }
  public VCryptObjectResponse<VCryptObjectResponse<EntityHeader>[]> createOrUpdateEntities(EntityData[] 
      entityRequestData,boolean isReplaceEntity, int commitBatchSize, String requestId){
	  long beginTime = System.currentTimeMillis();
      VCryptObjectResponse<VCryptObjectResponse<EntityHeader>[]> response = null;
	  try {
		  response = vcryptTracker.createOrUpdateEntities(entityRequestData, isReplaceEntity, commitBatchSize, requestId);
	  } finally {
		  if (logger.isDebugEnabled())
	          logger.debug("FILTER:createOrUpdateEntities:" + (System.currentTimeMillis() - beginTime));
	  }
      return response;    
    }
  
    public VCryptObjectResponse<EntityHeader> searchEntityByKey(EntityData entityData){
    	long beginTime = System.currentTimeMillis();
        VCryptObjectResponse<EntityHeader> response = null;
  	  try {
  		  response = vcryptTracker.searchEntityByKey(entityData);
  	  } finally {
  		  if (logger.isDebugEnabled())
  	          logger.debug("FILTER:searchEntityByKey:" + (System.currentTimeMillis() - beginTime));
  	  }
        return response;          
    }

    public VCryptObjectResponse<CookieSet> createOAAMSession(String requestId, Date requestTime, OAAMUserData user, OAAMIPData ip, 
                                            List<OAAMDeviceFingerprintData> cookieList, OAAMSessionData sessionData) {
      long beginTime = System.currentTimeMillis();
        VCryptObjectResponse<CookieSet> response = null;
      try {
        response = vcryptTracker.createOAAMSession(requestId, requestTime, user, ip, cookieList, sessionData);
      } finally {
        if (logger.isDebugEnabled())
              logger.debug("FILTER:createOAAMSession:" + (System.currentTimeMillis() - beginTime));
      }
        return response;  
    }


    public VCryptResponse updateAuthStatus(String requestId, OAAMSessionData sessionData) {
      long beginTime = System.currentTimeMillis();
        VCryptResponse response = null;
      try {
        response = vcryptTracker.updateAuthStatus(requestId, sessionData);
      } finally {
        if (logger.isDebugEnabled())
              logger.debug("FILTER:updateAuthStatus:" + (System.currentTimeMillis() - beginTime));
      }
        return response;   
    }
}
