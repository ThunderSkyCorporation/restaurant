package com.bharosa.vcrypt.tracker.impl;

import com.bharosa.vcrypt.tracker.intf.VAlertData;

public class VAlertDataImpl implements VAlertData {

    private Long id;
    private String message;
    private String type;
    private String level;

    public VAlertDataImpl() {
    }

    public Long getId() {
        return id;
    }

    public String getMessage() {
        return message;
    }

    public String getType() {
        return type;
    }

    public String getLevel() {
        return level;
    }


    public void setId(Long id) {
        this.id = id;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String toString() {
        return "VAlertDataImpl{" +
                "id=" + id +
                ", message='" + message + '\'' +
                ", type=" + type +
                ", level=" + level +
                '}';
    }
}
