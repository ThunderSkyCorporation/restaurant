package com.bharosa.vcrypt.tracker.impl;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.vcrypt.common.intf.VCryptSOAP;
import com.bharosa.vcrypt.common.util.VCryptCommonUtil;
import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.tracker.intf.VCryptRulesEngine;
import com.bharosa.vcrypt.tracker.intf.VCryptRulesResult;
import com.bharosa.vcrypt.tracker.util.VCryptTrackerUtil;
import com.bharosa.common.logger.Logger;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * This class provides the interface to process rules.
 *
 * @author bosco
 */

public class VCryptRulesEngineSOAPImpl implements VCryptRulesEngine {

    static Logger logger = Logger.getLogger(VCryptRulesEngineSOAPImpl.class);

    static Object lock = new Object();
    static boolean initDone = false;

    /**
     * Use accessMethod to get this object.
     */
    static ArrayList vcryptSoapList = null;
    static int totalServers = 0;

    /**
     * Default constructor
     */
    public VCryptRulesEngineSOAPImpl() {
        if (logger.isDebugEnabled()) logger.debug("VCryptRulesEngineSOAPImpl() constructor");
    }

    /**
     * This is important to use this method for getting the VCryptSOAP,
     * because if server is not up when the client comes up and if the
     * connection is not established, then we might have retry issues.
     */
    VCryptSOAP getVCryptSOAP(String requestId) {
        if (vcryptSoapList == null || !initDone) {
            synchronized (lock) {
                initDone = false;
                if (vcryptSoapList == null) {
                    String serverUrl
                            = BharosaConfig.get("vcrypt.tracker.soap.url");
                    String serviceName
                            = BharosaConfig.get("vcrypt.tracker.soap.rulesEngineName");
                    if (StringUtil.isEmpty(serverUrl)) {
                        logger.fatal("SOAP url not given. Please set vcrypt.tracker.soap.url property");
                        return null;
                    }
                    vcryptSoapList = new ArrayList();
                    String urls[] = serverUrl.trim().split(",");
                    for (int i = 0; i < urls.length; i++) {
                        VCryptSOAP vcryptSoap =
                                VCryptCommonUtil.newVCryptSOAPInstance(urls[i].trim(),
                                        serviceName);
                        vcryptSoapList.add(vcryptSoap);
                    }
                    totalServers = vcryptSoapList.size();
                }
                initDone = true;
            }
        }
        if (totalServers != 0) {
            int index = 0;
            char[] charArray = requestId.toCharArray();

            for (int i = 0; i < charArray.length; i++) {
                index += (int) charArray[i];
            }
            index = index % totalServers;
            return (VCryptSOAP) vcryptSoapList.get(index);
        } else {
            return null;
        }

    }


    /**
     * This method runs the processing rules and returns VCryptRulesResult
     *
     * @param requestId   Id for the request.
     * @param requestTime Time when this rule was run.
     * @param checkpointList List of Integer objects with checkpoints to be run, can't be null or empty.
     *                    Only one profile type is supported, however this remains List for legacy reasons.
     * @return The <code>VCryptRulesResult</code>
     */
    public VCryptRulesResult processRules(final String requestId, Date requestTime, final List checkpointList, final Map contextMap) {
        if (logger.isDebugEnabled()) logger.debug("processRules( requestId=" + requestId + ")");
        try {
            String xmlParameter = VCryptTrackerUtil.toXMLProcessRulesRequest(requestId, null, null, requestTime, checkpointList, contextMap);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(REQ_PROCESS_RULES, xmlParameter);
                return VCryptTrackerUtil.fromXMLProcessRulesResponse(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for processRules() requestId=" + requestId);
                VCryptRulesResultImpl retVal = new VCryptRulesResultImpl();
                retVal.setVCryptResponse(new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "No SOAP Service"));
                return retVal;
            }
        } catch (Exception ex) {
            logger.error("Caught exception. processRules() requestId=" + requestId, ex);
            VCryptRulesResultImpl retVal = new VCryptRulesResultImpl();
            retVal.setVCryptResponse(new VCryptResponse(VCryptResponse.UNEXPECTED_ERROR, ex.getMessage()));
            return retVal;
        }


    } // end processRules

    public VCryptRulesResult processRules(final String requestId, final Long transactionId, final String extTransactionId, Date requestTime, final List checkpointList, final Map contextMap) {
        if (logger.isDebugEnabled()) logger.debug("processRules( requestId=" + requestId + ")");
        try {
            String xmlParameter = VCryptTrackerUtil.toXMLProcessRulesRequest(requestId, transactionId, extTransactionId, requestTime, checkpointList, contextMap);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(requestId);
            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(REQ_PROCESS_RULES, xmlParameter);
                return VCryptTrackerUtil.fromXMLProcessRulesResponse(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for processRules() requestId=" + requestId);
                VCryptRulesResultImpl retVal = new VCryptRulesResultImpl();
                retVal.setVCryptResponse(new VCryptResponse(VCryptResponse.APPLICATION_ERROR, "No SOAP Service"));
                return retVal;
            }
        } catch (Exception ex) {
            logger.error("Caught exception. processRules() requestId=" + requestId, ex);
            VCryptRulesResultImpl retVal = new VCryptRulesResultImpl();
            retVal.setVCryptResponse(new VCryptResponse(VCryptResponse.UNEXPECTED_ERROR, ex.getMessage()));
            return retVal;
        }


    } // end processRules

    /**
     * This method runs the processing rules and returns
     * rules result.
     *
     * @param requestId    Id for the request.
     * @param checkpointList List of Integer objects with checkpoints to be run, can't be null or empty.
     * @param contextMap  List of name value pairs to be used by the rules
     * @return The <code>VCryptRulesResult</code>
     */
    public VCryptRulesResult processRules(String requestId, List checkpointList, Map contextMap) {
        Date requestTime = null;
        return processRules(requestId, requestTime, checkpointList, contextMap);

    }

}
