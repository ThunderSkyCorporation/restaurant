package com.bharosa.vcrypt.tracker.impl;

import com.bharosa.common.exception.BharosaErrorIds;
import com.bharosa.common.exception.BharosaRuntimeException;
import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.tracker.intf.VCryptSessionRuleData;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class VCryptSessionRuleDataImpl implements VCryptSessionRuleData {

    VCryptResponse response;
    Map runtimeData;
    String requestId;

    public VCryptSessionRuleDataImpl(String requestId, VCryptResponse response, Map runtimeData) {
        this.requestId = requestId;
        this.response = response;
        this.runtimeData = runtimeData;
    }

    public VCryptResponse getResponse() {
        return response;
    }

    public List getRuntimeDataList(Integer runtime) {

        if (!response.isSuccess()) {
        	throw new BharosaRuntimeException(BharosaErrorIds.INVALID_RESPONSE);
//            throw new RuntimeException("Invalid Reponse");
        }

        List list = (List) runtimeData.get(runtime);
        return list == null ? Collections.EMPTY_LIST : Collections.unmodifiableList(list);

    }

    public Map getRuntimeDataMap() {
        return runtimeData == null ? Collections.EMPTY_MAP : Collections.unmodifiableMap(runtimeData);
    }

    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("VCryptSessionRuleDataImpl{requestId=").append(requestId)
              .append(", response=").append(response).append(", runtimeData=");
        Map runtimeDataMap = getRuntimeDataMap();
        Iterator itr = runtimeDataMap.keySet().iterator();
        while (itr.hasNext()) {
            buffer.append("\n").append(runtimeDataMap.get(itr.next()));
        }
        return buffer.append('}').toString();
    }

    public String getRequestId() {
        return requestId;
    }


}
        