package com.bharosa.vcrypt.tracker.impl;

import com.bharosa.vcrypt.tracker.intf.VCryptRuleData;

public class VCryptRuleDataImpl implements VCryptRuleData {

    private String ruleInstanceName;
    private Long ruleInstanceId;
    private Long modelId;
    private String modelName;

    public VCryptRuleDataImpl() {
    }

    public VCryptRuleDataImpl(String ruleInstanceName, Long ruleInstanceId, Long modelId, String modelName) {
        this();
        this.ruleInstanceName = ruleInstanceName;
        this.ruleInstanceId = ruleInstanceId;
        this.modelId = modelId;
        this.modelName = modelName;
    }

    public String getRuleInstanceName() {
        return ruleInstanceName;
    }

    public void setRuleInstanceName(String ruleName) {
        this.ruleInstanceName = ruleName;
    }

    public Long getModelId() {
        return modelId;
    }

    public void setModelId(Long modelId) {
        this.modelId = modelId;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String value) {
        this.modelName = value;
    }

    public Long getRuleInstanceId() {
        return ruleInstanceId;
    }

    public void setRuleInstanceId(Long ruleInstanceId) {
        this.ruleInstanceId = ruleInstanceId;
    }

    public String toString() {
        return "VCryptRuleDataImpl{" +
                "ruleInstanceName='" + ruleInstanceName + '\'' +
                ", ruleInstanceId=" + ruleInstanceId +
                ", modelId=" + modelId +
                ", modelName=" + modelName +
                '}';
    }
}
