package com.bharosa.vcrypt.tracker.impl;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.tracker.intf.VCryptRulesResult;
import com.bharosa.vcrypt.tracker.util.CookieSet;
import com.bharosa.common.logger.Logger;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Iterator;

/**
 * This class contains the result of the rules processing.
 *
 * @author bosco
 */

public class VCryptRulesResultImpl implements VCryptRulesResult {

    private final static Logger logger = Logger.getLogger(VCryptRulesResultImpl.class);

    private List actionList = null;
    private List alertIdList = null;
    private List alertMessageList = null;
    private List alertTemplateList = null;
    private String result = null;
    private Integer runtimeType = null;
    private int score = 0;
    private Long transactionLogId;
    private VCryptResponse reponse = null;
    private Map /*<Integer>runtime, VCryptRulesResultImpl*/responseMap;
    private CookieSet cookieSet = null;
  	private Long deviceId = null;

    /**
     * Default constructor
     */
    public VCryptRulesResultImpl() {
        if (logger.isDebugEnabled()) logger.debug("default constructor()");
    }


    /**
     * Constructor which take result, actionList and alertIdList
     *
     * @param result       The rule result
     * @param actionList   The ArrayList containing the actionList
     * @param alertIdList  The ArrayList containing the alertIdList
     * @param alertMsgList The ArrayList containing the alertIdList
     */
    public VCryptRulesResultImpl(String result, List actionList, List alertIdList, List alertMsgList) {
        if (logger.isDebugEnabled()) logger.debug("constructor(result=" + result + ", actionList, alertIdList )");
        this.result = result;
        this.actionList = actionList;
        this.alertIdList = alertIdList;
        this.alertMessageList = alertMsgList;
        this.reponse = VCryptResponse.getSuccess();
    }

    public VCryptRulesResultImpl(String result, List actionList, List alertIdList, List alertMsgList, List alertTemplateList, int score) {
        this(result, actionList, alertIdList, alertMsgList);
        this.score = score;
        this.alertTemplateList = alertTemplateList;
    }

    /**
     * This method returns the list of actions.
     *
     * @return ArrayList with String objects.
     */
    public List getAllActions() {
        return this.actionList == null ? Collections.EMPTY_LIST : this.actionList;
    }

    /**
     * Sets the value of actionList
     *
     * @param argActionList Value to assign to this.actionList
     */
    public void setAllActions(List argActionList) {
        this.actionList = argActionList;
    }

    /**
     * This is the action to be taken. This action is the
     * after applying the processing rule on the list of
     * actions returned by the rule engine
     *
     * @return Action string.
     */
    public String getResult() {
        return this.result;
    }

    /**
     * Sets the value of result
     *
     * @param argResult Value to assign to this.result
     */
    public void setResult(String argResult) {
        this.result = argResult;
    }

    public Integer getRuntimeType() {
        return runtimeType;
    }

    public void setRuntimeType(Integer runtimeType) {
        this.runtimeType = runtimeType;
    }

    /**
     * Gets the value of alertIdList
     *
     * @return the value of alertIdList
     */
    public List getAlertIdList() {
        return alertIdList != null ? this.alertIdList : Collections.EMPTY_LIST;
    }

    public List getAlertMessageList() {
        return alertMessageList != null ? this.alertMessageList : Collections.EMPTY_LIST;
    }

    public void setAlertMessageList(List list) {
        alertMessageList = list;
    }

    public List getAlertTemplateList() {
        return (this.alertTemplateList != null) ? Collections.unmodifiableList(alertTemplateList) : Collections.EMPTY_LIST;
    }

    /**
     * Sets the value of alertIdList
     *
     * @param argAlertList Value to assign to this.alertIdList
     */
    public void setAlertIdList(List argAlertList) {
        this.alertIdList = argAlertList;
    }

    /**
     * @return score risk score based on all policies and pluggable scoring engines used
     */
    public final int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    /**
     * Get the transaction log id
     *
     * @return Long transaction Id, null if none available
     */
    public Long getTransactionLogId() {
        return this.transactionLogId;
    }

    public void setTransactionLogId(Long Id) {
        this.transactionLogId = Id;
    }

    /**
     * Return response code for the transaction
     *
     * @return VCryptResponse response object with error code
     */
    public VCryptResponse getVCryptResponse() {
        return reponse;
    }

    public void setVCryptResponse(VCryptResponse reponse) {
        this.reponse = reponse;
    }

    public void setResultMap(Map responseMap) {
        this.responseMap = responseMap;
    }

    public Map getResultMap() {
        return responseMap == null ? Collections.EMPTY_MAP : responseMap;
    }


    public void setCookieSet(CookieSet cookieSet) {
        this.cookieSet = cookieSet;
    }

    public CookieSet getCookieSet() {
        return this.cookieSet;
    }

	public Long getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(Long deviceId) {
		if (logger.isDebugEnabled()) {
			logger.debug("setDeviceId : deviceId [" + deviceId + " ]"
							+ " this.deviceId [" + this.deviceId + "]");
		}
		this.deviceId = deviceId;
	}

    public String toString() {
        String ret = "VCryptRulesResultImpl. " +
                     "actionList=" + actionList +
                     (alertIdList == null ? "" : ("; alertIdList=" + alertIdList)) +
                     "; result='" + result +
                     "; score=" + score +
                     "; transactionLogId=" + transactionLogId +
                     "; deviceId=" + deviceId +
                     "; runtimeType=" + runtimeType +
                     "; response=" + reponse;
        if (responseMap != null) {
            ret += "; responseMap: runtimeTypeList =";
            Iterator iter = responseMap.values().iterator();
            VCryptRulesResultImpl rulesRes = (VCryptRulesResultImpl)iter.next();
            if (rulesRes != null)
                ret += "{" + rulesRes.getRuntimeType() + "}";
            while (iter.hasNext()) {
                rulesRes = (VCryptRulesResultImpl)iter.next();
                if (rulesRes != null)
                    ret += "{" + rulesRes.getRuntimeType() + "}";
            }
        }
        return ret;
	}
}
