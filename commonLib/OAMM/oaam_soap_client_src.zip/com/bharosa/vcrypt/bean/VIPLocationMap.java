package com.bharosa.vcrypt.bean;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * Mapping of the IP range to city, state and country
 * @author bosco
 */

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.annotations.Convert;
import org.eclipse.persistence.annotations.Converter;

@Entity
@Cache(disableHits=true)
@Table(name="VCRYPT_IP_LOCATION_MAP")
public class VIPLocationMap extends BharosaBaseBean implements java.io.Serializable {


	/**
	 * Id for this range
	 * <ul>
	 * <li>This attribute is the <b>Primary Key</b> for this class<br>.
	 * <li>The maximum length for this attribute is <b>16</b>.
	 * </ul>
	 *
	 */
@SequenceGenerator(name="V_IP_LOCATION_MAP_SEQ", allocationSize=1)
@Id
@GeneratedValue(strategy=GenerationType.AUTO, generator="V_IP_LOCATION_MAP_SEQ")
@Column(name="IP_RANGE_ID")
	protected Long ipRangeId;
	/**
	 * The from IP address
	 * <ul>
	 * <li>The maximum length for this attribute is <b>15</b>.
	 * </ul>
	 *
	 */
@Converter(name="IP Address", converterClass=com.bharosa.common.toplink.TOPLinkIPAttributeTransformer.class)
@Convert("IP Address")
@Column(name="FROM_IP_ADDR")
	protected String fromIPAddr;
	/**
	 * The to IP address
	 * <ul>
	 * <li>The maximum length for this attribute is <b>15</b>.
	 * </ul>
	 *
	 */
@Converter(name="IP Address", converterClass=com.bharosa.common.toplink.TOPLinkIPAttributeTransformer.class)
@Convert("IP Address")
@Column(name="TO_IP_ADDR")
	protected String toIPAddr;
	/**
	 * Date/Time for this log.
	 * <ul>
	 * </ul>
	 *
	 */
@Temporal(TemporalType.TIMESTAMP)
@Column(name="CREATE_TIME")
	protected Date createTime = new Date();
	/**
	 * Last update time for this object.
	 * <ul>
	 * </ul>
	 *
	 */
@Temporal(TemporalType.TIMESTAMP)
@Column(name="UPDATE_TIME")
	protected Date updateTime = new Date();
	/**
	 * Id for the country to which this state belongs to.
	 * <ul>
	 * <li>The maximum length for this attribute is <b>16</b>.
	 * </ul>
	 *
	 */
@Column(name="COUNTRY_ID")
	protected Long countryId;
	/**
	 * Id for the state to which this IP range belongs to.
	 * <ul>
	 * <li>The maximum length for this attribute is <b>16</b>.
	 * </ul>
	 *
	 */
@Column(name="STATE_ID")
	protected Long stateId;
	/**
	 * Id for the city to which this IP range belongs to.
	 * <ul>
	 * <li>The maximum length for this attribute is <b>16</b>.
	 * </ul>
	 *
	 */
@Column(name="CITY_ID")
	protected Long cityId;
	/**
	 * Id of the metro for this IP
	 * <ul>
	 * </ul>
	 *
	 */
@Column(name="METRO_ID")
	protected Long metroId;
	/**
	 * Id for the ISP to which this IP range belongs to.
	 * <ul>
	 * <li>The maximum length for this attribute is <b>16</b>.
	 * </ul>
	 *
	 */
@Column(name="ISP_ID")
	protected Long ispId;
	/**
	 * IP routing type
	 * <ul>
	 * <li>The maximum length for this attribute is <b>3</b>.
	 * </ul>
	 *
	 */
@Column(name="ROUTING_TYPE")
	protected Integer ipRoutingType;
	/**
	 * Connection type
	 * <ul>
	 * </ul>
	 *
	 */
@Column(name="CONNECTION_TYPE")
	protected Integer connectionType;
	/**
	 * Connection speed
	 * <ul>
	 * </ul>
	 *
	 */
@Column(name="CONNECTION_SPEED")
	protected Integer connectionSpeed;
	/**
	 * Top level domain
	 * <ul>
	 * <li>The maximum length for this attribute is <b>255</b>.
	 * </ul>
	 *
	 */
@Column(name="TOP_LEVEL_DOMAIN")
	protected String topLevelDomain;
	/**
	 * Second level domain
	 * <ul>
	 * <li>The maximum length for this attribute is <b>255</b>.
	 * </ul>
	 *
	 */
@Column(name="SEC_LEVEL_DOMAIN")
	protected String secondLevelDomain;
	/**
	 * ASN
	 * <ul>
	 * <li>The maximum length for this attribute is <b>25</b>.
	 * </ul>
	 *
	 */
@Column(name="ASN")
	protected String asn;
	/**
	 * Carrier
	 * <ul>
	 * <li>The maximum length for this attribute is <b>128</b>.
	 * </ul>
	 *
	 */
@Column(name="CARRIER")
	protected String carrier;
	/**
	 * Zip code
	 * <ul>
	 * <li>The maximum length for this attribute is <b>24</b>.
	 * </ul>
	 *
	 */
@Column(name="ZIP_CODE")
	protected String zipCode;
	/**
	 * U.S. Designated Market Area, AC Nielsen
	 * <ul>
	 * <li>The maximum length for this attribute is <b>6</b>.
	 * </ul>
	 *
	 */
@Column(name="DMA")
	protected Integer dma;
	/**
	 * Metropolitan Statistical Area
	 * <ul>
	 * <li>The maximum length for this attribute is <b>6</b>.
	 * </ul>
	 *
	 */
@Column(name="MSA")
	protected Integer msa;
	/**
	 * Primary Metropolitan Statistical Area
	 * <ul>
	 * <li>The maximum length for this attribute is <b>6</b>.
	 * </ul>
	 *
	 */
@Column(name="PMSA")
	protected Integer pmsa;
	/**
	 * Id the region
	 * <ul>
	 * <li>The maximum length for this attribute is <b>16</b>.
	 * </ul>
	 *
	 */
@Column(name="REGION_ID")
	protected Long regionId;
	/**
	 * Phone area code
	 * <ul>
	 * <li>The maximum length for this attribute is <b>10</b>.
	 * </ul>
	 *
	 */
@Column(name="PHONE_AREA")
	protected String phoneAreaCode;
	/**
	 * Is the IP split. If so, in some queries, we might have to do addtional checks.
	 * <ul>
	 * </ul>
	 *
	 */
@Column(name="IS_SPLIT")
	protected boolean isSplit = false;
	/**
	 * Confidence factor of the country
	 * <ul>
	 * <li>The maximum length for this attribute is <b>4</b>.
	 * </ul>
	 *
	 */
@Column(name="COUNTRY_CF")
	protected Integer countryCF;
	/**
	 * Confidence factor of the state
	 * <ul>
	 * <li>The maximum length for this attribute is <b>4</b>.
	 * </ul>
	 *
	 */
@Column(name="STATE_CF")
	protected Integer stateCF;
	/**
	 * Confidence factor of the city
	 * <ul>
	 * <li>The maximum length for this attribute is <b>4</b>.
	 * </ul>
	 *
	 */
@Column(name="CITY_CF")
	protected Integer cityCF;
	/**
	 * Notes for this IP range
	 * <ul>
	 * <li>The maximum length for this attribute is <b>255</b>.
	 * </ul>
	 *
	 */
@Column(name="NOTES")
	protected String notes;

	/**
	 * Default constructor. This will set all the attributes to default value.
	 */
	public VIPLocationMap ( ) {
	}

	/**
	 * This method sets the value to the member attribute <b>ipRangeId</b>.
	 * You cannot set null to the attribute.
	 * @param ipRangeId Value to set member attribute <b>ipRangeId</b>
	 */
	public void setIpRangeId( Long ipRangeId ) {
		this.ipRangeId = ipRangeId;
	}

	/**
	 * Returns the value for the member attribute <b>ipRangeId</b>
	 * @return Long - value of member attribute <b>ipRangeId</b>.
	 */
	public Long getIpRangeId( ) {
		return this.ipRangeId;
	}

	public Long getPKId( ) {
		return this.getIpRangeId( );
	}
	/**
	 * This method sets the value to the member attribute <b>fromIPAddr</b>.
	 * You cannot set null to the attribute.
	 * @param fromIPAddr Value to set member attribute <b>fromIPAddr</b>
	 */
	public void setFromIPAddr( String fromIPAddr ) {
		this.fromIPAddr = fromIPAddr;
	}

	/**
	 * Returns the value for the member attribute <b>fromIPAddr</b>
	 * @return String - value of member attribute <b>fromIPAddr</b>.
	 */
	public String getFromIPAddr( ) {
		return this.fromIPAddr;
	}

	/**
	 * This method sets the value to the member attribute <b>toIPAddr</b>.
	 * You cannot set null to the attribute.
	 * @param toIPAddr Value to set member attribute <b>toIPAddr</b>
	 */
	public void setToIPAddr( String toIPAddr ) {
		this.toIPAddr = toIPAddr;
	}

	/**
	 * Returns the value for the member attribute <b>toIPAddr</b>
	 * @return String - value of member attribute <b>toIPAddr</b>.
	 */
	public String getToIPAddr( ) {
		return this.toIPAddr;
	}

	/**
	 * This method sets the value to the member attribute <b>createTime</b>.
	 * You cannot set null to the attribute.
	 * @param createTime Value to set member attribute <b>createTime</b>
	 */
	public void setCreateTime( Date createTime ) {
		this.createTime = createTime;
	}

	/**
	 * Returns the value for the member attribute <b>createTime</b>
	 * @return Date - value of member attribute <b>createTime</b>.
	 */
	public Date getCreateTime( ) {
		return this.createTime;
	}

	/**
	 * This method sets the value to the member attribute <b>updateTime</b>.
	 * You cannot set null to the attribute.
	 * @param updateTime Value to set member attribute <b>updateTime</b>
	 */
	public void setUpdateTime( Date updateTime ) {
		this.updateTime = updateTime;
	}

	/**
	 * Returns the value for the member attribute <b>updateTime</b>
	 * @return Date - value of member attribute <b>updateTime</b>.
	 */
	public Date getUpdateTime( ) {
		return this.updateTime;
	}

	/**
	 * This method sets the value to the member attribute <b>countryId</b>.
	 * You cannot set null to the attribute.
	 * @param countryId Value to set member attribute <b>countryId</b>
	 */
	public void setCountryId( Long countryId ) {
		this.countryId = countryId;
	}

	/**
	 * Returns the value for the member attribute <b>countryId</b>
	 * @return Long - value of member attribute <b>countryId</b>.
	 */
	public Long getCountryId( ) {
		return this.countryId;
	}

	/**
	 * This method sets the value to the member attribute <b>stateId</b>.
	 * You cannot set null to the attribute.
	 * @param stateId Value to set member attribute <b>stateId</b>
	 */
	public void setStateId( Long stateId ) {
		this.stateId = stateId;
	}

	/**
	 * Returns the value for the member attribute <b>stateId</b>
	 * @return Long - value of member attribute <b>stateId</b>.
	 */
	public Long getStateId( ) {
		return this.stateId;
	}

	/**
	 * This method sets the value to the member attribute <b>cityId</b>.
	 * You cannot set null to the attribute.
	 * @param cityId Value to set member attribute <b>cityId</b>
	 */
	public void setCityId( Long cityId ) {
		this.cityId = cityId;
	}

	/**
	 * Returns the value for the member attribute <b>cityId</b>
	 * @return Long - value of member attribute <b>cityId</b>.
	 */
	public Long getCityId( ) {
		return this.cityId;
	}

	/**
	 * This method sets the value to the member attribute <b>metroId</b>.
	 * You cannot set null to the attribute.
	 * @param metroId Value to set member attribute <b>metroId</b>
	 */
	public void setMetroId( Long metroId ) {
		this.metroId = metroId;
	}

	/**
	 * Returns the value for the member attribute <b>metroId</b>
	 * @return Long - value of member attribute <b>metroId</b>.
	 */
	public Long getMetroId( ) {
		return this.metroId;
	}

	/**
	 * This method sets the value to the member attribute <b>ispId</b>.
	 * You cannot set null to the attribute.
	 * @param ispId Value to set member attribute <b>ispId</b>
	 */
	public void setIspId( Long ispId ) {
		this.ispId = ispId;
	}

	/**
	 * Returns the value for the member attribute <b>ispId</b>
	 * @return Long - value of member attribute <b>ispId</b>.
	 */
	public Long getIspId( ) {
		return this.ispId;
	}

	/**
	 * This method sets the value to the member attribute <b>ipRoutingType</b>.
	 * You cannot set null to the attribute.
	 * @param ipRoutingType Value to set member attribute <b>ipRoutingType</b>
	 */
	public void setIpRoutingType( Integer ipRoutingType ) {
		this.ipRoutingType = ipRoutingType;
	}

	/**
	 * Returns the value for the member attribute <b>ipRoutingType</b>
	 * @return Integer - value of member attribute <b>ipRoutingType</b>.
	 */
	public Integer getIpRoutingType( ) {
		return this.ipRoutingType;
	}

	/**
	 * This method sets the value to the member attribute <b>connectionType</b>.
	 * You cannot set null to the attribute.
	 * @param connectionType Value to set member attribute <b>connectionType</b>
	 */
	public void setConnectionType( Integer connectionType ) {
		this.connectionType = connectionType;
	}

	/**
	 * Returns the value for the member attribute <b>connectionType</b>
	 * @return Integer - value of member attribute <b>connectionType</b>.
	 */
	public Integer getConnectionType( ) {
		return this.connectionType;
	}

	/**
	 * This method sets the value to the member attribute <b>connectionSpeed</b>.
	 * You cannot set null to the attribute.
	 * @param connectionSpeed Value to set member attribute <b>connectionSpeed</b>
	 */
	public void setConnectionSpeed( Integer connectionSpeed ) {
		this.connectionSpeed = connectionSpeed;
	}

	/**
	 * Returns the value for the member attribute <b>connectionSpeed</b>
	 * @return Integer - value of member attribute <b>connectionSpeed</b>.
	 */
	public Integer getConnectionSpeed( ) {
		return this.connectionSpeed;
	}

	/**
	 * This method sets the value to the member attribute <b>topLevelDomain</b>.
	 * You cannot set null to the attribute.
	 * @param topLevelDomain Value to set member attribute <b>topLevelDomain</b>
	 */
	public void setTopLevelDomain( String topLevelDomain ) {
		this.topLevelDomain = topLevelDomain;
	}

	/**
	 * Returns the value for the member attribute <b>topLevelDomain</b>
	 * @return String - value of member attribute <b>topLevelDomain</b>.
	 */
	public String getTopLevelDomain( ) {
		return this.topLevelDomain;
	}

	/**
	 * This method sets the value to the member attribute <b>secondLevelDomain</b>.
	 * You cannot set null to the attribute.
	 * @param secondLevelDomain Value to set member attribute <b>secondLevelDomain</b>
	 */
	public void setSecondLevelDomain( String secondLevelDomain ) {
		this.secondLevelDomain = secondLevelDomain;
	}

	/**
	 * Returns the value for the member attribute <b>secondLevelDomain</b>
	 * @return String - value of member attribute <b>secondLevelDomain</b>.
	 */
	public String getSecondLevelDomain( ) {
		return this.secondLevelDomain;
	}

	/**
	 * This method sets the value to the member attribute <b>asn</b>.
	 * You cannot set null to the attribute.
	 * @param asn Value to set member attribute <b>asn</b>
	 */
	public void setAsn( String asn ) {
		this.asn = asn;
	}

	/**
	 * Returns the value for the member attribute <b>asn</b>
	 * @return String - value of member attribute <b>asn</b>.
	 */
	public String getAsn( ) {
		return this.asn;
	}

	/**
	 * This method sets the value to the member attribute <b>carrier</b>.
	 * You cannot set null to the attribute.
	 * @param carrier Value to set member attribute <b>carrier</b>
	 */
	public void setCarrier( String carrier ) {
		this.carrier = carrier;
	}

	/**
	 * Returns the value for the member attribute <b>carrier</b>
	 * @return String - value of member attribute <b>carrier</b>.
	 */
	public String getCarrier( ) {
		return this.carrier;
	}

	/**
	 * This method sets the value to the member attribute <b>zipCode</b>.
	 * You cannot set null to the attribute.
	 * @param zipCode Value to set member attribute <b>zipCode</b>
	 */
	public void setZipCode( String zipCode ) {
		this.zipCode = zipCode;
	}

	/**
	 * Returns the value for the member attribute <b>zipCode</b>
	 * @return String - value of member attribute <b>zipCode</b>.
	 */
	public String getZipCode( ) {
		return this.zipCode;
	}

	/**
	 * This method sets the value to the member attribute <b>dma</b>.
	 * You cannot set null to the attribute.
	 * @param dma Value to set member attribute <b>dma</b>
	 */
	public void setDma( Integer dma ) {
		this.dma = dma;
	}

	/**
	 * Returns the value for the member attribute <b>dma</b>
	 * @return Integer - value of member attribute <b>dma</b>.
	 */
	public Integer getDma( ) {
		return this.dma;
	}

	/**
	 * This method sets the value to the member attribute <b>msa</b>.
	 * You cannot set null to the attribute.
	 * @param msa Value to set member attribute <b>msa</b>
	 */
	public void setMsa( Integer msa ) {
		this.msa = msa;
	}

	/**
	 * Returns the value for the member attribute <b>msa</b>
	 * @return Integer - value of member attribute <b>msa</b>.
	 */
	public Integer getMsa( ) {
		return this.msa;
	}

	/**
	 * This method sets the value to the member attribute <b>pmsa</b>.
	 * You cannot set null to the attribute.
	 * @param pmsa Value to set member attribute <b>pmsa</b>
	 */
	public void setPmsa( Integer pmsa ) {
		this.pmsa = pmsa;
	}

	/**
	 * Returns the value for the member attribute <b>pmsa</b>
	 * @return Integer - value of member attribute <b>pmsa</b>.
	 */
	public Integer getPmsa( ) {
		return this.pmsa;
	}

	/**
	 * This method sets the value to the member attribute <b>regionId</b>.
	 * You cannot set null to the attribute.
	 * @param regionId Value to set member attribute <b>regionId</b>
	 */
	public void setRegionId( Long regionId ) {
		this.regionId = regionId;
	}

	/**
	 * Returns the value for the member attribute <b>regionId</b>
	 * @return Long - value of member attribute <b>regionId</b>.
	 */
	public Long getRegionId( ) {
		return this.regionId;
	}

	/**
	 * This method sets the value to the member attribute <b>phoneAreaCode</b>.
	 * You cannot set null to the attribute.
	 * @param phoneAreaCode Value to set member attribute <b>phoneAreaCode</b>
	 */
	public void setPhoneAreaCode( String phoneAreaCode ) {
		this.phoneAreaCode = phoneAreaCode;
	}

	/**
	 * Returns the value for the member attribute <b>phoneAreaCode</b>
	 * @return String - value of member attribute <b>phoneAreaCode</b>.
	 */
	public String getPhoneAreaCode( ) {
		return this.phoneAreaCode;
	}

	/**
	 * This method sets the value to the member attribute <b>isSplit</b>.
	 * You cannot set null to the attribute.
	 * @param isSplit Value to set member attribute <b>isSplit</b>
	 */
	public void setIsSplit( boolean isSplit ) {
		this.isSplit = isSplit;
	}

	/**
	 * Returns the value for the member attribute <b>isSplit</b>
	 * @return boolean - value of member attribute <b>isSplit</b>.
	 */
	public boolean getIsSplit( ) {
		return this.isSplit;
	}

	/**
	 * This method sets the value to the member attribute <b>countryCF</b>.
	 * You cannot set null to the attribute.
	 * @param countryCF Value to set member attribute <b>countryCF</b>
	 */
	public void setCountryCF( Integer countryCF ) {
		this.countryCF = countryCF;
	}

	/**
	 * Returns the value for the member attribute <b>countryCF</b>
	 * @return Integer - value of member attribute <b>countryCF</b>.
	 */
	public Integer getCountryCF( ) {
		return this.countryCF;
	}

	/**
	 * This method sets the value to the member attribute <b>stateCF</b>.
	 * You cannot set null to the attribute.
	 * @param stateCF Value to set member attribute <b>stateCF</b>
	 */
	public void setStateCF( Integer stateCF ) {
		this.stateCF = stateCF;
	}

	/**
	 * Returns the value for the member attribute <b>stateCF</b>
	 * @return Integer - value of member attribute <b>stateCF</b>.
	 */
	public Integer getStateCF( ) {
		return this.stateCF;
	}

	/**
	 * This method sets the value to the member attribute <b>cityCF</b>.
	 * You cannot set null to the attribute.
	 * @param cityCF Value to set member attribute <b>cityCF</b>
	 */
	public void setCityCF( Integer cityCF ) {
		this.cityCF = cityCF;
	}

	/**
	 * Returns the value for the member attribute <b>cityCF</b>
	 * @return Integer - value of member attribute <b>cityCF</b>.
	 */
	public Integer getCityCF( ) {
		return this.cityCF;
	}

	/**
	 * This method sets the value to the member attribute <b>notes</b>.
	 * You cannot set null to the attribute.
	 * @param notes Value to set member attribute <b>notes</b>
	 */
	public void setNotes( String notes ) {
		this.notes = notes;
	}

	/**
	 * Returns the value for the member attribute <b>notes</b>
	 * @return String - value of member attribute <b>notes</b>.
	 */
	public String getNotes( ) {
		return this.notes;
	}

	/**
	 * This return the bean content in string format
	 * @return formatedStr
	*/
	public String toString( ) {
		String str = "";
		str += "ipRangeId={" + ipRangeId + "} ";
		str += "fromIPAddr={" + fromIPAddr + "} ";
		str += "toIPAddr={" + toIPAddr + "} ";
		str += "createTime={" + createTime + "} ";
		str += "updateTime={" + updateTime + "} ";
		str += "countryId={" + countryId + "} ";
		str += "stateId={" + stateId + "} ";
		str += "cityId={" + cityId + "} ";
		str += "metroId={" + metroId + "} ";
		str += "ispId={" + ispId + "} ";
		str += "ipRoutingType={" + ipRoutingType + "} ";
		str += "connectionType={" + connectionType + "} ";
		str += "connectionSpeed={" + connectionSpeed + "} ";
		str += "topLevelDomain={" + topLevelDomain + "} ";
		str += "secondLevelDomain={" + secondLevelDomain + "} ";
		str += "asn={" + asn + "} ";
		str += "carrier={" + carrier + "} ";
		str += "zipCode={" + zipCode + "} ";
		str += "dma={" + dma + "} ";
		str += "msa={" + msa + "} ";
		str += "pmsa={" + pmsa + "} ";
		str += "regionId={" + regionId + "} ";
		str += "phoneAreaCode={" + phoneAreaCode + "} ";
		str += "isSplit={" + isSplit + "} ";
		str += "countryCF={" + countryCF + "} ";
		str += "stateCF={" + stateCF + "} ";
		str += "cityCF={" + cityCF + "} ";
		str += "notes={" + notes + "} ";
		return str;
	}
}
