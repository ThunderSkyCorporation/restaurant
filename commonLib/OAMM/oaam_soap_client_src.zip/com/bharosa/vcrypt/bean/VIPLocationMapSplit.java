package com.bharosa.vcrypt.bean;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * Mapping of the split Class C IP ranges
 * @author bosco
 */

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.annotations.Convert;
import org.eclipse.persistence.annotations.Converter;

@Entity
@Cache(disableHits=true)
@Table(name="V_IP_LOC_MAP_SPLIT")
public class VIPLocationMapSplit extends BharosaBaseBean implements java.io.Serializable {


	/**
	 * Id for this range
	 * <ul>
	 * <li>This attribute is the <b>Primary Key</b> for this class<br>.
	 * <li>The maximum length for this attribute is <b>16</b>.
	 * </ul>
	 *
	 */
@SequenceGenerator(name="V_IP_LOC_MAP_SPLIT_SEQ", allocationSize=1)
@Id
@GeneratedValue(strategy=GenerationType.AUTO, generator="V_IP_LOC_MAP_SPLIT_SEQ")
@Column(name="IP_RANGE_ID")
	protected Long ipRangeId;
	/**
	 * The from IP address
	 * <ul>
	 * <li>The maximum length for this attribute is <b>15</b>.
	 * </ul>
	 *
	 */
@Converter(name="IP Address", converterClass=com.bharosa.common.toplink.TOPLinkIPAttributeTransformer.class)
@Convert("IP Address")
@Column(name="BASE_IP_ADDR")
	protected String baseIPAddr;
	/**
	 * The from IP address
	 * <ul>
	 * <li>The maximum length for this attribute is <b>15</b>.
	 * </ul>
	 *
	 */
@Converter(name="IP Address", converterClass=com.bharosa.common.toplink.TOPLinkIPAttributeTransformer.class)
@Convert("IP Address")
@Column(name="FROM_IP_ADDR")
	protected String fromIPAddr;
	/**
	 * The to IP address
	 * <ul>
	 * <li>The maximum length for this attribute is <b>15</b>.
	 * </ul>
	 *
	 */
@Converter(name="IP Address", converterClass=com.bharosa.common.toplink.TOPLinkIPAttributeTransformer.class)
@Convert("IP Address")
@Column(name="TO_IP_ADDR")
	protected String toIPAddr;
	/**
	 * Date/Time for this log.
	 * <ul>
	 * </ul>
	 *
	 */
@Temporal(TemporalType.TIMESTAMP)
@Column(name="CREATE_TIME")
	protected Date createTime = new Date();
	/**
	 * Last update time for this object.
	 * <ul>
	 * </ul>
	 *
	 */
@Temporal(TemporalType.TIMESTAMP)
@Column(name="UPDATE_TIME")
	protected Date updateTime = new Date();
	/**
	 * Second level domain
	 * <ul>
	 * <li>The maximum length for this attribute is <b>255</b>.
	 * </ul>
	 *
	 */
@Column(name="SEC_LEVEL_DOMAIN")
	protected String secondLevelDomain;
	/**
	 * Notes for this IP range
	 * <ul>
	 * <li>The maximum length for this attribute is <b>255</b>.
	 * </ul>
	 *
	 */
@Column(name="NOTES")
	protected String notes;

	/**
	 * Default constructor. This will set all the attributes to default value.
	 */
	public VIPLocationMapSplit ( ) {
	}

	/**
	 * This method sets the value to the member attribute <b>ipRangeId</b>.
	 * You cannot set null to the attribute.
	 * @param ipRangeId Value to set member attribute <b>ipRangeId</b>
	 */
	public void setIpRangeId( Long ipRangeId ) {
		this.ipRangeId = ipRangeId;
	}

	/**
	 * Returns the value for the member attribute <b>ipRangeId</b>
	 * @return Long - value of member attribute <b>ipRangeId</b>.
	 */
	public Long getIpRangeId( ) {
		return this.ipRangeId;
	}

	public Long getPKId( ) {
		return this.getIpRangeId( );
	}
	/**
	 * This method sets the value to the member attribute <b>baseIPAddr</b>.
	 * You cannot set null to the attribute.
	 * @param baseIPAddr Value to set member attribute <b>baseIPAddr</b>
	 */
	public void setBaseIPAddr( String baseIPAddr ) {
		this.baseIPAddr = baseIPAddr;
	}

	/**
	 * Returns the value for the member attribute <b>baseIPAddr</b>
	 * @return String - value of member attribute <b>baseIPAddr</b>.
	 */
	public String getBaseIPAddr( ) {
		return this.baseIPAddr;
	}

	/**
	 * This method sets the value to the member attribute <b>fromIPAddr</b>.
	 * You cannot set null to the attribute.
	 * @param fromIPAddr Value to set member attribute <b>fromIPAddr</b>
	 */
	public void setFromIPAddr( String fromIPAddr ) {
		this.fromIPAddr = fromIPAddr;
	}

	/**
	 * Returns the value for the member attribute <b>fromIPAddr</b>
	 * @return String - value of member attribute <b>fromIPAddr</b>.
	 */
	public String getFromIPAddr( ) {
		return this.fromIPAddr;
	}

	/**
	 * This method sets the value to the member attribute <b>toIPAddr</b>.
	 * You cannot set null to the attribute.
	 * @param toIPAddr Value to set member attribute <b>toIPAddr</b>
	 */
	public void setToIPAddr( String toIPAddr ) {
		this.toIPAddr = toIPAddr;
	}

	/**
	 * Returns the value for the member attribute <b>toIPAddr</b>
	 * @return String - value of member attribute <b>toIPAddr</b>.
	 */
	public String getToIPAddr( ) {
		return this.toIPAddr;
	}

	/**
	 * This method sets the value to the member attribute <b>createTime</b>.
	 * You cannot set null to the attribute.
	 * @param createTime Value to set member attribute <b>createTime</b>
	 */
	public void setCreateTime( Date createTime ) {
		this.createTime = createTime;
	}

	/**
	 * Returns the value for the member attribute <b>createTime</b>
	 * @return Date - value of member attribute <b>createTime</b>.
	 */
	public Date getCreateTime( ) {
		return this.createTime;
	}

	/**
	 * This method sets the value to the member attribute <b>updateTime</b>.
	 * You cannot set null to the attribute.
	 * @param updateTime Value to set member attribute <b>updateTime</b>
	 */
	public void setUpdateTime( Date updateTime ) {
		this.updateTime = updateTime;
	}

	/**
	 * Returns the value for the member attribute <b>updateTime</b>
	 * @return Date - value of member attribute <b>updateTime</b>.
	 */
	public Date getUpdateTime( ) {
		return this.updateTime;
	}

	/**
	 * This method sets the value to the member attribute <b>secondLevelDomain</b>.
	 * You cannot set null to the attribute.
	 * @param secondLevelDomain Value to set member attribute <b>secondLevelDomain</b>
	 */
	public void setSecondLevelDomain( String secondLevelDomain ) {
		this.secondLevelDomain = secondLevelDomain;
	}

	/**
	 * Returns the value for the member attribute <b>secondLevelDomain</b>
	 * @return String - value of member attribute <b>secondLevelDomain</b>.
	 */
	public String getSecondLevelDomain( ) {
		return this.secondLevelDomain;
	}

	/**
	 * This method sets the value to the member attribute <b>notes</b>.
	 * You cannot set null to the attribute.
	 * @param notes Value to set member attribute <b>notes</b>
	 */
	public void setNotes( String notes ) {
		this.notes = notes;
	}

	/**
	 * Returns the value for the member attribute <b>notes</b>
	 * @return String - value of member attribute <b>notes</b>.
	 */
	public String getNotes( ) {
		return this.notes;
	}

	/**
	 * This return the bean content in string format
	 * @return formatedStr
	*/
	public String toString( ) {
		String str = "";
		str += "ipRangeId={" + ipRangeId + "} ";
		str += "baseIPAddr={" + baseIPAddr + "} ";
		str += "fromIPAddr={" + fromIPAddr + "} ";
		str += "toIPAddr={" + toIPAddr + "} ";
		str += "createTime={" + createTime + "} ";
		str += "updateTime={" + updateTime + "} ";
		str += "secondLevelDomain={" + secondLevelDomain + "} ";
		str += "notes={" + notes + "} ";
		return str;
	}
}
