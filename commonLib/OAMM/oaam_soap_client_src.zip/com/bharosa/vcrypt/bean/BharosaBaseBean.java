package com.bharosa.vcrypt.bean;

/**
 * Created by IntelliJ IDEA.
 * User: bosco
 * Date: Aug 23, 2008
 * Time: 11:33:12 AM
 */
public abstract class BharosaBaseBean implements java.io.Serializable {
    abstract public Long getPKId();
}
