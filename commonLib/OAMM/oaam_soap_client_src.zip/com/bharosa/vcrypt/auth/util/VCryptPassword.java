package com.bharosa.vcrypt.auth.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;

import com.bharosa.common.util.Password;
import com.bharosa.common.util.BharosaCipher;

/**
 * This class implements the password encryption/decryption logic for VCrypt applications.
 *
 * @author bosco
 */
public class VCryptPassword implements Password {
    
    static private Logger logger = Logger.getLogger(VCryptPassword.class);
	static private BharosaCipher mCipher = null;

	public VCryptPassword() {
		if (logger.isDebugEnabled()) 
			logger.debug("Constructing VCryptPassword") ;
		mCipher = BharosaCipher.getCipher();
		if (logger.isDebugEnabled()) 
			logger.debug("Constructing VCryptPassword BharosaCipher Object [" + mCipher + "]") ;
	}

	public String encrypt(String str) throws SecurityException {
        String encrypted = mCipher.encrypt(str);
        if (logger.isDebugEnabled()) {
            logger.debug("encrypt str length=["+(str!=null?str.length():0)+"] encrypted=["+encrypted+"]");
        }
        return encrypted;
	}

	public String decrypt(String str) throws SecurityException {
        String decrypted = mCipher.decrypt(str);
        if (logger.isDebugEnabled())
            logger.debug("decrypt str=["+str+"] decrypted length=["+(decrypted!=null?decrypted.length():0)+"]");
        return decrypted;
	}
}
