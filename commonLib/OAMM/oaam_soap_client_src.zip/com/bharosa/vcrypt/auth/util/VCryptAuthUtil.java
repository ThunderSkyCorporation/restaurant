package com.bharosa.vcrypt.auth.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.vcrypt.common.util.XMLParserFactory;
import com.bharosa.vcrypt.auth.intf.*;
import com.bharosa.vcrypt.common.util.VCryptCommonUtil;

import com.bharosa.common.logger.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import java.io.StringReader;
import java.util.*;

/**
 * Provides utility method to instantiate classes required from VCryptAuth
 */

public class VCryptAuthUtil {

	static private Logger logger = Logger.getLogger(VCryptAuthUtil.class);

	final static private Object lock = new Object();
	static private VCryptAuth vcryptAuth = null;

	static private String root_setImageAndCaption = "ImageAndCaption";
	static private String root_GetUser = "GetUserByUserAndGroup";
	static private String root_setGroupUsersAuthMode = "SetGroupUsersAuthMode";
	static public String GROUP_NAME = "groupName";
	static public String USER_AUTH_MODE = "userAuthMode";
	static public String root_AuthQuestionRequest = "AuthQuestionRequest";

	/**
	 * This method returns the of instance of VCryptAuth class.
	 * 
	 * @return Returns instance of VCryptAuth class
	 */
	static public VCryptAuth getVCryptAuthInstance() {
		if (vcryptAuth != null) { return vcryptAuth; }
		synchronized (lock) {
			if (vcryptAuth == null) {
				logger.info("Creating new VCryptAuth instance...");
				try {
					boolean useSoap = BharosaConfig.getBoolean("vcrypt.tracker.soap.useSOAPServer", false);
					String authClassName = BharosaConfig.get("vcrypt.auth.impl.classname");
					if (authClassName == null || authClassName.trim().equals("")) {
						logger.info("vcrypt.auth.impl.classname not set, using defaults");
						if (useSoap) {
							authClassName = BharosaConfig.get("vcrypt.auth.util.soap.classname", "com.bharosa.vcrypt.auth.impl.VCryptAuthSOAPImpl");
							logger.info("vcrypt.tracker.soap.useSOAPServer is set to true, using class " + authClassName);
						} else {
							authClassName = BharosaConfig.get("vcrypt.auth.util.static.classname", "com.bharosa.vcrypt.auth.impl.VCryptAuthImpl");
							logger.info("vcrypt.tracker.soap.useSOAPServer is set to false, using class " + authClassName);
						}
					}
					// Loading instance
					logger.info("Loading class " + authClassName);
					vcryptAuth = (VCryptAuth) Class.forName(authClassName).newInstance();
				} catch (Exception ex) {
					logger.error("Error creating VCryptAuth instance.", ex);
				}
			}
		}
		return vcryptAuth;
	}

	static public String toXMLAuthUser(VCryptAuthUser authUser) {
		if (logger.isDebugEnabled()) logger.debug("toXMLAuthUser() enter()");
		if (authUser == null) {
			logger.error("toXMLAuthUser null authUser");
			return null;
		}

		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<AuthUser>");
		xmlString.append(VCryptCommonUtil.getXmlElement("loginId", authUser.getLoginId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", authUser.getCustomerId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("bharosaUserId", authUser.getBharosaUserId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("customerGroupId", authUser.getCustomerGroupId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("fullName", authUser.getFullName()));
		xmlString.append("<rolesList>");
		if (authUser.getRoles() != null) {
			Iterator iter = authUser.getRoles().iterator();
			while (iter.hasNext()) {
				xmlString.append("<role>").append(iter.next().toString()).append("</role>");
			}
		}
		xmlString.append("</rolesList>");
		xmlString.append("<securityPreferenceList>");
		if (authUser.getSecurityPreferences() != null) {
			Map nvList = authUser.getSecurityPreferences();
			Iterator iter = nvList.keySet().iterator();
			while (iter.hasNext()) {
				String name = (String) iter.next();
				Object value = nvList.get(name);
				if (value != null) {
					xmlString.append("<securityPreference>");
					xmlString.append(VCryptCommonUtil.getXmlElement("name", name));
					xmlString.append(VCryptCommonUtil.getXmlElement("value", value));
					xmlString.append("</securityPreference>");
				}
			}
		}
		xmlString.append("</securityPreferenceList>");
		xmlString.append("</AuthUser>");
		return xmlString.toString();
	}

	static public VCryptAuthUser fromXMLAuthUser(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLAuthUser() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLAuthUser() got null xmlString");
			return null;
		}

		VCryptAuthUser retVal = new VCryptAuthUser();
		retVal.setSecurityPreferences(new HashMap());
		String rootNode = "AuthUser";
		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("loginId"))
                {
                    retVal.setLoginId(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("bharosaUserId"))
                {
                    retVal.setBharosaUserId(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("customerId"))
                {
                    retVal.setCustomerId(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("customerGroupId"))
                {
                    retVal.setCustomerGroupId(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("fullName"))
                {
                    retVal.setFullName(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("rolesList"))
                {
                    ArrayList objSubList = new ArrayList();
                    NodeList subList = node.getChildNodes();
                    for (int p = 0; p < subList.getLength(); p++)
                    {
                        Node subNode = subList.item(p);
                        String subName = subNode.getNodeName();
                        Node subValue = subNode.getFirstChild();
                        if (subValue == null)
                        {
                            continue;
                        }
                        if (subName.equalsIgnoreCase("role"))
                        {
                            objSubList.add(subValue.getNodeValue());
                        }
                        else if (!subName.startsWith("#"))
                        {
                            logger.error("Invalid element name <" + subName + "> in subList element " + nodeName
                                    + " in xml " + xmlString);
                        }
                    }
                    retVal.setRoles(objSubList);
                }
                else if (nodeName.equalsIgnoreCase("securityPreferenceList"))
                {
                    // Lets the the parameter element
                    NodeList securityPrefList = node.getChildNodes();
                    for (int p = 0; p < securityPrefList.getLength(); p++)
                    {
                        Node param = securityPrefList.item(p);
                        String paramName = param.getNodeName();
                        Node valueParam = param.getFirstChild();
                        if (valueParam == null)
                        {
                            continue;
                        }
                        if (paramName.equalsIgnoreCase("securityPreference"))
                        {
                            // Lets the name value
                            String name = null;
                            String value = null;
                            NodeList nvList = param.getChildNodes();
                            for (int n = 0; n < nvList.getLength(); n++)
                            {
                                Node nv = nvList.item(n);
                                String nvName = nv.getNodeName();
                                Node valueNv = nv.getFirstChild();
                                if (valueNv == null)
                                {
                                    continue;
                                }
                                if (nvName.equalsIgnoreCase("name"))
                                {
                                    name = valueNv.getNodeValue();
                                }
                                else if (nvName.equalsIgnoreCase("value"))
                                {
                                    value = valueNv.getNodeValue();
                                }
                                else if (!nvName.startsWith("#"))
                                {
                                    logger.error("Invalid element name <" + nvName
                                            + "> in securityPreference element xml " + xmlString);
                                }
                            }
                            if (!StringUtil.isEmpty(name) && !StringUtil.isEmpty(value))
                            {
                                retVal.getSecurityPreferences().put(name, value);
                            }
                        }
                        else if (!paramName.startsWith("#"))
                        {
                            logger.error("Invalid element name <" + paramName
                                    + "> in securityPreferenceList element xml " + xmlString);
                        }
                    }

                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return retVal;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLAuthPasswordRequest(String customerId, String password, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint) {
		String authSessionId = null;
		if (logger.isDebugEnabled()) logger.debug("toXMLAuthPasswordRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<AuthPasswordRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("password", password));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionId", authSessionId));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionType", authSessionType));
		xmlString.append(VCryptCommonUtil.getXmlElement("clientType", clientType));
		xmlString.append(VCryptCommonUtil.getXmlElement("clientVersion", clientVersion));
		xmlString.append(VCryptCommonUtil.getXmlElement("ipAddress", ipAddress));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrintType", fingerPrintType));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrint", fingerPrint));
		xmlString.append("</AuthPasswordRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLAuthPasswordRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLAuthPasswordRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLAuthPasswordRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "AuthPasswordRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("password"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("password", value);
                }
                else if (nodeName.equalsIgnoreCase("authSessionId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("authSessionId", value);
                }
                else if (nodeName.equalsIgnoreCase("authSessionType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("authSessionType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("clientType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("clientType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("clientVersion"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("clientVersion", value);
                }
                else if (nodeName.equalsIgnoreCase("ipAddress"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("ipAddress", value);
                }
                else if (nodeName.equalsIgnoreCase("fingerPrintType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("fingerPrintType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("fingerPrint"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("fingerPrint", value);

                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLAuthPinRequest(String customerId, String pin, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint) {

		// Temporary
		String authSessionId = null;
		if (logger.isDebugEnabled()) logger.debug("toXMLAuthPinRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<AuthPinRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("pin", pin));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionId", authSessionId));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionType", authSessionType));
		xmlString.append(VCryptCommonUtil.getXmlElement("clientType", clientType));
		xmlString.append(VCryptCommonUtil.getXmlElement("clientVersion", clientVersion));
		xmlString.append(VCryptCommonUtil.getXmlElement("ipAddress", ipAddress));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrintType", fingerPrintType));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrint", fingerPrint));
		xmlString.append("</AuthPinRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLAuthPinRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLAuthPinRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLAuthPinRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "AuthPinRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("pin"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("pin", value);
                }
                else if (nodeName.equalsIgnoreCase("authSessionId"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value)) nvList.put("authSessionId", new Long(value));
                }
                else if (nodeName.equalsIgnoreCase("authSessionType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("authSessionType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("clientType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("clientType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("clientVersion"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("clientVersion", value);
                }
                else if (nodeName.equalsIgnoreCase("ipAddress"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("ipAddress", value);
                }
                else if (nodeName.equalsIgnoreCase("fingerPrintType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("fingerPrintType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("fingerPrint"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("fingerPrint", value);

                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLAuthResultResponse(VCryptAuthResult authResult) {
		if (logger.isDebugEnabled()) logger.debug("toXMLAuthResultResponse() enter()");
		if (authResult == null) return null;

		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<AuthResultResponse>");
		xmlString.append(VCryptCommonUtil.getXmlElement("authResult", authResult.getCode()));
		xmlString.append(VCryptCommonUtil.getXmlElement("loginId", authResult.getLoginId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", authResult.getCustomerId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("bharosaUserId", authResult.getBharosaUserId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("customerGroupId", authResult.getCustomerGroupId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("fullName", authResult.getUserName()));
		xmlString.append("<rolesList>");
		if (authResult.getRoles() != null) {
			Iterator iter = authResult.getRoles().iterator();
			while (iter.hasNext()) {
				xmlString.append(VCryptCommonUtil.getXmlElement("role", iter.next()));
			}
		}
		xmlString.append("</rolesList>");
		xmlString.append(VCryptCommonUtil.getXmlElement("secondFactor", authResult.getDefaultAuthMode()));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionId", authResult.getAuthSessionId()));
		xmlString.append("</AuthResultResponse>");
		return xmlString.toString();
	}

	static public VCryptAuthResult fromXMLAuthResultResponse(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLAuthResultResponse() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLAuthResultResponse() got null xmlString");
			return null;
		}

		VCryptAuthResult retVal = new VCryptAuthResult();
		String rootNode = "AuthResultResponse";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("authResult"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        retVal.setCode(Integer.parseInt(value.trim()));
                    }
                    else
                    {
                        retVal.setCode(-1);
                    }
                }
                else if (nodeName.equalsIgnoreCase("loginId"))
                {
                    retVal.setLoginId(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("bharosaUserId"))
                {
                    retVal.setBharosaUserId(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("customerId"))
                {
                    retVal.setCustomerId(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("customerGroupId"))
                {
                    retVal.setCustomerGroupId(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("fullName"))
                {
                    retVal.setUserName(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("rolesList"))
                {
                    ArrayList objSubList = new ArrayList();
                    NodeList subList = node.getChildNodes();
                    for (int p = 0; p < subList.getLength(); p++)
                    {
                        Node subNode = subList.item(p);
                        String subName = subNode.getNodeName();
                        Node subValue = subNode.getFirstChild();
                        if (subValue == null)
                        {
                            continue;
                        }
                        if (subName.equalsIgnoreCase("role"))
                        {
                            objSubList.add(subValue.getNodeValue());
                        }
                        else if (!subName.startsWith("#"))
                        {
                            logger.error("Invalid element name <" + subName + "> in subList element " + nodeName
                                    + " in xml " + xmlString);
                        }
                    }
                    retVal.setRoles(objSubList);
                }
                else if (nodeName.equalsIgnoreCase("secondFactor"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        retVal.setDefaultAuthMode(Integer.parseInt(value.trim()));
                    }
                    else
                    {
                        retVal.setDefaultAuthMode(-1);
                    }
                }
                else if (nodeName.equalsIgnoreCase("authSessionId"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        retVal.setAuthSessionId(new Long(value.trim()));
                    }
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return retVal;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLGenerateWheelRequest(int length, int sets, Long previousAuthSessionId, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint) {

		if (logger.isDebugEnabled()) logger.debug("toXMLGenerateWheelRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<GenerateWheelRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("wheelLength", length));
		xmlString.append(VCryptCommonUtil.getXmlElement("sets", sets));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionId", previousAuthSessionId));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionType", authSessionType));
		xmlString.append(VCryptCommonUtil.getXmlElement("clientType", clientType));
		xmlString.append(VCryptCommonUtil.getXmlElement("clientVersion", clientVersion));
		xmlString.append(VCryptCommonUtil.getXmlElement("ipAddress", ipAddress));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrintType", fingerPrintType));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrint", fingerPrint));
		xmlString.append("</GenerateWheelRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLGenerateWheelRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLGenerateWheelRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLGenerateWheelRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "GenerateWheelRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase("wheelLength"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("length", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("sets"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("sets", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("authSessionId"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("previousAuthSessionId", new Long(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("authSessionType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("authSessionType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("clientType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("clientType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("clientVersion"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("clientVersion", value);
                }
                else if (nodeName.equalsIgnoreCase("ipAddress"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("ipAddress", value);
                }
                else if (nodeName.equalsIgnoreCase("fingerPrintType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("fingerPrintType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("fingerPrint"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("fingerPrint", value);
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLGenerateWheelResponse(VCryptWheel vcryptWheel) {
		if (logger.isDebugEnabled()) logger.debug("toXMLGenerateWheelResponse() enter()");
		if (vcryptWheel == null) {
			logger.error("toXMLGenerateWheelResponse no wheel");
			return null;
		}

		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<GenerateWheelResponse>");
		xmlString.append(VCryptCommonUtil.getXmlElement("wheel", vcryptWheel.getWheel()));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionId", vcryptWheel.getAuthSessionId()));
		xmlString.append("</GenerateWheelResponse>");
		return xmlString.toString();
	}

	static public VCryptWheel fromXMLGenerateWheelResponse(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLGenerateWheelResponse() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLGenerateWheelResponse() got null xmlString");
			return null;
		}

		VCryptWheel retVal = new VCryptWheel();
		String rootNode = "GenerateWheelResponse";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("wheel"))
                {
                    retVal.setWheel(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("authSessionId"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        retVal.setAuthSessionId(new Long(value.trim()));
                    }
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return retVal;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLAuthSliderRequest(String customerId, String pin, Vector displacements, Map authStats, Long authSessionId, String ipAddress, int fingerPrintType, String fingerPrint) {

		if (logger.isDebugEnabled()) logger.debug("toXMLAuthSliderRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<AuthSliderRequest>");

		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("pin", pin));
		String dispStr = "";
		if (displacements != null) {
			Enumeration e = displacements.elements();
			for (int i = 0; e.hasMoreElements(); i++) {
				if (i != 0) {
					dispStr += "X";
				}
				dispStr += e.nextElement().toString();
			}
		}
		xmlString.append(VCryptCommonUtil.getXmlElement("displacements", dispStr));

		xmlString.append("<statistics>");
		if (authStats != null) {
			Iterator iter = authStats.keySet().iterator();
			while (iter.hasNext()) {
				String name = (String) iter.next();
				String value = (String) authStats.get(name);
				if (value != null) {
					xmlString.append("<metric>");
					xmlString.append(VCryptCommonUtil.getXmlElement("name", name));
					xmlString.append(VCryptCommonUtil.getXmlElement("value", value));
					xmlString.append("</metric>");
				}
			}
		}
		xmlString.append("</statistics>");
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionId", authSessionId));
		xmlString.append(VCryptCommonUtil.getXmlElement("ipAddress", ipAddress));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrintType", fingerPrintType));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrint", fingerPrint));
		xmlString.append("</AuthSliderRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLAuthSliderRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLAuthSliderRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLAuthSliderRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "AuthSliderRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("pin"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("pin", value);
                }
                else if (nodeName.equalsIgnoreCase("displacements"))
                {
                    Vector objSubList = new Vector();
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        StringTokenizer st = new StringTokenizer(value, "X");
                        while (st.hasMoreTokens())
                        {
                            objSubList.add(new Integer(st.nextToken()));
                        }
                    }
                    nvList.put("displacements", objSubList);
                }
                else if (nodeName.equalsIgnoreCase("statistics"))
                {
                    HashMap statMap = new HashMap();
                    // Lets the the metriceter element
                    NodeList metricList = node.getChildNodes();
                    for (int p = 0; p < metricList.getLength(); p++)
                    {
                        Node metric = metricList.item(p);
                        String metricName = metric.getNodeName();
                        Node valueMetric = metric.getFirstChild();
                        if (valueMetric == null)
                        {
                            continue;
                        }
                        if (metricName.equalsIgnoreCase("metric"))
                        {
                            // Lets the name value
                            String name = null;
                            String value = null;
                            NodeList metricNVList = metric.getChildNodes();
                            for (int n = 0; n < metricNVList.getLength(); n++)
                            {
                                Node nv = metricNVList.item(n);
                                String nvName = nv.getNodeName();
                                Node valueNv = nv.getFirstChild();
                                if (valueNv == null)
                                {
                                    continue;
                                }
                                if (nvName.equalsIgnoreCase("name"))
                                {
                                    name = valueNv.getNodeValue();
                                }
                                else if (nvName.equalsIgnoreCase("value"))
                                {
                                    value = valueNv.getNodeValue();
                                }
                                else if (!nvName.startsWith("#"))
                                {
                                    logger.error(
                                            "Invalid element name <" + nvName + "> in metric element xml " + xmlString);
                                }
                            }
                            if (!StringUtil.isEmpty(name) && !StringUtil.isEmpty(value))
                            {
                                statMap.put(name, value);
                            }
                        }
                        else if (!metricName.startsWith("#"))
                        {
                            logger.error(
                                    "Invalid element name <" + metricName + "> in metricList element xml " + xmlString);
                        }
                    }
                    nvList.put("authStats", statMap);
                }
                else if (nodeName.equalsIgnoreCase("authSessionId"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("authSessionId", new Long(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("ipAddress"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("ipAddress", value);
                }
                else if (nodeName.equalsIgnoreCase("fingerPrintType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("fingerPrintType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("fingerPrint"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("fingerPrint", value);
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	public static String toXMLGetSignOnQuestionsRequest(String customerId, VCryptLocale locale) {
		if (logger.isDebugEnabled()) logger.debug("toXMLGetSecretQuestionRequest() enter()");
		return new StringBuffer(400)
			.append("<GetSignOnQuestionsRequest>")
			.append(VCryptCommonUtil.getXmlElement("customerId", customerId))
			.append(toXMLLocale(locale))
			.append("</GetSignOnQuestionsRequest>")
			.toString();
	}

	public static String toXMLLocale(VCryptLocale locale) {
		return new StringBuffer(200)
			.append("<locale>")
			.append(VCryptCommonUtil.getXmlElement("language", locale.getLanguage()))
			.append(VCryptCommonUtil.getXmlElement("country", locale.getCountry()))
			.append(VCryptCommonUtil.getXmlElement("variant", locale.getVariant()))
			.append("</locale>")
			.toString();
	}

	public static String toXMLLocalizedString(VCryptLocalizedString caption) {
		return new StringBuffer(400)
			.append("<localizedString>")
			.append(VCryptCommonUtil.getXmlElement("text", caption.getText()))
			.append(toXMLLocale(caption.getLocale()))
			.append("</localizedString>")
			.toString();
	}
	public static String toXMLQuestion(VCryptQuestion vcryptQuestion) {
		StringBuffer xmlString = new StringBuffer(500)
			.append("<UserQuestion>")
			.append(VCryptCommonUtil.getXmlElement("questionId", vcryptQuestion.getQuestionId()))
			.append(VCryptCommonUtil.getXmlElement("questionText", vcryptQuestion.getQuestion()))
			.append(toXMLLocale(vcryptQuestion.getLocale()));
		if (vcryptQuestion.getAnswerList().size() > 0) {
			xmlString.append(VCryptCommonUtil.getXmlElement("answerText", vcryptQuestion.getAnswerList().get(0)));
		} else {
			xmlString.append("<answerText />");
		}
		xmlString.append("</UserQuestion>");
		return xmlString.toString();
	}

	public static Map fromXMLGetSignOnQuestionsRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLGetSignOnQuestionsRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLGetSignOnQuestionsRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap(3);
		String rootNode = "GetSignOnQuestionsRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value.trim());
                }
                else if (nodeName.equalsIgnoreCase("locale"))
                {
                    nvList.put("locale", fromNodeLocale(node));
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static VCryptLocale fromNodeLocale(Node localeNode) {
		String language = "";
		String country = "";
		String variant = "";
		NodeList nodeList = localeNode.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			String nodeName = node.getNodeName();
			Node valueNode = node.getFirstChild();
			if (valueNode == null) {
				continue;
			}
			if (nodeName.equalsIgnoreCase("language")) {
				String value = valueNode.getNodeValue();
				if (!StringUtil.isEmpty(value)) {
					language = value.trim();
				}
			} else if (nodeName.equalsIgnoreCase("country")) {
				String value = valueNode.getNodeValue();
				if (!StringUtil.isEmpty(value)) {
					country = value.trim();
				}
			} else if (nodeName.equalsIgnoreCase("variant")) {
				String value = valueNode.getNodeValue();
				if (!StringUtil.isEmpty(value)) {
					variant = value.trim();
				}
			}
		}
		return new VCryptLocale(language, country, variant);
	}

	static VCryptLocalizedString fromNodeLocalizedString(Node captionNode) {
		VCryptLocale locale = null;
		String text = "";
		NodeList nodeList = captionNode.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			String nodeName = node.getNodeName();
			Node valueNode = node.getFirstChild();
			if (valueNode == null) {
				continue;
			}
			if (nodeName.equalsIgnoreCase("text")) {
				String value = valueNode.getNodeValue();
				if (!StringUtil.isEmpty(value)) {
					text = value.trim();
				}
			} else if (nodeName.equalsIgnoreCase("locale")) {
				locale = fromNodeLocale(node);
			}
		}
		if (locale == null) return new VCryptLocalizedString(text);
		return new VCryptLocalizedString(text, locale);
	}

	static public String toXMLGetSecretQuestionRequest(String customerId, Long previousAuthSessionId, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint) {

		if (logger.isDebugEnabled()) logger.debug("toXMLGetSecretQuestionRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<GetSecretQuestionRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionId", previousAuthSessionId));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionType", authSessionType));
		xmlString.append(VCryptCommonUtil.getXmlElement("clientType", clientType));
		xmlString.append(VCryptCommonUtil.getXmlElement("clientVersion", clientVersion));
		xmlString.append(VCryptCommonUtil.getXmlElement("ipAddress", ipAddress));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrintType", fingerPrintType));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrint", fingerPrint));
		xmlString.append("</GetSecretQuestionRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLGetSecretQuestionRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLGetSecretQuestionRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLGetSecretQuestionRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "GetSecretQuestionRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("authSessionId"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("previousAuthSessionId", new Long(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("authSessionType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("authSessionType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("clientType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("clientType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("clientVersion"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("clientVersion", value);
                }
                else if (nodeName.equalsIgnoreCase("ipAddress"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("ipAddress", value);
                }
                else if (nodeName.equalsIgnoreCase("fingerPrintType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("fingerPrintType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("fingerPrint"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("fingerPrint", value);
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLGetSecretQuestionResponse(VCryptQuestion vcryptQuestion) {
		if (logger.isDebugEnabled()) logger.debug("toXMLGetSecretQuestionResponse() enter()");
		if (vcryptQuestion == null) {
			logger.error("toXMLGetSecretQuestionResponse question is null");
			return null;
		}

		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<GetSecretQuestionResponse>");
		xmlString.append(VCryptCommonUtil.getXmlElement("question", vcryptQuestion.getQuestion()));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionId", vcryptQuestion.getAuthSessionId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("questionId", vcryptQuestion.getQuestionId()));
		xmlString.append("<answerList>");
		if (vcryptQuestion.getAnswerList() != null) {
			Iterator iter = vcryptQuestion.getAnswerList().iterator();
			while (iter.hasNext())
				xmlString.append(VCryptCommonUtil.getXmlElement("answer", iter.next()));
		}
		xmlString.append("</answerList>");
		xmlString.append(toXMLLocale(vcryptQuestion.getLocale()));
		xmlString.append("</GetSecretQuestionResponse>");
		return xmlString.toString();
	}

	static public VCryptQuestion fromXMLGetSecretQuestionResponse(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLGetSecretQuestionResponse() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLGetSecretQuestionResponse() got null xmlString");
			return null;
		}

		VCryptQuestion retVal = new VCryptQuestion();
		String rootNode = "GetSecretQuestionResponse";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("question"))
                {
                    retVal.setQuestion(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("answerList"))
                {
                    ArrayList answerList = new ArrayList();
                    NodeList answerNodeList = node.getChildNodes();
                    for (int r = 0; r < answerNodeList.getLength(); r++)
                    {
                        Node answerNode = answerNodeList.item(r);
                        String answerNodeName = answerNode.getNodeName();
                        Node valueAnswerNode = answerNode.getFirstChild();
                        if (valueAnswerNode == null)
                        {
                            continue;
                        }
                        if (answerNodeName.equalsIgnoreCase("answer"))
                        {
                            answerList.add(valueAnswerNode.getNodeValue().trim());
                        }
                        else if (!answerNodeName.startsWith("#"))
                        {
                            logger.error("Invalid element name <" + answerNodeName + "> in answerList element xml "
                                    + xmlString);
                        }
                    }
                    retVal.setAnswerList(answerList);
                }
                else if (nodeName.equalsIgnoreCase("authSessionId"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        retVal.setAuthSessionId(new Long(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("questionId"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        retVal.setQuestionId(new Long(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("locale"))
                {
                    retVal.setLocale(fromNodeLocale(node));
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return retVal;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLAuthQuestionRequest(String requestId, Integer challengeChannel, String customerId, String answer) {
		if (logger.isDebugEnabled()) logger.debug("toXMLAuthQuestionRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append(VCryptCommonUtil.getXmlElement("requestId", requestId));
		xmlString.append(VCryptCommonUtil.getXmlElement("challengeChannel", challengeChannel));
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("answer", answer));
		return VCryptCommonUtil.getXmlElement(root_AuthQuestionRequest, xmlString).toString();
	}

	static public String toXMLAuthQuestionRequest(String customerId, Long authSessionId, String answer, String ipAddress, int fingerPrintType, String fingerPrint) {

		if (logger.isDebugEnabled()) logger.debug("toXMLAuthQuestionRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionId", authSessionId));
		xmlString.append(VCryptCommonUtil.getXmlElement("answer", answer));
		xmlString.append(VCryptCommonUtil.getXmlElement("ipAddress", ipAddress));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrintType", fingerPrintType));
		xmlString.append(VCryptCommonUtil.getXmlElement("fingerPrint", fingerPrint));
		return VCryptCommonUtil.getXmlElement(root_AuthQuestionRequest, xmlString).toString();
	}

	static public Map fromXMLAuthQuestionRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLAuthQuestionRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLAuthQuestionRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = root_AuthQuestionRequest;

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("challengeChannel"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value)) nvList.put("challengeChannel", new Integer(value));
                }
                else if (nodeName.equalsIgnoreCase("requestId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("requestId", value);
                }
                else if (nodeName.equalsIgnoreCase("authSessionId"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("authSessionId", new Long(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("answer"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("answer", value);
                }
                else if (nodeName.equalsIgnoreCase("ipAddress"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("ipAddress", value);
                }
                else if (nodeName.equalsIgnoreCase("fingerPrintType"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        nvList.put("fingerPrintType", new Integer(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("fingerPrint"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("fingerPrint", value);
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLSetUserPinRequest(String customerId, String pin, int pinStatus) {

		if (logger.isDebugEnabled()) logger.debug("toXMLSetUserPinRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<SetUserPinRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("pin", pin));
		xmlString.append(VCryptCommonUtil.getXmlElement("pinStatus", pinStatus));
		xmlString.append("</SetUserPinRequest>");
		return xmlString.toString();
	}

	static public String toXMLSetUserAuthModeRequest(String customerId, int userAuthMode) {
		if (logger.isDebugEnabled()) logger.debug("toXMLSetUserAuthModeRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<SetUserAuthModeRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("userAuthMode", userAuthMode));
		xmlString.append("</SetUserAuthModeRequest>");
		return xmlString.toString();
	}

	static public String toXMLSetUserStatusRequest(String customerId, int userStatus) {
		if (logger.isDebugEnabled()) logger.debug("toXMLSetUserStatusRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<SetUserStatusRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("userStatus", userStatus));
		xmlString.append("</SetUserStatusRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLSetUserPinRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLSetUserPinRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLSetUserPinRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "SetUserPinRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("pin"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("pin", value);
                }
                else if (nodeName.equalsIgnoreCase("pinStatus"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("pinStatus", new Integer(value));
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLSetUserPasswordRequest(String customerId, String password, int passwordStatus) {
		if (logger.isDebugEnabled()) logger.debug("toXMLSetUserPasswordRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<SetUserPasswordRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("password", password));
		xmlString.append(VCryptCommonUtil.getXmlElement("passwordStatus", passwordStatus));
		xmlString.append("</SetUserPasswordRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLSetUserPasswordRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLSetUserPasswordRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLSetUserPasswordRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "SetUserPasswordRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("password"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("password", value);
                }
                else if (nodeName.equalsIgnoreCase("passwordStatus"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("passwordStatus", new Integer(value));
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public Map fromXMLSetUserAuthModeRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLSetUserAuthModeRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLSetUserAuthModeRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "SetUserAuthModeRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("userAuthMode"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("userAuthMode", new Integer(value));
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public Map fromXMLSetUserStatusRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLSetUserStatusRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLSetUserStatusRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "SetUserStatusRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("userStatus"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("userStatus", new Integer(value));
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLSignOnQuestions(VCryptQuestion[][] questions) {
		if (logger.isDebugEnabled()) logger.debug("toXMLSignOnQuestions() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<SignOnQuestions>");
		for (int idxCategory = 0; questions != null && idxCategory < questions.length; idxCategory++) {
			xmlString.append("<category>");
			for (int idxQuestion = 0; idxQuestion < questions[idxCategory].length; idxQuestion++) {
				xmlString.append("<question>");
				VCryptQuestion eachQuestion = questions[idxCategory][idxQuestion];
				String questionStr = eachQuestion.getQuestion();
				Long questionId = eachQuestion.getQuestionId();
				xmlString.append(VCryptCommonUtil.getXmlElement("id", questionId));
				xmlString.append(VCryptCommonUtil.getXmlElement("value", questionStr));
				xmlString.append(toXMLLocale(eachQuestion.getLocale()));
				xmlString.append("</question>");
			}
			xmlString.append("</category>");
		}
		xmlString.append("</SignOnQuestions>");
		if (logger.isDebugEnabled()) logger.debug("toXMLSignOnQuestions() exit()");
		return xmlString.toString();
	}

	static public String toXMLGetAllMappedSignOnQuestionsResponse(VCryptQuestion[] questions) {
		if (logger.isDebugEnabled()) logger.debug("toXMLGetAllMappedSignOnQuestionsResponse() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<GetAllMappedSignOnQuestionsResponse>");
		for (int idxQuestion = 0; questions != null && idxQuestion < questions.length; idxQuestion++) {
			xmlString.append("<question>");
			VCryptQuestion eachQuestion = questions[idxQuestion];
			String questionStr = eachQuestion.getQuestion();
			Long questionId = eachQuestion.getQuestionId();
			xmlString.append(VCryptCommonUtil.getXmlElement("id", questionId));
			xmlString.append(VCryptCommonUtil.getXmlElement("value", questionStr));
			xmlString.append(toXMLLocale(eachQuestion.getLocale()));
			xmlString.append("</question>");
		}
		xmlString.append("</GetAllMappedSignOnQuestionsResponse>");
		if (logger.isDebugEnabled()) logger.debug("toXMLGetAllMappedSignOnQuestionsResponse() exit()");
		return xmlString.toString();
	}

	static public VCryptQuestion[][] fromXMLSignOnQuestions(String xmlString) {

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLSignOnQuestions() got null xmlString");
			return null;
		}

		if (logger.isDebugEnabled()) logger.debug("fromXMLSignOnQuestions() enter()");

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));
            String rootNode = "SignOnQuestions";

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                if (logger.isDebugEnabled()) logger.debug("root node '" + rootNode + "' not found");
                return null;
            }

            Vector vecCategory = new Vector();

            NodeList categoryNodeList = root.getChildNodes();
            for (int i = 0; i < categoryNodeList.getLength(); i++)
            {
                Node categoryNode = categoryNodeList.item(i);
                String nodeName = categoryNode.getNodeName();

                if (!nodeName.equalsIgnoreCase("category"))
                {
                    if (logger.isDebugEnabled())
                        logger.debug(nodeName + ": unexpected node name; expecting 'category'");
                    continue;
                }

                Vector vecQuestion = new Vector();

                NodeList questionNodeList = categoryNode.getChildNodes();
                for (int j = 0; j < questionNodeList.getLength(); j++)
                {
                    Node questionNode = questionNodeList.item(j);

                    nodeName = questionNode.getNodeName();

                    if (!nodeName.equalsIgnoreCase("question"))
                    {
                        if (logger.isDebugEnabled())
                            logger.debug(nodeName + ": unexpected node name; expecting 'question'");
                        continue;
                    }

                    Long questionId = null;
                    String questionStr = null;
                    VCryptLocale locale = new VCryptLocale();

                    NodeList valueNodeList = questionNode.getChildNodes();
                    for (int k = 0; k < valueNodeList.getLength(); k++)
                    {
                        Node valueNode = valueNodeList.item(k);
                        String value =
                                (valueNode.getFirstChild() == null) ? null : valueNode.getFirstChild().getNodeValue();

                        nodeName = valueNode.getNodeName();

                        if (nodeName.equalsIgnoreCase("id"))
                        {
                            questionId = new Long(Long.parseLong(value));
                        }
                        else if (nodeName.equalsIgnoreCase("value"))
                        {
                            questionStr = value;
                        }
                        else if (nodeName.equalsIgnoreCase("locale"))
                        {
                            locale = fromNodeLocale(valueNode);
                        }
                        else if (!nodeName.startsWith("#"))
                        {
                            if (logger.isDebugEnabled())
                                logger.debug(nodeName + ": unexpected node name; expecting 'id' or 'value'");
                        }
                    }

                    if (questionId != null && questionStr != null)
                    {
                        VCryptQuestion question = new VCryptQuestion();

                        question.setQuestionId(questionId);
                        question.setQuestion(questionStr);
                        question.setLocale(locale);

                        vecQuestion.add(question);
                    }
                }

                vecCategory.add(vecQuestion);
            }

            VCryptQuestion[][] ret = new VCryptQuestion[vecCategory.size()][];

            for (int i = 0; i < ret.length; i++)
            {
                ret[i] = (VCryptQuestion[]) ((Vector) vecCategory.get(i)).toArray(new VCryptQuestion[0]);
            }

            return ret;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
		}

		return null;
	}

	static public VCryptQuestion[] fromXMLGetAllMappedSignOnQuestionsResponse(String xmlString) {

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLGetAllMappedSignOnQuestionsResponse() got null xmlString");
			return null;
		}

		if (logger.isDebugEnabled()) logger.debug("fromXMLGetAllMappedSignOnQuestionsResponse() enter()");

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));
            String rootNode = "GetAllMappedSignOnQuestionsResponse";

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                if (logger.isDebugEnabled()) logger.debug("root node '" + rootNode + "' not found");
                return null;
            }

            Vector vecQuestion = new Vector();

            NodeList questionNodeList = root.getChildNodes();
            for (int j = 0; j < questionNodeList.getLength(); j++)
            {
                Node questionNode = questionNodeList.item(j);

                String nodeName = questionNode.getNodeName();

                if (!nodeName.equalsIgnoreCase("question"))
                {
                    if (logger.isDebugEnabled())
                        logger.debug(nodeName + ": unexpected node name; expecting 'question'");
                    continue;
                }

                Long questionId = null;
                String questionStr = null;
                VCryptLocale locale = new VCryptLocale();

                NodeList valueNodeList = questionNode.getChildNodes();
                for (int k = 0; k < valueNodeList.getLength(); k++)
                {
                    Node valueNode = valueNodeList.item(k);
                    String value =
                            (valueNode.getFirstChild() == null) ? null : valueNode.getFirstChild().getNodeValue();

                    nodeName = valueNode.getNodeName();

                    if (nodeName.equalsIgnoreCase("id"))
                    {
                        questionId = new Long(Long.parseLong(value));
                    }
                    else if (nodeName.equalsIgnoreCase("value"))
                    {
                        questionStr = value;
                    }
                    else if (nodeName.equalsIgnoreCase("locale"))
                    {
                        locale = fromNodeLocale(valueNode);
                    }
                    else if (!nodeName.startsWith("#"))
                    {
                        if (logger.isDebugEnabled())
                            logger.debug(nodeName + ": unexpected node name; expecting 'id' or 'value'");
                    }
                }

                if (questionId != null && questionStr != null)
                {
                    VCryptQuestion question = new VCryptQuestion();

                    question.setQuestionId(questionId);
                    question.setQuestion(questionStr);
                    question.setLocale(locale);

                    vecQuestion.add(question);
                }
            }

            return (VCryptQuestion[]) vecQuestion.toArray(new VCryptQuestion[0]);
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
		}

		return null;
	}

	static public String toXMLSetCaptionRequest(String customerId, String caption) {
		if (logger.isDebugEnabled()) logger.debug("toXMLSetCaptionRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<SetCaptionRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("caption", caption));
		xmlString.append("</SetCaptionRequest>");
		return xmlString.toString();
	}

	static public String toXMLSetCaptionRequest(String customerId, VCryptLocalizedString caption) {
		if (logger.isDebugEnabled()) logger.debug("toXMLSetCaptionRequest() enter()");
		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<SetCaptionRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(toXMLLocalizedString(caption));
		xmlString.append("</SetCaptionRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLSetCaptionRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLSetCaptionRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLSetCaptionRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "SetCaptionRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("caption"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("caption", value);
                }
                else if (nodeName.equalsIgnoreCase("localizedString"))
                {
                    VCryptLocalizedString value = fromNodeLocalizedString(node);
                    nvList.put("localizedString", value);
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public VCryptLocalizedString fromXMLLocalizedString(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLLocalizedString() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLLocalizedString() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "localizedString";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }
            return fromNodeLocalizedString(root);
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLSetImageRequest(String customerId, String imagePath) {

		if (logger.isDebugEnabled()) logger.debug("toXMLSetImageRequest start");

		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<SetUserImageRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("imagePath", imagePath));
		xmlString.append("</SetUserImageRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLSetImageRequest(String xmlString) {

		if (logger.isDebugEnabled()) logger.debug("fromXMLSetImageRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLSetImageRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "SetUserImageRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("imagePath"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("imagePath", value);
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLImageAndCaptionRequest(String customerId, String imagePath, String caption) {
		if (logger.isDebugEnabled()) logger.debug("toXMLImageAndCaptionRequest start");
		StringBuffer xmlBuffer = new StringBuffer(500);
		xmlBuffer.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlBuffer.append(VCryptCommonUtil.getXmlElement("imagePath", imagePath));
		xmlBuffer.append(VCryptCommonUtil.getXmlElement("caption", caption));
		return VCryptCommonUtil.getXmlElement(root_setImageAndCaption, xmlBuffer).toString();
	}

	static public String toXMLImageAndCaptionRequest(String customerId, String imagePath, VCryptLocalizedString caption) {
		if (logger.isDebugEnabled()) logger.debug("toXMLImageAndCaptionRequest start");
		StringBuffer xmlBuffer = new StringBuffer(500);
		xmlBuffer.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlBuffer.append(VCryptCommonUtil.getXmlElement("imagePath", imagePath));
		xmlBuffer.append(toXMLLocalizedString(caption));
		return VCryptCommonUtil.getXmlElement(root_setImageAndCaption, xmlBuffer).toString();
	}

	static public Map fromXMLImageAndCaptionRequest(String xmlString) {

		if (logger.isDebugEnabled()) logger.debug("fromXMLImageAndCaptionRequest enter");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLImageAndCaptionRequest got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(root_setImageAndCaption))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("imagePath"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("imagePath", value);
                }
                else if (nodeName.equalsIgnoreCase("caption"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("caption", value);
                }
                else if (nodeName.equalsIgnoreCase("localizedString"))
                {
                    VCryptLocalizedString value = fromNodeLocalizedString(node);
                    nvList.put("localizedString", value);
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLAddQuestionRequest(String requestId, String customerId, VCryptQuestion vcryptQuestion) {
		if (logger.isDebugEnabled()) logger.debug("toXMLAddQuestionRequest() enter()");
		if (vcryptQuestion == null) { return null; }

		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<AddUserQuestionRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("requestId", requestId));
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("questionId", vcryptQuestion.getQuestionId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("questionText", vcryptQuestion.getQuestion()));
		xmlString.append(toXMLLocale(vcryptQuestion.getLocale()));
		if (vcryptQuestion.getAnswerList().size() > 0) xmlString.append(VCryptCommonUtil.getXmlElement("answerText", vcryptQuestion.getAnswerList().get(0)));
		xmlString.append("</AddUserQuestionRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLAddQuestionRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLAddUserQuestionRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLAddUserQuestionRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "AddUserQuestionRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            VCryptQuestion vcryptQuestion = new VCryptQuestion();
            ArrayList answerList = new ArrayList();
            vcryptQuestion.setAnswerList(answerList);
            nvList.put("vcryptQuestion", vcryptQuestion);

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("requestId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("requestId", value);
                }
                else if (nodeName.equalsIgnoreCase("questionId"))
                {
                    String value = valueNode.getNodeValue();
                    vcryptQuestion.setQuestionId(new Long(value));
                }
                else if (nodeName.equalsIgnoreCase("questionText"))
                {
                    String value = valueNode.getNodeValue();
                    vcryptQuestion.setQuestion(value);
                }
                else if (nodeName.equalsIgnoreCase("answerText"))
                {
                    String value = valueNode.getNodeValue();
                    answerList.add(value);
                }
                else if (nodeName.equalsIgnoreCase("locale"))
                {
                    vcryptQuestion.setLocale(fromNodeLocale(node));
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLAddQuestionsRequest(String requestId, String customerId, VCryptQuestion[] vcryptQuestions) {
		if (logger.isDebugEnabled()) logger.debug("toXMLAddQuestionsRequest() enter()");
		if (vcryptQuestions == null) return null;

		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<AddUserQuestionsRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("requestId", requestId));
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		if (vcryptQuestions.length > 0) {
			for (int i = 0; i < vcryptQuestions.length; i++) {
				VCryptQuestion vcryptQuestion = vcryptQuestions[i];
				if (vcryptQuestion == null) continue;
				xmlString.append(toXMLQuestion(vcryptQuestion));
			}
		}
		xmlString.append("</AddUserQuestionsRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLAddQuestionsRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLAddUserQuestionsRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLAddUserQuestionsRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "AddUserQuestionsRequest";
		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }
            if (root == null)
            {
                return null;
            }

            ArrayList questionList = new ArrayList();
            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();

                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    Node valueNode = node.getFirstChild();
                    if (valueNode == null)
                    {
                        continue;
                    }

                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("requestId"))
                {
                    Node valueNode = node.getFirstChild();
                    if (valueNode == null) continue;
                    String value = valueNode.getNodeValue();
                    nvList.put("requestId", value);
                }
                else if (nodeName.equalsIgnoreCase("UserQuestion"))
                {
                    Long questionId = null;
                    String questionStr = null;
                    VCryptLocale locale = new VCryptLocale();
                    ArrayList answerList = new ArrayList();

                    NodeList questionElementList = node.getChildNodes();
                    for (int k = 0; k < questionElementList.getLength(); k++)
                    {
                        Node valueNode = questionElementList.item(k);
                        String value =
                                (valueNode.getFirstChild() == null) ? null : valueNode.getFirstChild().getNodeValue();

                        nodeName = valueNode.getNodeName();

                        if (nodeName.equalsIgnoreCase("questionId"))
                        {
                            questionId = new Long(Long.parseLong(value));
                        }
                        else if (nodeName.equalsIgnoreCase("questionText"))
                        {
                            questionStr = value;
                        }
                        else if (nodeName.equalsIgnoreCase("answerText"))
                        {
                            answerList.add(value);
                        }
                        else if (nodeName.equalsIgnoreCase("locale"))
                        {
                            locale = fromNodeLocale(valueNode);
                        }
                        else if (!nodeName.startsWith("#"))
                        {
                            if (logger.isDebugEnabled()) logger.debug(nodeName
                                    + ": unexpected node name; expecting 'questionId', 'questionText' or 'answerText'");
                        }
                    }

                    if (questionId != null)
                    {
                        VCryptQuestion question = new VCryptQuestion();
                        question.setQuestionId(questionId);
                        question.setQuestion(questionStr);
                        question.setAnswerList(answerList);
                        question.setLocale(locale);
                        questionList.add(question);
                    }
                }
            }
            VCryptQuestion[] questionObjArr = new VCryptQuestion[questionList.size()];
            if (questionList.size() > 0)
            {
                Iterator iter = questionList.iterator();
                int q = 0;
                while (iter.hasNext())
                {
                    questionObjArr[q++] = (VCryptQuestion) iter.next();
                }
            }
            nvList.put("vcryptQuestions", questionObjArr);
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLDeleteQuestionRequest(String customerId, VCryptQuestion vcryptQuestion) {
		if (logger.isDebugEnabled()) logger.debug("toXMLDeleteQuestionRequest() enter()");
		if (vcryptQuestion == null) {
			logger.error("toXMLDeleteQuestionRequest null question");
			return null;
		}

		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<DeleteUserQuestionRequest>");
		xmlString.append(VCryptCommonUtil.getXmlElement("customerId", customerId));
		xmlString.append(VCryptCommonUtil.getXmlElement("questionId", vcryptQuestion.getQuestionId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("questionText", vcryptQuestion.getQuestion()));
		if (vcryptQuestion.getAnswerList() != null && vcryptQuestion.getAnswerList().size() > 0) xmlString.append(VCryptCommonUtil.getXmlElement("answerText", vcryptQuestion.getAnswerList().get(0)));
		xmlString.append(toXMLLocale(vcryptQuestion.getLocale()));
		xmlString.append("</DeleteUserQuestionRequest>");
		return xmlString.toString();
	}

	static public Map fromXMLDeleteQuestionRequest(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLDeleteUserQuestionRequest() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLDeleteUserQuestionRequest() got null xmlString");
			return null;
		}

		HashMap nvList = new HashMap();
		String rootNode = "DeleteUserQuestionRequest";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            VCryptQuestion vcryptQuestion = new VCryptQuestion();
            ArrayList answerList = new ArrayList();
            vcryptQuestion.setAnswerList(answerList);
            nvList.put("vcryptQuestion", vcryptQuestion);

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase("customerId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("customerId", value);
                }
                else if (nodeName.equalsIgnoreCase("questionId"))
                {
                    String value = valueNode.getNodeValue();
                    vcryptQuestion.setQuestionId(new Long(value));
                }
                else if (nodeName.equalsIgnoreCase("questionText"))
                {
                    String value = valueNode.getNodeValue();
                    vcryptQuestion.setQuestion(value);
                }
                else if (nodeName.equalsIgnoreCase("locale"))
                {
                    vcryptQuestion.setLocale(fromNodeLocale(valueNode));
                }
                else if (nodeName.equalsIgnoreCase("answerText"))
                {
                    String value = valueNode.getNodeValue();
                    answerList.add(value);
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLMoveToNextSecretQuestionResponse(VCryptQuestion vcryptQuestion) {
		if (logger.isDebugEnabled()) logger.debug("toXMLMoveToNextSecretQuestionResponse() enter()");

		if (vcryptQuestion == null) {
			logger.error("toXMLMoveToNextSecretQuestionResponse null question");
			return null;
		}

		StringBuffer xmlString = new StringBuffer(500);
		xmlString.append("<MoveToNextSecretQuestionResponse>");
		xmlString.append(VCryptCommonUtil.getXmlElement("question", vcryptQuestion.getQuestion()));
		xmlString.append(VCryptCommonUtil.getXmlElement("authSessionId", vcryptQuestion.getAuthSessionId()));
		xmlString.append(VCryptCommonUtil.getXmlElement("questionId", vcryptQuestion.getQuestionId()));
		xmlString.append("<answerList>");
		if (vcryptQuestion.getAnswerList() != null) {
			Iterator iter = vcryptQuestion.getAnswerList().iterator();
			while (iter.hasNext())
				xmlString.append(VCryptCommonUtil.getXmlElement("answer", iter.next()));
		}
		xmlString.append("</answerList>");
		xmlString.append(toXMLLocale(vcryptQuestion.getLocale()));
		xmlString.append("</MoveToNextSecretQuestionResponse>");

		return xmlString.toString();
	}

	static public String toXMLSetGroupUsersAuthMode(String groupName, int userAuthMode) {
		if (logger.isDebugEnabled()) logger.debug("toXMLSetGroupUsersAuthMode enter()");
		StringBuffer buffer = new StringBuffer(500);
		buffer.append(VCryptCommonUtil.getXmlElement(GROUP_NAME, groupName));
		buffer.append(VCryptCommonUtil.getXmlElement(USER_AUTH_MODE, userAuthMode));
		return VCryptCommonUtil.getXmlElement(root_setGroupUsersAuthMode, buffer).toString();
	}

	static public Map fromXMLSetGroupUsersAuthMode(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLSetGroupUsersAuthMode enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLSetGroupUsersAuthMode() got null xmlString");
			return null;
		}
		HashMap nvList = new HashMap();
		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(root_setGroupUsersAuthMode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }

                if (nodeName.equalsIgnoreCase(GROUP_NAME))
                {
                    nvList.put(GROUP_NAME, valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase(USER_AUTH_MODE))
                {
                    nvList.put(USER_AUTH_MODE, new Integer(valueNode.getNodeValue()));
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public VCryptQuestion fromXMLMoveToNextSecretQuestionResponse(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLMoveToSecretQuestionResponse() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLMoveToNextSecretQuestionResponse() got null xmlString");
			return null;
		}

		VCryptQuestion retVal = new VCryptQuestion();
		String rootNode = "MoveToNextSecretQuestionResponse";

		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(rootNode))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("question"))
                {
                    retVal.setQuestion(valueNode.getNodeValue());
                }
                else if (nodeName.equalsIgnoreCase("answerList"))
                {
                    ArrayList answerList = new ArrayList();
                    NodeList answerNodeList = node.getChildNodes();
                    for (int r = 0; r < answerNodeList.getLength(); r++)
                    {
                        Node answerNode = answerNodeList.item(r);
                        String answerNodeName = answerNode.getNodeName();
                        Node valueAnswerNode = answerNode.getFirstChild();
                        if (valueAnswerNode == null)
                        {
                            continue;
                        }
                        if (answerNodeName.equalsIgnoreCase("answer"))
                        {
                            answerList.add(valueAnswerNode.getNodeValue().trim());
                        }
                        else if (!answerNodeName.startsWith("#"))
                        {
                            logger.error("Invalid element name <" + answerNodeName + "> in answerList element xml "
                                    + xmlString);
                        }
                    }
                    retVal.setAnswerList(answerList);
                }
                else if (nodeName.equalsIgnoreCase("authSessionId"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        retVal.setAuthSessionId(new Long(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("questionId"))
                {
                    String value = valueNode.getNodeValue();
                    if (!StringUtil.isEmpty(value))
                    {
                        retVal.setQuestionId(new Long(value.trim()));
                    }
                }
                else if (nodeName.equalsIgnoreCase("locale"))
                {
                    retVal.setLocale(fromNodeLocale(valueNode));
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return retVal;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}

	static public String toXMLGetUser(String loginId, String groupName) {

		if (logger.isDebugEnabled()) logger.debug("toXMLGetUser() enter()");
		StringBuffer xmlString = new StringBuffer(200);
		xmlString.append(VCryptCommonUtil.getXmlElement("LoginId", loginId));
		xmlString.append(VCryptCommonUtil.getXmlElement("GroupName", groupName));
		return VCryptCommonUtil.getXmlElement(root_GetUser, xmlString).toString();
	}

	static public Map fromXMLGetUser(String xmlString) {
		if (logger.isDebugEnabled()) logger.debug("fromXMLGetUser() enter()");

		if (StringUtil.isEmpty(xmlString)) {
			logger.warn("fromXMLGetUser() got null xmlString");
			return null;
		}
		HashMap nvList = new HashMap();
		try
        {
            final DocumentBuilder builder = XMLParserFactory.createDOMParserInstance();
            Document document = builder.parse(new InputSource(new StringReader(xmlString)));

            Node root = null;
            NodeList rootList = document.getChildNodes();
            for (int i = 0; i < rootList.getLength(); i++)
            {
                Node node = rootList.item(i);
                if (node.getNodeName().equalsIgnoreCase(root_GetUser))
                {
                    root = node;
                    break;
                }
            }

            if (root == null)
            {
                return null;
            }

            NodeList nodeList = root.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                String nodeName = node.getNodeName();
                Node valueNode = node.getFirstChild();
                if (valueNode == null)
                {
                    continue;
                }
                if (nodeName.equalsIgnoreCase("LoginId"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("LoginId", value);
                }
                else if (nodeName.equalsIgnoreCase("GroupName"))
                {
                    String value = valueNode.getNodeValue();
                    nvList.put("GroupName", value);
                }
                else if (!nodeName.startsWith("#"))
                {
                    logger.error("Invalid element name <" + nodeName + "> in xml " + xmlString);
                }
            }
            return nvList;
        } catch (Exception ex) {
			logger.error("Exception while parsing xml =" + xmlString, ex);
			return null;
		}
	}
}
