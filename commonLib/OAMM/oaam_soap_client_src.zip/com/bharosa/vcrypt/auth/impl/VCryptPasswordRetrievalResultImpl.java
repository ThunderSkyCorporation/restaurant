package com.bharosa.vcrypt.auth.impl;

import java.util.List;
import java.util.ArrayList;

import com.bharosa.common.logger.Logger;

import com.bharosa.vcrypt.auth.intf.VCryptPasswordRetrievalResult;

/**
 * Provides information about authentication results
 * @author Luke
 */

public class VCryptPasswordRetrievalResultImpl implements VCryptPasswordRetrievalResult, java.io.Serializable{
	static Logger logger = Logger.getLogger(VCryptPasswordRetrievalResultImpl.class);

	int statusCode = -1;
	String question = null;
	String answer = null;

	public VCryptPasswordRetrievalResultImpl(){
		if(logger.isDebugEnabled()) logger.debug("Using default constructor");
	}

	public VCryptPasswordRetrievalResultImpl(int status){
		if(logger.isDebugEnabled()) logger.debug("Setting status to: "+status);
		statusCode = status;
	}

	public VCryptPasswordRetrievalResultImpl(int status, String secretQuestion, String secretAnswer){
		if(logger.isDebugEnabled()) logger.debug("Setting status to: "+status);
		statusCode = status;

		question = secretQuestion;
		answer = secretAnswer;
	}

	public int getStatus(){
		return statusCode;
	}

	public String getSecretQuestion(){
		return question;
	}

	public String getSecretAnswer(){
		return answer;
	}
}
