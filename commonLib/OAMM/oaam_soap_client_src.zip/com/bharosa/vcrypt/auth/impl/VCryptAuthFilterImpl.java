package com.bharosa.vcrypt.auth.impl;

/*
 * Copyright (c) 2006 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.Date;
import java.util.Map;
import java.util.Vector;

import com.bharosa.common.logger.Logger;

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.vcrypt.auth.intf.VCryptAuth;
import com.bharosa.vcrypt.auth.intf.VCryptAuthResult;
import com.bharosa.vcrypt.auth.intf.VCryptAuthUser;
import com.bharosa.vcrypt.auth.intf.VCryptLocale;
import com.bharosa.vcrypt.auth.intf.VCryptLocalizedString;
import com.bharosa.vcrypt.auth.intf.VCryptQuestion;
import com.bharosa.vcrypt.auth.intf.VCryptWheel;
import com.bharosa.vcrypt.common.util.VCryptResponse;

/**
 * VCryptAuthFilterImpl <p/> Date: Dec 18, 2006
 * 
 * @since 3.5
 */

public class VCryptAuthFilterImpl implements VCryptAuth {

	private static Logger logger = Logger.getLogger(VCryptAuthFilterImpl.class);

	final static Object lock = new Object();
	static VCryptAuth vCryptAuth = null;

	public VCryptAuthFilterImpl() {
		synchronized (lock) {
			if (vCryptAuth == null) {
				logger.info("Creating new vCryptAuthinstance...");
				try {
					String name = BharosaConfig.get("vcrypt.auth.filter.impl.classname");
					if (name == null || name.trim().equals("")) {
						boolean useSoap = BharosaConfig.getBoolean("vcrypt.tracker.soap.useSOAPServer", false);
						logger.info("vcrypt.auth.filter.impl.classname not set, using defaults");
						if (useSoap) {
							name = BharosaConfig.get("vcrypt.auth.util.soap.classname", "com.bharosa.vcrypt.auth.impl.VCryptAuthSOAPImpl");
							logger.info("vcrypt.tracker.soap.useSOAPServer is set to true, using class " + name);
						} else {
							name = BharosaConfig.get("vcrypt.auth.util.static.classname", "com.bharosa.vcrypt.auth.impl.VCryptAuthMonitorImpl");
							logger.info("vcrypt.tracker.soap.useSOAPServer is set to false, using class " + name);
						}
					}
					// Loading instance
					logger.info("Loading class " + name);
					if (!StringUtil.isEmpty(name)) {
						logger.info("Loading class " + name);
						vCryptAuth = (VCryptAuth) Class.forName(name).newInstance();
					} else {
						logger.error("Class not created. vcrypt.auth.filter.impl.classname should be set");
					}
				} catch (Exception ex) {
					logger.error("Error creating vCryptAuthinstance.", ex);
				}
			}
		}
	}

	/**
	 * Return the user details without the password and pin for the given
	 * customer and group
	 * 
	 * @param loginId
	 *           of the user.
	 * @param groupName
	 *           groupName
	 * @return a <code>VCryptAuthUser</code> value. If the user is not valid,
	 *         then all the values in the object is is null. Any unexpected
	 *         error, Null is returned.
	 */
	public VCryptAuthUser getUserByLoginId(String loginId, String groupName) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getUserByLoginId(loginId, groupName);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getUser: CustomerId:" + loginId + ":" + "groupName:" + groupName + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthUser getUser(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getUser(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getUser: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthUser getUserByLoginId(String loginId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getUserByLoginId(loginId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getUserByLoginId: CustomerId:" + loginId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthUser createUser(VCryptAuthUser user) {
		Date beginTime = new Date();
		String customerId = null;
		try {
			VCryptAuthUser authUser = vCryptAuth.createUser(user);
			if (authUser != null) customerId = authUser.getCustomerId();
			return authUser;
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:createUser: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthUser setUser(VCryptAuthUser user) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.setUser(user);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:setUser: CustomerId:" + user.getCustomerId() + ":" + +(new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthResult authenticatePassword(String customerId, String password, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.authenticatePassword(customerId, password, authSessionType, clientType, clientVersion, ipAddress, fingerPrintType, fingerPrint);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:authenticatePassword: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthResult authenticatePin(String customerId, String pin, Long authSessionId, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.authenticatePin(customerId, pin, authSessionId, authSessionType, clientType, clientVersion, ipAddress, fingerPrintType, fingerPrint);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:authenticatePin: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptWheel genWheel(int length, int sets, Long previousAuthSessionId, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.genWheel(length, sets, previousAuthSessionId, authSessionType, clientType, clientVersion, ipAddress, fingerPrintType, fingerPrint);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:genWheel: CustomerId:" + null + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthResult authenticateSlider(String customerId, Vector displacements, Map authStats, Long authSessionId, String ipAddress, int fingerPrintType, String fingerPrint) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.authenticateSlider(customerId, displacements, authStats, authSessionId, ipAddress, fingerPrintType, fingerPrint);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:authenticateSlider: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthResult authenticateSlider(String customerId, String pin, Vector displacements, Map authStats, Long authSessionId, String ipAddress, int fingerPrintType, String fingerPrint) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.authenticateSlider(customerId, pin, displacements, authStats, authSessionId, ipAddress, fingerPrintType, fingerPrint);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:authenticateSlider(2): CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));

		}
	}

	public boolean setPIN(String customerId, String PIN, int pinStatus) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.setPIN(customerId, PIN, pinStatus);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:setPIN: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public boolean setPassword(String customerId, String password, int passwordStatus) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.setPassword(customerId, password, passwordStatus);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:setPassword: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public boolean setImage(String customerId, String imagePath) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.setImage(customerId, imagePath);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:setImage: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public boolean setCaption(String customerId, String caption) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.setCaption(customerId, caption);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:setCaption: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}
	
	public boolean setCaption(String customerId, VCryptLocalizedString caption) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.setCaption(customerId, caption);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:setCaption: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public boolean setImageAndCaption(String customerId, String imagePath, String caption) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.setImageAndCaption(customerId, imagePath, caption);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:setImageAndCaption: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public boolean setImageAndCaption(String customerId, String imagePath, VCryptLocalizedString caption) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.setImageAndCaption(customerId, imagePath, caption);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:setImageAndCaption: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public boolean setUserAuthMode(String customerId, int authMode) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.setUserAuthMode(customerId, authMode);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:setUserAuthMode: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public boolean setGroupUsersAuthMode(String groupName, int authMode) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.setGroupUsersAuthMode(groupName, authMode);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:setGroupUsersAuthMode: CustomerId:" + null + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public boolean setUserStatus(String customerId, int status) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.setUserStatus(customerId, status);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:setUserStatus: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public String getImage(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getImage(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getImage: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public String getCaption(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getCaption(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getCaption: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}
	public VCryptLocalizedString getLocalizedCaption(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getLocalizedCaption(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getLocalizedCaption: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public String[] getImageAndCaption(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getImageAndCaption(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getImageAndCaption: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}
	public Object[] getImageAndLocalizedCaption(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getImageAndLocalizedCaption(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getImageAndLocalizedCaption: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public int getUserAuthMode(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getUserAuthMode(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getUserAuthMode: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public int getUserStatus(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getUserStatus(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getUserStatus: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptQuestion[][] getSignOnQuestions(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getSignOnQuestions(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getSignOnQuestions: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptQuestion[][] getSignOnQuestions(String customerId, VCryptLocale locale) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getSignOnQuestions(customerId, locale);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getSignOnQuestions: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptQuestion[] getAllMappedSignOnQuestions(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getAllMappedSignOnQuestions(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getAllMappedSignOnQuestions: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public boolean deleteAllSignOnQuestions(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.deleteAllSignOnQuestions(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:deleteAllSignOnQuestions: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptResponse addQuestions(String customerId, VCryptQuestion[] questions) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.addQuestions(customerId, questions);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:addQuestions: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptResponse addQuestion(String requestId, String customerId, VCryptQuestion question) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.addQuestion(requestId, customerId, question);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:addQuestion: CustomerId:" + customerId + ", requestId:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptResponse addQuestions(String requestId, String customerId, VCryptQuestion[] questions) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.addQuestions(requestId, customerId, questions);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:addQuestions: CustomerId:" + customerId + ":" + ", requestId:" + requestId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptResponse addQuestion(String customerId, VCryptQuestion question) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.addQuestion(customerId, question);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:addQuestion: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public boolean deleteQuestion(String customerId, VCryptQuestion question) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.deleteQuestion(customerId, question);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:deleteQuestion: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptQuestion getSecretQuestionForCSR(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getSecretQuestion(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getSecretQuestionForCSR: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptQuestion getSecretQuestion(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.getSecretQuestion(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:getSecretQuestion: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptQuestion moveToNextSecretQuestion(String customerId) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.moveToNextSecretQuestion(customerId);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:moveToNextSecretQuestion: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthResult authenticateQuestionForCSR(String customerId, String answer) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.authenticateQuestion(customerId, answer);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:authenticateQuestionForCSR: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthResult authenticateQuestion(String customerId, String answer) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.authenticateQuestion(customerId, answer);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:authenticateQuestion: CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthResult authenticateQuestion(String requestId, Integer challengeChannel, String customerId, String answer) {

		Date beginTime = new Date();
		try {
			return vCryptAuth.authenticateQuestion(requestId, challengeChannel, customerId, answer);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:authenticateQuestion:" + requestId + ", challengeChannel:" + challengeChannel + ", CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}

	public VCryptAuthResult authenticateQuestionForCSR(String requestId, Integer challengeChannel, String customerId, String answer) {
		Date beginTime = new Date();
		try {
			return vCryptAuth.authenticateQuestionForCSR(requestId, challengeChannel, customerId, answer);
		} finally {
			if (logger.isDebugEnabled()) logger.debug("FILTER:authenticateQuestionForCSR:" + requestId + ", challengeChannel:" + challengeChannel + ", CustomerId:" + customerId + ":" + (new Date().getTime() - beginTime.getTime()));
		}
	}
}
