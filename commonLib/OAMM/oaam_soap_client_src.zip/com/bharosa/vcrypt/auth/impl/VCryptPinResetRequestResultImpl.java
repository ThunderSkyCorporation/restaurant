package com.bharosa.vcrypt.auth.impl;

import java.util.List;
import java.util.ArrayList;

import com.bharosa.common.logger.Logger;

import com.bharosa.vcrypt.auth.intf.VCryptPinResetRequestResult;

/**
 * Provides information about authentication results
 * @author Luke
 */

public class VCryptPinResetRequestResultImpl 
	implements VCryptPinResetRequestResult, java.io.Serializable{
	static Logger logger = Logger.getLogger(VCryptPinResetRequestResultImpl.class);

	int statusCode = -1;
	String magicKey = null;

	public VCryptPinResetRequestResultImpl(){
		if(logger.isDebugEnabled()) logger.debug("Using default constructor");
	}

	public VCryptPinResetRequestResultImpl(int status){
		if(logger.isDebugEnabled()) logger.debug("Setting status to: "+status);
		statusCode = status;
		magicKey = null;
	}

	public VCryptPinResetRequestResultImpl(int status, String mkey){
		if(logger.isDebugEnabled()) logger.debug("Setting status to: "+status);
		if(logger.isDebugEnabled()) logger.debug("Setting magicKey to: "+mkey);
		statusCode = status;
		magicKey = mkey;
	}

	/**
	 * Returns the status code
	 * @return status code from VCryptPinResetRequestResult<br>
	 */
	public int getStatus(){ return statusCode; }

	public String getMagicKey(){ return magicKey; }
}
