package com.bharosa.vcrypt.auth.impl;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.security.SecureRandom;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import com.bharosa.common.logger.Logger;

import com.bharosa.common.exception.BharosaErrorIds;
import com.bharosa.common.exception.BharosaRuntimeException;
import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.common.util.UserDefEnum;
import com.bharosa.vcrypt.auth.intf.VCryptAuth;
import com.bharosa.vcrypt.auth.intf.VCryptAuthResult;
import com.bharosa.vcrypt.auth.intf.VCryptAuthUser;
import com.bharosa.vcrypt.auth.intf.VCryptLocale;
import com.bharosa.vcrypt.auth.intf.VCryptLocalizedString;
import com.bharosa.vcrypt.auth.intf.VCryptQuestion;
import com.bharosa.vcrypt.auth.intf.VCryptWheel;
import com.bharosa.vcrypt.auth.util.VCryptPassword;
import com.bharosa.vcrypt.common.util.VCryptResponse;

/**
 * Light version without database support.
 * 
 * @author Bosco
 */

public class VCryptAuthLite implements VCryptAuth {
	static Logger logger = Logger.getLogger(VCryptAuthLite.class);
	static final Object lock = new Object();
	static boolean initDone = false;
	// private String outer =
	// "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890-_";
	private String outer = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";

	static Hashtable sessionList = null;
	static UserDefEnum authStatusEnum = null;
	static VCryptPassword vcryptPassword = null;

	private static SecureRandom sRand = new SecureRandom();

	/**
	 * Default constructer.
	 */
	public VCryptAuthLite() {
		if (logger.isDebugEnabled()) logger.debug("VCryptAuthLite()");
		try {
			if (!initDone) {
				synchronized (lock) {
					if (!initDone) {
						logger.info("Construction VCryptAuthLite()...");
						sessionList = new Hashtable();
						vcryptPassword = new VCryptPassword();
						authStatusEnum = UserDefEnum.getEnum("auth.status.enum");
						if (authStatusEnum == null) {
							logger.fatal("User defined enum auth.status.enum not found in any property file");
						}
					}
					initDone = true;
				}
			}
		} catch (Exception e) {
			logger.error("Exception while constructing VCryptAuthLite", e);
		}
	}

	/**
	 * Return the user details without the password and pin for the given
	 * customer and group
	 * 
	 * @param customerId
	 *           of the user.
	 * @return a <code>VCryptAuthUser</code> value. If the user is not valid,
	 *         then all the values in the object is is null. Any unexpected
	 *         error, Null is returned.
	 */
	public VCryptAuthUser getUser(String customerId) {
		try {
			if (logger.isDebugEnabled()) logger.debug("getUser() customerId=" + customerId);
			logger.error("getUser() Not supported");
			return null;
		} catch (Exception e) {
			logger.error("Unable to getUser() for customerId=" + customerId, e);
			return null;
		}
	}

	/**
	 * Return the user details without the password and pin for the given
	 * customer and group
	 * 
	 * @param loginId
	 *           of the user.
	 * @param groupName
	 *           groupName
	 * @return a <code>VCryptAuthUser</code> value. If the user is not valid,
	 *         then all the values in the object is is null. Any unexpected
	 *         error, Null is returned.
	 */
	public VCryptAuthUser getUserByLoginId(String loginId, String groupName) {
		try {
			if (logger.isDebugEnabled()) logger.debug("getUser() loginId=" + loginId + ", groupName=" + groupName);
			logger.error("getUser() Not supported");
			return null;
		} catch (Exception e) {
			logger.error("Unable to getUser() for login id: " + loginId, e);
			return null;
		}
	}

	public VCryptAuthUser getUserByLoginId(String loginId) {
		try {
			if (logger.isDebugEnabled()) logger.debug("getUserByLoginId() loginId=" + loginId);
			logger.error("getUserByLoginId() Not supported");
			return null;
		} catch (Exception e) {
			logger.error("Unable to getUserByLoginId() for login id: " + loginId, e);
			return null;
		}
	}

	public VCryptAuthUser createUser(VCryptAuthUser authUser) {
		try {
			if (authUser != null) {
				if (logger.isDebugEnabled()) logger.debug("createUser() customerId=" + authUser.getCustomerId());
			}
			logger.error("createUser() Not supported");
			return null;
		} catch (Exception e) {
			logger.error("Unable to setUser() for login id: " + authUser, e);
			return null;
		}
	}

	public VCryptAuthUser setUser(VCryptAuthUser user) {
		try {
			if (user != null) {
				if (logger.isDebugEnabled()) logger.debug("setUser() customerId=" + user.getCustomerId());
			}
			logger.error("setUser() Not supported");
			return null;
		} catch (Exception e) {
			logger.error("Unable to setUser() for login id: " + user, e);
			return null;
		}
	}

	/**
	 * This method generates a new wheel with creating the VCryptAuthSession
	 * object.
	 * 
	 * @param length
	 *           of the wheel
	 * @param sets
	 *           number of sets
	 * @param previousAuthSessionId
	 *           previous authentication session id (if available)
	 * @param authSessionType
	 *           What type of authentication session this is. It could be login,
	 *           in-session, pin reset, etc.
	 * @param clientType
	 *           what type of client is used for authentication
	 * @param clientVersion
	 *           what is the version of the client
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return a <code>VCryptWheel</code> value
	 */
	public VCryptWheel genWheel(int length, int sets, Long previousAuthSessionId, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint) {
		try {
			if (logger.isDebugEnabled()) logger.debug("genWheel() length=" + length + ", sets=" + sets + ", previousAuthSessionId=" + previousAuthSessionId + ", authSessionType=" + authSessionType + ", clientType=" + clientType + ", clientVersion=" + clientVersion + ", ipAddress=" + ipAddress);

			VCryptWheel wheel = genWheel(length, sets);

			Long sessionId = generateSessionId();
			wheel.setAuthSessionId(sessionId);
			synchronized (lock) {
				// First, lets remove all expired sessions
				Iterator iter = sessionList.keySet().iterator();
				while (iter.hasNext()) {
					Object key = iter.next();
					AuthSessionLite authSession = (AuthSessionLite) sessionList.get(key);
					if (authSession.createDate != null) {
						int sessionLife = BharosaConfig.getInt("bharosa.slider.session.timeout.min", 60);
						Calendar fromCal = Calendar.getInstance();
						fromCal.add(Calendar.MINUTE, -1 * sessionLife);
						if (fromCal.getTime().getTime() > authSession.createDate.getTime()) {
							if (logger.isDebugEnabled()) logger.debug("Removed expired authSessionId=" + key);
							iter.remove();
						}

					}
				}

				AuthSessionLite authSession = new AuthSessionLite();
				authSession.wheel = wheel;
				authSession.createDate = new Date();
				authSession.isAuthenticated = false;

				sessionList.put(sessionId, authSession);
			}

			return wheel;
		} catch (Exception ex) {
			logger.error("Exception genWheel()", ex);
		}
		return null;
	}

	/**
	 * This method generates a new wheel.
	 * 
	 * @param length
	 *           of the wheel
	 * @param sets
	 *           number of sets
	 * @return a <code>VCryptWheel</code> value
	 */
	VCryptWheel genWheel(int length, int sets) {
		if (logger.isDebugEnabled()) logger.debug("Generating new set of " + sets + " wheels of length " + length);
		// Random rand = new Random();
		String wheelstr = "";

		int[] outerWheel = new int[length];
		for (int i = 0; i < length; i++) {
			outerWheel[i] = i;
		}

		for (int wheelCount = 0; wheelCount < sets; wheelCount++) {
			wheelstr += "&wheel" + wheelCount + "=";
			int arr[] = new int[length];

			Integer newWheel[] = new Integer[length];

			for (int i = 0; i < length; i++) {
				arr[i] = 0;
			}
			for (int i = 0; i < length; i++) {
				int value = getRandomInt(length);
				if (arr[value] != 0) {
					--i;
					continue;
				}
				arr[value] = 1;
				newWheel[i] = new Integer(outerWheel[value]);
			}
			wheelstr += formatIntegerArray(newWheel);
		}

		VCryptWheel wheel = new VCryptWheel();
		wheel.setWheel(wheelstr);
		return wheel;
	}

	/**
	 * Formats the Integer array to be passed on to the client.
	 */
	String formatIntegerArray(Integer[] arr) {
		String str = "";
		for (int i = 0; i < arr.length; i++) {
			if (i != 0) {
				str += "X";
			}
			str += arr[i].toString();
		}
		return str;
	}

	/**
	 * Regenerates the Vector containing wheels
	 */
	Vector parseWheelStr(String wheelStr) {
		try {
			if (StringUtil.isEmpty(wheelStr)) { return null; }
			Vector wheelList = new Vector();

			StringTokenizer st = new StringTokenizer(wheelStr, "&=");
			boolean odd = true;
			while (st.hasMoreTokens()) {
				String lineStr = st.nextToken();
				if (odd) {
					// ignore the name part
					odd = false;
				} else {
					odd = true;
					StringTokenizer valueStrT = new StringTokenizer(lineStr, "X");
					int len = valueStrT.countTokens();
					Integer newWheel[] = new Integer[len];
					for (int i = 0; valueStrT.hasMoreTokens(); i++) {
						newWheel[i] = new Integer(valueStrT.nextToken());
					}
					wheelList.add(newWheel);
				}
			}
			return wheelList;
		} catch (Exception ex) {
			logger.error("Caught exception. parseWheelStr(): wheelStr=" + wheelStr, ex);
			return null;
		}
	}

	/**
	 * Method to athenticate password
	 * 
	 * @param customerId
	 *           The customerId used by the user.
	 * @param password
	 *           The raw password entered by the user.
	 * @param authSessionType
	 *           Reason for authentication
	 * @param clientType
	 *           Client type used.
	 * @param clientVersion
	 *           Client version
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return a <code>VCryptAuthResult</code> value
	 */
	public VCryptAuthResult authenticatePassword(String customerId, String password, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint) {
		try {
			if (logger.isDebugEnabled()) logger.debug("Authenticating password for customerId=" + customerId + ", authSessionType=" + authSessionType + ", clientType=" + clientType + ", clientVersion=" + clientVersion + ", ipAddress=" + ipAddress);
			logger.error("authenticatePassword() Not supported");
			return new VCryptAuthResult(authStatusEnum.getElementValue("system_error"));
		} catch (Exception ex) {
			logger.error("authenticatePassword(customerId=" + customerId, ex);
			return new VCryptAuthResult(authStatusEnum.getElementValue("system_error"));
		}
	}

	/**
	 * Method to athenticate pin
	 * 
	 * @param customerId
	 *           The customerId used by the user.
	 * @param pin
	 *           The raw pin entered by the user.
	 * @param authSessionType
	 *           Reason for authentication
	 * @param clientType
	 *           Client type used.
	 * @param clientVersion
	 *           Client version
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return The VCryptAuthResult object
	 */
	public VCryptAuthResult authenticatePin(String customerId, String pin, Long authSessionId, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint) {
		try {
			if (logger.isDebugEnabled()) logger.debug("Authenticating pin for customerId=" + customerId + ", authSessionType=" + authSessionType + ", clientType=" + clientType + ", clientVersion=" + clientVersion + ", ipAddress=" + ipAddress);
			logger.error("authenticatePin() Not supported");
			return new VCryptAuthResult(authStatusEnum.getElementValue("system_error"));
		} catch (Exception ex) {
			logger.error("authenticatePin(customerId=" + customerId, ex);
			return new VCryptAuthResult(authStatusEnum.getElementValue("system_error"));
		}

	}

	/**
	 * Master method to athenticate password
	 * 
	 * @param customerId
	 *           The customerId used by the user.
	 * @param password
	 *           The raw password entered by the user.
	 * @param authSessionType
	 *           Reason for authentication
	 * @param clientType
	 *           Client type used.
	 * @param clientVersion
	 *           Client version
	 * @param authSessionId
	 *           the authentication session id
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return a <code>VCryptAuthResult</code> value
	 */
	public VCryptAuthResult authenticatePassword(String customerId, String password, int authSessionType, int clientType, String clientVersion, Long authSessionId, String ipAddress, int fingerPrintType, String fingerPrint) {
		try {
			if (logger.isDebugEnabled()) logger.debug("Authenticating password for customerId=" + customerId + ", clientType=" + clientType + ", clientVersion=" + clientVersion + ", ipAddress=" + ipAddress);
			logger.error("authenticatePassword() Not supported");
			return new VCryptAuthResult(authStatusEnum.getElementValue("system_error"));
		} catch (Exception ex) {
			logger.error("authenticatePassword(customerId=" + customerId, ex);
			return new VCryptAuthResult(authStatusEnum.getElementValue("system_error"));
		}
	}

	/**
	 * This method does the PIN authentication using the pin value and the
	 * displacements.
	 * 
	 * @param PIN
	 *           The raw PIN value
	 * @param displacements
	 *           The displacements
	 * @return a <code>VCryptAuthResult</code> value
	 */
	VCryptAuthResult authenticateSlider(String PIN, Vector wheelList, Vector displacements, VCryptAuthResult authResult) {
		if (logger.isDebugEnabled()) logger.debug("authenticateSlider() displacements=" + displacements);
		if (authResult == null) {
			authResult = new VCryptAuthResult();
		}

		try {
			int rcode = authStatusEnum.getElementValue("success");

			if (displacements == null) {
				logger.info("No displacements values for authenticateSlider");
				rcode = authStatusEnum.getElementValue("wrong_pin");
			} else if (PIN == null) {
				logger.warn("authenticateSlider(): Pin is null");
				rcode = authStatusEnum.getElementValue("wrong_pin");
			} else {
				if (displacements.size() != PIN.length()) {
					logger.info("Pin length and displacemnts don't match. PIN.size()=" + PIN.length() + ", displacements=" + displacements.size());
					rcode = authStatusEnum.getElementValue("wrong_pin");
				}
			}

			if (rcode == authStatusEnum.getElementValue("success")) {
				Integer marker = null;
				for (int x = 0, i = 0; rcode == 0 && i < PIN.length(); i++, x++) {
					Integer[] of = (Integer[]) wheelList.elementAt(x);
					int offset = ((Integer) displacements.elementAt(x)).intValue();

					String currchar = "" + PIN.charAt(i);
					int index = outer.indexOf(currchar);
					int bignum = 100000 * outer.length();
					int m;

					if (offset < 0) {
						m = (offset * -1) % outer.length();
						m = (bignum + index - offset) % outer.length();
					} else if (offset > 0) {
						m = offset % outer.length();
						m = (bignum + index - offset) % outer.length();
					} else {
						m = index;
					}

					// out.println("Testing: "+currchar+" fell under
					// "+of[m/3]+"<br>");
					if (marker == null) {
						marker = of[m / 3];
					} else {
						int a = of[m / 3].intValue();
						int b = marker.intValue();

						if (a != b) {
							logger.info("PIN mismatch at position " + x);
							rcode = authStatusEnum.getElementValue("wrong_pin");
							break;
						}
					}
				}
			}
			authResult.setCode(rcode);
			return authResult;
		} catch (Exception ex) {
			logger.error("authenticateSlider() displacements=" + displacements, ex);
			authResult.setCode(authStatusEnum.getElementValue("system_error"));
			return authResult;
		}
	}// end authenticate()

	/**
	 * This is the master authentication method for PIN.
	 */
	VCryptAuthResult masterAuthenticateSlider(String customerId, String PIN, Vector displacements, Map authStats, Long authSessionId, String ipAddress, int fingerPrintType, String fingerPrint) {
		try {
			if (logger.isDebugEnabled()) logger.debug("masterAuthenticateSlider for customerId=" + customerId + ", authSessionId=" + authSessionId + ", ipAddress=" + ipAddress);

			VCryptAuthResult authResult = new VCryptAuthResult();
			authResult.setCode(authStatusEnum.getElementValue("success"));
			authResult.setCustomerId(customerId);

			AuthSessionLite authSession = null;
			synchronized (lock) {
				authSession = (AuthSessionLite) sessionList.get(authSessionId);
				if (authSession != null) {
					sessionList.remove(authSessionId);
				}
			}

			if (authSession == null) {
				authResult.setCode(authStatusEnum.getElementValue("session_expired"));
			} else {
				String wheelStr = authSession.wheel.getWheel();
				Vector wheelList = parseWheelStr(wheelStr);
				if (wheelList == null || wheelList.size() == 0) { throw new Exception("authSession doesn't have wheel data. authSessionId=" + authSessionId); }
				String usePin = PIN;
				if (StringUtil.isEmpty(usePin)) {
					authResult.setCode(authStatusEnum.getElementValue("wrong_pin"));
				}
				if (!StringUtil.isEmpty(usePin)) {
					// Luke note: This needs to default to false as we don't want
					// this to be configured in a client property file.
					boolean isEncrypted = BharosaConfig.getBoolean("bharosa.pin.is.encrypted", false);
					if (isEncrypted) {
						if (logger.isDebugEnabled()) logger.debug("PIN is encrypted.");
						usePin = vcryptPassword.decrypt(usePin);
					}
					boolean isUpperCase = BharosaConfig.getBoolean("bharosa.pin.is.uppercase", true);
					if (isUpperCase) {
						usePin = usePin.toUpperCase();
					}
					authResult = authenticateSlider(usePin, wheelList, displacements, authResult);
				} else {
					logger.info("pin is null for customerId=" + customerId + ", so authentication failed");
				}
			}

			if (logger.isDebugEnabled()) logger.debug("masterAuthenticateSlider() customerId=" + customerId + ", rcode=" + authResult.getCode());
			return authResult;

		} catch (Exception ex) {
			logger.error("masterAuthenticateSlider(customerId=" + customerId, ex);
			return new VCryptAuthResult(authStatusEnum.getElementValue("system_error"));
		}
	}

	/**
	 * This method authenticates the PIN entered by the user using the slider.
	 * 
	 * @param customerId
	 *           CustomerId used by the user
	 * @param displacements
	 *           Displacement of the marker
	 * @param authStats
	 *           Hash map of user input metrics, like time taken, etc.
	 * @param authSessionId
	 *           The Id of the auth session
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return a <code>VCryptAuthResult</code> value
	 */
	public VCryptAuthResult authenticateSlider(String customerId, Vector displacements, Map authStats, Long authSessionId, String ipAddress, int fingerPrintType, String fingerPrint) {
		try {
			if (logger.isDebugEnabled()) logger.debug("authenticateSlider for customerId=" + customerId + ", displacements=" + displacements + ", authSessionId=" + authSessionId + ", ipAddress=" + ipAddress);
			logger.error("authenticateSlider() Not supported without PIN");
			return new VCryptAuthResult(authStatusEnum.getElementValue("system_error"));
		} catch (Exception ex) {
			logger.error("Error while authenticating user authenticateSliderbyUser for customerId=" + customerId + ", displacements=" + displacements, ex);
			return new VCryptAuthResult(authStatusEnum.getElementValue("db_error"));
		}
	}

	/**
	 * This method authenticates the PIN entered by the user using the slider.
	 * This passess the PIN to be used for authentication. This method is usually
	 * used for PIN reset utility program.
	 * 
	 * @param customerId
	 *           CustomerId used by the user
	 * @param pin
	 *           a <code>String</code> value
	 * @param displacements
	 *           Displacement of the marker
	 * @param authStats
	 *           Hash map of user input metrics, like time taken, etc.
	 * @param authSessionId
	 *           The session Id for this authentication
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return a <code>VCryptAuthResult</code> value
	 */
	public VCryptAuthResult authenticateSlider(String customerId, String pin, Vector displacements, Map authStats, Long authSessionId, String ipAddress, int fingerPrintType, String fingerPrint) {
		try {
			if (logger.isDebugEnabled()) logger.debug("authenticateSlider using pin for customerId=" + customerId + ", displacements=" + displacements + ", authSessionId=" + authSessionId + ", ipAddress=" + ipAddress);
			return masterAuthenticateSlider(customerId, pin, displacements, authStats, authSessionId, ipAddress, fingerPrintType, fingerPrint);
		} catch (Exception ex) {
			logger.error("Error while authenticating user authenticateSliderbyUser for customerId=" + customerId + ", displacements=" + displacements, ex);
			return new VCryptAuthResult(authStatusEnum.getElementValue("db_error"));
		}
	}

	/**
	 * Gets a secret question for the user
	 * 
	 * @param customerId
	 *           The login id of the user to authenticate
	 * @param previousAuthSessionId
	 *           The previous authentication session id. This would be
	 *           authentication session id used by the password authentication.
	 *           Pass null, if there was not previous authentication.
	 * @param authSessionType
	 *           What type of authentication session this is. It could be login,
	 *           in-session, pin reset, etc.
	 * @param clientType
	 *           what type of client is used for authentication
	 * @param clientVersion
	 *           what is the version of the client
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return The object containing the question to ask and also the
	 *         authentication session id.
	 */
	public VCryptQuestion getSecretQuestion(String customerId, Long previousAuthSessionId, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint) {
		if (logger.isDebugEnabled()) logger.debug("getSecretQuestion() customerId=" + customerId + ", previousAuthSessionId=" + previousAuthSessionId + ", authSessionType=" + authSessionType + ", clientType=" + clientType + ", clientVersion=" + clientVersion + ", ipAddress=" + ipAddress);
		try {
			logger.error("getSecretQuestion() Not supported");
			return null;
		} catch (Exception ex) {
			logger.error("getSecretQuestion() Caught exception. customerId=" + customerId, ex);
			return null;
		}
	}

	/**
	 * Method for authenticate question/answer
	 * 
	 * @param customerId
	 *           The login id of the user to authenticate
	 * @param authSessionId
	 *           Id of the auth session
	 * @param answer
	 *           the answer given by the user
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return VCryptAuthResult describing result of authentication attempt
	 */
	public VCryptAuthResult authenticateQuestion(String customerId, Long authSessionId, String answer, String ipAddress, int fingerPrintType, String fingerPrint) {
		try {
			if (logger.isDebugEnabled()) logger.debug("masterAuthenticateQuestionByUser()customerId=" + customerId + ", authSessionId=" + authSessionId + ", ipAddress=" + ipAddress);
			logger.error("authenticateQuestion() Not supported");
			return new VCryptAuthResult(authStatusEnum.getElementValue("system_error"));
		} catch (Exception ex) {
			logger.error("Got exception in authenticateQuestion()customerId=" + customerId + ", authSessionId=" + authSessionId + ", ipAddress=" + ipAddress, ex);
			return new VCryptAuthResult(authStatusEnum.getElementValue("db_error"));
		}
	}

	public boolean setPIN(String customerId, String PIN, int pinStatus) {
		try {
			if (logger.isDebugEnabled()) logger.debug("setPIN customerId=" + customerId);
			logger.error("setPIN() Not supported");
			return false;
		} catch (Exception e) {
			logger.error("Unable to save pin for login id: " + customerId, e);
			return false;
		}
	}

	public boolean setPassword(String customerId, String password, int passwordStatus) {
		try {
			if (logger.isDebugEnabled()) logger.debug("setPassword customerId=" + customerId);
			logger.error("setPassword() Not supported");
			return false;
		} catch (Exception e) {
			logger.error("Unable to save password for login id: " + customerId, e);
			return false;
		}
	}

	/**
	 * Sets a new image for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param imagePath
	 *           Path to the image file
	 * @return whether the operation was success or failure
	 */
	public boolean setImage(String customerId, String imagePath) {
		try {
			if (logger.isDebugEnabled()) logger.debug("setImage customerId=" + customerId);
			logger.error("setImage() Not supported");
			return false;
		} catch (Exception e) {
			logger.error("Unable to save image for login id: " + customerId, e);
			return false;
		}

	}

	/**
	 * Sets a new caption for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param caption
	 *           New caption to set
	 * @return whether the operation was success or failure
	 */
	public boolean setCaption(String customerId, String caption) {
		try {
			if (logger.isDebugEnabled()) logger.debug("setCaption customerId=" + customerId);
			logger.error("setCaption() Not supported");
			return false;
		} catch (Exception e) {
			logger.error("Unable to save caption for login id: " + customerId, e);
			return false;
		}
	}
	
	public boolean setCaption(String customerId, VCryptLocalizedString caption) {
		try {
			if (logger.isDebugEnabled()) logger.debug("setCaption customerId=" + customerId);
			logger.error("setCaption() Not supported");
			return false;
		} catch (Exception e) {
			logger.error("Unable to save caption for login id: " + customerId, e);
			return false;
		}
	}

	/**
	 * Sets a new caption for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param imagePath
	 *           Path to the image file
	 * @param caption
	 *           New caption to set
	 * @return whether the operation was success or failure
	 */
	public boolean setImageAndCaption(String customerId, String imagePath, String caption) {
		try {
			if (logger.isDebugEnabled()) logger.debug("setImageAndCaption customerId=" + customerId);
			logger.error("setImageAndCaption() Not supported");
			return false;
		} catch (Exception e) {
			logger.error("Unable to save caption for login id: " + customerId, e);
			return false;
		}
	}
	public boolean setImageAndCaption(String customerId, String imagePath, VCryptLocalizedString caption) {
		try {
			if (logger.isDebugEnabled()) logger.debug("setImageAndCaption customerId=" + customerId);
			logger.error("setImageAndCaption() Not supported");
			return false;
		} catch (Exception e) {
			logger.error("Unable to save caption for login id: " + customerId, e);
			return false;
		}
	}

	/**
	 * Sets a new authMode for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param authMode
	 *           new authMode to be set for the user
	 * @return whether the operation was success or failure
	 */
	public boolean setUserAuthMode(String customerId, int authMode) {
		try {
			if (logger.isDebugEnabled()) logger.debug("setUserAuthMode customerId=" + customerId);
			logger.error("setUserAuthMode() Not supported");
			return false;
		} catch (Exception e) {
			logger.error("Unable to set authMode for login id: " + customerId, e);
			return false;
		}
	}

	/**
	 * @param groupName
	 *           groupId of the users
	 * @param authMode
	 *           new Auth mode
	 * @return true if update is successful
	 */
	public boolean setGroupUsersAuthMode(String groupName, int authMode) {
		throw new BharosaRuntimeException(BharosaErrorIds.NOT_SUPPORTED);
		// throw new RuntimeException("Not supported.");
	}

	/**
	 * Sets a new status for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param status
	 *           new status to be set for the user
	 * @return whether the operation was success or failure
	 */
	public boolean setUserStatus(String customerId, int status) {
		try {
			if (logger.isDebugEnabled()) logger.debug("setUserStatus customerId=" + customerId);
			logger.error("setUserStatus() Not supported");
			return false;
		} catch (Exception e) {
			logger.error("Unable to set status for login id: " + customerId, e);
			return false;
		}
	}

	/**
	 * Gets the imagePath for the user
	 * 
	 * @param customerId
	 *           user login Id
	 * @return Path to the image
	 */
	public String getImage(String customerId) {
		try {
			if (logger.isDebugEnabled()) logger.debug("getImage customerId=" + customerId);
			logger.error("getImage() Not supported");
			return null;
		} catch (Exception e) {
			logger.error("Unable to get imagePath for login id: " + customerId, e);
			return null;
		}
	}

	/**
	 * Gets the caption for the user
	 * 
	 * @param customerId
	 *           user login Id
	 * @return Caption string
	 */
	public String getCaption(String customerId) {
		try {
			if (logger.isDebugEnabled()) logger.debug("getCaption customerId=" + customerId);
			logger.error("getCaption() Not supported");
			return null;
		} catch (Exception e) {
			logger.error("Unable to get caption for login id: " + customerId, e);
			return null;
		}
	}
	public VCryptLocalizedString getLocalizedCaption(String customerId) {
		try {
			if (logger.isDebugEnabled()) logger.debug("getLocalizedCaption customerId=" + customerId);
			logger.error("getLocalizedCaption() Not supported");
			return null;
		} catch (Exception e) {
			logger.error("Unable to get caption for login id: " + customerId, e);
			return null;
		}
	}

	/**
	 * Gets the image path and caption for the user
	 * 
	 * @param customerId
	 *           user login Id
	 * @return String[0]= Image path, String[1] is Caption
	 */
	public String[] getImageAndCaption(String customerId) {
		try {
			if (logger.isDebugEnabled()) logger.debug("getImageAndCaption customerId=" + customerId);
			logger.error("getImageAndCaption() Not supported");
			return null;
		} catch (Exception e) {
			logger.error("Unable to get caption for login id: " + customerId, e);
			return null;
		}
	}
	public Object[] getImageAndLocalizedCaption(String customerId) {
		try {
			if (logger.isDebugEnabled()) logger.debug("getImageAndLocalizedCaption customerId=" + customerId);
			logger.error("getImageAndLocalizedCaption() Not supported");
			return null;
		} catch (Exception e) {
			logger.error("Unable to get caption for login id: " + customerId, e);
			return null;
		}
	}

	/**
	 * Gets the authMode for the user
	 * 
	 * @param customerId
	 *           user login Id
	 * @return authMode int
	 */
	public int getUserAuthMode(String customerId) {
		try {
			if (logger.isDebugEnabled()) logger.debug("getUserAuthMode customerId=" + customerId);
			logger.error("getUserAuthMode() Not supported");
			return 0;
		} catch (Exception e) {
			logger.error("Unable to get authMode for login id: " + customerId, e);
			return 0;
		}
	}

	/**
	 * Gets the status for the user
	 * 
	 * @param customerId
	 *           user login Id
	 * @return status int
	 */
	public int getUserStatus(String customerId) {
		try {
			if (logger.isDebugEnabled()) logger.debug("getUserStatus customerId=" + customerId);
			logger.error("getUserStatus() Not supported");
			return 0;
		} catch (Exception e) {
			logger.error("Unable to get status for login id: " + customerId, e);
			return 0;
		}
	}

	public VCryptQuestion[][] getSignOnQuestions(String customerId) {
		if (logger.isDebugEnabled()) logger.debug("getSignonQuestions customerId=" + customerId);
		logger.error("getSignonQuestions() Not supported");
		return null;
	}

	public VCryptQuestion[][] getSignOnQuestions(String customerId, VCryptLocale locale) {
		if (logger.isDebugEnabled()) logger.debug("getSignonQuestions customerId=" + customerId + ",locale=" + locale);
		logger.error("getSignonQuestions() Not supported");
		return null;
	}

	public VCryptQuestion[] getAllMappedSignOnQuestions(String customerId) {
		if (logger.isDebugEnabled()) logger.debug("getAllMappedSignOnQuestions customerId=" + customerId);
		logger.error("getAllMappedSignOnQuestions() Not supported");
		return null;
	}

	public boolean deleteAllSignOnQuestions(String customerId) {
		if (logger.isDebugEnabled()) logger.debug("deleteAllSignOnQuestions customerId=" + customerId);
		logger.error("deleteAllSignOnQuestions() Not supported");
		return false;
	}

	/**
	 * Adds a new question for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param question
	 *           New question to be added. Overrides if the same question is
	 *           already set for this user.
	 * @return whether the operation was success or failure
	 */
	public VCryptResponse addQuestion(String customerId, VCryptQuestion question) {
		throw new BharosaRuntimeException(BharosaErrorIds.NOT_SUPPORTED);
		// throw new RuntimeException("Not supported");
	}

	public VCryptResponse addQuestion(String requestId, String customerId, VCryptQuestion question) {
		throw new BharosaRuntimeException(BharosaErrorIds.NOT_SUPPORTED);
		// throw new RuntimeException("Not supported");
	}

	public VCryptResponse addQuestions(String requestId, String customerId, VCryptQuestion[] questions) {
		throw new BharosaRuntimeException(BharosaErrorIds.NOT_SUPPORTED);
		// throw new RuntimeException("Not supported");
	}

	public VCryptResponse addQuestions(String customerId, VCryptQuestion[] questions) {
		if (logger.isDebugEnabled()) logger.debug("addQuestion customerId=" + customerId);
		logger.error("addQuestions() Not supported");
		VCryptResponse vResult = new VCryptResponse();
		vResult.setSuccess(false);
		return vResult;
	}

	/**
	 * Deletes the question for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param question
	 *           The question to be deleted
	 * @return whether the operation was success or failure
	 */
	public boolean deleteQuestion(String customerId, VCryptQuestion question) {
		if (logger.isDebugEnabled()) logger.debug("deleteQuestion customerId=" + customerId);
		logger.error("deleteQuestion() Not supported");
		return false;
	}

	public VCryptQuestion getSecretQuestionForCSR(String customerId) {
		return this.getSecretQuestion(customerId);
	}

	/**
	 * Gets a secret question for the user
	 * 
	 * @param customerId
	 *           The login id of the user to authenticate
	 * @return The object containing the question to ask
	 */
	public VCryptQuestion getSecretQuestion(String customerId) {
		if (logger.isDebugEnabled()) logger.debug("getSecretQuestion customerId=" + customerId);
		logger.error("getSecretQuestion() Not supported");
		return null;
	}

	/**
	 * Move the current secret question for the user to next
	 * 
	 * @param customerId
	 *           The login id of the user to authenticate
	 * @return The object containing the question to ask
	 */
	public VCryptQuestion moveToNextSecretQuestion(String customerId) {
		if (logger.isDebugEnabled()) logger.debug("moveToNextSecretQuestion customerId=" + customerId);
		logger.error("moveToNextSecretQuestion() Not supported");
		return null;
	}

	public VCryptAuthResult authenticateQuestionForCSR(String customerId, String answer) {
		return this.authenticateQuestion(customerId, answer);
	}

	/**
	 * Method for authenticate question/answer
	 * 
	 * @param customerId
	 *           The login id of the user to authenticate
	 * @param answer
	 *           the answer given by the user
	 * @return VCryptAuthResult describing result of authentication attempt
	 */
	public VCryptAuthResult authenticateQuestion(String customerId, String answer) {
		if (logger.isDebugEnabled()) logger.debug("authenticateQuestion customerId=" + customerId);
		logger.error("authenticateQuestion() Not supported");
		return null;
	}

	public VCryptAuthResult authenticateQuestion(String requestId, Integer challengeChannel, String customerId, String answer) {
		throw new BharosaRuntimeException(BharosaErrorIds.AUTHENTICATE_QUESTION_NOT_SUPPORTED);
		// throw new RuntimeException("authenticateQuestion not supported");
	}

	public VCryptAuthResult authenticateQuestionForCSR(String requestId, Integer challengeChannel, String customerId, String answer) {
		throw new BharosaRuntimeException(BharosaErrorIds.AUTHENTICATE_QUESTION_NOT_SUPPORTED);
		// throw new RuntimeException("authenticateQuestion not supported");
	}

	Long generateSessionId() {
		synchronized (lock) {
			try {
				// Run the clock for 1 milli second
				lock.wait(1);
				return new Long((new Date()).getTime());
			} catch (Exception ex) {
				logger.error("Error while creating session id", ex);
			}
		}
		return new Long(0);
	}

	int getRandomInt(int upperBound) {
		return sRand.nextInt(upperBound);
	}

	class AuthSessionLite {
		VCryptWheel wheel = null;
		Date createDate = new Date();
		boolean isAuthenticated = false;
	}
}
