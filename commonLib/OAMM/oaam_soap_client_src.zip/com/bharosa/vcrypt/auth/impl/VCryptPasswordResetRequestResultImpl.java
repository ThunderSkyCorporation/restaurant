package com.bharosa.vcrypt.auth.impl;

import java.util.List;
import java.util.ArrayList;

import com.bharosa.common.logger.Logger;

import com.bharosa.vcrypt.auth.intf.VCryptPasswordResetRequestResult;

/**
 * Provides information about authentication results
 * @author Luke
 */

public class VCryptPasswordResetRequestResultImpl 
	implements VCryptPasswordResetRequestResult, java.io.Serializable{
	static Logger logger = Logger.getLogger(VCryptPasswordResetRequestResultImpl.class);

	int statusCode;
	String magicKey = null;

	public VCryptPasswordResetRequestResultImpl(){
		if(logger.isDebugEnabled()) logger.debug("Using default constructor");
	}

	public VCryptPasswordResetRequestResultImpl(int status){
		if(logger.isDebugEnabled()) logger.debug("Setting status to: "+status);
		statusCode = status;
		magicKey = null;
	}

	public VCryptPasswordResetRequestResultImpl(int status, String mkey){
		if(logger.isDebugEnabled()) logger.debug("Setting status to: "+status);
		if(logger.isDebugEnabled()) logger.debug("Setting magicKey to: "+mkey);
		statusCode = status;
		magicKey = mkey;
	}

	/**
	 * Returns the status code
	 * @return status code from VCryptPinResetRequestResult<br>
	 */
	public int getStatus(){ return statusCode; }

	public String getMagicKey(){ return magicKey; }
}
