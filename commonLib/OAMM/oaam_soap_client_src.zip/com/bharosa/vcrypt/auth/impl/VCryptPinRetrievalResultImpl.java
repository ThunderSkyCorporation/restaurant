package com.bharosa.vcrypt.auth.impl;

import java.util.List;
import java.util.ArrayList;

import com.bharosa.common.logger.Logger;

import com.bharosa.vcrypt.auth.intf.VCryptPinRetrievalResult;

/**
 * Provides information about authentication results
 * @author Luke
 */

public class VCryptPinRetrievalResultImpl implements VCryptPinRetrievalResult,
													 java.io.Serializable{
	static Logger logger = Logger.getLogger(VCryptPinRetrievalResultImpl.class);

	private int statusCode = -1;

	private String secretWordHint = null;
	private String secretWordString = null; //upper columns
	private String newPinString = null; //lower columns


	public VCryptPinRetrievalResultImpl(){
		if(logger.isDebugEnabled()) logger.debug("Using default constructor");
	}

	public VCryptPinRetrievalResultImpl(int status){
		if(logger.isDebugEnabled()) logger.debug("Setting status to: "+status);
		statusCode = status;
	}

	public VCryptPinRetrievalResultImpl(String secretHint,
			String wordString, String pinString){
		secretWordHint = secretHint;
		secretWordString = wordString;
		newPinString = pinString;
	}

	public VCryptPinRetrievalResultImpl(int status, String secretHint,
			String wordString, String pinString){
		if(logger.isDebugEnabled()) logger.debug("Setting status to: "+status);

		statusCode = status;

		secretWordHint = secretHint;
		secretWordString = wordString;
		newPinString = pinString;
	}

	public int getStatus(){
		return statusCode;
	}

	public String getWordHint(){
		return secretWordHint;
	}


	public String getWordString(){
		return secretWordString;
	}

	public String getPinString(){
		return newPinString;
	}
}
