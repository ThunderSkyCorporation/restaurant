package com.bharosa.vcrypt.auth.impl;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.vcrypt.auth.intf.*;
import com.bharosa.vcrypt.auth.util.VCryptAuthUtil;
import com.bharosa.vcrypt.common.intf.VCryptSOAP;
import com.bharosa.vcrypt.common.util.VCryptCommonUtil;
import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.common.logger.Logger;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.Vector;
import java.util.List;


/**
 * Provides various methods for authenticating PIN/passwords using VCrypt system
 *
 * @author Luke
 */

public class VCryptAuthSOAPImpl implements VCryptAuth {

    static Logger logger = Logger.getLogger(VCryptAuthSOAPImpl.class);
    static boolean initDone = false;

    /**
     * Use accessMethod to get this object.
     */
    static ArrayList vcryptSoapList = null;
    static int totalServers = 0;

    /**
     * Default constructer.
     */
    public VCryptAuthSOAPImpl() {
        if (logger.isDebugEnabled()) logger.debug("Creating VCryptAuthSOAPImpl");
    }

    /**
     * This is important to use this method for getting the VCryptSOAP,
     * because if server is not up when the client comes up and if the
     * connection is not established, then we might have retry issues.
     *
     * @param seedStr seed string
     * @return VCryptSOAP
     */
    VCryptSOAP getVCryptSOAP(String seedStr) {
        if (seedStr == null) {
            seedStr = "" + new Date().getTime();
        }
        if (vcryptSoapList == null || !initDone) {
            synchronized (VCryptAuthSOAPImpl.class) {
                initDone = false;
                if (vcryptSoapList == null) {
                    logger.info("Creating soap object...");
                    String serverUrl;
                    if (BharosaConfig.getBoolean("bharosa.authenticator.module.is", false)) {
                        serverUrl = BharosaConfig.get("bharosa.authenticator.soap.url");
                        logger.info("**** This is an authenticator module. serverUrl=" + serverUrl);
                    } else {
                        serverUrl = BharosaConfig.get("vcrypt.tracker.soap.url");
                        logger.info("serverUrl=" + serverUrl);
                    }
                    String serviceName
                            = BharosaConfig.get("vcrypt.tracker.soap.authenticatorServiceName");
                    if (StringUtil.isEmpty(serverUrl)) {
                        logger.fatal("SOAP url not given. Please set vcrypt.tracker.soap.url property");
                        return null;
                    }
                    vcryptSoapList = new ArrayList();
                    String urls[] = serverUrl.trim().split(",");
                    for (int i = 0; i < urls.length; i++) {
                        VCryptSOAP vcryptSoap =
                                VCryptCommonUtil.newVCryptSOAPInstance(urls[i].trim(),
                                        serviceName);
                        vcryptSoapList.add(vcryptSoap);
                    }
                    totalServers = vcryptSoapList.size();
                }
                initDone = true;
            }
        }
        if (totalServers != 0) {
            int index = 0;
            char[] charArray = seedStr.toCharArray();

            for (int i = 0; i < charArray.length; i++) {
                index += (int) charArray[i];
            }
            index = index % totalServers;
            return (VCryptSOAP) vcryptSoapList.get(index);
        } else {
            return null;
        }

    }


    /**
     * Return the user details without the password and pin for the given customer
     *
     * @param customerId of the user.
     * @return a <code>VCryptAuthUser</code> value. If the user is not valid,
     *         then all the values in the object is is null
     */
    public VCryptAuthUser getUser(String customerId) {
        VCryptAuthUser retVal = null;
        try {
            if (logger.isDebugEnabled())
                logger.debug("getUser() customerId=" + customerId);

            String requestName = "getUser";
            String xmlParameter = VCryptCommonUtil.toXMLString(customerId);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLAuthUser(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for getUser() customerId="
                        + customerId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. getUser() customerId=" + customerId, ex);
        }
        return retVal;
    }

    /**
     * Return the user details without the password and pin for the given customer and groupId
     *
     * @param loginId   of the user.
     * @param groupName groupName
     * @return a <code>VCryptAuthUser</code> value. If the user is not valid,
     *         then all the values in the object is is null. Any unexpected error, Null is returned.
     */
    public VCryptAuthUser getUserByLoginId(String loginId, String groupName) {
        VCryptAuthUser retVal = null;
        try {
            if (logger.isDebugEnabled())
                logger.debug("getUser() loginId=" + loginId + ",groupName=" + groupName);

            String xmlParameter = VCryptAuthUtil.toXMLGetUser(loginId, groupName);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(loginId);
            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(VCryptAuth.REQ_GET_USER, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLAuthUser(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for getUser() loginId=" + loginId + ",groupName=" + groupName);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. getUser() loginId=" + loginId + ",groupName=" + groupName, ex);
        }
        return retVal;
    }


    /**
     * This returns the user details without the password
     * and pin.
     *
     * @param loginId of the user.
     * @return a <code>VCryptAuthUser</code> value. If the user is not valid,
     *         then all the values in the object is is null
     */
    public VCryptAuthUser getUserByLoginId(String loginId) {
        VCryptAuthUser retVal = null;
        try {
            if (logger.isDebugEnabled()) logger.debug("getUserByLoginId() loginId="
                    + loginId);

            String requestName = "getUserByLoginId";
            String xmlParameter =
                    VCryptCommonUtil.toXMLString(loginId);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(loginId);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLAuthUser(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for getUserByLoginId() loginId="
                        + loginId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. getUserByLoginId() loginId=" + loginId, ex);
        }
        return retVal;
    }

    public VCryptAuthUser createUser(VCryptAuthUser authUser) {

        if (logger.isDebugEnabled()) logger.debug("createUser() customerId=" + authUser.getCustomerId());
        if (authUser == null) {
            logger.error("createUser: Null authUser passed.");
            return null;
        }
        try {
            String requestName = "createUser";
            String xmlParameter = VCryptAuthUtil.toXMLAuthUser(authUser);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(authUser.getCustomerId());

            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
                authUser = VCryptAuthUtil.fromXMLAuthUser(xmlReturn);
                return authUser;
            } else {
                logger.error("VCryptSOAP not created yet. No action take for getUser() customerId="
                        + authUser.getCustomerId());
            }
        } catch (Exception ex) {
            logger.error("Caught exception. getUser() customerId=" + authUser.getCustomerId(), ex);
        }

        return null;
    }

    public VCryptAuthUser setUser(VCryptAuthUser authUser) {
        if (logger.isDebugEnabled()) logger.debug("setUser() customerId=" + authUser.getCustomerId());
        if (authUser == null) {
            logger.error("createUser: Null authUser passed.");
            return null;
        }
        try {
            String requestName = "setUser";
            String xmlParameter = VCryptAuthUtil.toXMLAuthUser(authUser);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(authUser.getCustomerId());

            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
                authUser = VCryptAuthUtil.fromXMLAuthUser(xmlReturn);
                return authUser;
            } else {
                logger.error("VCryptSOAP not set yet. No action take for getUser() customerId="
                        + authUser.getCustomerId());
            }
        } catch (Exception ex) {
            logger.error("Caught exception. getUser() customerId=" + authUser.getCustomerId(), ex);
        }

        return null;
    }

    /**
     * Master method to athenticate password
     *
     * @param customerId      The customerId used by the user.
     * @param password        The raw password entered by the user.
     * @param authSessionType Reason for authentication
     * @param clientType      Client type used.
     * @param clientVersion   Client version
     * @param ipAddress       IP address of the user device.
     * @param fingerPrintType Type of finger printing
     * @param fingerPrint     Finger print
     * @return a <code>VCryptAuthResult</code> value
     */
    public VCryptAuthResult authenticatePassword(String customerId, String password,
                                                 int authSessionType,
                                                 int clientType, String clientVersion,
                                                 String ipAddress, int fingerPrintType,
                                                 String fingerPrint) {
        VCryptAuthResult retVal = null;
        try {
            if (logger.isDebugEnabled()) logger.debug("Authenticating password for customerId=" + customerId
                    + ", authSessionType=" + authSessionType
                    + ", clientType=" + clientType + ", clientVersion="
                    + clientVersion
                    + ", ipAddress=" + ipAddress);

            String requestName = "authenticatePassword";
            String xmlParameter =
                    VCryptAuthUtil.toXMLAuthPasswordRequest(customerId, password, authSessionType,
                            clientType, clientVersion, ipAddress, fingerPrintType, fingerPrint);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLAuthResultResponse(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for authenticatePassword() customerId=" + customerId
                        + ", authSessionType=" + authSessionType
                        + ", clientType=" + clientType + ", clientVersion="
                        + clientVersion
                        + ", ipAddress=" + ipAddress);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. authenticatePassword() customerId=" + customerId
                    + ", authSessionType=" + authSessionType
                    + ", clientType=" + clientType + ", clientVersion="
                    + clientVersion
                    + ", ipAddress=" + ipAddress, ex);
        }
        return retVal;
    }


    /**
     * This method generates a new wheel with creating the VCryptAuthSession object.
     *
     * @param length                of the wheel
     * @param sets                  number of sets
     * @param previousAuthSessionId previous authentication session id (if available)
     * @param authSessionType       What type of authentication session this is. It could be
     *                              login, in-session, pin reset, etc.
     * @param clientType            what type of client is used for authentication
     * @param clientVersion         what is the version of the client
     * @param ipAddress             IP address of the user device.
     * @param fingerPrintType       Type of finger printing
     * @param fingerPrint           Finger print
     * @return a <code>VCryptWheel</code> value
     */
    public VCryptWheel genWheel(int length, int sets, Long previousAuthSessionId,
                                int authSessionType, int clientType, String clientVersion,
                                String ipAddress, int fingerPrintType,
                                String fingerPrint) {
        VCryptWheel retVal = null;

        try {
            if (logger.isDebugEnabled()) logger.debug("genWheel() length=" + length + ", sets="
                    + sets + ", previousAuthSessionId=" + previousAuthSessionId
                    + ", authSessionType=" + authSessionType
                    + ", clientType=" + clientType
                    + ", clientVersion=" + clientVersion
                    + ", ipAddress=" + ipAddress);

            String requestName = "genWheel";
            String xmlParameter =
                    VCryptAuthUtil.toXMLGenerateWheelRequest(length, sets, previousAuthSessionId,
                            authSessionType, clientType, clientVersion,
                            ipAddress, fingerPrintType, fingerPrint);

            String seedStr = "" + (new Date()).getTime();
            VCryptSOAP vcryptSOAP = getVCryptSOAP(seedStr);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLGenerateWheelResponse(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for genWheel() length=" + length + ", sets="
                        + sets + ", previousAuthSessionId=" + previousAuthSessionId
                        + ", authSessionType=" + authSessionType
                        + ", clientType=" + clientType
                        + ", clientVersion=" + clientVersion
                        + ", ipAddress=" + ipAddress);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. genWheel() length=" + length + ", sets="
                    + sets + ", previousAuthSessionId=" + previousAuthSessionId
                    + ", authSessionType=" + authSessionType
                    + ", clientType=" + clientType
                    + ", clientVersion=" + clientVersion
                    + ", ipAddress=" + ipAddress, ex);
        }
        return retVal;

    }

    /**
     * This method authenticates the PIN entered by the user
     * using the slider.
     *
     * @param customerId      CustomerId used by the user
     * @param displacements   Displacement of the marker
     * @param authStats       Hash map of user input metrics, like time taken, etc.
     * @param authSessionId   The Id of the auth session
     * @param ipAddress       IP address of the user device.
     * @param fingerPrintType Type of finger printing
     * @param fingerPrint     Finger print
     * @return a <code>VCryptAuthResult</code> value
     */
    public VCryptAuthResult authenticateSlider(String customerId, Vector displacements,
                                               Map authStats,
                                               Long authSessionId, String ipAddress, int fingerPrintType,
                                               String fingerPrint) {

        VCryptAuthResult retVal = null;
        String pin = null;
        try {
            if (logger.isDebugEnabled()) logger.debug("authenticateSlider for customerId=" + customerId
                    + ", displacements=" + displacements
                    + ", authSessionId=" + authSessionId
                    + ", ipAddress=" + ipAddress);

            String requestName = "authenticateSlider";
            String xmlParameter =
                    VCryptAuthUtil.toXMLAuthSliderRequest(customerId, pin, displacements, authStats,
                            authSessionId, ipAddress, fingerPrintType, fingerPrint);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLAuthResultResponse(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for authenticateSlider() customerId=" + customerId
                        + ", displacements=" + displacements
                        + ", authSessionId=" + authSessionId
                        + ", ipAddress=" + ipAddress);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. authenticateSlider() customerId=" + customerId
                    + ", displacements=" + displacements
                    + ", authSessionId=" + authSessionId
                    + ", ipAddress=" + ipAddress, ex);
        }
        return retVal;
    }


    /**
     * This method authenticates the PIN entered by the user
     * using the slider. This passess the PIN to be used for authentication.
     * This method is usually used for PIN reset utility program.
     *
     * @param customerId      CustomerId used by the user
     * @param pin             a <code>String</code> value
     * @param displacements   Displacement of the marker
     * @param authStats       Hash map of user input metrics, like time taken, etc.
     * @param authSessionId   The session Id for this authentication
     * @param ipAddress       IP address of the user device.
     * @param fingerPrintType Type of finger printing
     * @param fingerPrint     Finger print
     * @return a <code>VCryptAuthResult</code> value
     */
    public VCryptAuthResult authenticateSlider(String customerId, String pin,
                                               Vector displacements,
                                               Map authStats,
                                               Long authSessionId, String ipAddress, int fingerPrintType,
                                               String fingerPrint) {
        VCryptAuthResult retVal = null;
        try {
            if (logger.isDebugEnabled()) logger.debug("authenticateSlider for customerId=" + customerId
                    + ", displacements=" + displacements
                    + ", authSessionId=" + authSessionId
                    + ", ipAddress=" + ipAddress);

            String requestName = "authenticateSlider";
            String xmlParameter =
                    VCryptAuthUtil.toXMLAuthSliderRequest(customerId, pin, displacements, authStats,
                            authSessionId, ipAddress, fingerPrintType, fingerPrint);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLAuthResultResponse(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for authenticateSlider() customerId=" + customerId
                        + ", displacements=" + displacements
                        + ", authSessionId=" + authSessionId
                        + ", ipAddress=" + ipAddress);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. authenticateSlider() customerId=" + customerId
                    + ", displacements=" + displacements
                    + ", authSessionId=" + authSessionId
                    + ", ipAddress=" + ipAddress, ex);
        }
        return retVal;
    }


    /**
     * Gets a secret question for the user
     *
     * @param customerId            The login id of the user to authenticate
     * @param previousAuthSessionId The previous authentication session id.
     *                              This would be authentication session id used by the password
     *                              authentication. Pass null, if there was not previous authentication.
     * @param authSessionType       What type of authentication session this is. It could be
     *                              login, in-session, pin reset, etc.
     * @param clientType            what type of client is used for authentication
     * @param clientVersion         what is the version of the client
     * @param ipAddress             IP address of the user device.
     * @param fingerPrintType       Type of finger printing
     * @param fingerPrint           Finger print
     * @return The object containing the question to ask and also the authentication
     *         session id.
     */
    public VCryptQuestion getSecretQuestion(String customerId, Long previousAuthSessionId,
                                            int authSessionType, int clientType, String clientVersion,
                                            String ipAddress, int fingerPrintType,
                                            String fingerPrint) {

        VCryptQuestion retVal = null;

        try {
            if (logger.isDebugEnabled()) logger.debug("getSecretQuestion() customerId=" + customerId
                    + ", previousAuthSessionId=" + previousAuthSessionId
                    + ", authSessionType=" + authSessionType
                    + ", clientType=" + clientType + ", clientVersion="
                    + clientVersion + ", ipAddress=" + ipAddress);

            String requestName = "getSecretQuestion";
            String xmlParameter =
                    VCryptAuthUtil.toXMLGetSecretQuestionRequest(customerId, previousAuthSessionId,
                            authSessionType, clientType,
                            clientVersion, ipAddress, fingerPrintType, fingerPrint);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLGetSecretQuestionResponse(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for getSecretQuestion() customerId=" + customerId
                        + ", previousAuthSessionId=" + previousAuthSessionId
                        + ", authSessionType=" + authSessionType
                        + ", clientType=" + clientType + ", clientVersion="
                        + clientVersion + ", ipAddress=" + ipAddress);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. getSecretQuestion() customerId=" + customerId
                    + ", previousAuthSessionId=" + previousAuthSessionId
                    + ", authSessionType=" + authSessionType
                    + ", clientType=" + clientType + ", clientVersion="
                    + clientVersion + ", ipAddress=" + ipAddress, ex);
        }
        return retVal;

    }

    /**
     * Method for authenticate question/answer
     * @param customerId The login id of the user to authenticate
     * @param authSessionId Id of the auth session
     * @param answer the answer given by the user
     * @param ipAddress IP address of the user device.
     * @param fingerPrintType Type of finger printing
     * @param fingerPrint Finger print
     * @return VCryptAuthResult describing result of authentication attempt
    public VCryptAuthResult authenticateQuestion( String customerId,
    Long authSessionId,
    String answer,
    String ipAddress, int fingerPrintType,
    String fingerPrint ) {
    VCryptAuthResult retVal = null;
    try {
    if(logger.isDebugEnabled()) logger.debug("authenticateQuestion() customerId=" + customerId
    + ", authSessionId=" + authSessionId
    + ", ipAddress=" + ipAddress );

    String requestName = "authenticateQuestion";
    String xmlParameter =
    VCryptAuthUtil.toXMLAuthQuestionRequest( customerId, authSessionId,
    answer, ipAddress, fingerPrintType, fingerPrint );

    VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
    if(  vcryptSOAP != null ) {
    String xmlReturn
    = vcryptSOAP.execute( requestName, xmlParameter );
    retVal = VCryptAuthUtil.fromXMLAuthResultResponse( xmlReturn );
    } else {
    logger.error("VCryptSOAP not created yet. No action take for authenticateQuestion() customerId=" + customerId
    + ", authSessionId=" + authSessionId
    + ", ipAddress=" + ipAddress );
    }
    } catch( Exception ex ) {
    logger.error("Caught exception. authenticateQuestion() customerId=" + customerId
    + ", authSessionId=" + authSessionId
    + ", ipAddress=" + ipAddress, ex );
    }
    return retVal;
    }
     */

    /**
     * Sets a new PIN for the specified user
     *
     * @param customerId user login Id
     * @param PIN        New PIN to set
     * @param pinStatus  Status of the PIN, like one time, etc.
     * @return whether the operation was success or failure
     */
    public boolean setPIN(String customerId, String PIN, int pinStatus) {
        boolean retVal = false;
        try {
            if (logger.isDebugEnabled()) logger.debug("setPIN(): customerId="
                    + customerId + ", pinStatus="
                    + pinStatus);
            String requestName = "setPIN";

            String xmlParameter =
                    VCryptAuthUtil.toXMLSetUserPinRequest(customerId, PIN, pinStatus);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
                if (boolVal != null) {
                    retVal = boolVal.booleanValue();
                } else {
                    logger.error("setPIN didn't return any value. customerId=" + customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action take for setPIN() customerId=" + customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. setPIN() customerId=" + customerId, ex);
        }
        return retVal;

    }

    /**
     * Sets a new Password for the specified user
     *
     * @param customerId     user login Id
     * @param password       New password to set
     * @param passwordStatus Status of the Password, like one time, etc.
     */
    public boolean setPassword(String customerId, String password, int passwordStatus) {
        boolean retVal = false;
        try {
            if (logger.isDebugEnabled()) logger.debug("setPassword(): customerId="
                    + customerId + ", passwordStatus="
                    + passwordStatus);
            String requestName = "setPassword";

            String xmlParameter =
                    VCryptAuthUtil.toXMLSetUserPasswordRequest(customerId, password, passwordStatus);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
                if (boolVal != null) {
                    retVal = boolVal.booleanValue();
                } else {
                    logger.error("setPassword didn't return any value. customerId=" + customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action take for setPassword() customerId=" + customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. setPassword() customerId=" + customerId, ex);
        }
        return retVal;

    }


    /**
     * Sets a new image for the specified user
     *
     * @param customerId user login Id
     * @param imagePath  Path to the image file
     * @return whether the operation was success or failure
     */
    public boolean setImage(String customerId, String imagePath) {
        boolean retVal = false;
        try {

            if (logger.isDebugEnabled()) logger.debug("customerId=" + customerId + ", image=" + imagePath);

            String requestName = "setImage";

            String xmlParameter = VCryptAuthUtil.toXMLSetImageRequest(customerId, imagePath);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
                Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
                if (boolVal != null) {
                    retVal = boolVal.booleanValue();
                } else {
                    logger.error("setImage didn't return any value. customerId=" + customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action take for setImaage customerId=" + customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. setImage customerId=" + customerId, ex);
        }
        return retVal;
    }


    /**
     * Sets a new caption for the specified user
     *
     * @param customerId user login Id
     * @param caption    New caption to set
     * @return whether the operation was success or failure
     */
    public boolean setCaption(String customerId, String caption) {
        boolean retVal = false;
        try {
            if (logger.isDebugEnabled()) logger.debug("setCaption(): customerId="
                    + customerId + ", caption="
                    + caption);
            String requestName = "setCaption";

            String xmlParameter = VCryptAuthUtil.toXMLSetCaptionRequest(customerId, caption);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
                if (boolVal != null) {
                    retVal = boolVal.booleanValue();
                } else {
                    logger.error("setCaption didn't return any value. customerId=" + customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action take for setCaption() customerId=" + customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. setCaption() customerId=" + customerId, ex);
        }
        return retVal;
    }
    public boolean setCaption(String customerId, VCryptLocalizedString caption) {
       boolean retVal = false;
       try {
           if (logger.isDebugEnabled()) logger.debug("setCaption(): customerId="
                   + customerId + ", caption="
                   + caption);
           
           if(caption == null) caption = new VCryptLocalizedString();
           String requestName = "setCaption";

           String xmlParameter = VCryptAuthUtil.toXMLSetCaptionRequest(customerId, caption);

           VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
           if (vcryptSOAP != null) {
               String xmlReturn
                       = vcryptSOAP.execute(requestName, xmlParameter);
               Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
               if (boolVal != null) {
                   retVal = boolVal.booleanValue();
               } else {
                   logger.error("setCaption didn't return any value. customerId=" + customerId);
               }
           } else {
               logger.error("VCryptSOAP not created yet. No action take for setCaption() customerId=" + customerId);
           }

       } catch (Exception ex) {
           logger.error("Caught exception. setCaption() customerId=" + customerId, ex);
       }
       return retVal;
   }

    /**
     * Sets a new caption for the specified user
     *
     * @param customerId user login Id
     * @param imagePath  Path to the image file
     * @param caption    New caption to set
     * @return whether the operation was success or failure
     */
    public boolean setImageAndCaption(String customerId, String imagePath, String caption) {
        boolean retVal = false;
        try {
            if (logger.isDebugEnabled())
                logger.debug("setImageAndCaption. customerId=" + customerId + ", caption=" + caption + ", image=" + imagePath);

            String xmlParameter = VCryptAuthUtil.toXMLImageAndCaptionRequest(customerId, imagePath, caption);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(REQ_SET_IMAGE_AND_CAPTION, xmlParameter);
                Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
                if (boolVal != null) {
                    retVal = boolVal.booleanValue();
                } else {
                    logger.error("setCaption didn't return any value. customerId=" + customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action take for setCaption() customerId=" + customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. setCaption() customerId=" + customerId, ex);
        }
        return retVal;
    }
    public boolean setImageAndCaption(String customerId, String imagePath, VCryptLocalizedString caption) {
       boolean retVal = false;
       try {
           if (logger.isDebugEnabled())
               logger.debug("setImageAndCaption. customerId=" + customerId + ", caption=" + caption + ", image=" + imagePath);

           if(caption == null) caption = new VCryptLocalizedString();
           String xmlParameter = VCryptAuthUtil.toXMLImageAndCaptionRequest(customerId, imagePath, caption);

           VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
           if (vcryptSOAP != null) {
               String xmlReturn = vcryptSOAP.execute(REQ_SET_IMAGE_AND_CAPTION, xmlParameter);
               Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
               if (boolVal != null) {
                   retVal = boolVal.booleanValue();
               } else {
                   logger.error("setCaption didn't return any value. customerId=" + customerId);
               }
           } else {
               logger.error("VCryptSOAP not created yet. No action take for setCaption() customerId=" + customerId);
           }

       } catch (Exception ex) {
           logger.error("Caught exception. setCaption() customerId=" + customerId, ex);
       }
       return retVal;
   }

    /**
     * Sets auth mode for the specified user
     *
     * @param customerId user login Id
     * @param authMode   mode of authentication for the user
     * @return whether the operation was success or failure
     */
    public boolean setUserAuthMode(String customerId, int authMode) {
        boolean retVal = false;
        try {
            if (logger.isDebugEnabled()) logger.debug("setUserAuthMode(): customerId="
                    + customerId + ", authMode="
                    + authMode);
            String requestName = "setUserAuthMode";

            String xmlParameter = VCryptAuthUtil.toXMLSetUserAuthModeRequest(customerId, authMode);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
                if (boolVal != null) {
                    retVal = boolVal.booleanValue();
                } else {
                    logger.error("setUserAuthMode didn't return any value. customerId=" + customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action take for setUserAuthMode() customerId=" + customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. setUserAuthMode() customerId=" + customerId, ex);
        }
        return retVal;
    }

    /**
     * Set authmode of <code>groupId</code> users to <code>authMode</code>
     *
     * @param groupName groupName of the users
     * @param authMode  new Auth mode
     * @return true if update is successful
     */
    public boolean setGroupUsersAuthMode(String groupName, int authMode) {
        boolean retVal = false;
        try {
            if (logger.isDebugEnabled())
                logger.debug("setUserAuthMode(): group=" + groupName + ", authMode=" + authMode);

            String xmlParameter = VCryptAuthUtil.toXMLSetGroupUsersAuthMode(groupName, authMode);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(String.valueOf(System.currentTimeMillis()));
            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(REQ_SET_GROUP_AUTH_MODE, xmlParameter);
                Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
                if (boolVal != null) {
                    retVal = boolVal.booleanValue();
                } else {
                    logger.error("setGroupUsersAuthMode didn't return any value. group=" + groupName);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action take for setGroupUsersAuthMode() group=" + groupName);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. setGroupUsersAuthMode() group=" + groupName, ex);
        }
        return retVal;
    }

    /**
     * Sets auth mode for the specified user
     *
     * @param customerId user login Id
     * @param userStatus status of the user
     * @return whether the operation was success or failure
     */
    public boolean setUserStatus(String customerId, int userStatus) {
        boolean retVal = false;
        try {
            if (logger.isDebugEnabled()) logger.debug("setUserStatus(): customerId="
                    + customerId + ", authMode="
                    + userStatus);
            String requestName = "setUserStatus";

            String xmlParameter = VCryptAuthUtil.toXMLSetUserStatusRequest(customerId, userStatus);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn
                        = vcryptSOAP.execute(requestName, xmlParameter);
                Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
                if (boolVal != null) {
                    retVal = boolVal.booleanValue();
                } else {
                    logger.error("setUserStatus didn't return any value. customerId=" + customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action take for setUserStatus() customerId=" + customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. setUserStatus() customerId=" + customerId, ex);
        }
        return retVal;
    }

    /**
     * Gets the imagePath for the user
     *
     * @param customerId user login Id
     * @return Path to the image
     */
    public String getImage(String customerId) {
        String image = null;
        try {
            if (logger.isDebugEnabled())
                logger.debug("getImage customerId=" + customerId);

            String xmlParameter = VCryptCommonUtil.toXMLString(customerId);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(REQ_GET_IMAGE, xmlParameter);
                image = VCryptCommonUtil.fromXMLString(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for getImage customerId=" + customerId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. getImage, customerId=" + customerId, ex);
        }
        return image;
    }

    /**
     * Gets the caption for the user
     *
     * @param customerId user login Id
     * @return Caption string
     */
    public String getCaption(String customerId) {

        String caption = null;
        try {
            if (logger.isDebugEnabled())
                logger.debug("getCaption customerId=" + customerId);

            String xmlParameter = VCryptCommonUtil.toXMLString(customerId);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(REQ_GET_CAPTION, xmlParameter);
                caption = VCryptCommonUtil.fromXMLString(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. No action take for getCaption customerId=" + customerId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. getCaption, customerId=" + customerId, ex);
        }
        return caption;
    }
    public VCryptLocalizedString getLocalizedCaption(String customerId) {

   	 VCryptLocalizedString caption = null;
     if (StringUtil.isEmpty(customerId)) {
         logger.warn("getLocalizedCaption() got null or empty customer Id");
         return caption;
     }
       try {
           if (logger.isDebugEnabled())
               logger.debug("getLocalizedCaption customerId=" + customerId);

           String xmlParameter = VCryptCommonUtil.toXMLString(customerId);
           VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

           if (vcryptSOAP != null) {
               String xmlReturn = vcryptSOAP.execute(REQ_GET_LOCALIZED_CAPTION, xmlParameter);
               caption = VCryptAuthUtil.fromXMLLocalizedString(xmlReturn);
           } else {
               logger.error("VCryptSOAP not created yet. No action take for getLocalizedCaption customerId=" + customerId);
           }
       } catch (Exception ex) {
           logger.error("Caught exception. getLocalizedCaption, customerId=" + customerId, ex);
       }
       return caption;
   }
    /**
     * Gets the image path and caption for the user
     *
     * @param customerId user login Id
     * @return String[0]= Image path, String[1] is Caption
     */
    public String[] getImageAndCaption(String customerId) {
        String[] retVal = new String[2];
        if (StringUtil.isEmpty(customerId)) {
            logger.warn("getImageAndCaption() got null or empty customer Id");
            return retVal;
        }
        try {
            if (logger.isDebugEnabled())
                logger.debug("getImageAndCaption customerId=" + customerId);

            String xmlParameter = VCryptCommonUtil.toXMLString(customerId);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(REQ_GET_IMAGE_AND_CAPTION, xmlParameter);
                Map map = VCryptAuthUtil.fromXMLImageAndCaptionRequest(xmlReturn);
                if(map != null) {
                  retVal[0] = (String) map.get("imagePath");
                  retVal[1] = (String) map.get("caption");
                }              
            } else {
                logger.error("VCryptSOAP not created yet. No action take for getImageAndCaption customerId=" + customerId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. getImageAndCaption, customerId=" + customerId, ex);
        }
        return retVal;
    }
    public Object[] getImageAndLocalizedCaption(String customerId) {
   	 Object[] retVal = new Object[2];
     if (StringUtil.isEmpty(customerId)) {
         logger.warn("getImageAndLocalizedCaption() got null or empty customer Id");
         return retVal;
     }
       try {
           if (logger.isDebugEnabled())
               logger.debug("getImageAndLocalizedCaption customerId=" + customerId);

           String xmlParameter = VCryptCommonUtil.toXMLString(customerId);
           VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

           if (vcryptSOAP != null) {
               String xmlReturn = vcryptSOAP.execute(REQ_GET_IMAGE_AND_LOCALIZED_CAPTION, xmlParameter);
               Map map = VCryptAuthUtil.fromXMLImageAndCaptionRequest(xmlReturn);
               if(map != null) {
                 retVal[0] = map.get("imagePath");
                 retVal[1] = map.get("localizedString");
               }
           } else {
               logger.error("VCryptSOAP not created yet. No action take for getImageAndLocalizedCaption customerId=" + customerId);
           }
       } catch (Exception ex) {
           logger.error("Caught exception. getImageAndLocalizedCaption, customerId=" + customerId, ex);
       }
       return retVal;
   }
    /**
     * Gets the authMode for the user
     *
     * @param customerId user login Id
     * @return authMode int
     */
    public int getUserAuthMode(String customerId) {
        int authMode = 0;

        try {
            if (logger.isDebugEnabled())
                logger.debug("getUserAuthMode() customerId=" + customerId);

            String requestName = "getUserAuthMode";
            String xmlParameter = VCryptCommonUtil.toXMLString(customerId);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);

                Long authModeObj = VCryptCommonUtil.fromXMLLong(xmlReturn);

                if (authModeObj != null)
                    authMode = authModeObj.intValue();
            } else {
                logger.error("VCryptSOAP not created yet. No action take for getUserAuthMode() customerId="
                        + customerId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. getUserAuthMode() customerId=" + customerId, ex);
        }

        return authMode;
    }

    /**
     * Gets the userStatus for the user
     *
     * @param customerId user login Id
     * @return userStatus int
     */
    public int getUserStatus(String customerId) {
        int userStatus = 0;

        try {
            if (logger.isDebugEnabled())
                logger.debug("getUserStatus() customerId=" + customerId);

            String requestName = "getUserStatus";
            String xmlParameter = VCryptCommonUtil.toXMLString(customerId);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);

                Long userStatusObj = VCryptCommonUtil.fromXMLLong(xmlReturn);

                if (userStatusObj != null)
                    userStatus = userStatusObj.intValue();
            } else {
                logger.error("VCryptSOAP not created yet. No action take for getUserStatus() customerId="
                        + customerId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. getUserStatus() customerId=" + customerId, ex);
        }

        return userStatus;
    }

    public VCryptQuestion[][] getSignOnQuestions(String customerId) {
        if (logger.isDebugEnabled()) logger.debug("getSignOnQuestions() customerId=" + customerId);

        try {
            String requestName = "getSignOnQuestions";
            String xmlParameter = VCryptCommonUtil.toXMLString(customerId);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);

                return VCryptAuthUtil.fromXMLSignOnQuestions(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. Could not get signon questions for customerId=" + customerId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. Could not get signon questions for customerId=" + customerId, ex);
        }

        return null;
    }
    public VCryptQuestion[][] getSignOnQuestions(String customerId, VCryptLocale locale) {
       if (logger.isDebugEnabled()) logger.debug("getSignOnQuestions() customerId=" + customerId + ",locale=" + locale);

       try {
           if(locale == null) return null;
           String requestName = "getSignOnQuestions";          
           String xmlParameter = VCryptAuthUtil.toXMLGetSignOnQuestionsRequest(customerId, locale);
           VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

           if (vcryptSOAP != null) {
               String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);

               return VCryptAuthUtil.fromXMLSignOnQuestions(xmlReturn);
           } else {
               logger.error("VCryptSOAP not created yet. Could not get signon questions for customerId=" + customerId);
           }
       } catch (Exception ex) {
           logger.error("Caught exception. Could not get signon questions for customerId=" + customerId, ex);
       }

       return null;
   }

    public VCryptQuestion[] getAllMappedSignOnQuestions(String customerId) {
        if (logger.isDebugEnabled()) logger.debug("getAllMappedSignOnQuestions customerId=" + customerId);

        try {
            String requestName = "GetAllMappedSignOnQuestions";
            String xmlParameter = VCryptCommonUtil.toXMLString(customerId);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);

                return VCryptAuthUtil.fromXMLGetAllMappedSignOnQuestionsResponse(xmlReturn);
            } else {
                logger.error("VCryptSOAP not created yet. Could not get mapped signon questions for customerId=" + customerId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. Could not get signon questions for customerId=" + customerId, ex);
        }

        return null;
    }

    public boolean deleteAllSignOnQuestions(String customerId) {
        if (logger.isDebugEnabled()) logger.debug("deleteAllSignOnQuestions customerId=" + customerId);

        try {
            String requestName = "DeleteAllMappedSignOnQuestions";
            String xmlParameter = VCryptCommonUtil.toXMLString(customerId);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);

                Boolean boolVal = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
                if (boolVal != null) {
                    return boolVal.booleanValue();
                } else {
                    logger.error("deleteAllSignOnQuestions didn't return any value. customerId=" + customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. Could not delete signon questions for customerId=" + customerId);
            }
        } catch (Exception ex) {
            logger.error("Caught exception. Could not delete signon questions for customerId=" + customerId, ex);
        }

        return false;
    }

    /**
     * Adds a new question for the specified user
     *
     * @param customerId user login Id
     * @param question   New question to be added. Overrides if the same question is already set for this user.
     * @return whether the operation was success or failure
     */
    public VCryptResponse addQuestion(String customerId, VCryptQuestion question) {
        return addQuestion(null, customerId, question);
    }

    /**
     * Adds a new question for the specified user
     *
     * @param requestId  Bharosa RequestId
     * @param customerId user login Id
     * @param question   New question to be added. Overrides if the same question is already set for this user.
     * @return whether the operation was success or failure
     */
    public VCryptResponse addQuestion(String requestId, String customerId, VCryptQuestion question) {
        VCryptResponse response = null;
        if (logger.isDebugEnabled()) logger.debug("addQuestion(): requestId=" +requestId + ", customerId="
                + customerId + ", question=" + question.getQuestion());

        boolean bRet;

        try {
            String requestName = "addQuestion";
            
            if (question == null) {
                logger.error("Question is null. requestId=" + requestId + ", customerId=" + customerId + ", question=" + question);
                return new VCryptResponse(VCryptResponse.INVALID_DATA, "Question is null");
            }
            
            List answerList = question.getAnswerList();
            if(answerList==null || answerList.isEmpty())  {
              logger.error("Answer List is null or Empty. requestId=" + requestId + ", customerId=" + customerId + ", question=" + question);
              return new VCryptResponse(VCryptResponse.INVALID_DATA, "Answer List is null");
            }

            String xmlParameter = VCryptAuthUtil.toXMLAddQuestionRequest(requestId, customerId, question);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
                response = VCryptCommonUtil.fromVCryptResponseXml(xmlReturn);
                if (response == null) {
                    logger.error("addQuestion returned null. customerId=" + customerId);
                    response = new VCryptResponse();
                    response.setSuccess(false);
                    response.setErrorMessage("addQuestion returned null. customerId=" + customerId);
                } else {
                    bRet = response.isSuccess();
                    if(logger.isDebugEnabled())
                        logger.debug("addQuestion returned " + bRet + ". requestId=" +requestId + ", customerId="+ customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action taken for addQuestion requestrId="+requestId + ", customerId=" + customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. addQuestion() requestId=" +requestId + ", customerId="+ customerId, ex);
        }
        return response;
    }

    public VCryptResponse addQuestions(String customerId, VCryptQuestion[] questions) {
        return addQuestions(null, customerId, questions);
    }

    public VCryptResponse addQuestions(String requestId, String customerId, VCryptQuestion[] questions) {
        VCryptResponse response = new VCryptResponse();
        if (logger.isDebugEnabled()) {
            StringBuffer questionList = new StringBuffer();
            for (int i = 0; i < questions.length; i++) {
                questionList
                        .append(", questions[")
                        .append(i)
                        .append("]=")
                        .append(questions[i].getQuestion());
            }
            logger.debug("addQuestions(): requestId=" +requestId + ", customerId="+ customerId + questionList.toString());
        }

        boolean bRet;

        try {
            String requestName = VCryptAuth.REQ_ADD_QUESTIONS;

            String xmlParameter = VCryptAuthUtil.toXMLAddQuestionsRequest(requestId, customerId, questions);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
                //			 logger.info("XML RESULT IS " + xmlReturn);
                response = VCryptCommonUtil.fromVCryptResponseXml(xmlReturn);
                //			 logger.info(" AuthSOAPImpl: Response is " + response);
                if (response == null) {
                    logger.error("addQuestions returned null. requestId="+requestId + ", customerId=" + customerId);
                    response = new VCryptResponse();
                    response.setSuccess(false);
                    response.setErrorMessage("addQuestions returned null. requestId=" +requestId + ", customerId="+ customerId);
                } else {
                    bRet = response.isSuccess();
                    if(logger.isDebugEnabled())
                        logger.debug("addQuestions returned " + bRet + ". requestId=" +requestId + ", customerId="+ customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action taken for addQuestions() requestId=" +requestId + ", customerId="+ customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. addQuestions() requestId=" +requestId + ", customerId="+ customerId, ex);
        }
        //	 vResult.setIsValid(bRet);
        return response;
    }

    /**
     * Deletes the question for the specified user
     *
     * @param customerId user login Id
     * @param question   The question to be deleted
     * @return whether the operation was success or failure
     */
    public boolean deleteQuestion(String customerId, VCryptQuestion question) {
        if (logger.isDebugEnabled()) logger.debug("deleteQuestion(): customerId="
                + customerId + ", question=" + question.getQuestion());

        boolean bRet = false;

        try {
            String requestName = "deleteQuestion";

            String xmlParameter = VCryptAuthUtil.toXMLDeleteQuestionRequest(customerId, question);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
                Boolean result = VCryptCommonUtil.fromXMLBoolean(xmlReturn);
                if (result == null) {
                    logger.error("deleteQuestion returned null. customerId=" + customerId);
                } else {
                    bRet = result.booleanValue();
                    if(logger.isDebugEnabled())
                        logger.debug("deleteQuestion returned " + bRet + ". customerId=" + customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action taken for deleteQuestion() customerId=" + customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. deleteQuestion() customerId=" + customerId, ex);
        }

        return bRet;
    }

    public VCryptQuestion getSecretQuestionForCSR(String customerId) {
        return this.getSecretQuestion(customerId);
    }

    /**
     * Gets a secret question for the user
     *
     * @param customerId The login id of the user to authenticate
     * @return The object containing the question to ask
     */
    public VCryptQuestion getSecretQuestion(String customerId) {

        if (logger.isDebugEnabled()) logger.debug("getSecretQuestion(): customerId=" + customerId);

        VCryptQuestion retVal = null;

        try {
            String requestName = "getSecretQuestion";

            String xmlParameter = VCryptCommonUtil.toXMLString(customerId);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

            if (vcryptSOAP != null) {

                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLGetSecretQuestionResponse(xmlReturn);

                if (retVal == null) {
                    logger.error("getSecretQuestion returned question obj as null. customerId=" + customerId);
                } else {
                    if(logger.isDebugEnabled())
                        logger.debug("getSecretQuestion returned question obj. customerId=" + customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action taken for getSecretQuestion() customerId=" + customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. getSecretQuestion() customerId=" + customerId, ex);
        }

        return retVal;
    }

    /**
     * Move the current secret question for the user to next
     *
     * @param customerId The login id of the user to authenticate
     * @return The object containing the question to ask
     */
    public VCryptQuestion moveToNextSecretQuestion(String customerId) {
        if (logger.isDebugEnabled()) logger.debug("moveToNextSecretQuestion(): customerId=" + customerId);

        VCryptQuestion retVal = null;

        try {
            String requestName = "moveToNextSecretQuestion";

            String xmlParameter = VCryptCommonUtil.toXMLString(customerId);
            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);

            if (vcryptSOAP != null) {

                String xmlReturn = vcryptSOAP.execute(requestName, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLMoveToNextSecretQuestionResponse(xmlReturn);

                if (retVal == null) {
                    logger.error("moveToNextSecretQuestion returned question obj as null. customerId=" + customerId);
                } else {
                    if(logger.isDebugEnabled())
                        logger.debug("moveToNextSecretQuestion returned question obj. customerId=" + customerId);
                }
            } else {
                logger.error("VCryptSOAP not created yet. No action taken for moveToNextSecretQuestion() customerId=" + customerId);
            }

        } catch (Exception ex) {
            logger.error("Caught exception. moveToNextSecretQuestion() customerId=" + customerId, ex);
        }

        return retVal;
    }

    public VCryptAuthResult authenticateQuestionForCSR(String customerId, String answer) {
        return this.authenticateQuestionForCSR(null, null, customerId, answer);
    }

    public VCryptAuthResult authenticateQuestion(String customerId, String answer) {
        return authenticateQuestion(null, null, customerId, answer);
    }

    public VCryptAuthResult authenticateQuestion(String requestId, Integer challengeChannel, String customerId, String answer) {
        VCryptAuthResult retVal = null;
        try {
            if (logger.isDebugEnabled())
                logger.debug("authenticateQuestion "+requestId+ ",challengeChannel="+challengeChannel
                        + ", customerId=" + customerId + ", answer=" + answer);

            String xmlParameter = VCryptAuthUtil.toXMLAuthQuestionRequest(requestId, challengeChannel, customerId, answer);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(REQ_AUTH_QUESTION, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLAuthResultResponse(xmlReturn);

            } else {
                logger.error("authenticateQuestion VCryptSOAP not created yet. " + requestId +
                        ",challengeChannel="+challengeChannel + ", customerId=" + customerId + ", answer=" + answer);
            }
        } catch (Exception ex) {
            logger.error("authenticateQuestion error " + requestId + ",challengeChannel=" + challengeChannel
                    + ", customerId=" + customerId + ", answer=" + answer, ex);
        }
        return retVal;
    }

    public VCryptAuthResult authenticateQuestionForCSR(String requestId, Integer challengeChannel, String customerId, String answer) {

        VCryptAuthResult retVal = null;
        try {
            if (logger.isDebugEnabled())
                logger.debug("authenticateQuestionForCSR "+requestId+ ",challengeChannel="+challengeChannel
                        + ", customerId=" + customerId + ", answer=" + answer);

            String xmlParameter = VCryptAuthUtil.toXMLAuthQuestionRequest(requestId, challengeChannel, customerId, answer);

            VCryptSOAP vcryptSOAP = getVCryptSOAP(customerId);
            if (vcryptSOAP != null) {
                String xmlReturn = vcryptSOAP.execute(REQ_AUTH_QUESTION_CSR, xmlParameter);
                retVal = VCryptAuthUtil.fromXMLAuthResultResponse(xmlReturn);

            } else {
                logger.error("authenticateQuestionForCSR VCryptSOAP not created yet."+requestId+
                        ",challengeChannel="+challengeChannel + ", customerId=" + customerId + ", answer=" + answer);
            }
        } catch (Exception ex) {
            logger.error("authenticateQuestionForCSR "+requestId+ ",challengeChannel="+challengeChannel +
                    ", customerId=" + customerId + ", answer=" + answer,ex);
        }

        if (logger.isDebugEnabled())
            logger.debug("authenticateQuestionForCSR "+requestId+ ",challengeChannel="+challengeChannel +
                    ", customerId=" + customerId + ", answer=" + answer+", retVal="+retVal);
        
        return retVal;
    }

    /**
     * Method to athenticate pin
     *
     * @param customerId      The customerId used by the user.
     * @param pin             The raw pin entered by the user.
     * @param authSessionId   Authentication sessionId
     * @param authSessionType Reason for authentication
     * @param clientType      Client type used.
     * @param clientVersion   Client version
     * @param ipAddress       IP address of the user device.
     * @param fingerPrintType Type of finger printing
     * @param fingerPrint     Finger print
     * @return The VCryptAuthResult object
     * @deprecated
     */
    public VCryptAuthResult authenticatePin(String customerId, String pin,
                                            Long authSessionId, int authSessionType,
                                            int clientType, String clientVersion,
                                            String ipAddress, int fingerPrintType,
                                            String fingerPrint) {
        //Deprecated
        logger.error("This API is deprecated or not implemented, return null");
        return null;
    }
}

