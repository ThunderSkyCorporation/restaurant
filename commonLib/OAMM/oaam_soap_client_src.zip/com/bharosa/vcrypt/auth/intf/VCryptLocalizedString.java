package com.bharosa.vcrypt.auth.intf;

import java.io.Serializable;
import java.util.Locale;

import com.bharosa.common.util.StringUtil;

public class VCryptLocalizedString implements Serializable {
	private static final long serialVersionUID = -2230750386714118733L;
	String text;
	VCryptLocale locale;
	
	public VCryptLocalizedString() {
		this("");
	}
	
	public VCryptLocalizedString(String text) {
		this(text, new VCryptLocale());
	}
	
	public VCryptLocalizedString(String text, Locale locale) {
		this(text, new VCryptLocale(locale));
	}
	
	public VCryptLocalizedString(String text, VCryptLocale locale) {
		super();
		this.text = text;
		this.locale = locale;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public VCryptLocale getLocale() {
		return locale;
	}

	public void setLocale(VCryptLocale locale) {
		this.locale = locale;
	}
	public String toString() {
		return "[" + getLocale() + "] \"" + getText() + "\"";
	}
	//@Override
	public boolean equals(Object obj) {
		return obj instanceof VCryptLocalizedString && equals((VCryptLocalizedString) obj);
	}
	public boolean equals(VCryptLocalizedString obj) {
		return StringUtil.isEqual(text, obj.getText()) && locale.equals(obj.getLocale());
	}
	//@Override
	public int hashCode() {
		return text.hashCode() ^ locale.hashCode();
	}
}
