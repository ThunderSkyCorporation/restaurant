package com.bharosa.vcrypt.auth.intf;
/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.List;

/**
 * Provides information about pin reset request results
 * @author Luke
 */

public interface VCryptPasswordRetrievalResult{

	//status codes
	static public final int NONE = 0;
	static public final int SUCCESS = 1;
	static public final int TIMED_OUT = 2;
	static public final int ALREADY_RETRIEVED = 3;
	static public final int NO_QUESTION_FOUND = 4;
	static public final int NO_ANSWER_FOUND = 5;
	static public final int SYSTEM_ERROR =6;

	/**
	 * Returns the pin retrieval status code.
	 * @return one of the defined codes in VCryptPasswordRetrievalResult
	 */
	public int getStatus();

	/**
	 * Returns the secret question of the user
	 * @return one of the defined codes in VCryptPasswordRetrievalResult
	 */
	public String getSecretQuestion();

	/**
	 * Returns the secret answer of the user
	 * @return one of the defined codes in VCryptPasswordRetrievalResult
	 */
	public String getSecretAnswer();
}
