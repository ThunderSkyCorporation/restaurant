package com.bharosa.vcrypt.auth.intf;
/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.List;

/**
 * Provides information about pin reset request results
 * @author Luke
 */

public interface VCryptPinResetRequestResult{

	//status codes
	static public final int NONE = 0;
	static public final int SUCCESS = 1;
	static public final int INVALID_USER = 2;
	static public final int INVALID_EMAIL_ADDRESS = 3;
	static public final int ERROR_SENDING_EMAIL = 4;
	static public final int SYSTEM_ERROR =5;

	/**
	 * Returns the pin reset status code.
	 * @return one of the defined codes in VCryptPinResetRequestResult
	 */
	public int getStatus();

	/*
	* Returns the magic key that was generated for this request
	* @return a String
	*/
	public String getMagicKey();
}
