package com.bharosa.vcrypt.auth.intf;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.Map;
import java.util.Vector;

import com.bharosa.vcrypt.common.util.VCryptResponse;

/**
 * Provides various methods for authenticating PIN/passwords using VCrypt system
 * 
 * @author Luke
 */

public interface VCryptAuth {

	String REQ_GET_CAPTION = "getCaption";
	String REQ_GET_PREF_DELIVERY_CHANNEL = "getPreferredDeliveryChannel";
	String REQ_GET_IMAGE = "getImage";
	String REQ_GET_IMAGE_AND_CAPTION = "getImageAndCaption";
	String REQ_SET_IMAGE_AND_CAPTION = "setImageAndCaption";
	String REQ_SET_GROUP_AUTH_MODE = "setGroupUsersAuthMode";
	String REQ_ADD_QUESTIONS = "addQuestions";
	String REQ_GET_USER = "getUserByUserAndGroup";
	String REQ_AUTH_QUESTION_CSR = "authenticateQuestionCSR";
	String REQ_AUTH_QUESTION = "authenticateQuestion";
	String REQ_GET_LOCALIZED_CAPTION = "getLocalizedCaption";
	String REQ_GET_IMAGE_AND_LOCALIZED_CAPTION = "getImageAndLocalizedCaption";
	

	static final String QUESTION_STATUS = "questionStatus";
	static final String IMAGE_STATUS = "imageStatus";
	static final String PHRASE_STATUS = "phraseStatus";

	/**
	 * Return the user details without the password and pin for the given
	 * customer and group
	 * 
	 * @param customerId
	 *           of the user.
	 * @return a <code>VCryptAuthUser</code> value. If the user is not valid,
	 *         then all the values in the object is is null. Any unexpected
	 *         error, Null is returned.
	 */
	VCryptAuthUser getUser(String customerId);

	/**
	 * Return the user details without the password and pin for the given
	 * customer and group
	 * 
	 * @param loginId
	 *           of the user.
	 * @param groupName
	 *           groupName
	 * @return a <code>VCryptAuthUser</code> value. If the user is not valid,
	 *         then all the values in the object is is null. Any unexpected
	 *         error, Null is returned.
	 */
	VCryptAuthUser getUserByLoginId(String loginId, String groupName);

	/**
	 * This returns the user details without the password and pin.
	 * 
	 * @param loginId
	 *           of the user.
	 * @return a <code>VCryptAuthUser</code> value. If the user is not valid,
	 *         then all the values in the object is is null
	 */
	VCryptAuthUser getUserByLoginId(String loginId);

	/**
	 * This creates an user in the Authentication database.
   * Returns null if user is null.
	 * 
	 * @param user
	 *           Auth user
	 * @return The newly created AuthUser
	 */
	VCryptAuthUser createUser(VCryptAuthUser user);

	/**
	 * This updates the AuthUser
   * Returns null if user is null or the customerId attribute in user is invalid.
	 * 
	 * @param user
	 *           From the attributes in the map, it will only update the
	 *           name/values which are given in this list.
	 * @return The updated AuthUser
	 */
	VCryptAuthUser setUser(VCryptAuthUser user);

	/**
	 * Method to athenticate password
	 * 
	 * @param customerId
	 *           The customerId used by the user.
	 * @param password
	 *           The raw password entered by the user.If null is passed,"system_error" would be returned.
	 * @param authSessionType
	 *           Reason for authentication
	 * @param clientType
	 *           Client type used.
	 * @param clientVersion
	 *           Client version
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return The VCryptAuthResult object
	 */
	VCryptAuthResult authenticatePassword(String customerId, String password, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint);

	/**
	 * Method to athenticate pin
	 * 
	 * @param customerId
	 *           The customerId used by the user.
	 * @param pin
	 *           The raw pin entered by the user.
	 * @param authSessionId
	 *           Authentication sessionId
	 * @param authSessionType
	 *           Reason for authentication
	 * @param clientType
	 *           Client type used.
	 * @param clientVersion
	 *           Client version
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return The VCryptAuthResult object
	 */
	VCryptAuthResult authenticatePin(String customerId, String pin, Long authSessionId, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint);

	/**
	 * This method generates a new wheel with creating the VCryptAuthSession
	 * object.
	 * 
	 * @param length
	 *           of the wheel
	 * @param sets
	 *           number of sets
	 * @param previousAuthSessionId
	 *           previous authentication session id (if available)
	 * @param authSessionType
	 *           What type of authentication session this is. It could be login,
	 *           in-session, pin reset, etc.
	 * @param clientType
	 *           what type of client is used for authentication
	 * @param clientVersion
	 *           what is the version of the client
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return a <code>VCryptWheel</code> value
	 */
	VCryptWheel genWheel(int length, int sets, Long previousAuthSessionId, int authSessionType, int clientType, String clientVersion, String ipAddress, int fingerPrintType, String fingerPrint);

	/**
	 * This method authenticates the PIN entered by the user using the slider.
	 * 
	 * @param customerId
	 *           CustomerId used by the user
	 * @param displacements
	 *           Displacement of the marker
	 * @param authStats
	 *           Hash map of user input metrics, like time taken, etc.
	 * @param authSessionId
	 *           The Id of the auth session
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return a <code>VCryptAuthResult</code> value
	 */
	VCryptAuthResult authenticateSlider(String customerId, Vector displacements, Map authStats, Long authSessionId, String ipAddress, int fingerPrintType, String fingerPrint);

	/**
	 * This method authenticates the PIN entered by the user using the slider.
	 * This passess the PIN to be used for authentication. This method is usually
	 * used for PIN reset utility program.
	 * 
	 * @param customerId
	 *           CustomerId used by the user
	 * @param pin
	 *           a <code>String</code> value
	 * @param displacements
	 *           Displacement of the marker
	 * @param authStats
	 *           Hash map of user input metrics, like time taken, etc.
	 * @param authSessionId
	 *           The session Id for this authentication
	 * @param ipAddress
	 *           IP address of the user device.
	 * @param fingerPrintType
	 *           Type of finger printing
	 * @param fingerPrint
	 *           Finger print
	 * @return a <code>VCryptAuthResult</code> value
	 */
	VCryptAuthResult authenticateSlider(String customerId, String pin, Vector displacements, Map authStats, Long authSessionId, String ipAddress, int fingerPrintType, String fingerPrint);

	/**
	 * Sets a new PIN for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param PIN
	 *           New PIN to set
	 * @param pinStatus
	 *           Status of the PIN, like one time, etc.
	 * @return whether the operation was success or failure
	 */
	boolean setPIN(String customerId, String PIN, int pinStatus);

	/**
	 * Sets a new password for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param password
	 *           New password to set
	 * @param passwordStatus
	 *           Status of the Password, like one time, etc.
	 * @return whether the operation was success or failure
	 */
	boolean setPassword(String customerId, String password, int passwordStatus);

	/**
	 * Sets a new image for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param imagePath
	 *           Path to the image file
	 * @return whether the operation was success or failure
	 */
	boolean setImage(String customerId, String imagePath);

    /**
     * Sets a new caption for the specified user
     * If caption is null, A caption with default locale is set.
     *
     * @param customerId
     *           user login Id
     * @param caption
     *           New caption to set
     * @return whether the operation was success or failure
     */
	boolean setCaption(String customerId, String caption);

    /**
     * Sets a new caption for the specified user
     * If caption is null, A caption with default locale and default text is set.
     *
     * @param customerId
     *           user login Id
     * @param caption
     *           New caption to set
     * @return whether the operation was success or failure
     */
	boolean setCaption(String customerId, VCryptLocalizedString caption);

	/**
	 * This sets the Image and caption for the user.
	 * If caption is null, A caption with default locale is set.
     * 
	 * @param customerId
	 *           user customerId
	 * @param imagePath
	 *           Path to the image file
	 * @param caption
	 *           Caption to set for user
	 * @return a <code>boolean</code> value
	 */
	boolean setImageAndCaption(String customerId, String imagePath, String caption);

    /**
     * This sets the Image and caption for the user.
     * If caption is null, A caption with default locale and a default text is set.
     *
     * @param customerId
     *           user customerId
     * @param imagePath
     *           Path to the image file
     * @param caption
     *           Caption to set for user
     * @return a <code>boolean</code> value
     */
	boolean setImageAndCaption(String customerId, String imagePath, VCryptLocalizedString caption);

	/**
	 * Sets a authMode for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param authMode
	 *           New authMode to set
	 * @return whether the operation was success or failure
	 */
	boolean setUserAuthMode(String customerId, int authMode);

	/**
	 * Set authmode of <code>customerGroupId</code> users to
	 * <code>authMode</code> <p/> Uses batch updates and failure is not
	 * guaranteed to leave the system in old auth mode as failure may occur in
	 * later batch, after initial batches are saved.
	 * 
	 * @param groupName
	 *           customerGroupId of the users
	 * @param authMode
	 *           new Auth mode
	 * @return true if update is successful
	 */
	boolean setGroupUsersAuthMode(String groupName, int authMode);

	/**
	 * Sets a status for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param status
	 *           New status to set
	 * @return whether the operation was success or failure
	 */
	boolean setUserStatus(String customerId, int status);

	/**
	 * Gets the imagePath for the user
	 * 
	 * @param customerId
	 *           user login Id
	 * @return Path to the image, null for invalid users and unexpected errors
	 */
	String getImage(String customerId);

	/**
	 * Gets the caption for the user
	 * 
	 * @param customerId
	 *           user login Id
	 * @return Caption string, null for invalid users and unexpected errors
	 */
	String getCaption(String customerId);
	VCryptLocalizedString getLocalizedCaption(String customerId);

	/**
	 * Gets the image path and caption for the user
	 * 
	 * @param customerId
	 *           user login Id
	 * @return String[0]= Image path, String[1] is Caption
	 */
	String[] getImageAndCaption(String customerId);
	Object[] getImageAndLocalizedCaption(String customerId);

	/**
	 * Gets the authMode for the user
	 * 
	 * @param customerId
	 *           user login Id
	 * @return authMode int
	 */
	int getUserAuthMode(String customerId);

	/**
	 * Gets the status for the user
	 * 
	 * @param customerId
	 *           user login Id
	 * @return status int, 0 is returned for invalid user and unexpcted errors
	 */
	int getUserStatus(String customerId);

	/**
	 * Gets all the secret questions available for the user.
	 * 
	 * @param customerId
	 *           The login id of the user to authenticate
	 * @return The 2-D array object containing the questions to ask. First
	 *         dimension denotes the number of (configurable) question pick sets
	 *         to display to user and the second dimension denotes the number of
	 *         questions in each pick set.
	 */
	VCryptQuestion[][] getSignOnQuestions(String customerId);
    /**
     *
     * @param customerId
     *              The login id of the user to authenticate
     * @param aLocale The Locale to return in. If passed null, null is returned.
     *        Use getSignOnQuestions(String > customerId), if default locale is to be used.
     * @return The 2-D array object containing the questions to ask. First
     *         dimension denotes the number of (configurable) question pick sets
     *         to display to user and the second dimension denotes the number of
     *         questions in each pick set.
     */
	VCryptQuestion[][] getSignOnQuestions(String customerId, VCryptLocale aLocale);

	/**
	 * Get user questions
	 * 
	 * @param customerId
	 *           customer Id
	 * @return Array of <code>VCryptQuestion</code>, null incase of invalid
	 *         users and unexpected erros
	 */
	VCryptQuestion[] getAllMappedSignOnQuestions(String customerId);

	/**
	 * Delete all sign on questions for the given user
	 * 
	 * @param customerId
	 *           customer id
	 * @return boolean if success
	 */
	boolean deleteAllSignOnQuestions(String customerId);

	/**
	 * Adds a new question for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param question
	 *           New question to be added. Overrides if the same question is
	 *           already set for this user.
	 * @return whether the operation was success or failure
	 */

	VCryptResponse addQuestion(String customerId, VCryptQuestion question);

	/**
	 * Adds a new question for the specified user
	 * 
	 * @param requestId
	 *           Bharosa Request Id
	 * @param customerId
	 *           user login Id
	 * @param question
	 *           New question to be added. Overrides if the same question is
	 *           already set for this user.
	 * @return whether the operation was success or failure
	 */
	VCryptResponse addQuestion(String requestId, String customerId, VCryptQuestion question);

	/**
	 * Add questions to the customer
	 * 
	 * Expects the number of questions to be exactly equal to the required number
	 * of questions Calling this method will delete any previously existing
	 * quesions Success indicates adding all questions, failure means none of the
	 * questions are added.
	 * 
	 * @param customerId
	 *           user login Id
	 * @param questions
	 *           New questions to be added. Overrides if the same question is
	 *           already set for this user.
	 * @return whether the operation was success or failure
	 */
	VCryptResponse addQuestions(String customerId, VCryptQuestion[] questions);

	/**
	 * Add questions to the customer
	 * 
	 * Expects the number of questions to be exactly equal to the required number
	 * of questions Calling this method will delete any previously existing
	 * quesions Success indicates adding all questions, failure means none of the
	 * questions are added.
	 * 
	 * @param requestId
	 *           Bharosa Request Id
	 * @param customerId
	 *           customerId
	 * @param questions
	 *           Question
	 * @return VCryptResponse to get response status and message
	 */
	VCryptResponse addQuestions(String requestId, String customerId, VCryptQuestion[] questions);

	/**
	 * Deletes the question for the specified user
	 * 
	 * @param customerId
	 *           user login Id
	 * @param question
	 *           The question to be deleted
	 * @return whether the operation was success or failure
	 */
	boolean deleteQuestion(String customerId, VCryptQuestion question);

	/**
	 * Gets a secret question for the user
	 * 
	 * @param customerId
	 *           The login id of the user to authenticate
	 * @return The object containing the question to ask
	 */
	VCryptQuestion getSecretQuestion(String customerId);

	/**
	 * Gets a secret question for the user for CSR policy
	 * 
	 * @param customerId
	 *           The login id of the user to authenticate
	 * @return The object containing the question to ask
	 */
	VCryptQuestion getSecretQuestionForCSR(String customerId);

	/**
	 * Move the current secret question for the user to next
	 * 
	 * @param customerId
	 *           The login id of the user to authenticate
	 * @return The object containing the question to ask, null in case of errors
	 */
	VCryptQuestion moveToNextSecretQuestion(String customerId);

	/**
	 * Method for authenticate question/answer
	 * 
	 * @param customerId
	 *           The login id of the user to authenticate
	 * @param answer
	 *           the answer given by the user
	 * @return VCryptAuthResult describing result of authentication attempt
	 */
	VCryptAuthResult authenticateQuestion(String customerId, String answer);

	/**
	 * Method for authenticate question/answer
	 * 
	 * @param requestId           requestId
	 * @param challengeChannel    IBharosaConstants.ENUM_CHALLENGE_CHANNEL
	 * @param customerId          The login id of the user to authenticate
	 * @param answer              The answer given by the user
	 * @return VCryptAuthResult describing result of authentication attempt
	 */
	VCryptAuthResult authenticateQuestion(String requestId, Integer challengeChannel, String customerId, String answer);

	/**
	 * Method for authenticate question/answer for customer care
	 * 
	 * @param requestId         requestId
	 * @param challengeChannel  IBharosaConstants.ENUM_CHALLENGE_CHANNEL
	 * @param customerId        The login id of the user to authenticate
	 * @param answer            The answer given by the user
	 * @return VCryptAuthResult describing result of authentication attempt
	 */
	VCryptAuthResult authenticateQuestionForCSR(String requestId, Integer challengeChannel, String customerId, String answer);

	/**
	 * Method for authenticate question/answer for CSR policy
	 * 
	 * @param customerId
	 *           The login id of the user to authenticate
	 * @param answer
	 *           the answer given by the user
	 * @return VCryptAuthResult describing result of authentication attempt
	 */
	VCryptAuthResult authenticateQuestionForCSR(String customerId, String answer);

}// end interface VCryptAuthInterface
