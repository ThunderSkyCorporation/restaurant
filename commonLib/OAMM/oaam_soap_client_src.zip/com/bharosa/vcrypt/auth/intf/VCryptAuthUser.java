package com.bharosa.vcrypt.auth.intf;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.List;
import java.util.Map;
import java.util.HashMap;

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.common.util.IBharosaConstants;


/**
 * Provides information about the user
 * 
 * @author bosco
 */

public class VCryptAuthUser implements java.io.Serializable {

    public static final String PREF_STATUS = "status";
    public static final String OTP_STATUS = "otpStatus";
    public static final String OTP_SMS_CHANNEL = "otpSMS";
    public static final String OTP_EMAIL_CHANNEL = "otpEmail";
    public static final String OTP_PREFERRED_CHANNEL = "otpPreferredChannel";

    String loginId = null;
    String bharosaUserId = null;
    String customerGroupId = null;
    String customerId = null;
    String fullName = null;
    List roles = null;
    Map securityPreferences = new HashMap();

    /**
     * Returns the loginId
     */
    public String getLoginId() {
        return loginId;
    }

    /**
     * Returns the bharosaUserId for this loginId. It returns null if the loginId
     * is invalid
     */
    public String getBharosaUserId() {
        return bharosaUserId;
    }

    /**
     * Returns the customerGroupId to which this user belongs to.
     * 
     * @return The user group id of the user. It will null if the user is not in
     *         the database or if there was some other exception.
     */
    public String getCustomerGroupId() {
        return customerGroupId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
        if (this.customerId != null && BharosaConfig.getBoolean("vcryptuser.customerid.lowercase", false)) {
            this.customerId = this.customerId.toLowerCase();
        }
    }

    /**
     * Returns the name of the user. Can be used for customizing the web page
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * Returns the list of roles associated with this user.
     * 
     * @return List of the Strings with Roles.
     */
    public List getRoles() {
        return roles;
    }

    /**
     * Returns user security preferences
     * 
     * @return Name Value pair of preferences
     */
    public Map getSecurityPreferences() {
        return securityPreferences;
    }

    /**
     * Sets the value of loginId
     * 
     * @param argLoginId
     *           Value to assign to this.loginId
     */
    public void setLoginId(String argLoginId) {
        this.loginId = argLoginId;
        if (this.loginId != null && BharosaConfig.getBoolean("vcryptuser.loginid.lowercase", false)) {
            this.loginId = this.loginId.toLowerCase();
        }
    }

    /**
     * Sets the value of bharosaUserId
     * 
     * @param argUserId
     *           Value to assign to this.bharosaUserId
     */
    public void setBharosaUserId(String argUserId) {
        this.bharosaUserId = argUserId;
    }

    /**
     * Sets the value of customerGroupId
     * 
     * @param argGroupId
     *           Value to assign to this.customerGroupId
     */
    public void setCustomerGroupId(String argGroupId) {
        this.customerGroupId = argGroupId;
    }

    /**
     * Sets the value of fullName
     * 
     * @param argUserName
     *           Value to assign to this.fullName
     */
    public void setFullName(String argUserName) {
        this.fullName = argUserName;
    }

    /**
     * Sets the value of roles
     * 
     * @param argRoles
     *           Value to assign to this.roles
     */
    public void setRoles(List argRoles) {
        this.roles = argRoles;
    }

    /**
     * Sets the value of securityPreferences
     * 
     * @param argSecurityPreferences
     *           Value to assign to this.securityPreferences
     */
    public void setSecurityPreferences(Map argSecurityPreferences) {
        this.securityPreferences = argSecurityPreferences;
    }

    public int getRegistrationStatus() {
        return getStatus();
    }

    public int getQuestionStatus() {
        String status = (String) securityPreferences.get(VCryptAuth.QUESTION_STATUS);
        return parseInt(status, 0);
    }

    public int getImageStatus() {
        String status = (String) securityPreferences.get(VCryptAuth.IMAGE_STATUS);
        return parseInt(status, 0);
    }

    public int getPhraseStatus() {
        String status = (String) securityPreferences.get(VCryptAuth.PHRASE_STATUS);
        return parseInt(status, 0);
    }

    public int getStatus() {
        String status = (String) securityPreferences.get(VCryptAuthUser.PREF_STATUS);
        return parseInt(status, 0);
    }

    public VCryptLocalizedString getCaption(){
        String captionText = (String)  securityPreferences.get("personalNote");
        String language = (String) securityPreferences.get("localeLanguage");
        String country = (String) securityPreferences.get("localeCountry");
        String variant = (String) securityPreferences.get("localeVariant");
        VCryptLocale captionLocale = new VCryptLocale((language == null) ? "" : language,(country == null) ? "" : country,(variant == null) ? "" : variant);
        return new VCryptLocalizedString(captionText, captionLocale);
    }
    
    public void setCaption(VCryptLocalizedString caption){
        if (caption != null){
            securityPreferences.put("personalNote", caption.getText());
            
            VCryptLocale captionLocale = caption.getLocale();
            if (captionLocale != null){
                securityPreferences.put("localeLanguage", captionLocale.getLanguage());
                securityPreferences.put("localeCountry", captionLocale.getCountry());
                securityPreferences.put("localeVariant", captionLocale.getVariant());
            }
        }
    }
    
    public void setCaption(String captionText, VCryptLocale captionLocale){
        securityPreferences.put("personalNote", captionText);
        
        if (captionLocale != null){
            securityPreferences.put("localeLanguage", captionLocale.getLanguage());
            securityPreferences.put("localeCountry", captionLocale.getCountry());
            securityPreferences.put("localeVariant", captionLocale.getVariant());
        }
    }
    
    public VCryptLocale getCaptionLocale() {
        String language = (String) securityPreferences.get("localeLanguage");
        String country = (String) securityPreferences.get("localeCountry");
        String variant = (String) securityPreferences.get("localeVariant");
        return new VCryptLocale(
                (language == null) ? "" : language, 
                (country == null) ? "" : country, 
                (variant == null) ? "" : variant
        );
    }
    
    public void setCaptionLocale(VCryptLocale locale) {
        securityPreferences.put("localeLanguage", locale.getLanguage());
        securityPreferences.put("localeCountry", locale.getCountry());
        securityPreferences.put("localeVariant", locale.getVariant());
    }
    
    public String getUserData(String key){
        String retVal = (String) securityPreferences.get(key);
        if (StringUtil.isEmpty(retVal)){
            retVal = (String) securityPreferences.get(IBharosaConstants.VCRYPT_USER_DATA_PREFIX + key);
        }
        
        return retVal;
    }
    
    public void setUserData(String key, String value){
        if (!key.startsWith(IBharosaConstants.VCRYPT_USER_DATA_PREFIX)){
            key = IBharosaConstants.VCRYPT_USER_DATA_PREFIX + key;
        }
        securityPreferences.put(key, value);		
    }
    
    private int parseInt(String str, int defaultValue) {
        if (str != null) {
            try {
                return Integer.parseInt(str);
            } catch (Exception excp) {
                    // ignore parsing exception
            }
        }

        return defaultValue;
    }

    public String toString() {
        return "VCryptAuthUser{" + "loginId='" + loginId + "'" + ", bharosaUserId='" + bharosaUserId + "'" + ", customerGroupId='" + customerGroupId + "'" + ", customerId='" + customerId + "'" + ", fullName='" + fullName + "'" + ", roles=" + roles + ", securityPreferences=" + securityPreferences + "}";
    }
    
}
