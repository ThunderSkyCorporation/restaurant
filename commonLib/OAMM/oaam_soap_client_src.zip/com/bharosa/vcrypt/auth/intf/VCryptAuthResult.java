package com.bharosa.vcrypt.auth.intf;
/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.List;
import java.util.ArrayList;

/**
 * Provides information about authentication results
 * @author Luke
 */

public class VCryptAuthResult implements java.io.Serializable { 

	int resultCode;
	String loginId = null;
	String bharosaUserId = null;
    String customerId = null;
    String customerGroupId = null;
    ArrayList roles = new ArrayList();
	String userName = null;
	int defaultAuthMode = -1;
	Long authSessionId = null;

	public VCryptAuthResult(){
		resultCode = 10;
	}
	
	public VCryptAuthResult(int rcode){
		resultCode = rcode;
	}

	/**
	 * Returns the result code
	 * @return result code<br>
	 */	
	public int getCode(){ return resultCode; }
	
	
	/**
	 * Sets the value of resultCode
	 *
	 * @param argResultCode Value to assign to this.resultCode
	 */
	public void setCode(int argResultCode){
		this.resultCode = argResultCode;
	}

	
	/**
	 * Gets the value of loginId
	 *
	 * @return the value of loginId
	 */
	public String getLoginId() {
		return this.loginId;
	}

	/**
	 * Sets the value of loginId
	 *
	 * @param argLoginId Value to assign to this.loginId
	 */
	public void setLoginId(String argLoginId){
		this.loginId = argLoginId;
	}

	/**
	 * Gets the value of bharosaUserId
	 *
	 * @return the value of bharosaUserId
	 */
	public String getBharosaUserId() {
		return this.bharosaUserId;
	}

	/**
	 * Sets the value of bharosaUserId
	 *
	 * @param argUserId Value to assign to this.bharosaUserId
	 */
	public void setBharosaUserId(String argUserId){
		this.bharosaUserId = argUserId;
	}

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    /**
	 * Gets the value of customerGroupId
	 *
	 * @return the value of customerGroupId
	 */
	public String getCustomerGroupId() {
		return this.customerGroupId;
	}

	/**
	 * Sets the value of customerGroupId
	 *
	 * @param argGroupId Value to assign to this.customerGroupId
	 */
	public void setCustomerGroupId(String argGroupId){
		this.customerGroupId = argGroupId;
	}

	/**
	 * Gets the value of roles
	 *
	 * @return the value of roles
	 */
	public List getRoles() {
		return this.roles;
	}

	/**
	 * Sets the value of roles
	 *
	 * @param argRoles Value to assign to this.roles
	 */
	public void setRoles(ArrayList argRoles){
		this.roles = argRoles;
	}

	
	/**
	 * Gets the value of resultCode
	 *
	 * @return the value of resultCode
	 */
	public int getResultCode() {
		return this.resultCode;
	}

	/**
	 * Sets the value of resultCode
	 *
	 * @param argResultCode Value to assign to this.resultCode
	 */
	public void setResultCode(int argResultCode){
		this.resultCode = argResultCode;
	}

	/**
	 * Gets the value of userName
	 *
	 * @return the value of userName
	 */
	public String getUserName() {
		return this.userName;
	}

	/**
	 * Sets the value of userName
	 *
	 * @param argUserName Value to assign to this.userName
	 */
	public void setUserName(String argUserName){
		this.userName = argUserName;
	}

	/**
	 * Gets the value of defaultAuthMode
	 *
	 * @return the value of defaultAuthMode
	 */
	public int getDefaultAuthMode() {
		return this.defaultAuthMode;
	}

	/**
	 * Sets the value of defaultAuthMode
	 *
	 * @param argDefaultAuthMode Value to assign to this.defaultAuthMode
	 */
	public void setDefaultAuthMode(int argDefaultAuthMode){
		this.defaultAuthMode = argDefaultAuthMode;
	}

	
	/**
	 * Gets the value of authSessionId
	 *
	 * @return the value of authSessionId
	 */
	public Long getAuthSessionId() {
		return this.authSessionId;
	}

	/**
	 * Sets the value of authSessionId
	 *
	 * @param argAuthSessionId Value to assign to this.authSessionId
	 */
		public void setAuthSessionId(Long argAuthSessionId){
			this.authSessionId = argAuthSessionId;
		}

} 
