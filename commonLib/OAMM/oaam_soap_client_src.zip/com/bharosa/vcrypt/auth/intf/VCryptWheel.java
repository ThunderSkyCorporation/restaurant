package com.bharosa.vcrypt.auth.intf;
/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.List;

/**
 * Used to encapsulate the wheel/slider data
 * @author bosco
 */

public class VCryptWheel implements java.io.Serializable{

	Long authSessionId = null;
	String wheel = null;

	
	/**
	 * Gets the value of authSessionId
	 *
	 * @return the value of authSessionId
	 */
	public Long getAuthSessionId() {
		return this.authSessionId;
	}

	/**
	 * Sets the value of authSessionId
	 *
	 * @param argAuthSessionId Value to assign to this.authSessionId
	 */
	public void setAuthSessionId(Long argAuthSessionId){
		this.authSessionId = argAuthSessionId;
	}

	/**
	 * Gets the value of wheel
	 *
	 * @return the value of wheel
	 */
	public String getWheel() {
		return this.wheel;
	}

	/**
	 * Sets the value of wheel
	 *
	 * @param argWheel Value to assign to this.wheel
	 */
	public void setWheel(String argWheel){
		this.wheel = argWheel;
	}

}
