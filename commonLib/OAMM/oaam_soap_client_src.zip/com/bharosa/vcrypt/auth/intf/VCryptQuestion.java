package com.bharosa.vcrypt.auth.intf;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

/**
 * Used to encapsulate the question data
 * 
 * @author bosco
 */

public class VCryptQuestion implements Serializable {

	private static final long serialVersionUID = 4171036453458081361L;
	Long authSessionId = null;
	Long questionId = null;
	VCryptLocale locale = new VCryptLocale();
	String question = null;
	List answerList = null;

	public VCryptQuestion() {
	}
	
	/**
	 * Gets the value of authSessionId
	 * 
	 * @return the value of authSessionId
	 */
	public Long getAuthSessionId() {
		return this.authSessionId;
	}

	/**
	 * Sets the value of authSessionId
	 * 
	 * @param argAuthSessionId
	 *           Value to assign to this.authSessionId
	 */
	public void setAuthSessionId(Long argAuthSessionId) {
		this.authSessionId = argAuthSessionId;
	}

	/**
	 * Gets the value of questionId
	 * 
	 * @return the value of questionId
	 */
	public Long getQuestionId() {
		return this.questionId;
	}

	/**
	 * Sets the value of question
	 * 
	 * @param argQuestionId
	 *           Value to assign to this.questionId
	 */
	public void setQuestionId(Long argQuestionId) {
		this.questionId = argQuestionId;
	}

	/**
	 * Gets the value of question
	 * 
	 * @return the value of question
	 */
	public String getQuestion() {
		return this.question;
	}

	/**
	 * Sets the value of question
	 * 
	 * @param argQuestion
	 *           Value to assign to this.question
	 */
	public void setQuestion(String argQuestion) {
		this.question = argQuestion;
	}

	public VCryptLocale getLocale() {
		return locale;
	}

	public void setLocale(VCryptLocale locale) {
		this.locale = locale;
	}

	/**
	 * Gets the value of answerList
	 * 
	 * @return the value of answerList
	 */
	public List getAnswerList() {
		return this.answerList;
	}

	/**
	 * Sets the value of answerList
	 * 
	 * @param argAnswerList
	 *           Value to assign to this.answerList
	 */
	public void setAnswerList(List argAnswerList) {
		this.answerList = argAnswerList;
	}

	public String toString() {
		return "VCryptQuestion{" + "authSessionId=" + authSessionId + ", questionId=" + questionId + ", question='" + question + '\'' + '}';
	}

	public VCryptQuestion getNonMutableInstance() {
		return new XVCryptQuestion(this);
	}
}

class XVCryptQuestion extends VCryptQuestion {
	VCryptQuestion base = null;

	XVCryptQuestion(VCryptQuestion parent) {
		this.base = parent;
	}

	public Long getAuthSessionId() {
		return base.getAuthSessionId();
	}

	public void setAuthSessionId(Long argAuthSessionId) {
		throw new UnsupportedOperationException("Object is non mutable.");
	}

	public Long getQuestionId() {
		return base.getQuestionId();
	}

	public void setQuestionId(Long argQuestionId) {
		throw new UnsupportedOperationException("Object is non mutable.");
	}

	public String getQuestion() {
		return base.getQuestion();
	}

	public void setQuestion(String argQuestion) {
		throw new UnsupportedOperationException("Object is non mutable.");
	}

	public VCryptLocale getLocale() {
		return base.getLocale();
	}

	public void setLocale(VCryptLocale aLocale) {
		throw new UnsupportedOperationException("Object is non mutable.");
	}

	public List getAnswerList() {
		return (base.getAnswerList() != null) ? Collections.unmodifiableList(base.getAnswerList()) : Collections.EMPTY_LIST;
	}

	public void setAnswerList(List argAnswerList) {
		throw new UnsupportedOperationException("Object is non mutable.");
	}

	public String toString() {
		return base.toString();
	}
}