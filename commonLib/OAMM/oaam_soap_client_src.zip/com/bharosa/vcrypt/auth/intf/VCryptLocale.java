package com.bharosa.vcrypt.auth.intf;

import java.io.Serializable;
import java.util.Locale;

import com.bharosa.common.util.BharosaLocale;

public class VCryptLocale implements Serializable {
	private static final long serialVersionUID = -6904703002950491378L;
	Locale locale;
	
	public VCryptLocale() {
		this (BharosaLocale.getDefaultLocale());
	}
	
	public VCryptLocale(String language) {
		this(new Locale(language, "", ""));
	}

	public VCryptLocale(String language, String country) {
		this(new Locale(language, country, ""));
	}

	public VCryptLocale(String language, String country, String variant) {
		this(new Locale(language, country, variant));
	}
	
	public VCryptLocale(Locale aLocale) {
		if (aLocale == null) throw new NullPointerException("VCryptLocale constructed with null Locale");
		this.locale = aLocale;
	}

	public String getLanguage() {
		return locale.getLanguage();
	}

	public String getCountry() {
		return locale.getCountry();
	}

	public String getVariant() {
		return locale.getVariant();
	}

	public Locale getLocale() {
		return new Locale(getLanguage(), getCountry(), getVariant());
	}
	
	public void setLocale(Locale aLocale) {
		this.locale = aLocale;
	}
	
	public String toString() {
		return getLocale().toString();
	}
	//@Override
	public boolean equals(Object obj) {
		return obj instanceof VCryptLocale && equals((VCryptLocale) obj);
	}
	public boolean equals(VCryptLocale obj) {
		return locale.equals(obj.getLocale());
	}
	//@Override
	public int hashCode() {
		return locale.hashCode();
	}
}
