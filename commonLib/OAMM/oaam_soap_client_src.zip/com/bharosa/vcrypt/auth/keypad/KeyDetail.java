package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.awt.*;
import java.io.Serializable;

public class KeyDetail implements Serializable {
	String keyName = null;
	String altKeyName = null;
	String shiftKeyName = null;
	String keyValue = null;
	String altKeyValue = null;
	String shiftKeyValue = null;
	String fileName = null;
	String altFileName = null;
	String shiftFileName = null;
	boolean isActive = true;
	boolean isEmbedded = true;
	boolean useExternalText = false;
	Rectangle area = null;

	boolean textFrameFlag = false;
	boolean textWrapFlag = true;
	String textFontName = "Verdana";

  String textFontColor = "000000";
  int textFontType = Font.PLAIN;
	int textFontSize = 9;
	int textWidth = 9;
	int textHeight= 9;
	int widthJitter  = 0;
	int heightJitter = 0;

	public KeyDetail() {
	}

	public KeyDetail( String keyName, Rectangle area ) {
			this.keyName = keyName;
			this.keyValue = keyName;
			this.altKeyValue = keyName;
			this.area = area;
			this.isActive = false;
	}

	public KeyDetail( String keyName, String keyValue, Rectangle area ) {
		this.keyName = keyName;
		this.keyValue = keyValue;
		this.area = area;
		this.isActive = false;
	}

	public KeyDetail( String fileName, String keyValue ) {
		this.fileName = fileName;
		this.keyValue = keyValue;
	}

	public KeyDetail( String fileName, String keyValue, String altKeyValue ) {
		this.fileName = fileName;
		this.keyValue = keyValue;
		this.altKeyValue = altKeyValue;
	}

	public KeyDetail( String fileName, String keyValue, String altKeyValue, int widthJitter, int heightJitter ) {
		this.fileName = fileName;
		this.keyValue = keyValue;
		this.altKeyValue = altKeyValue;
		this.widthJitter = widthJitter;
		this.heightJitter = heightJitter;
	}

	public KeyDetail( String keyName, String fileName, String keyValue, Rectangle area ) {
			this.keyName = keyName;
			this.fileName = fileName;
			this.keyValue = keyValue;
			this.area = area;
	}

	public KeyDetail( String keyName, String fileName, String altFileName, String keyValue, String altKeyValue, Rectangle area ) {
		this.keyName = keyName;
		this.fileName = fileName;
		this.altFileName = altFileName;
		this.keyValue = keyValue;
		this.altKeyValue = altKeyValue;
		this.area = area;
	}

	public KeyDetail( String keyName, String keyValue, boolean isActive, Rectangle area, boolean isEmbedded ) {
		this.keyName = keyName;
		this.keyValue = keyValue;
		this.isActive = isActive;
		this.area = area;
		this.isEmbedded = isEmbedded;
	}

	public KeyDetail( String keyName, String fileName, String keyValue, boolean isActive, Rectangle area ) {
		this.keyName = keyName;
		this.fileName = fileName;
		this.keyValue = keyValue;
		this.isActive = isActive;
		this.area = area;
	}

	public KeyDetail( String keyName, String fileName, String altFileName, String keyValue, String altKeyValue, Rectangle area, boolean isEmbedded  ) {
		this.keyName = keyName;
		this.fileName = fileName;
		this.keyValue = keyValue;
		this.area = area;
		this.isEmbedded = isEmbedded;
	}

	public KeyDetail( String keyName, String altKeyName, String fileName, String altFileName, String keyValue, String altKeyValue, Rectangle area, boolean isEmbedded ) {
		this.keyName = keyName;
		this.altKeyName = altKeyName;
		this.fileName = fileName;
		this.altFileName = altFileName;
		this.keyValue = keyValue;
		this.altKeyValue = altKeyValue;
		this.isEmbedded = isEmbedded;
		this.area = area;
	}

	public KeyDetail( String keyName, String altKeyName, String shiftKeyName, String fileName, String altFileName, String shiftFileName, String keyValue, String altKeyValue, String shiftKeyValue, Rectangle area, boolean isEmbedded ) {
		this.keyName = keyName;
		this.altKeyName = altKeyName;
		this.shiftKeyName = shiftKeyName;
		this.fileName = fileName;
		this.altFileName = altFileName;
		this.shiftFileName = shiftFileName;
		this.keyValue = keyValue;
		this.altKeyValue = altKeyValue;
		this.shiftKeyValue = shiftKeyValue;
		this.isEmbedded = isEmbedded;
		this.area = area;
	}


	/**
	 * Gets the value of keyName
	 *
	 * @return the value of keyName
	 */
	public String getKeyName() {
		return this.keyName;
	}

	/**
	 * Sets the value of keyName
	 *
	 * @param argKeyName Value to assign to this.keyName
	 */
	public void setKeyName(String argKeyName){
		this.keyName = argKeyName;
	}

	/**
	 * Gets the value of altKeyName
	 *
	 * @return the value of altKeyName
	 */
	public String getAltKeyName() {
		return this.altKeyName;
	}

	/**
	 * Sets the value of altKeyName
	 *
	 * @param argaAltKeyName Value to assign to this.altKeyName
	 */
	public void setAltKeyName(String argAltKeyName){
		this.altKeyName = argAltKeyName;
	}

	/**
	 * Gets the value of shiftKeyName
	 *
	 * @return the value of shiftKeyName
	 */
	public String getShiftKeyName() {
		return this.shiftKeyName;
	}

	/**
	 * Sets the value of shiftKeyName
	 *
	 * @param argShiftKeyName Value to assign to this.shiftKeyName
	 */
	public void setShiftKeyName(String argShiftKeyName){
		this.shiftKeyName = argShiftKeyName;
	}


	/**
	 * Gets the value of keyValue
	 *
	 * @return the value of keyValue
	 */
	public String getKeyValue() {
		return this.keyValue;
	}

	/**
	 * Sets the value of keyValue
	 *
	 * @param argKeyValue Value to assign to this.keyValue
	 */
	public void setKeyValue(String argKeyValue){
		this.keyValue = argKeyValue;
	}


	/**
	 * Gets the value of altKeyValue
	 *
	 * @return the value of altKeyValue
	 */
	public String getAltKeyValue() {
		return this.altKeyValue;
	}

	/**
	 * Sets the value of altKeyValue
	 *
	 * @param argAltKeyValue Value to assign to this.altKeyValue
	 */
	public void setAltKeyValue(String argAltKeyValue){
		this.altKeyValue = argAltKeyValue;
	}

	/**
	 * Gets the value of shiftKeyValue
	 *
	 * @return the value of shiftKeyValue
	 */
	public String getShiftKeyValue() {
		return this.shiftKeyValue;
	}

	/**
	 * Sets the value of shiftKeyValue
	 *
	 * @param argShiftKeyValue Value to assign to this.shiftKeyValue
	 */
	public void setShiftKeyValue(String argShiftKeyValue){
		this.shiftKeyValue = argShiftKeyValue;
	}

	/**
	 * Gets the value of fileName
	 *
	 * @return the value of fileName
	 */
	public String getFileName() {
		return this.fileName;
	}

	/**
	 * Sets the value of fileName
	 *
	 * @param argFileName Value to assign to this.fileName
	 */
	public void setFileName(String argFileName){
		this.fileName = argFileName;
	}


	/**
	 * Gets the value of altFileName
	 *
	 * @return the value of altFileName
	 */
	public String getAltFileName() {
		return this.altFileName;
	}

	/**
	 * Sets the value of altFileName
	 *
	 * @param argAltFileName Value to assign to this.altFileName
	 */
	public void setAltFileName(String argAltFileName){
		this.altFileName = argAltFileName;
	}


	/**
	 * Gets the value of shiftFileName
	 *
	 * @return the value of shiftFileName
	 */
	public String getShiftFileName() {
		return this.shiftFileName;
	}

	/**
	 * Sets the value of shiftFileName
	 *
	 * @param argShiftFileName Value to assign to this.shiftFileName
	 */
	public void setShiftFileName(String argShiftFileName){
		this.shiftFileName = argShiftFileName;
	}

	/**
	 * Gets the value of isActive
	 *
	 * @return the value of isActive
	 */
	public boolean isActive() {
		return this.isActive;
	}


	/**
	 * Gets the value of isEmbedded
	 *
	 * @return the value of isEmbedded
	 */
	public boolean isEmbedded() {
		return this.isEmbedded;
	}

	/**
	 * Gets the value of useExternalText
	 *
	 * @return the value of useExternalText
	 */
	public boolean useExternalText() {
		return this.useExternalText;
	}


	/**
	 * Gets the value of area
	 *
	 * @return the value of area
	 */
	public Rectangle getArea() {
		return this.area;
	}

	/**
	 * Sets the value of area
	 *
	 * @param argArea Value to assign to this.area
	 */
	public void setArea(Rectangle argArea){
		this.area = argArea;
	}

	/**
	 * Gets the value of textFrameFlag
	 *
	 * @return the value of textFrameFlag
	 */
	public boolean getTextFrameFlag() {
		return this.textFrameFlag;
	}

	/**
	 * Sets the value of textFrameFlag
	 *
	 * @param argTextFrameFlag Value to assign to this.textFrameFlag
	 */
	public void setTextFrameFlag(boolean argTextFrameFlag){
		this.textFrameFlag = argTextFrameFlag;
	}

	/**
	 * Gets the value of textWrapFlag
	 *
	 * @return the value of textWrapFlag
	 */
	public boolean getTextWrapFlag() {
		return this.textWrapFlag;
	}

	/**
	 * Sets the value of textWrapFlag
	 *
	 * @param argTextFrameFlag Value to assign to this.textFrameFlag
	 */
	public void setTextWrapFlag(boolean argTextWrapFlag){
		this.textWrapFlag = argTextWrapFlag;
	}

	/**
	 * Gets the value of textFontName
	 *
	 * @return the value of textFontName
	 */
	public String getTextFontName() {
		return this.textFontName;
	}

	/**
	 * Sets the value of textFontName
	 *
	 * @param argTextFrameFlag Value to assign to this.textFontName
	 */
	public void setTextFontName(String argTextFontName){
		this.textFontName = argTextFontName;
	}

  /**
     * Gets the value of textFontColor
     *
     * @return the value of textFontColor
     */
	  public String getTextFontColor() {
      return textFontColor;
    }

  /**
   * Sets the value of textFontColor
   *
   * @param argTextFontColor Value to assign to this.textFontColor
   */
   public void setTextFontColor(String argTextFontColor) {
      this.textFontColor = argTextFontColor;
   }


  /**
	 * Gets the value of textFontType
	 *
	 * @return the value of textFontType
	 */
	public int getTextFontType() {
		return this.textFontType;
	}

	/**
	 * Sets the value of textFontType
	 *
	 * @param argTextFontType Value to assign to this.textFontType
	 */
	public void setTextFontType(int argTextFontType){
		this.textFontType = argTextFontType;
	}

	/**
	 * Gets the value of textFontSize
	 *
	 * @return the value of textFontSize
	 */
	public int getTextFontSize() {
		return this.textFontSize;
	}

	/**
	 * Sets the value of textFontSize
	 *
	 * @param argTextFontSize Value to assign to this.textFontSize
	 */
	public void setTextFontSize(int argTextFontSize){
		this.textFontSize = argTextFontSize;
	}


	/**
	 * Gets the value of textWidth
	 *
	 * @return the value of textWidth
	 */
	public int getTextWidth() {
		return this.textWidth;
	}

	/**
	 * Sets the value of textWidth
	 *
	 * @param argTextWidth Value to assign to this.textWidth
	 */
	public void setTextWidth(int argTextWidth){
		this.textWidth = argTextWidth;
	}

	/**
	 * Gets the value of textHeight
	 *
	 * @return the value of textHeight
	 */
	public int getTextHeight() {
		return this.textHeight;
	}

	/**
	 * Sets the value of textHeight
	 *
	 * @param argTextHeight Value to assign to this.textHeight
	 */
	public void setTextHeight(int argTextHeight){
		this.textHeight = argTextHeight;
	}

	/**
	 * Gets the padding of key width
	 *
	 * @return the value of width pading
	 */
	public int getWidthJitter(){
		return this.widthJitter;
	}

	/**
	 * Gets the padding of key height
	 *
	 * @return the value of height pading
	 */
	public int getHeightJitter() {
		return this.heightJitter;
	}


	public String toString( ) {
		String str = "";
		str += "keyValue=" + keyValue + ", fileName=" + fileName
			+ ", isActive=" + isActive + ", area=" + area;
		return str;
	}
}
