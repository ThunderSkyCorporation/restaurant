package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.*;
import com.bharosa.vcrypt.auth.intf.VCryptLocalizedString;
import com.bharosa.common.logger.Logger;

import java.awt.Rectangle;

import java.io.Serializable;
import java.security.SecureRandom;
import java.util.*;

/**
 * This encapsulates all the properties for the KeyPad which was
 * generated for the given session.
 */

public abstract class AuthentiPad implements Serializable {
    static protected Logger logger = Logger.getLogger(AuthentiPad.class);

    protected static String PINPAD="T_PINPAD";
    protected static String KEYPAD="T_KEYPAD";
    protected static String QUESTIONPAD="T_QUESTIONPAD";
    protected static String CAPTIONPAD="T_CAPTIONPAD";
    protected static String CAPTIONCONFIRMPAD="T_CAPTIONCONFIRMPAD";
    protected static String TEXTPAD="T_TEXTPAD";
    protected static String TEXTPADRESET="T_TEXTPADRESET";

    protected static String NOIMG="NOIMG";

    protected double fileSizeEncryptValue = 1.0;

    protected String padType = null;
    protected String padProp = null;
    protected String padPropPrefix = "bharosa.authentipad";
    protected String padKeySetProp = "default";
    protected String padName = null;

    protected String imageFileName = null;
    protected String frameFileName = null;
    protected VCryptLocalizedString captionText = null;

    protected Date timeStamp = null;
    protected TimeZone timeZone = null;
    protected VCryptLocalizedString questionText = null;

    protected String userInput = null;
    protected boolean displayOnly = false;

    protected boolean hasImgs = true;
    protected boolean hasJS = true;

    protected String padId = null;

    protected boolean isInitialized = false;
    protected boolean isADACompliant = false;
    
    protected boolean useCaps = true;

    private static final Object counterLockObject = new Object();
    private static int uidCounter = 0;
    private static SecureRandom rand = new SecureRandom();

    protected AuthentiKey authKey = null;

    protected Rectangle authentiPadArea = null;

    protected transient AuthentiConfig authentiConfig = null;
    
    protected abstract PadImageDirectory getParentImageDir();
    
    protected AuthentiPad(String padName, String backgroundFilePath, String frameFilePath){
        this.padName = padName;
        this.imageFileName = backgroundFilePath;
        this.frameFileName = frameFilePath;
    }

    protected void initialize()
            throws ObjectNotCreatedException {

        padId = genNewUniqueId();

        if (StringUtil.isEmpty(padName)) {
            logger.error("AuthentiPad() padName is empty");
            throw ObjectNotCreatedException.createInvalidInputDataException();
        }

        if (StringUtil.isEmpty(imageFileName)) {
            logger.error("AuthentiPad() backgroundFile is empty");
            throw ObjectNotCreatedException.createInvalidInputDataException();
        }



    }

    private String genNewUniqueId() {
        String prefix;
        synchronized (counterLockObject) {
            prefix = "" + uidCounter++;
            try {
                //run the clock for 1 milli second, so we can get
                //a unique milli-second
                counterLockObject.wait(1);
            } catch (Exception ex) {
                logger.error("error while waiting for 1 milli second", ex);
            }
        }
        long time = System.currentTimeMillis();
        long randomNumber = rand.nextLong();

        String uid = prefix + "_" + time + "_" + randomNumber;
        return uid;
    }

    public AuthentiConfig getAuthentiConfig(){
    	if (authentiConfig == null){
    		authentiConfig = new AuthentiConfig(padPropPrefix, padProp, padKeySetProp, useCaps, captionText, timeStamp, timeZone);
    	}
    	
    	return authentiConfig;
    }
    
    private void prepare() {
        if (!this.isInitialized) {
            try {
                initialize();
                KeyPadUtil.createEncryptedKeyPad(this);
//                authKey = generateAuthentiKey();
				isInitialized = true;
            } catch (Exception e) {
                logger.error("Error initializing Authentipad", e);
            }
        }
    }

    /**
     * Gets the value of logger
     *
     * @return the value of logger
     */
    public static Logger getLogger() {
        return AuthentiPad.logger;
    }

    /**
     * Sets the value of logger
     *
     * @param argLogger Value to assign to this.logger
     */
    public static void setLogger(Logger argLogger) {
        AuthentiPad.logger = argLogger;
    }

    /**
     * Gets the value of padName
     *
     * @return the value of padName
     */
    public String getPadName() {
        return this.padName;
    }

    /**
     * Gets the value of captionText
     *
     * @return the value of captionText
     */
    public VCryptLocalizedString getCaptionText() {
        return this.captionText;
    }

    /**
     * Sets the value of captionText
     *
     * @param captionText Value to assign to this.captionText
     */
    public void setCaptionText(String captionText) {
        this.captionText = new VCryptLocalizedString(captionText);
    }

    /**
     * Sets the value of captionText
     *
     * @param captionText Value to assign to this.captionText
     * @param locale Locale of  captionText
     */
    public void setCaptionText(String captionText, Locale locale) {
        this.captionText = new VCryptLocalizedString(captionText, locale);
    }

    /**
     * Sets the value of captionText
     *
     * @param captionText Value to assign to this.captionText
     */
    public void setCaptionText(VCryptLocalizedString captionText) {
        this.captionText = captionText;
    }

    /**
     * Gets the value of questionText
     *
     * @return the value of questionText
     */
    public VCryptLocalizedString getQuestionText() {
        return this.questionText;
    }

    /**
     * Sets the value of questionText
     *
     * @param argQuestionText Value to assign to this.questionText
     */
    public void setQuestionText(String argQuestionText) {
        this.questionText = new VCryptLocalizedString(argQuestionText);
    }

    /**
     * Sets the value of questionText
     *
     * @param argQuestionText Value to assign to this.questionText
     * @param locale Locale of  questionText
     */
    public void setQuestionText(String argQuestionText, Locale locale) {
        this.questionText = new VCryptLocalizedString(argQuestionText, locale);
    }

    /**
     * Sets the value of questionText
     *
     * @param argQuestionText Value to assign to this.questionText
     */
    public void setQuestionText(VCryptLocalizedString argQuestionText) {
        this.questionText = argQuestionText;
    }

    /**
     * Gets the value of timeStamp
     *
     * @return the value of timeStamp
     */
    public Date getTimeStamp() {
        return timeStamp;
    }

    /**
     * Sets the value of timeStamp
     *
     * @param argTimeStamp Value to assign to this.timeStamp
     */
    public void setTimeStamp(Date argTimeStamp) {
        this.timeStamp = argTimeStamp;
    }

    /**
     * Gets the value of timeZone
     *
     * @return the value of timeZone
     */
    public TimeZone getTimeZone() {
        return timeZone;
    }

    /**
     * Sets the value of timeZone
     *
     * @param argTimeZone Value to assign to this.timeZone
     */
    public void setTimeZone(TimeZone argTimeZone) {
        this.timeZone = argTimeZone;
    }


    public String getPadKeySetProp() {
        return padKeySetProp;
    }

    public void setPadKeySetProp(String padKeySetProp) {
        this.padKeySetProp = padKeySetProp;
    }

    /**
     * Gets the value of displayOnly
     *
     * @return the value of displayOnly
     */
    public boolean getDisplayOnly() {
        return displayOnly;
    }

    /**
     * Sets the value of displayOnly
     *
     * @param argDisplayOnly Value to assign to this.displayOnly
     */
    public void setDisplayOnly(boolean argDisplayOnly) {
        this.displayOnly = argDisplayOnly;
    }

    /**
     * Gets the value of imageFileName
     *
     * @return the value of imageFileName
     */
    public String getImageFileName() {
        return this.imageFileName;
    }

    /**
     * Sets the value of imageFileName
     *
     * @param argImageFileName Value to assign to this.imageFileName
     */
    public void setImageFileName(String argImageFileName) {
        this.imageFileName = argImageFileName;
    }

    /**
     * Gets the value of frameFileName
     *
     * @return the value of frameFileName
     */
    public String getFrameFileName() {
        return this.frameFileName;
    }

    /**
     * Sets the value of frameFileName
     *
     * @param argFrameFileName Value to assign to this.frameFileName
     */
    public void setFrameFileName(String argFrameFileName) {
        this.frameFileName = argFrameFileName;
    }

    /**
     * Sets the value of Is ADA Compliant Flag
     *
     * @param argIsADACompliant Value to assign to this.randomizeKeysFlag
     */
    public void setIsADACompliant(boolean argIsADACompliant) {
        this.isADACompliant = argIsADACompliant;
    }

    /**
     * Gets the value of Is ADA Compliant Flag
     *
     * @return the value of isADACompliant
     */
    public boolean getIsADACompliant() {
        return this.isADACompliant;
    }

    /**
     * Sets the value of Has Images Flag
     *
     * @param argHasImgs Value to assign to this.hasImgs
     */
    public void setHasImgs(boolean argHasImgs) {
        this.hasImgs = argHasImgs;
        if (!this.hasImgs) {
            this.setIsADACompliant(true);
        }
    }

    /**
     * Gets the value of Has Images Flag
     *
     * @return the value of hasImgs
     */
    public boolean getHasImgs() {
        return this.hasImgs;
    }

    /**
     * Sets the value of Has Javascript Flag
     *
     * @param argHasJS Value to assign to this.hasImgs
     */
    public void setHasJS(boolean argHasJS) {
        this.hasJS = argHasJS;
        if (!this.hasJS) {
            this.setIsADACompliant(true);
        }
    }

    /**
     * Gets the value of Use Caps Flag
     *
     * @return the value of useCaps
     */
    public boolean getUseCaps() {
        return this.useCaps;
    }

    /**
     * Sets the value of Use Caps Flag
     *
     * @param argUseCaps Value to assign to this.useCaps
     */
    public void setUseCaps(boolean argUseCaps) {
        this.useCaps = argUseCaps;
    }

    /**
     * Gets the value of Has Javascript Flag
     *
     * @return the value of hasJS
     */
    public boolean getHasJS() {
        return this.hasJS;
    }

    /**
     * Gets the value of AuthentiPadArea
     *
     * @return the value of authentiPadArea
     */
    public Rectangle getAuthentiPadArea() {
        return this.authentiPadArea;
    }

    /**
     * Sets the value of AuthentiPadArea
     *
     * @param argAuthentiPadArea Value to assign to this.authentiPadArea
     */
    public void setAuthentiPadArea(Rectangle argAuthentiPadArea) {
        this.authentiPadArea = argAuthentiPadArea;
    }

    /**
     * Gets the value of userInput
     *
     * @return the value of userInput
     */
    public String getUserInput() {
        return this.userInput;
    }

    /**
     * Sets the value of userInput
     *
     * @param argUserInput Value to assign to userInput
     */
    public void setUserInput(String argUserInput) {
        this.userInput = argUserInput;
    }

    /**
     * Gets the value of authKey
     *
     * @return AuthentiKey authKey
     */
    public AuthentiKey getAuthKey(){
    	return authKey;
    }
    

    /**
     * Sets the value of authKey
     *
     * @param argAuthKey Value to assign to authKey
     */
    public void setAuthKey(AuthentiKey argAuthKey){
    	authKey = argAuthKey;
    }

    /**
     * Gets the value of fileSizeEncryptValue
     *
     * @return the value of fileSizeEncryptValue
     */
    public double getFileSizeEncryptValue() {
        return this.fileSizeEncryptValue;
    }

    /**
     * Sets the value of fileSizeEncryptValue
     *
     * @param argFileSizeEncryptValue Value to assign to this.fileSizeEncryptValue
     */
    public void setFileSizeEncryptValue(double argFileSizeEncryptValue) {
        this.fileSizeEncryptValue = argFileSizeEncryptValue;
    }


    /**
     * Gets the HTML for controls on the AuthentiPads.
     *
     * @return The html string which includes the controls
     */
    public String getKeyboardControls() {
    	return getKeyboardControls(this.getAuthentiConfig());
    }

    /**
     * Gets the HTML for controls on the AuthentiPads.
     *
     * @param authConfig authConfig
     * @return The html string which includes the controls
     */
    protected String getKeyboardControls(AuthentiConfig authConfig) {
        prepare();
        if (logger.isDebugEnabled()) {
            logger.debug("getKeyboardControls");
        }


        String ctrl = "";
        double x1 = 0;
        double y1 = 0;

        ctrl = "<script type=\"text/javascript\">\n";
        ctrl += "var " + padName + " = new Bharosa_Pad({type:\"" + padType + (hasImgs?"":AuthentiPad.NOIMG) + "\",name:\"" + padName + "\",canDrag:" + authConfig.windowEnableFlag + ",adaComp:" + isADACompliant + ",url:\"\",imgAlt:\"" + authConfig.padImgAlt + "\",bImgLoc:\"" + authConfig.imageUrl + "pid=" + padName + "&keyId=" + getPadId() + "\"";

        if (authentiPadArea != null) {
            x1 = authentiPadArea.getLocation().getX();
            y1 = authentiPadArea.getLocation().getY();
            ctrl += ",mapStartX:" + (int) x1 + ",mapStartY:" + (int) y1;
        }

        if (authConfig.dataMaxLength != 0) {
            ctrl += ",maxLength:" + authConfig.dataMaxLength;
        }

        if (authConfig.passUserInputFlag && this.userInput != null) {
            ctrl += ",userInput:\"" + HttpUtil.encode(this.userInput) + "\"";
        }

        if (authConfig.controls != null) {
            int controlKeysImageXOffset = 0;
            int controlKeysImageYOffset = 0;

            for (int i = 0; i < authConfig.controls.length; i++) {
                KeyDetail keyDetail = authConfig.controls[i];

                if ((keyDetail != null) && (!keyDetail.isEmbedded())) {
                    Rectangle keyArea = keyDetail.getArea();

                    if (keyArea != null) {
                        x1 = keyArea.getLocation().getX() + controlKeysImageXOffset;
                        y1 = keyArea.getLocation().getY() + controlKeysImageYOffset;

                        if (keyDetail.isActive()) {

                            if ((keyDetail.getFileName() != null) && (keyDetail.getAltFileName() != null) && (keyDetail.getShiftFileName() == null))
                            {
                                ctrl += "," + keyDetail.getKeyName() + "ImgLoc:\"" + authConfig.staticImageUrl + keyDetail.getFileName() + "\"";
                                ctrl += "," + keyDetail.getKeyName() + "Style:\"left:" + (int) x1 + "px;top:" + (int) y1 + "px;\"";

                                ctrl += "," + keyDetail.getAltKeyName() + "ImgLoc:\"" + authConfig.staticImageUrl + keyDetail.getAltFileName() + "\"";
                                ctrl += "," + keyDetail.getAltKeyName() + "Style:\"left:" + (int) x1 + "px;top:" + (int) y1 + "px;\"";
                            } else
                            if ((keyDetail.getFileName() != null) && (keyDetail.getAltFileName() != null) && (keyDetail.getShiftFileName() != null))
                            {

                                ctrl += "," + keyDetail.getKeyName() + "ImgLoc:\"" + authConfig.staticImageUrl + keyDetail.getFileName() + "\"";
                                ctrl += "," + keyDetail.getKeyName() + "Style:\"left:" + (int) x1 + "px;top:" + (int) y1 + "px;\"";

                                ctrl += "," + keyDetail.getAltKeyName() + "ImgLoc:\"" + authConfig.staticImageUrl + keyDetail.getAltFileName() + "\"";
                                ctrl += "," + keyDetail.getAltKeyName() + "Style:\"left:" + (int) x1 + "px;top:" + (int) y1 + "px;\"";

                                ctrl += "," + keyDetail.getShiftKeyName() + "ImgLoc:\"" + authConfig.staticImageUrl + keyDetail.getShiftFileName() + "\"";
                                ctrl += "," + keyDetail.getShiftKeyName() + "Style:\"left:" + (int) x1 + "px;top:" + (int) y1 + "px;\"";

                            }
                        }
                    }
                }
            }
        }
        if (!hasImgs) { // check for images disabled

            if (this.captionText != null && this.captionText.getText() != null) {
                ctrl += ", captionText:\"" + HttpUtil.encode(this.captionText.getText()) + "\"";
            }
            ctrl += ", keySet:({";

            ctrl += "keyGap:" + authConfig.iconGap + ", ";
            ctrl += "keyWidth:" + authConfig.iconWidth + ", ";
            ctrl += "keyHeight:" + authConfig.iconHeight + ", ";

            ctrl += "keys:({";

            if (authKey != null){
                String[] codes = authKey.getKeyCodes();
            
                if (codes != null) {
                    for (int i = 0; i < codes.length; i++) {
                        String key = codes[i];
                        KeyDetail keyDetail = KeyPadUtil.getKeyDetail(authKey, authConfig, i);
                        
                        if (keyDetail.isActive) {
                            if (i != 0) {
                                ctrl += ", ";
                            }
                            ctrl += "\"" + i + "\":({key:\"" + keyDetail.getAltKeyValue() + "\", value:\"" + key + "\"})";
                        }
                    }
                }
            }
            ctrl += "})";
            ctrl += "})";
        }

        if (displayOnly) {
            ctrl += ", showDataDiv:false";
        }
        
        if (!StringUtil.isEmpty(authConfig.dataDivStyle)){
        	ctrl += ", dataDivStyle:\"" + authConfig.dataDivStyle + "\""; 
        }

        if (!StringUtil.isEmpty(authConfig.dataInputStyle)){
        	ctrl += ", dataInputStyle:\"" + authConfig.dataInputStyle + "\""; 
        }

        if (!StringUtil.isEmpty(authConfig.dataInputType)){
        	ctrl += ", dataInputType:\"" + authConfig.dataInputType + "\"";
        }

        if (!StringUtil.isEmpty(authConfig.dataLabel)){
        	ctrl += ", dataLabel:\"" + authConfig.dataLabel + "\"";
        }

        if (!StringUtil.isEmpty(authConfig.confirmDivStyle)){
        	ctrl += ", confirmDivStyle:\"" + authConfig.confirmDivStyle + "\""; 
        }

        if (!StringUtil.isEmpty(authConfig.confirmInputStyle)){
        	ctrl += ", confirmInputStyle:\"" + authConfig.confirmInputStyle + "\""; 
        }

        if (!StringUtil.isEmpty(authConfig.confirmInputType)){
        	ctrl += ", confirmInputType:\"" + authConfig.confirmInputType + "\"";
        }
        
        if (!StringUtil.isEmpty(authConfig.confirmLabel)){
        	ctrl += ", confirmLabel:\"" + authConfig.confirmLabel + "\"";
        }

        ctrl += "})\n";
        ctrl += "</script>\n";

        return ctrl;

    }


    public String getImageMap() {
        if (hasImgs) {
            if (isADACompliant) {
                return getADAImageMap();
            } else {
                return getNonADAImageMap();
            }
        } else {
            return "";
        }
    }


    /**
     * Gets the Image Map for ADA compliant AuthentiPads.
     *
     * @return The map string which includes the map tag
     */
    public String getADAImageMap() {
    	AuthentiConfig authConfig = getAuthentiConfig();
        prepare();
        String map = startImageMap(authConfig, true);
        map += this.getImageMapContents(authConfig, true);
        map += getEnterKeyImageMap(authConfig);
        map += this.endImageMap(authConfig, true);

        return map;
    }

    /**
     * Gets the Image Map for non ADA compliant AuthentiPads.
     *
     * @return The map string which includes the map tag
     */
    public String getNonADAImageMap() {
    	AuthentiConfig authConfig = getAuthentiConfig();
        prepare();
        String map = startImageMap(authConfig, false);
        map += getImageMapContents(authConfig, false);
        map += getEnterKeyImageMap(authConfig);
        map += endImageMap(authConfig, false);


        return map;
    }


    /**
     * Gets the HTML for rendering an AuthentiPad.
     *
     * @return The html string which includes the image map and javscript declarations
     */
    public String getHTML() {
        prepare();

        AuthentiConfig authConfig = getAuthentiConfig();
        String returnStr = "";

        if (!hasJS) {
            returnStr += getNoScriptHTML(authConfig);
        }
        returnStr += getKeyboardControls(authConfig);

        returnStr += startImageMap(authConfig, this.isADACompliant);
        returnStr += getImageMapContents(authConfig, this.isADACompliant);
        returnStr += "\n";
        returnStr += getEnterKeyImageMap(authConfig);
        returnStr += endImageMap(authConfig, this.isADACompliant);
        return returnStr;
    }

    public String getPadId() {
        return padId;
    }

    public void setPadId(String padId) {
        this.padId = padId;
    }

    /**
     * Gets the non javascript alternative HTML an AuthentiPad.
     *
     * @return HTML string for non javascript alternative which includes image map and pad layout HTML
     */
    public String getNoScriptHTML() {
        return getNoScriptHTML(this.getAuthentiConfig());
    }

    /**
     * Gets the non javascript alternative HTML an AuthentiPad.
     *
     * @param authConfig AuthentiConfig
     * @return String - HTML string for non javascript alternative which includes image map and pad layout HTML
     */
    protected String getNoScriptHTML(AuthentiConfig authConfig) {
        return "";
    }

    /**
     * Gets the starting tags of the image map for the AuthentiPad
     *
     * @param argUseAccessibility ADA Compliance flag
     * @return HTML String of the starting area elements and starting map tag of the AuthentiPad image map
     */
    private String startImageMap(AuthentiConfig authConfig, boolean argUseAccessibility) {

        String accessKeyStr = "";
        if (authConfig.enableAccessKeyFlag && authConfig.accessKey != null) {
            accessKeyStr = " accesskey=\"" + authConfig.accessKey + "\"";
        }

        String startMapStr = "<map name=\"" + this.padName + "Map\" id=\"" + this.padName + "Map\"" + accessKeyStr + ">";
        if (argUseAccessibility) {
            startMapStr += "<area shape=\"rect\" href=\"#\" coords=\"0,0,0,0\" alt=\"Begin " + authConfig.padDescription + "\" />";
            if (authConfig.enableDirectionsFlag) {
                startMapStr += "<area shape=\"rect\" href=\"#\" coords=\"0,0,0,0\" alt=\"" + authConfig.padDirections + "\" />";
            }
        }

        return startMapStr;
    }

    /**
     * Gets the ending tags of the image map for the AuthentiPad
     *
     * @param argUseAccessibility ADA Compliance flag
     * @return HTML String of the ending area elements and ending map tag of the AuthentiPad image map
     */
    private String endImageMap(AuthentiConfig authConfig, boolean argUseAccessibility) {
        String endMapStr = "";
        if (argUseAccessibility) {
            endMapStr += "<area shape=\"rect\" href=\"#\" coords=\"0,0,0,0\" alt=\"End " + authConfig.padDescription + "\" />";
        } else {
            endMapStr += "<area shape=\"default\" nohref onclick=\"javascript:return false;\" />";
        }
        endMapStr += "</map>";

        return endMapStr;
    }

    /**
     * Gets the contents of the image map for the AuthentiPad
     *
     * @param argUseADA ADA Compliance flag
     * @return HTML String of the primary Area Elements of the AuthentiPad image map
     */
    private String getImageMapContents(AuthentiConfig authConfig, boolean argUseADA) {
        String map = "";

        if (argUseADA) {
            map += this.getTextElementsImageMap(authConfig);
        }

        if (displayOnly) {
            return map;
        }

        map += getControlsImageMap(authConfig);
        map += getDragBarImageMap(authConfig);
        
        String[] codes = null;
        if (authKey != null){
            codes = authKey.getKeyCodes();
        }
        
        if ((authentiPadArea != null) && (codes != null)) {
            double x1 = 0;
            double y1 = 0;
            double x2 = 0;
            double y2 = 0;

            if (argUseADA) {
                String href = null;

                for (int i = 0; i < codes.length; i++) {
                    String key = codes[i];
                    KeyDetail keyDetail = KeyPadUtil.getKeyDetail(authKey, authConfig, i);
                    
                    if (keyDetail.isActive()) {
                        if (keyDetail.getKeyValue() != "") {
                            Rectangle rect = keyDetail.getArea();

                            if (rect == null) {
                                logger.error("No area set for key " + keyDetail.getKeyValue());
                            }

                            x1 = rect.getLocation().getX();
                            y1 = rect.getLocation().getY();
                            x2 = x1 + rect.getSize().getWidth();
                            y2 = y1 + rect.getSize().getHeight();

                            if (this.hasJS) {
                                href = "href=\"javascript:" + padName + ".keyPress('" + key + "');\" ondblclick=\"javascript:" + padName + ".keyPressDbl('" + key + "');\"";
                            } else {
                                href = "href=\"" + authConfig.compatibilityUrl + "?pad=" + this.padName + "&key=" + key + "\"";
                            }

                            map += "<area shape=\"rect\" coords=\"" + (int) x1 + "," + (int) y1 + "," + (int) x2 + "," + (int) y2 + "\" " + href + " alt=\"" + keyDetail.getKeyValue() + "\" title=\"" + keyDetail.getKeyValue() + "\" /> ";
                        }
                    }
                }
            } else {
                x1 = authentiPadArea.getLocation().getX();
                y1 = authentiPadArea.getLocation().getY();
                x2 = x1 + authentiPadArea.getSize().getWidth();
                y2 = y1 + authentiPadArea.getSize().getHeight();

                map += "<area shape=\"rect\" coords=\"" + (int) x1 + "," + (int) y1 + "," + (int) x2 + "," + (int) y2 + "\" href=\"javascript:" + padName + ".keyPress('');\" alt=\"\" onclick=\"javascript:" + padName + ".trackMouse(arguments[0]);\" ondblclick=\"javascript:" + padName + ".keyPressDbl('');\" />";
            }
        }

        return map;
    }

    /**
     * @param keyDetail
     * @return String representing the area tag of a control key.
     */
    private String getControlKeyMap(AuthentiConfig authConfig, KeyDetail keyDetail) {
        double x1;
        double y1;
        double x2;
        double y2;
        String key;
        String href;
        String ctrlMap = "";

        if (keyDetail != null) {
            Rectangle keyArea = keyDetail.getArea();

            if ((keyArea != null) && (keyDetail.isActive())) {
                key = keyDetail.getKeyValue();

                x1 = keyArea.getLocation().getX();
                y1 = keyArea.getLocation().getY();
                x2 = x1 + keyArea.getSize().getWidth();
                y2 = y1 + keyArea.getSize().getHeight();
                if (this.hasJS) {
                    href = "href=\"javascript:" + padName + ".keyPress('" + key + "');\" ondblclick=\"javascript:" + padName + ".keyPressDbl('" + key + "');\"";
                } else {
                    href = "href=\"" + authConfig.compatibilityUrl + "?pad=" + this.padName + "&key=" + key + "\"";
                    if (key.equals("ENTERKEY")) {
                        href += " target=\"_top\"";
                    }
                }
                ctrlMap += "<area shape=\"rect\" coords=\"" + (int) x1 + "," + (int) y1 + "," + (int) x2 + "," + (int) y2 + "\" " + href + " alt=\"" + keyDetail.getKeyName() + "\" title=\"" + keyDetail.getKeyName() + " \" /> ";
            }
        }
        return ctrlMap;
    }

    /**
     * @return String representing the area tag of the drag bar.
     */
    private String getDragBarImageMap(AuthentiConfig authConfig) {
        String dragBar = "\n";

        if ((authConfig.windowEnableFlag) && (authConfig.dragBarControl != null)) {
            double x1 = authConfig.dragBarControl.getArea().getLocation().getX();
            double y1 = authConfig.dragBarControl.getArea().getLocation().getY();
            double x2 = x1 + authConfig.dragBarControl.getArea().getSize().getWidth();
            double y2 = y1 + authConfig.dragBarControl.getArea().getSize().getHeight();
            dragBar = "<area shape=\"rect\" coords=\"" + (int) x1 + "," + (int) y1 + "," + (int) x2 + "," + (int) y2 + "\" id=\"" + padName + authConfig.dragBarControl.getKeyName() + "\" alt=\"" + authConfig.dragBarControl.getKeyValue() + "\" style=\"cursor: default;\" />";
        }

        return dragBar;
    }

    /**
     * Gets the Image Map for AuthentiPads Controls.
     *
     * @return String representing the area tags of all the control elements
     */
    private String getControlsImageMap(AuthentiConfig authConfig) {
        String ctrlMap = "\n";

        if (authConfig.controls != null) {
            for (int i = 0; i < authConfig.controls.length; i++) {
                KeyDetail keyDetail = authConfig.controls[i];

                ctrlMap += getControlKeyMap(authConfig, keyDetail);
            }
        } else if (logger.isDebugEnabled()) {
            logger.debug("getControlsImageMap() controls is null ");
        }

        return ctrlMap;
    }

    /**
     * Gets the Image Map for AuthentiPads Text Elements.
     *
     * @return String representing the area tags of all the text elements
     */
    private String getTextElementsImageMap(AuthentiConfig authConfig) {
        String textMap = " ";

        if (authConfig.textElements != null) {
            double x1 = 0;
            double y1 = 0;
            double x2 = 0;
            double y2 = 0;

            for (int i = 0; i < authConfig.textElements.length; i++) {
                KeyDetail keyDetail = authConfig.textElements[i];

                if (keyDetail != null) {
                    Rectangle keyArea = keyDetail.getArea();

                    if (keyArea != null) {

                        x1 = keyArea.getLocation().getX();
                        y1 = keyArea.getLocation().getY();
                        x2 = x1 + keyArea.getSize().getWidth();
                        y2 = y1 + keyArea.getSize().getHeight();

                        textMap += "<area shape=\"rect\" coords=\"" + (int) x1 + "," + (int) y1 + "," + (int) x2 + "," + (int) y2 + "\" href=\"#\" alt=\"" + keyDetail.getKeyName() + "\" title=\"" + keyDetail.getKeyName() + "\" /> ";
                    }
                }
            }
        } else if (logger.isDebugEnabled()) {
            logger.debug("getTextElementsImageMap() Text Elements is null ");
        }

        return textMap;
    }

    private String getEnterKeyImageMap(AuthentiConfig authConfig) {
        if (displayOnly) {
            return "";
        }

        return this.getControlKeyMap(authConfig, authConfig.enterKeyControl);
    }
/*
    protected AuthentiKey generateAuthentiKey(){

  	  AuthentiKey authKey = new AuthentiKey();
  	  authKey.setADACompliant(isADACompliant);

  	  if (this instanceof DecodablePad){
  		  authKey.setDecodable(true);
  		  if (valueList != null && !valueList.isEmpty()){
	  		  int keyCount = valueList.size();

	  		  String[] keyValues = new String[keyCount * 2];;
	  		  short[] keyLocations = null;
	  		  String[] keyCodes = null;
	  		  KeyDetail[] keys = new KeyDetail[keyCount];

	  		  if (isADACompliant){
	  			keyCodes = new String[keyCount];
	  		  } else {
	  			keyLocations = new short[keyCount * 4];
	  		  }

	  		  int valueIndex = 0;
	  		  int locIndex = 0;
	  		  int codeIndex = 0;

	  		  for(int i=0; i < keyCount; i++){
	  			KeyDetail keyDetail = (KeyDetail)encryptedOTPKeyData.get(valueList.get(i));
	  			
	  			keys[i] = keyDetail;
	  			keyValues[valueIndex++] = keyDetail.getKeyValue();
	  			keyValues[valueIndex++] = keyDetail.getAltKeyValue();

	  			if (!isADACompliant){
	  				Rectangle rect = keyDetail.getArea();

	  				keyLocations[locIndex++] = (short) rect.x;
	  				keyLocations[locIndex++] = (short) rect.y;
	  				keyLocations[locIndex++] = (short) rect.width;
	  				keyLocations[locIndex++] = (short) rect.height;
	  			} else {
	  				keyCodes[codeIndex] = (String) valueList.get(i);
	  				codeIndex++;
	  			}

	  		  }

//	  		  authKey.setKeyValues(keyValues);
//	  		  authKey.setKeyLocations(keyLocations);
	  		  authKey.setKeyCodes(keyCodes);
	  		  authKey.setKeys(keys);

	  		  if (logger.isDebugEnabled()){
	  			  logger.debug("AuthentiPad::generateAuthentiKey() - End");
	  		  }
  		  }
  	  } else{
  		authKey.setDecodable(false);
  	  }

  	  return authKey;
    }
*/
}

