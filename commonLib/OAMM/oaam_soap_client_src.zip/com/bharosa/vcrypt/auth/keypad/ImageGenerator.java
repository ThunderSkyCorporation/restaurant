package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.logger.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

public class ImageGenerator extends HttpServlet
{
	static private Logger  logger = Logger.getLogger(ImageGenerator.class);

	public void doGet(HttpServletRequest request,  HttpServletResponse response)
		throws ServletException, IOException
	{
    try {
      if( logger.isDebugEnabled())
      {
        logger.debug("doGet() enter");
      }
  
      try
      {
  
        response.setHeader("Cache-Control","no-cache"); //HTTP 1.1
        response.setHeader("Pragma","no-cache"); //HTTP 1.0
        //response.setHeader("Cache-Control","no-store");
        //response.setHeader("Cache-Control", "no-cache");
        //response.setHeader("Cache-control", "must-revalidate"); // works in IE and FireFox
        response.setDateHeader ("Expires", 0); //prevents caching at the proxy server
        response.setDateHeader("Max-Age", 0);
  
        String imageName = request.getParameter("loadImage");
        String padName = request.getParameter("pid");
  
        File iconFile = null;
        BufferedImage newSource = null;
        AuthentiPad keyPad = keyPad = getAuthentiPad(request, padName);
        String outputType = "png";
  
        OutputStream os = response.getOutputStream();
  
        String skinDir = BharosaConfig.get("bharosa.authentipad.images.dir", "alphapad_bg");
  
        if( skinDir == null )
        {
          logger.error("doGet images directory is empty. Property name is bharosa.authentipad.images.dir");
          return;
        }
  
        if(imageName!=null)
        {
          String imageFilePath = skinDir + File.separator + imageName;
  
          iconFile = KeyPadUtil.getFile(imageFilePath);
  
          if( iconFile != null )
          {
            response.setContentType("image/" + outputType );
  
            os = KeyPadUtil.encryptImageToStream(iconFile, outputType, os);
          }
          else
          {
            logger.error("loadImage iconFile " + imageFilePath + " not found");
            return;
          }
        }
        else
        {
          if( keyPad != null )
          {
            AuthentiConfig authConfig = keyPad.getAuthentiConfig();
            outputType = authConfig.getOutputType();
  
            response.setContentType("image/" + outputType );
  
            os = KeyPadUtil.encryptImageToStream( keyPad, authConfig, os);
  
          }
          else
          {
            logger.info("KeyPad was not found in session. The sesion might have got expired or someone might have called the servlet without calling the login page. padName=" + padName);
  
            String imageFilePath = skinDir + File.separator + imageName;
  
            iconFile = KeyPadUtil.getFile(imageFilePath);
  
            if( iconFile != null )
            {
              os = KeyPadUtil.encryptImageToStream(iconFile, outputType, os);
            }
          }
        }
  
        os.close();
  
        return;
      }
      catch( Exception ex )
      {
        logger.error("Error while generating image", ex);
      }
  
      String redirect = BharosaConfig.get("bharosa.authentipad.error.redirect");
      if( redirect != null && redirect.length() > 0 ) {
        response.setHeader("Cache-Control","no-cache"); //HTTP 1.1
        response.setHeader("Pragma","no-cache"); //HTTP 1.0
        response.setHeader("Cache-Control","no-store");
        response.setDateHeader ("Expires", 0); //prevents caching at the proxy server
  
        response.sendRedirect(redirect);
        return;
      }
  
      logger.error("No error redirect page found. Property name is bharosa.authentipad.error.redirect");
      //TBD: Need to handle this

    } catch (Throwable t) {
      logger.error("Error in doGet of ImageGenerator servlet", t);
    }

  }

  protected AuthentiPad getAuthentiPad(HttpServletRequest request, String padName) {
    AuthentiPad keyPad = null;
    
    if (padName != null) {
      keyPad = (AuthentiPad) request.getSession().getAttribute(padName);
    }
    
    return keyPad;
  }

	public void doPost(HttpServletRequest request,  HttpServletResponse response)
		throws ServletException, IOException {
    try {
  		doGet(request, response);
	  } catch (Throwable t){
	    logger.error("Error in doPost of ImageGenerator servlet", t);
	  }
	}
}
