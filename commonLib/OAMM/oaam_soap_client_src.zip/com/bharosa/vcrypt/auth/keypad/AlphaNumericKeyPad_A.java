package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.DateUtil;
import com.bharosa.common.logger.Logger;

import java.awt.*;

/**
 * This encapsulates all the properties for the KeyPad which was
 * generated for the given session.
 */

public class AlphaNumericKeyPad_A extends AuthentiPad implements DecodablePad {
    static protected Logger logger = Logger.getLogger(AlphaNumericKeyPad_A.class);

    /**
     * Creates the full keypad with the given background image.
     * The images generation can be tweaked by using various
     * property values in the configuration file. Please refer
     * the property file for the list of properties this
     * method supports.
     *
     * @param backgroundFilePath Path to the background file. It
     *                           could be absolute path or the path should be relative to the
     *                           directories in the classpath
     *                           creates a KeyPad object if there were no errors.
     */
    public AlphaNumericKeyPad_A(String padName, String backgroundFilePath, String frameFilePath) {
        super(padName, backgroundFilePath, frameFilePath);

        padType = AuthentiPad.KEYPAD;
        padProp = "keypad";
        padKeySetProp = "alphanumericalternate";
    }

    protected void initialize() throws ObjectNotCreatedException {
        super.initialize();

    }

    public AuthentiConfig getAuthentiConfig(){
    	AuthentiConfig authConfig = super.getAuthentiConfig();
    	
        //Create the keys array
        KeyDetail [][] tmpKeys = {
                {
                        new KeyDetail("kp_v2_1.png", "1", "1"),
                        new KeyDetail("kp_v2_2.png", "2", "2"),
                        new KeyDetail("kp_v2_3.png", "3", "3"),
                        new KeyDetail("kp_v2_4.png", "4", "4"),
                        new KeyDetail("kp_v2_5.png", "5", "5"),
                        new KeyDetail("kp_v2_6.png", "6", "6"),
                        new KeyDetail("kp_v2_7.png", "7", "7"),
                        new KeyDetail("kp_v2_8.png", "8", "8"),
                        new KeyDetail("kp_v2_9.png", "9", "9"),
                        new KeyDetail("kp_v2_0.png", "0", "0"),
                },
                {
                        new KeyDetail("kp_v2_Q.png", "q", "Q"),
                        new KeyDetail("kp_v2_W.png", "w", "W"),
                        new KeyDetail("kp_v2_E.png", "e", "E"),
                        new KeyDetail("kp_v2_R.png", "r", "R"),
                        new KeyDetail("kp_v2_T.png", "t", "T"),
                        new KeyDetail("kp_v2_Y.png", "y", "Y"),
                        new KeyDetail("kp_v2_U.png", "u", "U"),
                        new KeyDetail("kp_v2_I.png", "i", "I"),
                        new KeyDetail("kp_v2_O.png", "o", "O"),
                        new KeyDetail("kp_v2_P.png", "p", "P"),
                },
                {
                        new KeyDetail("kp_v2_A.png", "a", "A"),
                        new KeyDetail("kp_v2_S.png", "s", "S"),
                        new KeyDetail("kp_v2_D.png", "d", "D"),
                        new KeyDetail("kp_v2_F.png", "f", "F"),
                        new KeyDetail("kp_v2_G.png", "g", "G"),
                        new KeyDetail("kp_v2_H.png", "h", "H"),
                        new KeyDetail("kp_v2_J.png", "j", "J"),
                        new KeyDetail("kp_v2_K.png", "k", "K"),
                        new KeyDetail("kp_v2_L.png", "l", "L"),
                        new KeyDetail("kp_v2_M.png", "m", "M"),
                },
                {
                        new KeyDetail("kp_v2_blank.png", "", ""),
                        new KeyDetail("kp_v2_blank.png", "", ""),

                        new KeyDetail("kp_v2_Z.png", "z", "Z"),
                        new KeyDetail("kp_v2_X.png", "x", "X"),
                        new KeyDetail("kp_v2_C.png", "c", "C"),
                        new KeyDetail("kp_v2_V.png", "v", "V"),
                        new KeyDetail("kp_v2_B.png", "b", "B"),
                        new KeyDetail("kp_v2_N.png", "n", "N"),

                        new KeyDetail("kp_v2_blank.png", "", ""),
                        new KeyDetail("kp_v2_blank.png", "", ""),

                }
        };

        authConfig.keys = tmpKeys;
        
        return authConfig;

    }
    
    protected PadImageDirectory getParentImageDir() {
        return PadImageDirectory.keypad;
    }
    
}
