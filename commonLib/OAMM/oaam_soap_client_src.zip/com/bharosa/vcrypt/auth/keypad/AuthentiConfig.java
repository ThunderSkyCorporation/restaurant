package com.bharosa.vcrypt.auth.keypad;

import java.awt.Font;
import java.awt.Rectangle;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;

import com.bharosa.common.logger.Logger;

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.DateUtil;
import com.bharosa.common.util.StringUtil;
import com.bharosa.common.util.UserDefEnum;
import com.bharosa.common.util.UserDefEnumElement;
import com.bharosa.vcrypt.auth.intf.VCryptLocalizedString;

public class AuthentiConfig implements Serializable{
    static protected Logger logger = Logger.getLogger(AuthentiConfig.class);

    protected String configResourceName = BharosaConfig.get("oaam.authentipad.resource.name", "authentipad_resource");
    protected String messageResourceName = BharosaConfig.get("oaam.authentipad.message.resource.name", "authentipad_msg_resource");
    
    protected String padDescription = null;
    protected String padDirections = null;
    protected String padImgAlt = null;
    protected String accessKey = null;

    protected String captionFontName = "Verdana";
    protected String captionFontColor = "000000";
    protected int captionFontType = Font.PLAIN;
    protected int captionFontSize = 9;
    protected int captionWidth = 9;
    protected int captionHeight = 9;

    protected boolean captionFrameFlag = true;
    protected boolean captionWrapFlag = true;

    protected String timeStampFontName = "Verdana";
    protected String timeStampFontColor = "ffffff";
    protected int timeStampFontType = Font.PLAIN;
    protected int timeStampFontSize = 9;
    protected int timeStampWidth = 9;
    protected int timeStampHeight = 9;

    protected String dataDivStyle = null;
    protected String dataInputStyle = null;
    protected String dataInputType = null;
    protected String dataLabel = null;
    protected String confirmDivStyle = null;
    protected String confirmInputStyle = null;
    protected String confirmInputType = null;
    protected String confirmLabel = null;
    
    protected boolean timeStampFrameFlag = true;
    protected boolean timeStampWrapFlag = true;

    protected String outputType = null;

    protected boolean jitterEncryptFlag = false;
    protected boolean filesizeEncryptFlag = false;
    protected boolean checksumEncryptFlag = false;
    protected boolean dataEncryptFlag = false;
    protected boolean randomizeKeysFlag = false;
    protected boolean windowEnableFlag = false;
    protected boolean enableDirectionsFlag = true;
    protected boolean enableAccessKeyFlag = true;
    protected boolean passUserInputFlag = false;
    protected boolean personalizeBackground = true;
    protected boolean personalizeCaption = true;
    protected boolean useCaps = true;

    protected boolean enableLogoFlag = true;
    protected String logoFileName = null;
    protected int logoXPtr = 0;
    protected int logoYPtr = 0;
    protected String logoFontName = null;
    protected int logoFontType = Font.PLAIN;
    protected int logoFontSize = 9;
    protected int logoWidth = 9;
    protected int logoHeight = 9;

    protected String skinDirList = null;

    protected int xPtr = 0;
    protected int yPtr = 0;

    protected int leftShift = 0;
    protected int topShift = 0;

    protected int displayWidth = 0;
    protected int displayHeight = 0;

    protected int leftFrame = 0;
    protected int topFrame = 0;

    protected int dataMaxLength = 0;

    protected int colSpace = 0;
    protected int topMargin = 0;
    protected int leftMargin = 0;
    protected int rightMargin = 0;
    protected int bottomMargin = 0;
    protected int iconGap = 0;

    protected int iconWidth = 0;
    protected int iconHeight = 0;

    protected String imageUrl = null; //"kbimage?"
    protected String staticImageUrl = null;
    protected String maskUrl = null;
    protected String compatibilityUrl = null;

    protected KeyDetail enterKeyControl = null;
    protected KeyDetail [][] keys = null;
    protected KeyDetail [] controls = null;
    protected KeyDetail [] textElements = null;
    protected KeyDetail dragBarControl = null;


	public AuthentiConfig(String padPropPrefix, String padProp, String padKeySetProp, boolean useCaps, VCryptLocalizedString captionText, Date timeStamp, TimeZone timeZone){
		
        String propPrefix = padPropPrefix + "." + padProp + ".";

        if (StringUtil.isEmpty(imageUrl)) {
            imageUrl = BharosaConfig.getLocalizedFromNamedBundle(padPropPrefix + ".image.url", configResourceName, "kbimage?");
        }

        if (StringUtil.isEmpty(staticImageUrl)) {
            staticImageUrl = BharosaConfig.getLocalizedFromNamedBundle(padPropPrefix + ".static.image.url", configResourceName, "/bharosa_web/images/");
        }

        if (StringUtil.isEmpty(maskUrl)) {
            maskUrl = BharosaConfig.getLocalizedFromNamedBundle(padPropPrefix + ".compatibility.entermask.file", configResourceName, "clear.gif");
        }

        if (StringUtil.isEmpty(compatibilityUrl)) {
            compatibilityUrl = BharosaConfig.getLocalizedFromNamedBundle(padPropPrefix + ".compatibility.click.url", configResourceName, "clickKey.jsp");
        }

        this.useCaps = useCaps;
        
        padDescription = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "accessibility.description", messageResourceName, "PinPad");

        enableDirectionsFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "accessibility.directions.enable", configResourceName, true);
        padDirections = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "accessibility.directions", messageResourceName, "PinPad directions: Use the following links to enter your numeric pin.  Your personalized caption text comes first, folowed by control links, then by the numeric links.  Once you have entered your numeric pin, use shift-tab to return to the enter link to submit your pin.");

        padImgAlt = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "security.image.alt", messageResourceName, "Security Device Image");
        
        enableAccessKeyFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "accessibility.accessKey.enable", configResourceName, false);
        accessKey = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "accessibility.accessKey", configResourceName, "p");

        personalizeBackground = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "background.personalize", configResourceName, true);
        personalizeCaption = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "caption.personalize", configResourceName, true);
        
        boolean hasKeys = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "haskeys", configResourceName, false);

        if (hasKeys) {
            boolean bRandomizeKeys = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "randomizeKeys", configResourceName, false);
            int keyWidthJitter = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "keyWidthJitter", configResourceName, 0);
            int keyHeightJitter = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "keyHeightJitter", configResourceName, 0);

            String localizedKeySetName = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + padKeySetProp + ".keyset", configResourceName, padKeySetProp);
            UserDefEnum keySetEnum = UserDefEnum.getEnum(propPrefix + localizedKeySetName + ".keyset.enum");
            if (keySetEnum != null){
                if (bRandomizeKeys) {

                    Object[] keyRows = keySetEnum.getOrderedEnumElements("order", true);

                    UserDefEnumElement tmpRowElem = (UserDefEnumElement) keyRows[0];
                    String tmpKeyEnumId = tmpRowElem.getProperty("keys");
                    Object[] tmpKeysArr = UserDefEnum.getOrderedEnumElements(tmpKeyEnumId, "order", true);
                    int numRows = keyRows.length;
                    int numCols = tmpKeysArr.length;

                    KeyDetail [] keyDetails = new KeyDetail[(numRows * numCols)];

                    int detailIndex = 0;
                    for (int i=0;i<keyRows.length;i++){
                        UserDefEnumElement rowElem = (UserDefEnumElement) keyRows[i];
                        String keyEnumId = rowElem.getProperty("keys");

                        Object[] keysArr = UserDefEnum.getOrderedEnumElements(keyEnumId, "order", true);

                        for (int j=0;j<keysArr.length;j++){
                            UserDefEnumElement key = (UserDefEnumElement) keysArr[j];

                            keyDetails[detailIndex++] = new KeyDetail(   key.getProperty("image"),
                                                                key.getProperty("value"),
                                                                key.getProperty("shiftvalue"),
                                                                keyWidthJitter,
                                                                keyHeightJitter);

                        }

                    }

                    Random rnd = new Random();

                    for (int i = 0; i < keyDetails.length; i++) {
                        int idx = rnd.nextInt(keyDetails.length);

                        if (idx == i)
                            continue;

                        KeyDetail tmp = keyDetails[i];

                        keyDetails[i] = keyDetails[idx];
                        keyDetails[idx] = tmp;
                    }

                    keys = new KeyDetail[numRows][numCols];

                    detailIndex = 0;

                    for (int i=0; i<numRows; i++){
                        for (int j=0; j<numCols; j++){
                            keys[i][j]=keyDetails[detailIndex++];
                        }
                    }

                } else {
                    Object[] keyRows = keySetEnum.getOrderedEnumElements("order", true);

                    KeyDetail [][] keyDetails = new KeyDetail [keyRows.length][];
                    for (int i=0;i<keyRows.length;i++){
                        UserDefEnumElement rowElem = (UserDefEnumElement) keyRows[i];
                        String keyEnumId = rowElem.getProperty("keys");

                        Object[] keysArr = UserDefEnum.getOrderedEnumElements(keyEnumId, "order", true);

                        keyDetails[i] = new KeyDetail[keysArr.length];

                        for (int j=0;j<keysArr.length;j++){
                            UserDefEnumElement key = (UserDefEnumElement) keysArr[j];

                            keyDetails[i][j] = new KeyDetail(   key.getProperty("image"),
                                                                key.getProperty("value"),
                                                                key.getProperty("shiftvalue"),
                                                                keyWidthJitter,
                                                                keyHeightJitter);

                        }

                    }

                    keys = keyDetails;
                }
            } else {
              logger.warn("Keyset null even though pad.hasKeys=true.");
            }
        }

        int x = 0;
        int y = 0;
        int width = 0;
        int height = 0;
        String controlLabel = "";

        if (BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "enterkey.enable", configResourceName, false)) {
            x = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "enterkey.x", configResourceName, 0);
            y = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "enterkey.y", configResourceName, 0);
            width = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "enterkey.width", configResourceName, 0);
            height = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "enterkey.height", configResourceName, 0);
            controlLabel = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "enterkey.label", messageResourceName, "enter");
            enterKeyControl = new KeyDetail(controlLabel, "ENTERKEY", true, new Rectangle(x, y, width, height), false);
        }

        //Create the controls array
        KeyDetail [] tmpControls = new KeyDetail[10];

        int ptr = 0;

        if (BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "datafield.enable", configResourceName, false)) {
            x = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "datafield.x", configResourceName, 0);
            y = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "datafield.y", configResourceName, 0);
            width = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "datafield.width", configResourceName, 0);
            height = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "datafield.height", configResourceName, 0);
            tmpControls[ptr] = new KeyDetail("data", "PASSWORD", false, new Rectangle(x, y, width, height), false);
            ptr++;

            String dataFont = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "datafield.font.name", configResourceName, "arial, helvetica");
            String dataFontSize = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "datafield.font.size", configResourceName, "12");
            String dataFontWeight = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "datafield.font.weight", configResourceName, "bold");
            String dataFontColor = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "datafield.font.color", configResourceName, "black");
            String dataInputBorderSize = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "datafield.border.size", configResourceName, "0");
            String dataInputBorderStyle = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "datafield.border.style", configResourceName, "solid");
            String dataInputBorderColor = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "datafield.border.color", configResourceName, "black");
            	
    		dataDivStyle = "left:" + x + "px;top:" + y + "px;font-family:" + dataFont + ";font-size:" + dataFontSize + "px;font-weight:" + dataFontWeight + ";color:" + dataFontColor + ";text-align:left;";
    		dataInputStyle = "border: " + dataInputBorderSize + "px " + dataInputBorderStyle + " " + dataInputBorderColor + "; font-family:" + dataFont + ";font-size:" + dataFontSize + "px;color:" + dataFontColor + ";width:" + width + "px;height:" + height + "px;";
    		dataInputType = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "datafield.input.type", configResourceName);
    		dataLabel = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "datafield.label", messageResourceName);
        }


        if (BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "confirmfield.enable", configResourceName, false)) {
            x = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "confirmfield.x", configResourceName, 0 );
            y = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "confirmfield.y", configResourceName, 0 );
            width = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "confirmfield.width", configResourceName, 0 );
            height = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "confirmfield.height", configResourceName, 0 );
            controlLabel = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "confirmfield.label", messageResourceName, "Confirm Password");
            tmpControls [ptr] = new KeyDetail(controlLabel, "CONFIRM", false, new Rectangle(x,y,width,height), false);
            ptr++;

            String confirmFont = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "confirmfield.font.name", configResourceName, "arial, helvetica");
            String confirmFontSize = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "confirmfield.font.size", configResourceName, "12");
            String confirmFontWeight = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "confirmfield.font.weight", configResourceName, "bold");
            String confirmInputBorderSize = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "confirmfield.border.size", configResourceName, "0");
            String confirmInputBorderStyle = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "confirmfield.border.size", configResourceName, "solid");
            String confirmInputBorderColor = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "confirmfield.border.size", configResourceName, "black");
            	
            confirmDivStyle = "left:" + x + "px;top:" + y + "px;font-family:" + confirmFont + ";font-size:" + confirmFontSize + "px;font-weight:" + confirmFontWeight + ";text-align:left;";
            confirmInputStyle = "border: " + confirmInputBorderSize + "px " + confirmInputBorderStyle + " " + confirmInputBorderColor + "; font-family:" + confirmFont + ";font-size:" + confirmFontSize + "px;width:" + width + "px;height:" + height + "px;";
    		confirmInputType = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "confirmfield.input.type", configResourceName);
    		confirmLabel = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "confirmfield.label", messageResourceName);

        }

        if (BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "backspace.enable", configResourceName, false)) {
            x = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "backspace.x", configResourceName, 0);
            y = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "backspace.y", configResourceName, 0);
            width = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "backspace.width", configResourceName, 0);
            height = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "backspace.height", configResourceName, 0);
            controlLabel = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "backspace.label", messageResourceName, "backspace");
            tmpControls[ptr] = new KeyDetail(controlLabel, "BSKEY", true, new Rectangle(x, y, width, height), false);
            ptr++;
        }

        if (BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "clear.enable", configResourceName, false)) {
            x = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "clear.x", configResourceName, 0);
            y = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "clear.y", configResourceName, 0);
            width = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "clear.width", configResourceName, 0);
            height = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "clear.height", configResourceName, 0);
            controlLabel = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "clear.label", messageResourceName, "Clear");
            tmpControls[ptr] = new KeyDetail(controlLabel, "CLEAR", true, new Rectangle(x, y, width, height), false);
            ptr++;
        }

        if (BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "closekey.enable", configResourceName, false)) {
            x = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "closekey.x", configResourceName, 0);
            y = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "closekey.y", configResourceName, 0);
            width = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "closekey.width", configResourceName, 0);
            height = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "closekey.height", configResourceName, 0);
            tmpControls[ptr] = new KeyDetail("close", "CLOSE", true, new Rectangle(x, y, width, height), false);
            ptr++;
        }


        if ((BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "dragbar.enable", configResourceName, false))) {
            x = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "dragbar.x", configResourceName, 0);
            y = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "dragbar.y", configResourceName, 0);
            width = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "dragbar.width", configResourceName, 128);
            height = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "dragbar.height", configResourceName, 40);
            dragBarControl = new KeyDetail("DragBar", "move", new Rectangle(x, y, width, height));
        }

        if(BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "capslock.enable", configResourceName, false ) && useCaps)
        {
          x = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "capslock.x", configResourceName, 0 );
          y = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "capslock.y", configResourceName, 0 );
          width = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "capslock.width", configResourceName, 0 );
          height = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "capslock.height", configResourceName, 0 );
          String capsOnImgLoc = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "capslock.capsOnImg", configResourceName, "kp_v2_all_caps.jpg" );
          String capsShiftImgLoc = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "capslock.capsShiftImg", configResourceName, "kp_v2_first_caps.jpg" );
          tmpControls [ptr] = new KeyDetail("capsShift","capsOn",capsShiftImgLoc,capsOnImgLoc,"CAPSLOCKKEY","CAPSLOCKKEY", new Rectangle(x,y,width,height), false);
          ptr++;
        }

        controls = tmpControls;

        KeyDetail [] tmpTextElements = new KeyDetail[5];
        ptr = 0;

        if (personalizeCaption && captionText != null && captionText.getText() != null) {
        	Locale captionLocale = captionText.getLocale().getLocale();
        	
            x = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale(propPrefix + "caption.x", configResourceName, captionLocale, 0);
            y = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale(propPrefix + "caption.y", configResourceName, captionLocale, 0);

            captionFrameFlag = BharosaConfig.getLocalizedBooleanFromNamedBundleAndLocale(propPrefix + "caption.frame", configResourceName, captionLocale, true);
            captionWrapFlag = BharosaConfig.getLocalizedBooleanFromNamedBundleAndLocale(propPrefix + "caption.wrap", configResourceName, captionLocale, true);

            captionFontName = BharosaConfig.getLocalizedFromNamedBundleAndLocale(propPrefix + "caption.font.name", configResourceName, captionLocale, "Verdana");
            captionFontColor = BharosaConfig.getLocalizedFromNamedBundleAndLocale(propPrefix + "caption.font.color", configResourceName, captionLocale, "000000");
            captionFontType = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale(propPrefix + "caption.font.type", configResourceName, captionLocale, Font.PLAIN);
            captionFontSize = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale(propPrefix + "caption.font.size", configResourceName, captionLocale, 9);
            captionWidth = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale(propPrefix + "caption.width", configResourceName, captionLocale, 9);
            captionHeight = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale(propPrefix + "caption.height", configResourceName, captionLocale, 9);


            Rectangle captionArea = new Rectangle(x, y, captionWidth, captionHeight);

            KeyDetail tmpDetail = new KeyDetail(captionText.getText(), captionArea);

            tmpDetail.setTextFontName(captionFontName);
            tmpDetail.setTextFontColor(captionFontColor);
            tmpDetail.setTextFontType(captionFontType);
            tmpDetail.setTextFontSize(captionFontSize);
            tmpDetail.setTextWrapFlag(captionWrapFlag);
            tmpDetail.setTextFrameFlag(captionFrameFlag);

            tmpTextElements[ptr] = tmpDetail;
            ptr++;
        } else if (logger.isDebugEnabled()) {
            logger.debug("getPinPad() caption is null");
        }

        if (timeStamp != null) {
            x = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "timestamp.x", configResourceName, 0);
            y = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "timestamp.y", configResourceName, 0);

            timeStampFrameFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "timestamp.frame", configResourceName, true);
            timeStampWrapFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "timestamp.wrap", configResourceName, true);

            timeStampFontName = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "timestamp.font.name", configResourceName, "Verdana");
            timeStampFontColor = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "timestamp.font.color", configResourceName, "ffffff");
            timeStampFontType = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "timestamp.font.type", configResourceName, Font.PLAIN);
            timeStampFontSize = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "timestamp.font.size", configResourceName, 9);
            timeStampWidth = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "timestamp.width", configResourceName, 9);
            timeStampHeight = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "timestamp.height", configResourceName, 9);


            Rectangle timeStampArea = new Rectangle(x, y, timeStampWidth, timeStampHeight);


            KeyDetail tmpDetail = new KeyDetail(DateUtil.getFormattedDateWithTZ(timeStamp, timeZone), timeStampArea);

            tmpDetail.setTextFontName(timeStampFontName);
            tmpDetail.setTextFontColor(timeStampFontColor);
            tmpDetail.setTextFontType(timeStampFontType);
            tmpDetail.setTextFontSize(timeStampFontSize);
            tmpDetail.setTextWrapFlag(timeStampWrapFlag);
            tmpDetail.setTextFrameFlag(timeStampFrameFlag);

            tmpTextElements[ptr] = tmpDetail;
            ptr++;
        } else {
            logger.debug("timeStamp is null");
        }

        textElements = tmpTextElements;

        displayWidth = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "width", configResourceName, 128);
        displayHeight = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "height", configResourceName, 223);

        dataMaxLength = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "datafield.maxLength", configResourceName, 9);

        leftFrame = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "frame.left", configResourceName, 0);
        topFrame = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "frame.top", configResourceName, 10);

        leftShift = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "shift.left", configResourceName, 0);
        topShift = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "shift.top", configResourceName, 0);

        colSpace = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "margin.colspace", configResourceName, 0);
        topMargin = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "margin.top", configResourceName, 50);
        leftMargin = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "margin.left", configResourceName, 0);
        rightMargin = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "margin.right", configResourceName, 50);
        bottomMargin = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "margin.bottom", configResourceName, 50);
        iconGap = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "icon.gap", configResourceName, 5);

        jitterEncryptFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "encrypt.jitter", configResourceName, true);
        filesizeEncryptFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "encrypt.filesize", configResourceName, true);
        checksumEncryptFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "encrypt.checksum", configResourceName, true);
        dataEncryptFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "encrypt.data", configResourceName, true);
        randomizeKeysFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "encrypt.skins", configResourceName, true);

        outputType = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "output.type.default", configResourceName, "jpeg");

        enableLogoFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "logo.enable", configResourceName, false);
        logoFileName = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "logo.file", configResourceName, "Bharosa_chip_sm3.png");
        logoXPtr = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "logo.x", configResourceName, 0);
        logoYPtr = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "logo.y", configResourceName, 0);

        logoFontName = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "logo.font.name", configResourceName, "Verdana");
        logoFontType = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "logo.font.type", configResourceName, Font.PLAIN);
        logoFontSize = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "logo.font.size", configResourceName, 9);
        logoWidth = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "logo.width", configResourceName, 9);
        logoHeight = BharosaConfig.getLocalizedIntFromNamedBundle(propPrefix + "logo.height", configResourceName, 9);

        skinDirList = BharosaConfig.getLocalizedFromNamedBundle(propPrefix + "skins.dirlist", configResourceName);

        windowEnableFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle(propPrefix + "window.enable", configResourceName, false);

	}

	
	
    /**
     * Gets the value of imageUrl
     *
     * @return the value of imageUrl
     */
    public String getImageUrl() {
        return this.imageUrl;
    }

    /**
     * Sets the value of imageUrl
     *
     * @param argUrl the value to assign to  this.imageUrl
     */
    public void setImageUrl(String argUrl) {
        this.imageUrl = argUrl;
    }

    /**
     * Gets the value of outputType
     *
     * @return the value of outputType
     */
    public String getOutputType() {
        return this.outputType;
    }

    /**
     * Sets the value of outputType
     *
     * @param argOutputType Value to assign to this.outputType
     */
    public void setOutputType(String argOutputType) {
        this.outputType = argOutputType;
    }

    /**
     * Gets the value of Jitter Encrypt Flag
     *
     * @return the value of jitterEncryptFlag
     */
    public boolean getJitterEncryptFlag() {
        return this.jitterEncryptFlag;
    }

    /**
     * Gets the value of FileSize Encrypt Flag
     *
     * @return the value of filesizeEncryptFlag
     */
    public boolean getFileSizeEncryptFlag() {
        return this.filesizeEncryptFlag;
    }

    /**
     * Gets the value of Checksum Encrypt Flag
     *
     * @return the value of checksumEncryptFlag
     */
    public boolean getCheckSumEncryptFlag() {
        return this.checksumEncryptFlag;
    }


    /**
     * Gets the value of Data Encrypt Flag
     *
     * @return the value of dataEncryptFlag
     */
    public boolean getDataEncryptFlag() {
        return this.dataEncryptFlag;
    }

    /**
     * Gets the value of Randomize Keys Flag
     *
     * @return the value of randomizeKeysFlag
     */
    public boolean getRandomizeKeysFlag() {
        return this.randomizeKeysFlag;
    }

    /**
     * Sets the value of Randomize Keys Flag
     *
     * @param argRandomizeKeysFlag Value to assign to this.randomizeKeysFlag
     */
    public void setRandomizeKeysFlag(boolean argRandomizeKeysFlag) {
        this.randomizeKeysFlag = argRandomizeKeysFlag;
    }

    /**
     * @return Returns the enableDirectionsFlag.
     */
    public boolean getEnableDirectionsFlag() {
        return enableDirectionsFlag;
    }

    /**
     * @param enableDirectionsFlag The enableDirectionsFlag to set.
     */
    public void setEnableDirectionsFlag(boolean enableDirectionsFlag) {
        this.enableDirectionsFlag = enableDirectionsFlag;
    }

    /**
     * @return Returns the enableAccessKeyFlag.
     */
    public boolean getEnableAccessKeyFlag() {
        return enableAccessKeyFlag;
    }

    /**
     * @param enableAccessKeyFlag The enableAccessKeyFlag to set.
     */
    public void setEnableAccessKeyFlag(boolean enableAccessKeyFlag) {
        this.enableAccessKeyFlag = enableAccessKeyFlag;
    }

    /**
     * Gets the value of Enable Logo Flag
     *
     * @return the value of enableLogoFlag
     */
    public boolean getEnableLogoFlag() {
        return this.enableLogoFlag;
    }

    /**
     * Gets the value of Logo File Name
     *
     * @return the value of logoFileName
     */
    public String getLogoFileName() {
        return this.logoFileName;
    }

    /**
     * Gets the value of Logo XPtr
     *
     * @return the value of logoXPtr
     */
    public int getLogoXPtr() {
        return this.logoXPtr;
    }

    /**
     * Gets the value of Logo YPtr
     *
     * @return the value of logoYPtr
     */
    public int getLogoYPtr() {
        return this.logoYPtr;
    }

    /**
     * Gets the value of Logo Font Name
     *
     * @return the value of logoFontName
     */
    public String getLogoFontName() {
        return this.logoFontName;
    }

    /**
     * Gets the value of Logo Font Size
     *
     * @return the value of logoFontSize
     */
    public int getLogoFontSize() {
        return this.logoFontSize;
    }

    /**
     * Gets the value of Logo Font Type
     *
     * @return the value of logoFontType
     */
    public int getLogoFontType() {
        return this.logoFontType;
    }

    /**
     * Gets the value of Logo Width
     *
     * @return the value of logoWidth
     */
    public int getLogoWidth() {
        return this.logoWidth;
    }

    /**
     * Gets the value of Logo Height
     *
     * @return the value of logoHeight
     */
    public int getLogoHeight() {
        return this.logoHeight;
    }

    /**
     * Gets the value of captionFontName
     *
     * @return the value of captionFontName
     */
    public String getCaptionFontName() {
        return this.captionFontName;
    }

    /**
     * Gets the value of captionFontType
     *
     * @return the value of captionFontType
     */
    public int getCaptionFontType() {
        return this.captionFontType;
    }

    /**
     * Gets the value of captionFontSize
     *
     * @return the value of captionFontSize
     */
    public int getCaptionFontSize() {
        return this.captionFontSize;
    }

    /**
     * Gets the value of captionWidth
     *
     * @return the value of captionWidth
     */
    public int getCaptionWidth() {
        return this.captionWidth;
    }

    /**
     * Gets the value of captionHeight
     *
     * @return the value of captionHeight
     */
    public int getCaptionHeight() {
        return this.captionHeight;
    }

    /**
     * Gets the value of CaptionFrame
     *
     * @return the value of captionFrame
     */
    public boolean getCaptionFrameFlag() {
        return this.captionFrameFlag;
    }

    /**
     * Gets the value of CaptionWrap
     *
     * @return the value of captionWrap
     */
    public boolean getCaptionWrapFlag() {
        return this.captionWrapFlag;
    }

    /**
     * Sets the value of skinDirList
     *
     * @param argSkinDirList Value to assign to this.skinDirList
     */
    public void setSkinDirList(String argSkinDirList) {
        this.skinDirList = argSkinDirList;
    }

    /**
     * Gets the value of Skin Directory
     *
     * @return the value of skinDirList
     */
    public String getSkinDirList() {
        return this.skinDirList;
    }

    /**
     * Gets the value of displayWidth
     *
     * @return the value of displayWidth
     */
    public int getDisplayWidth() {
        return this.displayWidth;
    }

    /**
     * Sets the value of displayWidth
     *
     * @param argDisplayWidth Value to assign to this.displayWidth
     */
    public void setDisplayWidth(int argDisplayWidth) {
        this.displayWidth = argDisplayWidth;
    }

    /**
     * Gets the value of displayHeight
     *
     * @return the value of displayHeight
     */
    public int getDisplayHeight() {
        return this.displayHeight;
    }

    /**
     * Sets the value of displayHeight
     *
     * @param argDisplayHeight Value to assign to this.displayHeight
     */
    public void setDisplayHeight(int argDisplayHeight) {
        this.displayHeight = argDisplayHeight;
    }

    /**
     * Gets the value of displayHeight
     *
     * @return the value of displayHeight
     */
    public int getDataMaxLength() {
        return this.dataMaxLength;
    }

    /**
     * Sets the value of dataMaxLength
     *
     * @param argDataMaxLength Value to assign to this.dataMaxLength
     */
    public void setDataMaxLength(int argDataMaxLength) {
        this.dataMaxLength = argDataMaxLength;
    }

    /**
     * Gets the value of iconWidth
     *
     * @return the value of iconWidth
     */
    public int getIconWidth() {
        return this.iconWidth;
    }

    /**
     * Sets the value of iconWidth
     *
     * @param argIconWidth Value to assign to this.iconWidth
     */
    public void setIconWidth(int argIconWidth) {
        this.iconWidth = argIconWidth;
    }

    /**
     * Gets the value of iconHeight
     *
     * @return the value of iconHeight
     */
    public int getIconHeight() {
        return this.iconHeight;
    }

    /**
     * Sets the value of iconHeight
     *
     * @param argIconHeight Value to assign to this.iconHeight
     */
    public void setIconHeight(int argIconHeight) {
        this.iconHeight = argIconHeight;
    }

    /**
     * Gets the value of xPtr
     *
     * @return the value of xPtr
     */
    public int getXPtr() {
        return this.xPtr;
    }

    /**
     * Sets the value of xPtr
     *
     * @param argXPtr Value to assign to this.xPtr
     */
    public void setXPtr(int argXPtr) {
        this.xPtr = argXPtr;
    }

    /**
     * Gets the value of yPtr
     *
     * @return the value of yPtr
     */
    public int getYPtr() {
        return this.yPtr;
    }

    /**
     * Sets the value of yPtr
     *
     * @param argYPtr Value to assign to this.yPtr
     */
    public void setYPtr(int argYPtr) {
        this.yPtr = argYPtr;
    }

    /**
     * Gets the value of leftShift
     *
     * @return the value of leftShift
     */
    public int getLeftShift() {
        return this.leftShift;
    }

    /**
     * Sets the value of leftShift
     *
     * @param argLeftShift Value to assign to this.leftShift
     */
    public void setLeftShift(int argLeftShift) {
        this.leftShift = argLeftShift;
    }

    /**
     * Gets the value of topShift
     *
     * @return the value of topShift
     */
    public int getTopShift() {
        return this.topShift;
    }

    /**
     * Sets the value of topShift
     *
     * @param argTopShift Value to assign to this.topShift
     */
    public void setTopShift(int argTopShift) {
        this.topShift = argTopShift;
    }

    /**
     * Gets the value of topFrame
     *
     * @return the value of topFrame
     */
    public int getTopFrame() {
        return this.topFrame;
    }

    /**
     * Sets the value of topFrame
     *
     * @param argTopFrame Value to assign to this.topFrame
     */
    public void setTopFrame(int argTopFrame) {
        this.topFrame = argTopFrame;
    }

    /**
     * Gets the value of leftFrame
     *
     * @return the value of leftFrame
     */
    public int getLeftFrame() {
        return this.leftFrame;
    }

    /**
     * Sets the value of leftFrame
     *
     * @param argLeftFrame Value to assign to this.leftFrame
     */
    public void setLeftFrame(int argLeftFrame) {
        this.leftFrame = argLeftFrame;
    }

    /**
     * Gets the value of colSpace
     *
     * @return the value of colSpace
     */
    public int getColSpace() {
        return this.colSpace;
    }

    /**
     * Sets the value of colSpace
     *
     * @param argColSpace Value to assign to this.colSpace
     */
    public void setColSpace(int argColSpace) {
        this.colSpace = argColSpace;
    }

    /**
     * Gets the value of topMargin
     *
     * @return the value of topMargin
     */
    public int getTopMargin() {
        return this.topMargin;
    }

    /**
     * Sets the value of topMargin
     *
     * @param argTopMargin Value to assign to this.topMargin
     */
    public void setTopMargin(int argTopMargin) {
        this.topMargin = argTopMargin;
    }

    /**
     * Gets the value of bottomMargin
     *
     * @return the value of bottomMargin
     */
    public int getBottomMargin() {
        return this.bottomMargin;
    }

    /**
     * Sets the value of bottomMargin
     *
     * @param argBottomMargin Value to assign to this.bottomMargin
     */
    public void setBottomMargin(int argBottomMargin) {
        this.bottomMargin = argBottomMargin;
    }


    /**
     * Gets the value of leftMargin
     *
     * @return the value of leftMargin
     */
    public int getLeftMargin() {
        return this.leftMargin;
    }

    /**
     * Sets the value of leftMargin
     *
     * @param argLeftMargin Value to assign to this.leftMargin
     */
    public void setLeftMargin(int argLeftMargin) {
        this.leftMargin = argLeftMargin;
    }

    /**
     * Gets the value of rightMargin
     *
     * @return the value of rightMargin
     */
    public int getRightMargin() {
        return this.rightMargin;
    }

    /**
     * Sets the value of rightMargin
     *
     * @param argRightMargin Value to assign to this.rightMargin
     */
    public void setRightMargin(int argRightMargin) {
        this.rightMargin = argRightMargin;
    }

    /**
     * Gets the value of iconGap
     *
     * @return the value of iconGap
     */
    public int getIconGap() {
        return this.iconGap;
    }

    /**
     * Sets the value of iconGap
     *
     * @param argIconGap Value to assign to this.iconGap
     */
    public void setIconGap(int argIconGap) {
        this.iconGap = argIconGap;
    }

    /**
     * Gets the value of maskUrl
     *
     * @return the value of maskUrl
     */
    public String getMaskUrl() {
        return this.maskUrl;
    }

    /**
     * Sets the value of maskUrl
     *
     * @param argMaskUrl Value to assign to maskUrl
     */
    public void setMaskUrl(String argMaskUrl) {
        this.maskUrl = argMaskUrl;
    }

    /**
     * Gets the value of compatibilityUrl
     *
     * @return the value of compatibilityUrl
     */
    public String getCompatibilityUrl() {
        return this.compatibilityUrl;
    }

    /**
     * Sets the value of compatibilityUrl
     *
     * @param argCompatibilityUrl Value to assign to compatibilityUrl
     */
    public void setCompatibilityUrl(String argCompatibilityUrl) {
        this.compatibilityUrl = argCompatibilityUrl;
    }

    /**
     * @return Returns the accessKey.
     */
    public String getAccessKey() {
        return accessKey;
    }

    /**
     * @param accessKey The accessKey to set.
     */
    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    /**
     * @return Returns the padDescription.
     */
    public String getPadDescription() {
        return padDescription;
    }

    /**
     * @param padDescription The padDescription to set.
     */
    public void setPadDescription(String padDescription) {
        this.padDescription = padDescription;
    }

    /**
     * @return Returns the padDirections.
     */
    public String getPadDirections() {
        return padDirections;
    }

    /**
     * @param padDirections The padDirections to set.
     */
    public void setPadDirections(String padDirections) {
        this.padDirections = padDirections;
    }

    /**
     * @return Returns the padImgAlt.
     */
    public String getPadImgAlt() {
        return padImgAlt;
    }

    /**
     * @param padImgAlt The padImgAlt to set.
     */
    public void setPadImgAlt(String padImgAlt) {
        this.padImgAlt = padImgAlt;
    }
    
    
    /**
     * Gets the value of keys
     *
     * @return the value of keys
     */
    public KeyDetail [][] getKeys() {
        return this.keys;
    }

    /**
     * Sets the value of keys
     *
     * @param argKeys Value to assign to this.keys
     */
    public void setKeys(KeyDetail [][] argKeys) {
        this.keys = argKeys;
    }

    /**
     * Gets the value of controls
     *
     * @return the value of controls
     */
    public KeyDetail [] getControls() {
        return this.controls;
    }

    /**
     * Sets the value of controls
     *
     * @param argControls Value to assign to this.controls
     */
    public void setControls(KeyDetail [] argControls) {
        this.controls = argControls;
    }


    /**
     * Gets the value of textElements
     *
     * @return the value of textElements
     */
    public KeyDetail [] getTextElements() {
        return this.textElements;
    }

    /**
     * Sets the value of textElements
     *
     * @param argTextElements Value to assign to this.textElements
     */
    public void setTextElements(KeyDetail [] argTextElements) {
        this.textElements = argTextElements;
    }

}
