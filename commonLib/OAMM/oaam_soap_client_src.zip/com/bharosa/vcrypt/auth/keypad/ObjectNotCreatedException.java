package com.bharosa.vcrypt.auth.keypad;

import com.bharosa.common.logger.Logger;

/**
 * Exception class for chart
 *
 * @author "Philomina Dorai"
 * @version 1.0
 * @since 1.0
 * @see BharosaException
 */
public class ObjectNotCreatedException
	extends Exception {

	static Logger logger = Logger.getLogger(ObjectNotCreatedException.class);


	static public ObjectNotCreatedException createInvalidInputDataException () {
		return new ObjectNotCreatedException("INVALID_INPUT_DATA");
	}

	/////////////////////////////////////////////////////////////////////
	//These are common for all exception classes and they are private
	/////////////////////////////////////////////////////////////////////

	/**
	 * Creates an exception instance with the error id, without variables.
	 * @param errorId Error Id.
	 */
	private ObjectNotCreatedException( String errorId ) {
		super( errorId );
	}


}
