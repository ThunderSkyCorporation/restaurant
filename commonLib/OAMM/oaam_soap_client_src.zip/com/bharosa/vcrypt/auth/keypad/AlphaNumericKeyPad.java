package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.DateUtil;
import com.bharosa.common.logger.Logger;

import java.awt.*;

/**
 * This encapsulates all the properties for the KeyPad which was
 * generated for the given session.
 */

public class AlphaNumericKeyPad extends AuthentiPad implements DecodablePad {
    static protected Logger logger = Logger.getLogger(AlphaNumericKeyPad.class);

    /**
     * Creates the full keypad with the given background image.
     * The images generation can be tweaked by using various
     * property values in the configuration file. Please refer
     * the property file for the list of properties this
     * method supports.
     *
     * @param backgroundFilePath Path to the background file. It
     *                           could be absolute path or the path should be relative to the
     *                           directories in the classpath
     *                           creates a KeyPad object if there were no errors.
     */
    public AlphaNumericKeyPad(String padName, String backgroundFilePath, String frameFilePath) {
        super(padName, backgroundFilePath, frameFilePath);

        padType = AuthentiPad.KEYPAD;
        padProp = "keypad";
        padKeySetProp = "alphanumeric";
    }

    protected void initialize()
            throws ObjectNotCreatedException {
        super.initialize();
    }

    protected void setPadType() {
        if (!this.hasImgs) {
            this.padType = "T_KEYPADNOIMG";
        } else {
            this.padType = "T_KEYPAD";
        }
    }

    protected PadImageDirectory getParentImageDir() {
        return PadImageDirectory.keypad;
    }
}
