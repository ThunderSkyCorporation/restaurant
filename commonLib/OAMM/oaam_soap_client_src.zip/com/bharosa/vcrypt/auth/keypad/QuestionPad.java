package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.DateUtil;
import com.bharosa.common.logger.Logger;

import java.awt.*;
import java.util.Locale;

/**
 * This encapsulates all the properties for the KeyPad which was
 * generated for the given session.
 */

public class QuestionPad extends AuthentiPad {
    static private Logger  logger = Logger.getLogger(TextPad.class);

    /**
     * Creates the TextPad with the given background image.
     * The images generation can be tweaked by using various
     * property values in the configuration file. Please refer
     * the property file for the list of properties this
     * method supports.
     *
     * @param backgroundFilePath Path to the background file. It
     * could be absolute path or the path should be relative to the
     * directories in the classpath
     * creates a KeyPad object if there were no errors.
     */
    public QuestionPad( String padName, String backgroundFilePath, String frameFilePath){
            super(padName, backgroundFilePath, frameFilePath);

    padType = AuthentiPad.QUESTIONPAD;
    padProp = "questionpad";
    }

    protected void initialize()
            throws ObjectNotCreatedException
    {
    super.initialize();
    }
    
    public AuthentiConfig getAuthentiConfig(){
            AuthentiConfig authConfig = super.getAuthentiConfig();
            
            int x = 0;
            int y = 0;
            int width = 0;
            int height = 0;

            int ptr = 0;

            KeyDetail [] tmpTextElements = new KeyDetail[5];
            
            if(authConfig.personalizeCaption && captionText != null && captionText.getText() != null)
            {
            Locale captionLocale = captionText.getLocale().getLocale();

                    x = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".caption.x", authConfig.configResourceName, captionLocale, 0 );
                    y = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".caption.y", authConfig.configResourceName, captionLocale, 0 );

                    authConfig.captionFrameFlag = BharosaConfig.getLocalizedBooleanFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".caption.frame", authConfig.configResourceName, captionLocale, true);
                    authConfig.captionWrapFlag = BharosaConfig.getLocalizedBooleanFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".caption.wrap", authConfig.configResourceName, captionLocale, true);

                    authConfig.captionFontName = BharosaConfig.getLocalizedFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".caption.font.name", authConfig.configResourceName, captionLocale, "Verdana");
                    authConfig.captionFontColor = BharosaConfig.getLocalizedFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".caption.font.color", authConfig.configResourceName, captionLocale, "000000");
                    authConfig.captionFontType = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".caption.font.type", authConfig.configResourceName, captionLocale, Font.PLAIN);
                    authConfig.captionFontSize = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".caption.font.size", authConfig.configResourceName, captionLocale, 9);
                    authConfig.captionWidth = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".caption.width", authConfig.configResourceName, captionLocale, 9);
                    authConfig.captionHeight= BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".caption.height", authConfig.configResourceName, captionLocale, 9);


                    Rectangle captionArea = new Rectangle(x, y, authConfig.captionWidth, authConfig.captionHeight);
                    KeyDetail tmpDetail = new KeyDetail(captionText.getText(), captionArea);
                    
                    tmpDetail.setTextFontName(authConfig.captionFontName);
                    tmpDetail.setTextFontColor(authConfig.captionFontColor);
                    tmpDetail.setTextFontType(authConfig.captionFontType);
                    tmpDetail.setTextFontSize(authConfig.captionFontSize);
                    tmpDetail.setTextWrapFlag(authConfig.captionWrapFlag);
                    tmpDetail.setTextFrameFlag(authConfig.captionFrameFlag);
                    
                    tmpTextElements[ptr] = tmpDetail;
                    ptr++;
            }
            else
            {
                    logger.debug("getPinPad() caption is null");
            }


            if(questionText != null && questionText.getText() != null)
            {
                    
            Locale questionLocale = questionText.getLocale().getLocale();

                    x = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".question.x", authConfig.configResourceName, questionLocale, 0 );
                    y = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".question.y", authConfig.configResourceName, questionLocale, 0 );


                    boolean questionFrameFlag = BharosaConfig.getLocalizedBooleanFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".question.frame", authConfig.configResourceName, questionLocale, true);
                    boolean questionWrapFlag = BharosaConfig.getLocalizedBooleanFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".question.wrap", authConfig.configResourceName, questionLocale, true);

                    String questionFontName = BharosaConfig.getLocalizedFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".question.font.name", authConfig.configResourceName, questionLocale, "Verdana");
                    String questionFontColor = BharosaConfig.getLocalizedFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".question.font.color", authConfig.configResourceName, questionLocale, "000000");
                    int questionFontType = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".question.font.type", authConfig.configResourceName, questionLocale, Font.PLAIN);
                    int questionFontSize = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".question.font.size", authConfig.configResourceName, questionLocale, 9);

                    int questionWidth = BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".question.width", authConfig.configResourceName, questionLocale, 9);
                    int questionHeight= BharosaConfig.getLocalizedIntFromNamedBundleAndLocale("bharosa.authentipad." + padProp + ".question.height", authConfig.configResourceName, questionLocale, 9);


                    Rectangle questionArea = new Rectangle(x, y, questionWidth, questionHeight);

                    KeyDetail tmpDetail = new KeyDetail(questionText.getText(), questionArea);
                    
                    tmpDetail.setTextFontName(questionFontName);
                    tmpDetail.setTextFontColor(questionFontColor);
                    tmpDetail.setTextFontType(questionFontType);
                    tmpDetail.setTextFontSize(questionFontSize);
                    tmpDetail.setTextWrapFlag(questionWrapFlag);
                    tmpDetail.setTextFrameFlag(questionFrameFlag);
                    
                    tmpTextElements[ptr] = tmpDetail;

                    ptr++;
            }
            else
            {
                    logger.debug("getPinPad() question is null");
            }

        if(timeStamp != null)
        {
          x = BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".timestamp.x", authConfig.configResourceName, 0 );
          y = BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".timestamp.y", authConfig.configResourceName, 0 );
    
          authConfig.timeStampFrameFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle("bharosa.authentipad." + padProp + ".timestamp.frame", authConfig.configResourceName, true);
          authConfig.timeStampWrapFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle("bharosa.authentipad." + padProp + ".timestamp.wrap", authConfig.configResourceName, true);
    
          authConfig.timeStampFontName = BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad." + padProp + ".timestamp.font.name", authConfig.configResourceName, "Verdana");
          authConfig.timeStampFontColor = BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad." + padProp + ".timestamp.font.color", authConfig.configResourceName, "ffffff");
          authConfig.timeStampFontType = BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".timestamp.font.type", authConfig.configResourceName, Font.PLAIN);
          authConfig.timeStampFontSize = BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".timestamp.font.size", authConfig.configResourceName, 9);
          authConfig.timeStampWidth = BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".timestamp.width", authConfig.configResourceName, 9);
          authConfig.timeStampHeight= BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".timestamp.height", authConfig.configResourceName, 9);
    
    
          Rectangle timeStampArea = new Rectangle(x, y, authConfig.timeStampWidth, authConfig.timeStampHeight);
    
    
          KeyDetail tmpDetail = new KeyDetail(DateUtil.getFormattedDateWithTZ(timeStamp, timeZone), timeStampArea);
    
          tmpDetail.setTextFontName(authConfig.timeStampFontName);
          tmpDetail.setTextFontColor(authConfig.timeStampFontColor);
          tmpDetail.setTextFontType(authConfig.timeStampFontType);
          tmpDetail.setTextFontSize(authConfig.timeStampFontSize);
          tmpDetail.setTextWrapFlag(authConfig.timeStampWrapFlag);
          tmpDetail.setTextFrameFlag(authConfig.timeStampFrameFlag);
    
          tmpTextElements[ptr] = tmpDetail;
          ptr++;
        }
        else
        {
          logger.debug("timeStamp is null");
        }

        authConfig.textElements = tmpTextElements;
        
        return authConfig;

    }
    
    protected String getNoScriptHTML(AuthentiConfig authConfig){

            String stylePosition = "relative";
            String styleVisibility = "visible";
            
            String dataStyle = "position:absolute;left:" + BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".datafield.x", authConfig.configResourceName, 0 ) +
                                                    "px;top:" + BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".datafield.y", authConfig.configResourceName, 0 ) +
                                                    "px;width:" + BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".datafield.width", authConfig.configResourceName, 0) +
                                                    "px;height:" + BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".datafield.height", authConfig.configResourceName, 0 ) + 
                                                    "px;font-family:helvetica, arial;font-size:9px;font-weight:bold;text-align:left;";
            
            //String dataStyleVisibility = (BharosaConfig.getLocalizedBooleanFromNamedBundle("bharosa.authentipad." + padProp + ".datafield.enable", authConfig.configResourceName, true)?"visible":"hidden");
            
            String styleLeft = "0";
            String styleTop = "0";
            
            int enterX = 0;
            int enterY = 0; 
            int enterWidth = 0; 
            int enterHeight = 0;
            String enterLabel = "enter";
            String dataFieldLabel = BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad." + padProp + ".datafield.label", "Answer" );
                    
            if (authConfig.enterKeyControl != null)
            {
                    enterX =  (int)authConfig.enterKeyControl.getArea().getX();
                    enterY = (int)authConfig.enterKeyControl.getArea().getY();
                    enterWidth = (int)authConfig.enterKeyControl.getArea().getWidth();
                    enterHeight = (int)authConfig.enterKeyControl.getArea().getHeight();
                    enterLabel = authConfig.enterKeyControl.getKeyName(); 
            }
            
            
            
            String returnStr = "<noscript>";
            
            if (this.hasImgs){
                    String dataInputStyle = "border:none;font-size:15px;width:125px;height:15px;";
                    
                    returnStr += "<div id=\"" + padName + "PadDiv\" name=\"" + padName + "PadDiv\" style=\"position: " + stylePosition + "; width: " + authConfig.displayWidth + "px; left: " + styleLeft + "px; top: " + styleTop + "px; visibility:" + styleVisibility + ";\">";
                    returnStr += "<img id=\"" + padName + "PadImage\" align=\"center\" valign=\"middle\" src=\"" + authConfig.imageUrl + "pid=" + padName + "&keyId=" + System.currentTimeMillis() + "\" border=\"0\" usemap=\"#" + this.padName + "Map\" alt=\"Security Device Image\">";
                    returnStr += "<div id=\"" + padName + "DataDiv\" style=\"visibility:" + styleVisibility + ";position:absolute;" + dataStyle + "\">";
                    returnStr += "<input type=\"password\" name=\"" + padName + "DataField\" id=\"" + padName + "DataField\" style=\"" + dataInputStyle + "\" maxlength=\"" + authConfig.dataMaxLength + "\">";
                    returnStr += "</div>";
                    if (authConfig.enterKeyControl != null)
                    {
                            returnStr += "<div id=\"" + padName + "EnterDiv\" style=\"position:absolute;left:" + enterX + "px;top:" + enterY + "px;\"><input type=\"image\" src=\"" + authConfig.maskUrl + "\" width=\"" + enterWidth + "\" height=\"" + enterHeight + "\" alt=\"" + enterLabel + "\"/></div>";
                    }
                    returnStr += "</div>";
            } else {
                    String dataInputStyle = "border:1px solid black;font-size:15px;width:125px;height:15px;";
                    
                    int captionX = BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".caption.x", authConfig.configResourceName, 0 );
                    int captionY = BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".caption.y", authConfig.configResourceName, 0 );

                    boolean captionFrameFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle("bharosa.authentipad." + padProp + ".caption.frame", authConfig.configResourceName, true);
                    boolean captionWrapFlag = BharosaConfig.getLocalizedBooleanFromNamedBundle("bharosa.authentipad." + padProp + ".caption.wrap", authConfig.configResourceName, true);

                    String captionFontName = BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad." + padProp + ".caption.font.name", authConfig.configResourceName, "Verdana");
                    int captionFontType = BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".caption.font.type", authConfig.configResourceName, Font.PLAIN);
                    int captionFontSize = BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".caption.font.size", authConfig.configResourceName, 9);
                    int captionWidth = BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".caption.width", authConfig.configResourceName, 9);
                    int captionHeight= BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad." + padProp + ".caption.height", authConfig.configResourceName, 9);

                    
                    String padFont = "arial, helvetica";
                    String padBGColor = "#EEEFE1";
                    String controlBGColor = "#BEBF9D";
    
                    returnStr += "<style type=\"text/css\">";
                    returnStr += "#" + this.padName + "PadDiv {position:" + stylePosition + ";visibility:" + styleVisibility + ";left:" + styleLeft + "px;top:" + styleTop + "px;height:" + authConfig.displayHeight + "px;width:" + authConfig.displayWidth + "px;background-color:" + padBGColor + ";border: 1px black solid;cursor:default;}";
                    returnStr += "#" + this.padName + "DragBar {width:100%;height:100%;}";
                    returnStr += "#" + this.padName + "DataDiv {" + dataStyle + "}";

                    if (authConfig.enterKeyControl != null)
                    {
                            returnStr += "#" + this.padName + "EnterDiv {position:absolute;left:" + enterX + "px;top:" + enterY + "px;width:" + enterWidth + "px;height:" + enterHeight + "px;font-size:12px;font-weight:bold;font-family:" + padFont + ";text-align:center;cursor:pointer;background-color:" + controlBGColor + ";}";
                            returnStr += "#" + this.padName + "EnterDiv a:link {text-decoration:none;color:black;}";
                            returnStr += "#" + this.padName + "EnterDiv a:visited {text-decoration:none;color:black;}";
                    }

                    returnStr += "#" + this.padName + "CaptionDiv {position:absolute;left:" + captionX + "px;top:" + captionY + "px;width:" + captionWidth + "px;height:" + captionHeight + "px;text-align:left;font-size:" + captionFontSize + "px;font-family:" + captionFontName + ";font-weight:" + (captionFontType==1?"bold":"normal") + ";}";
                    returnStr += "#" + this.padName + "CaptionDiv a:link {text-decoration:none;color:black;}";
                    returnStr += "#" + this.padName + "CaptionDiv a:visited {text-decoration:none;color:black;}";
    
                    returnStr += "</style>";
    
                    returnStr += "<div id=\"" + this.padName + "PadDiv\" name=\"" + this.padName + "PadDiv\">";
                    returnStr += "<div id=\"" + this.padName + "DragBar\">";
                    returnStr += "<div id=\"" + this.padName + "DataDiv\">";
                    returnStr += dataFieldLabel + ":<br>";
                    returnStr += "<textarea name=\"" + this.padName + "DataField\" id=\"" + this.padName + "DataField\" style=\"" + dataInputStyle + ">" + this.userInput + "</textarea>";
                    returnStr += "</div>";
                    
                    returnStr += "</div>";
//			returnStr += "<div id=\"" + this.padName + "EnterDiv\" onclick=\"" + this.padName + ".keyPress(\"ENTERKEY\";\"><a href=\"" + compatibilityUrl + "?pad=" + this.padName + "&key=ENTERKEY\" target=\"_top\">" + enterLabel + "</a></div>";
                    returnStr += "<input type=\"submit\" id=\"" + this.padName + "EnterDiv\" onclick=\"" + this.padName + ".keyPress(\"ENTERKEY\";\" value=\"" + enterLabel + "\" name=\"" + enterLabel + "\" />";
            
                    if (this.captionText != null)
                    {
                            returnStr += "<div id=\"" + this.padName + "CaptionDiv\"><a href=\"#\">" + this.captionText + "</a></div>";
                    }
                    
                    returnStr += "</div>";
                             
            }
            
            returnStr += "</noscript>\n";
            
            return returnStr;
    }

    protected PadImageDirectory getParentImageDir() {
        return PadImageDirectory.questionpad;
    }

}
