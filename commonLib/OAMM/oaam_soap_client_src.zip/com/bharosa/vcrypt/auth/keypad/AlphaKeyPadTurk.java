package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.DateUtil;
import com.bharosa.common.logger.Logger;

import java.awt.*;

/**
 * This encapsulates all the properties for the KeyPad which was
 * generated for the given session.
 */

public class AlphaKeyPadTurk extends AuthentiPad implements DecodablePad {
    static protected Logger logger = Logger.getLogger(AlphaNumericKeyPad.class);

    /**
     * Creates the full keypad with the given background image.
     * The images generation can be tweaked by using various
     * property values in the configuration file. Please refer
     * the property file for the list of properties this
     * method supports.
     *
     * @param backgroundFilePath Path to the background file. It
     *                           could be absolute path or the path should be relative to the
     *                           directories in the classpath
     *                           creates a KeyPad object if there were no errors.
     */
    public AlphaKeyPadTurk(String padName, String backgroundFilePath, String frameFilePath) {
        super(padName, backgroundFilePath, frameFilePath);

        padType = AuthentiPad.KEYPAD;
        padProp = "alphanumeric";
        padKeySetProp = "turk";
    }

    protected void initialize()
            throws ObjectNotCreatedException {
        super.initialize();
    }

    public AuthentiConfig getAuthentiConfig(){
    	AuthentiConfig authConfig = super.getAuthentiConfig();
    	
        String propPrefix = padPropPrefix + "." + padProp + ".";

        int keyWidthJitter = BharosaConfig.getInt(propPrefix + "keyWidthJitter", 0);
        int keyHeightJitter = BharosaConfig.getInt(propPrefix + "keyHeightJitter", 0);

        //Create the keys array
        KeyDetail [][] tmpKeys = {
                {
                        new KeyDetail("kp_v2_1.png", "1", "1", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_2.png", "2", "2", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_3.png", "3", "3", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_4.png", "4", "4", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_5.png", "5", "5", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_6.png", "6", "6", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_7.png", "7", "7", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_8.png", "8", "8", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_9.png", "9", "9", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_0.png", "0", "0", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_U_umlot.png", "!", "@", keyWidthJitter, keyHeightJitter),

                },
                {
                        new KeyDetail("kp_v2_Q.png", "q", "Q", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_W.png", "w", "W", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_E.png", "e", "E", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_R.png", "r", "R", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_T.png", "t", "T", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_Y.png", "y", "Y", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_U.png", "u", "U", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_I.png", "i", "I", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_O.png", "o", "O", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_P.png", "p", "P", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_G_silent.png", "#", "$", keyWidthJitter, keyHeightJitter),
                },
                {
                        new KeyDetail("kp_v2_A.png", "a", "A", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_S.png", "s", "S", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_D.png", "d", "D", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_F.png", "f", "F", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_G.png", "g", "G", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_H.png", "h", "H", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_J.png", "j", "J", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_K.png", "k", "K", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_L.png", "l", "L", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_S_sh.png", "%", "^", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_i_ee.png", "&", "*", keyWidthJitter, keyHeightJitter),
                },
                {
                        new KeyDetail("kp_v2_blank.png", "", "", keyWidthJitter, keyHeightJitter),

                        new KeyDetail("kp_v2_Z.png", "z", "Z", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_X.png", "x", "X", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_C.png", "c", "C", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_V.png", "v", "V", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_B.png", "b", "B", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_N.png", "n", "N", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_M.png", "m", "M", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_O_umlot.png", "(", ")", keyWidthJitter, keyHeightJitter),
                        new KeyDetail("kp_v2_C_ch.png", "_", "+", keyWidthJitter, keyHeightJitter),

                        new KeyDetail("kp_v2_blank.png", "", "", keyWidthJitter, keyHeightJitter),

                }
        };

        authConfig.keys = tmpKeys;

        return authConfig;
    	
    }
    
    protected PadImageDirectory getParentImageDir() {
        return PadImageDirectory.keypad;
    }

}
