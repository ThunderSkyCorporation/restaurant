package com.bharosa.vcrypt.auth.keypad;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class PadImageDirectory {

    private static ArrayList imageDirectoryList = new ArrayList();

    public static PadImageDirectory keypad = new PadImageDirectory("keypad");
    public static PadImageDirectory pinpad = new PadImageDirectory("textpad"); // Pinpad uses same images as textpad
    public static PadImageDirectory questionpad = new PadImageDirectory("textpad"); // Questionpad and textpad images are or same size:
    public static PadImageDirectory textpad = new PadImageDirectory("textpad"); 

    private String directory;
    PadImageDirectory(String directory) {
        this.directory = directory;
        imageDirectoryList.add(directory);
    }

    public String getDirectory() {
        return directory;
    }

    public static List getDirectoryList() {
        return Collections.unmodifiableList(imageDirectoryList);
    }
    
}
