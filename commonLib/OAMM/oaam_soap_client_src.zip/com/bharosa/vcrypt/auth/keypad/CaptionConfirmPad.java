package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.HttpUtil;
import com.bharosa.common.logger.Logger;

import java.awt.*;

/**
 * This encapsulates all the properties for the KeyPad which was
 * generated for the given session.
 */

public class CaptionConfirmPad extends AuthentiPad {
    static private Logger logger = Logger.getLogger(CaptionConfirmPad.class);

    /**
     * Creates the CaptionConfirmPad with the given background image.
     * The images generation can be tweaked by using various
     * property values in the configuration file. Please refer
     * the property file for the list of properties this
     * method supports.
     *
     * @param backgroundFilePath Path to the background file. It
     * could be absolute path or the path should be relative to the
     * directories in the classpath
     * creates a KeyPad object if there were no errors.
     */
    public CaptionConfirmPad(String padName, String backgroundFilePath,
                             String frameFilePath) {
        super(padName, backgroundFilePath, frameFilePath);

        padType = AuthentiPad.CAPTIONCONFIRMPAD;
        padProp = "captionconfirmpad";
    }

    protected void initialize() throws ObjectNotCreatedException {
        super.initialize();

    }

    protected String getNoScriptHTML(AuthentiConfig authConfig) {

        String propPrefix = padPropPrefix + "." + padProp + ".";

        String stylePosition = "relative";
        String styleVisibility = "visible";

        String dataStyle =
            "position:absolute;left:" + BharosaConfig.getInt(propPrefix +
                                                             "datafield.x",
                                                             0) + "px;top:" +
            BharosaConfig.getInt(propPrefix + "datafield.y", 0) + "px;width:" +
            BharosaConfig.getInt(propPrefix + "datafield.width", 0) +
            "px;height:" +
            BharosaConfig.getInt(propPrefix + "datafield.height", 0) +
            "px;font-family:helvetica, arial;font-size:9px;font-weight:bold;text-align:left;";

        //String dataStyleVisibility = (BharosaConfig.getBoolean("bharosa.authentipad.textpad.datafield.enable", true)?"visible":"hidden");

        String styleLeft = "0";
        String styleTop = "0";

        int enterX = 0;
        int enterY = 0;
        int enterWidth = 0;
        int enterHeight = 0;
        String enterLabel = "enter";
        //		String dataFieldLabel = BharosaConfig.get(propPrefix + "datafield.label", "Caption" );

        if (authConfig.enterKeyControl != null) {
            enterX = (int)authConfig.enterKeyControl.getArea().getX();
            enterY = (int)authConfig.enterKeyControl.getArea().getY();
            enterWidth = (int)authConfig.enterKeyControl.getArea().getWidth();
            enterHeight =
                    (int)authConfig.enterKeyControl.getArea().getHeight();
            enterLabel = authConfig.enterKeyControl.getKeyName();
        }


        String returnStr = "<noscript>";

        if (this.hasImgs) {
            String dataInputStyle =
                "border:1px solid black;font-size:12px;width:125px;height:15px;";

            returnStr +=
                    "<div id=\"" + padName + "PadDiv\" name=\"" + padName +
                    "PadDiv\" style=\"position: " + stylePosition +
                    "; width: " + authConfig.displayWidth + "px; left: " +
                    styleLeft + "px; top: " + styleTop + "px; visibility:" +
                    styleVisibility + ";\">";
            returnStr +=
                    "<img id=\"" + padName + "PadImage\" align=\"center\" valign=\"middle\" src=\"" +
                    authConfig.imageUrl + "pid=" + padName + "&keyId=" +
                    System.currentTimeMillis() + "\" border=\"0\" usemap=\"#" +
                    this.padName + "Map\">";
            if (authConfig.enterKeyControl != null) {
                returnStr +=
                        "<div id=\"" + padName + "EnterDiv\" style=\"position:absolute;left:" +
                        enterX + "px;top:" + enterY +
                        "px;\"><input type=\"image\" src=\"" +
                        authConfig.maskUrl + "\" width=\"" + enterWidth +
                        "\" height=\"" + enterHeight + "\" alt=\"" +
                        enterLabel + "\"/></div>";
            }
            returnStr += "</div>";
        } else {
            String dataInputStyle =
                "border:1px solid black;font-size:12px;font-weight:normal;width:125px;height:15px;";

            int captionX =
                BharosaConfig.getInt("bharosa.authentipad.textpad.caption.x",
                                     0);
            int captionY =
                BharosaConfig.getInt("bharosa.authentipad.textpad.caption.y",
                                     0);

            boolean captionFrameFlag =
                BharosaConfig.getBoolean(propPrefix + "caption.frame", true);
            boolean captionWrapFlag =
                BharosaConfig.getBoolean(propPrefix + "caption.wrap", true);

            String captionFontName =
                BharosaConfig.get(propPrefix + "caption.font.name", "Verdana");
            int captionFontType =
                BharosaConfig.getInt(propPrefix + "caption.font.type",
                                     Font.PLAIN);
            int captionFontSize =
                BharosaConfig.getInt(propPrefix + "caption.font.size", 9);
            int captionWidth =
                BharosaConfig.getInt(propPrefix + "caption.width", 9);
            int captionHeight =
                BharosaConfig.getInt(propPrefix + "caption.height", 9);

            String padFont = "arial, helvetica";
            String padBGColor = "#EEEFE1";
            String controlBGColor = "#BEBF9D";

            returnStr += "<style type=\"text/css\">";
            returnStr +=
                    "#" + this.padName + "PadDiv {position:" + stylePosition +
                    ";visibility:" + styleVisibility + ";left:" + styleLeft +
                    "px;top:" + styleTop + "px;height:" +
                    authConfig.displayHeight + "px;width:" +
                    authConfig.displayWidth + "px;background-color:" +
                    padBGColor + ";border: 1px black solid;cursor:default;}";
            returnStr +=
                    "#" + this.padName + "DragBar {width:100%;height:100%;}";
            returnStr += "#" + this.padName + "DataDiv {" + dataStyle + "}";

            if (authConfig.enterKeyControl != null) {
                returnStr +=
                        "#" + this.padName + "EnterDiv {position:absolute;left:" +
                        enterX + "px;top:" + enterY + "px;width:" +
                        enterWidth + "px;height:" + enterHeight +
                        "px;font-size:12px;font-weight:bold;font-family:" +
                        padFont +
                        ";text-align:center;cursor:pointer;background-color:" +
                        controlBGColor + ";}";
                returnStr +=
                        "#" + this.padName + "EnterDiv a:link {text-decoration:none;color:black;}";
                returnStr +=
                        "#" + this.padName + "EnterDiv a:visited {text-decoration:none;color:black;}";
            }

            returnStr +=
                    "#" + this.padName + "CaptionDiv {position:absolute;left:" +
                    captionX + "px;top:" + captionY + "px;width:" +
                    captionWidth + "px;height:" + captionHeight +
                    "px;text-align:left;font-size:" + captionFontSize +
                    "px;font-family:" + captionFontName + ";font-weight:" +
                    (captionFontType == 1 ? "bold" : "normal") + ";}";
            returnStr +=
                    "#" + this.padName + "CaptionDiv a:link {text-decoration:none;color:black;}";
            returnStr +=
                    "#" + this.padName + "CaptionDiv a:visited {text-decoration:none;color:black;}";

            returnStr += "</style>";

            returnStr +=
                    "<div id=\"" + this.padName + "PadDiv\" name=\"" + this.padName +
                    "PadDiv\">";
            returnStr += "<div id=\"" + this.padName + "DragBar\">";
            returnStr += "</div>";
            //			returnStr += "<div id=\"" + this.padName + "EnterDiv\" onclick=\"" + this.padName + ".keyPress(\"ENTERKEY\";\"><a href=\"" + compatibilityUrl + "?pad=" + this.padName + "&key=ENTERKEY\" target=\"_top\">" + enterLabel + "</a></div>";
            returnStr +=
                    "<input type=\"submit\" id=\"" + this.padName + "EnterDiv\" onclick=\"" +
                    this.padName + ".keyPress(\"ENTERKEY\";\" value=\"" +
                    enterLabel + "\" name=\"" + enterLabel + "\" />";

            if (this.captionText != null &&
                this.captionText.getText() != null) {
                returnStr +=
                        "<div id=\"" + this.padName + "CaptionDiv\"><a href=\"#\">" +
                        HttpUtil.encode(this.captionText.getText()) +
                        "</a></div>";
            }
            returnStr += "</div>";

        }

        returnStr += "</noscript>\n";

        return returnStr;
    }

    protected PadImageDirectory getParentImageDir() {
        return PadImageDirectory.textpad;
    }
}
