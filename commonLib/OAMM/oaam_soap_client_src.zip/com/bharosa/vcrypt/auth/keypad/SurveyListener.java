package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.BharosaMail;
import com.bharosa.common.logger.Logger;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import java.util.Enumeration;
import java.util.Vector;
 
 
public final class SurveyListener implements HttpSessionListener {
	static private Logger  logger = Logger.getLogger(SurveyListener.class);

	public void sessionCreated(HttpSessionEvent sessionEvent) {
		logger.debug("HTTP Session created: " + sessionEvent.getSession().getId());
	}
	
    public void sessionDestroyed(HttpSessionEvent sessionEvent) {
		logger.debug("HTTP Session destroyed: " + sessionEvent.getSession().getId());
        HttpSession session = sessionEvent.getSession();
		sendSurvey( session );
    }

	public static void sendSurvey( HttpSession session ) {
		String emailBody = "";
		try {
			logger.debug("sendSurvey()");
			
			String simpleOut = "<table border=\"1\">";
			Vector resultList = (Vector)session.getAttribute("resultList");
			if( resultList == null || resultList.size() == 0 ) {
				return;
			}
			
			Enumeration e = resultList.elements();
			while( e.hasMoreElements()) {
				String resultArr[] = (String[]) e.nextElement();
				simpleOut += "<tr><td>" + resultArr[0] + "</td><td>"
					+ resultArr[1] + "</td></tr>";
			}
			/*
			Enumeration paramEnum = request.getParameterNames();
			while (paramthisenum.hasMoreElements()){
				String param = (String)paramthisenum.nextElement();
				String value = request.getParameter(param);
				if( param.equalsIgnoreCase("submit") ) {
					continue;
				}
				simpleOut +="<tr><td>";
				simpleOut += param+"</td><td>"+value+"</td></tr>";
			}
			*/
			simpleOut +="</table>";
			
			if( BharosaConfig.get("keypad.focus.mailto.list") != null ) {
				BharosaMail mail = new BharosaMail();
				
				String[] mailTo = {BharosaConfig.get("keypad.focus.mailto.list")};
				String fromName = "Keypad Survey";
				String from = "support@bharosa.com";
				String replyTo = "bosco@bharosa.com";
				String subject = "Keypad Survey";
				
				emailBody = simpleOut;
				
				logger.debug("Sending mail to:" + mailTo[0]);
				mail.sendMail(mailTo, fromName, from, replyTo, subject, emailBody);
				logger.debug("mail sent to:" + mailTo[0]);
				resultList.clear();
			}
			logger.debug("mail content:" + simpleOut);
		} catch( Exception ex ) {
			logger.error("Error sending survery email:" + emailBody, ex );
		}
	}
}
 
