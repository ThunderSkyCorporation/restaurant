/**
 * 
 */
package com.bharosa.vcrypt.auth.keypad;

import java.io.Serializable;

/**
 * @author Dan
 *
 */
public class AuthentiKey implements Serializable {
	
	protected boolean bDecodable = true;
	protected boolean bADACompliant = false;
	
	protected short[] mKeyLocations; // 4 per key: x, y, w, h
	protected String[] mKeyCodes; // 1 per key: code
	protected short[] mKeyIndexes; // 2 per key: x-index, y-index in 2d array loaded from properties
	
	public AuthentiKey(){
	}

	public void setDecodable(boolean decodeFlag){
		bDecodable = decodeFlag;
	}
	
	public boolean isDecodable(){
		return bDecodable;
	}
	
	public void setADACompliant(boolean adaFlag){
		bADACompliant = adaFlag;
	}
	
	public boolean isADACompliant(){
		return bADACompliant;
	}

	public short[] getKeyLocations(){
		return mKeyLocations;
	}
	
	public void setKeyLocations(short[] keyLocs){
		mKeyLocations = keyLocs;
	}

	public short[] getKeyIndexes(){
		return mKeyIndexes;
	}
	
	public void setKeyIndexes(short[] keyIndexes){
		mKeyIndexes= keyIndexes;
	}

	public String[] getKeyCodes(){
		return mKeyCodes;
	}
	
	public void setKeyCodes(String[] keyCodes){
		mKeyCodes = keyCodes;
	}

	public String getCode(int index){
		return mKeyCodes[index];
	}
 
	public short getX(int index){
		return mKeyLocations[index*4];
	}

	public short getY(int index){
		return mKeyLocations[(index*4)+1];
	}

	public short getWidth(int index){
		return mKeyLocations[(index*4)+2];
	}

	public short getHeight(int index){
		return mKeyLocations[(index*4)+3];
	}
	
	public short getXIndex(int index){
		return mKeyIndexes[index*2];
	}

	public short getYIndex(int index){
		return mKeyIndexes[(index*2)+1];
	}

}
