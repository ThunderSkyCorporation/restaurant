package com.bharosa.vcrypt.auth.keypad;
/*
 * Copyright (c) 2006 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * Description
 * Date: Nov 28, 2006
 *
 * @author dan
 */
public interface DecodablePad {
  // Marker Interface for decodable authentipads.
}
