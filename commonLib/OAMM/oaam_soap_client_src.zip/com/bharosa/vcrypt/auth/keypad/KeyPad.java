package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;

public class KeyPad extends AuthentiPad implements DecodablePad {
    static protected Logger logger = Logger.getLogger(KeyPad.class);

    public KeyPad(String padName, String backgroundFilePath, String frameFilePath) {
        super(padName, backgroundFilePath, frameFilePath);
    }

    protected void initialize()
            throws ObjectNotCreatedException {
        padType = AuthentiPad.KEYPAD;
        padProp = "full";

        super.initialize();
    }

    protected PadImageDirectory getParentImageDir() {
        return PadImageDirectory.keypad;
    }

}
