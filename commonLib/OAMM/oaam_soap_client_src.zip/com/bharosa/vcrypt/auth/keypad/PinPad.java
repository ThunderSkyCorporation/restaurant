package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.DateUtil;
import com.bharosa.common.logger.Logger;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

/**
 * This encapsulates all the properties for the KeyPad which was
 * generated for the given session.
 */

public class PinPad extends AuthentiPad implements DecodablePad {
    static private Logger logger = Logger.getLogger(PinPad.class);

    public PinPad(String padName, String backgroundFilePath, String frameFilePath) {
        super(padName, backgroundFilePath, frameFilePath);

        padType = AuthentiPad.PINPAD;
        padProp = "pinpad";
    }

    protected void initialize()
            throws ObjectNotCreatedException {

        super.initialize();
    }

    protected String getNoScriptHTML(AuthentiConfig authConfig) {
    	
        String propPrefix = padPropPrefix + "." + padProp + ".";

        String userValue = this.userInput;

        int charCnt = 0;
        String displayStr = "";
        if (userValue != null && !"".equals(userValue)) {
            charCnt = userValue.split(":").length;
            for (int i = 0; i < charCnt; i++) {
                displayStr += "*";
            }
        }
        String returnStr = "<noscript>";

        String stylePosition = "relative";
        String styleVisibility = "visible";

        String dataStyle = "position:absolute;left:" + BharosaConfig.getInt(propPrefix + "datafield.x", 0) +
                "px;top:" + BharosaConfig.getInt(propPrefix + "datafield.y", 0) +
                "px;width:" + BharosaConfig.getInt(propPrefix + "datafield.width", 0) +
                "px;height:" + BharosaConfig.getInt(propPrefix + "datafield.height", 0) +
                "px;padding-top:4px;padding-left:0px;font-size:17px;font-family:helvetica,arial;text-align:left;";

        String dataStyleVisibility = (BharosaConfig.getBoolean(propPrefix + "datafield.enable", true) ? "visible" : "hidden");

        String styleLeft = "0";
        String styleTop = "0";

        int enterX = 0;
        int enterY = 0;
        int enterWidth = 0;
        int enterHeight = 0;
        String enterLabel = "enter";

        if (authConfig.enterKeyControl != null) {
            enterX = (int) authConfig.enterKeyControl.getArea().getX();
            enterY = (int) authConfig.enterKeyControl.getArea().getY();
            enterWidth = (int) authConfig.enterKeyControl.getArea().getWidth();
            enterHeight = (int) authConfig.enterKeyControl.getArea().getHeight();
            enterLabel = authConfig.enterKeyControl.getKeyName();
        }

        int backspaceX = 0;
        int backspaceY = 0;
        int backspaceWidth = 0;
        int backspaceHeight = 0;
        String backspaceLabel = "";
        boolean isBackspaceEnabled = BharosaConfig.getBoolean(propPrefix + "backspace.enable", false);

        if (isBackspaceEnabled) {
            backspaceX = BharosaConfig.getInt(propPrefix + "backspace.x", 0);
            backspaceY = BharosaConfig.getInt(propPrefix + "backspace.y", 0);
            backspaceWidth = BharosaConfig.getInt(propPrefix + "backspace.width", 0);
            backspaceHeight = BharosaConfig.getInt(propPrefix + "backspace.height", 0);

            backspaceLabel = BharosaConfig.get(propPrefix + "backspace.label", "backspace");
        }

        int clearX = 0;
        int clearY = 0;
        int clearWidth = 0;
        int clearHeight = 0;
        String clearLabel = "";
        boolean isClearEnabled = BharosaConfig.getBoolean(propPrefix + "clear.enable", false);

        if (isClearEnabled) {
            clearX = BharosaConfig.getInt(propPrefix + "clear.x", 0);
            clearY = BharosaConfig.getInt(propPrefix + "clear.y", 0);
            clearWidth = BharosaConfig.getInt(propPrefix + "clear.width", 0);
            clearHeight = BharosaConfig.getInt(propPrefix + "clear.height", 0);

            clearLabel = BharosaConfig.get(propPrefix + "clear.label", "Clear");
        }

        if (hasImgs) { // check if images are enabled

            returnStr += "<div id=\"" + padName + "PadDiv\" name=\"" + padName + "ImgDiv\" style=\"position:" + stylePosition + ";visibility:" + styleVisibility + ";width: " + authConfig.displayWidth + "px;\">\n";

            returnStr += "<img id=\"" + padName + "PadImage\" align=\"center\" valign=\"middle\" src=\"" + authConfig.imageUrl + "pid=" + padName + "&keyId=" + System.currentTimeMillis() + "\" border=\"0\" usemap=\"#" + this.padName + "Map\" alt=\"Security Device Image\">\n";
            returnStr += "<div id=\"" + padName + "DataDiv\" style=\"visibility:" + dataStyleVisibility + ";position:absolute;" + dataStyle + "\">" + displayStr + "</div>\n";

            returnStr += "<input type=\"hidden\" name=\"" + padName + "DataField\" id=\"" + padName + "DataField\">\n";
            returnStr += "</div>\n";


        } else {
            dataStyle += "background-color:#FFFFFF;border:1px black inset;";

            returnStr += "<style type=\"text/css\">\n";
            returnStr += "#" + this.padName + "PadDiv {position:" + stylePosition + ";visibility:" + styleVisibility + ";left:" + styleLeft + "px;top:" + styleTop + "px;height:" + authConfig.displayHeight + ";width:" + authConfig.displayWidth + ";background-color:#EEEFE1;border: 1px black solid;}\n";
            returnStr += "#" + this.padName + "DataDiv {visibility:" + dataStyleVisibility + ";" + dataStyle + "}\n";

            if (logger.isDebugEnabled()) {
                logger.debug("isBackspaceEnabled : " + isBackspaceEnabled);
                logger.debug("isClearEnabled : " + isClearEnabled);
            }

            if (isBackspaceEnabled) {
                returnStr += "#" + this.padName + "BackspaceDiv {visibility:" + styleVisibility + ";position:absolute;left:" + backspaceX + "px;top:" + backspaceY + ";width:" + backspaceWidth + "px;height:" + backspaceHeight + "px;padding-top:2px;font-size:13px;font-weight:bold;font-family:helvetica,arial;text-align:center;background-color:#BEBF9D;cursor:pointer;}\n";
            }
            if (isClearEnabled) {
                returnStr += "#" + this.padName + "ClearDiv {visibility:" + styleVisibility + ";position:absolute;left:" + clearX + "px;top:" + clearY + ";width:" + clearWidth + "px;height:" + clearHeight + "px;padding-top:2px;font-size:13px;font-weight:bold;font-family:helvetica,arial;text-align:center;background-color:#BEBF9D;cursor:pointer;}\n";
            }
            returnStr += "#" + this.padName + "EnterDiv {position:absolute;left:" + enterX + "px;top:" + enterY + "px;width:" + enterWidth + "px;height:" + enterHeight + "px;padding-top:2px;padding-bottom:2px;font-size:12px;font-weight:bold;font-family:helvetica,arial;text-align:center;cursor:pointer;background-color:#BEBF9D;}\n";
            returnStr += "#" + this.padName + "CaptionDiv {position:absolute;left:12;top:205px;text-align:left;font-size:9px;font-family:helvetica,arial;}\n";
            returnStr += "#" + this.padName + "KeyBGDiv {visibility:" + styleVisibility + ";position:absolute;left:" + authConfig.leftMargin + "px;top:" + authConfig.topMargin + "px;width:" + (authConfig.displayWidth - (authConfig.rightMargin + authConfig.leftMargin)) + ";height:" + (authConfig.displayHeight - (authConfig.bottomMargin + authConfig.topMargin)) + "px;background-color:#BEBF9D;}\n";
            returnStr += "#" + this.padName + "KeyDiv {visibility:" + styleVisibility + ";position:relative;left:25;top:15;}\n";
            returnStr += "." + this.padName + "Key {position:absolute;font-size:13px;font-weight:bold;font-family:helvetica,arial;text-align:center;width:20px;cursor:pointer;background-color:#EEEFE1;}\n";
            returnStr += "." + this.padName + "Key a:link {text-decoration:none;color:black;}";
            returnStr += "." + this.padName + "Key a:visited {text-decoration:none;color:black;}";
            returnStr += "#" + this.padName + "EnterDiv a:link {text-decoration:none;color:black;}";
            returnStr += "#" + this.padName + "EnterDiv a:visited {text-decoration:none;color:black;}";
            if (isBackspaceEnabled) {
                returnStr += "#" + this.padName + "BackspaceDiv a:link {text-decoration:none;color:black;}";
                returnStr += "#" + this.padName + "BackspaceDiv a:visited {text-decoration:none;color:black;}";
            }

            if (isClearEnabled) {
                returnStr += "#" + this.padName + "ClearDiv a:link {text-decoration:none;color:black;}";
                returnStr += "#" + this.padName + "ClearDiv a:visited {text-decoration:none;color:black;}";
            }

            returnStr += "</style>\n";

            returnStr += "<div id=\"" + this.padName + "PadDiv\" name=\"" + this.padName + "ImgDiv\">\n";
            returnStr += "<div id=\"" + this.padName + "DataDiv\">" + displayStr + "</div>\n";

            if (isBackspaceEnabled) {
                returnStr += "<div id=\"" + this.padName + "BackspaceDiv\"><a href=\"" + authConfig.compatibilityUrl + "?pad=" + this.padName + "&key=BSKEY\">" + backspaceLabel + "</a></div>\n";
            }

            if (isClearEnabled) {
                returnStr += "<div id=\"" + this.padName + "ClearDiv\"><a href=\"" + authConfig.compatibilityUrl + "?pad=" + this.padName + "&key=CLEAR\">" + clearLabel + "</a></div>\n";
            }

            returnStr += "<div id=\"" + this.padName + "KeyBGDiv\"></div>\n";
            //returnStr += "<div id=\"" + this.padName + "KeyDiv\">\n";


            double x1 = 0;
            double y1 = 0;

            String[] codes = authKey.getKeyCodes();
            
            if (codes != null) {
                for (int i = 0; i < codes.length; i++) {
                    String key = codes[i];
                    KeyDetail keyDetail = KeyPadUtil.getKeyDetail(authKey, authConfig, i);

                    if (keyDetail.isActive()) {
                        Rectangle rect = new Rectangle(authKey.getX(i), authKey.getY(i), authKey.getWidth(i), authKey.getHeight(i));

                        if (rect == null) {
                            logger.debug("No area set for key " + keyDetail.getKeyValue());
                        }
                        String keyDisplay = keyDetail.getKeyValue();
                        if (keyDisplay == null || keyDisplay == "") {
                            keyDisplay = "&nbsp;";
                        }
                        x1 = rect.getLocation().getX();
                        y1 = rect.getLocation().getY();

                        String keyHref = "";
                        String keyHrefEnd = "";
                        keyHref = "<a href=\"" + authConfig.compatibilityUrl + "?pad=" + this.padName + "&key=" + key + "\">";
                        keyHrefEnd = "</a>";

                        returnStr += "<div class=\"" + this.padName + "Key\" style=\"top:" + (int) y1 + "px;left:" + (int) x1 + "px;\">" + keyHref + keyDisplay + keyHrefEnd + "</div>\n";
                    }
                }
            }

            //returnStr += "</div>\n";
            //returnStr += "</div>\n";

            if (authConfig.enterKeyControl != null) {
                returnStr += "<div id=\"" + this.padName + "EnterDiv\"><a href=\"" + authConfig.compatibilityUrl + "?pad=" + this.padName + "&key=ENTERKEY\" target=\"_top\">" + enterLabel + "</a></div>\n";
//				returnStr += "<input type=\"submit\" id=\"" + this.padName + "EnterDiv\" onclick=\"" + this.padName + ".keyPress(\"ENTERKEY\";\" value=\"" + enterLabel + "\" name=\"" + enterLabel + "\" />";
            }

            if (this.captionText != null) {
                returnStr += "<div id=\"" + this.padName + "CaptionDiv\"><a href=\"#\">" + this.captionText + "</a></div>\n";
            }
            returnStr += "<input type=\"hidden\" name=\"" + this.padName + "DataField\" id=\"" + this.padName + "DataField\" value=\"" + userValue + "\">\n";
            returnStr += "</div>\n";

        }

        returnStr += "</noscript>\n";


        return returnStr;
    }
    
    protected PadImageDirectory getParentImageDir() {
        return PadImageDirectory.pinpad;
    }

}
