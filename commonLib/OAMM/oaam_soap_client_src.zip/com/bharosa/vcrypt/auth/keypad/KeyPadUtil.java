package com.bharosa.vcrypt.auth.keypad;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;
import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.BharosaLocale;
import com.bharosa.common.util.BharosaPropertyBoolean;
import com.bharosa.common.util.FileUtil;
import com.bharosa.common.util.StringUtil;

import javax.imageio.ImageIO;

import javax.swing.*;

import java.awt.*;
import java.awt.font.LineBreakMeasurer;
import java.awt.font.TextAttribute;
import java.awt.font.TextLayout;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

import java.net.URL;

import java.security.SecureRandom;

import java.text.AttributedString;

import java.util.*;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * This class has the utility method to get the keypad and also to decode it. All methods in this class are static
 * methods.
 */

public class KeyPadUtil {

  static private Logger logger = Logger.getLogger(KeyPadUtil.class);
  static SecureRandom random = new SecureRandom();

  public static final String authentiPadResource =
    BharosaConfig.get("oaam.authentipad.resource.name",
                      "authentipad_resource");
  public static final String authentiPadMessageResource =
    BharosaConfig.get("oaam.authentipad.message.resource.name",
                      "authentipad_msg_resource");

  private static boolean useDefaultImage =
    BharosaConfig.getBoolean("vcrypt.image.assignDefault", false);
  private static boolean useDefaultCaption =
    BharosaConfig.getBoolean("vcrypt.caption.assignDefault", false);
  private static String imageDirListPropertyName =
    BharosaConfig.get("vcrypt.user.image.dirlist.property.name",
                      "bharosa.image.dirlist");

  private static String word1PropertyName =
    BharosaConfig.get("vcrypt.user.word1.property.name",
                      "bharosa.user.caption.word1.list");
  private static String word2PropertyName =
    BharosaConfig.get("vcrypt.user.word2.property.name",
                      "bharosa.user.caption.word2.list");

  private static final String IMAGE_BASE_DIR = "$base";

  private static String obsoleteImgDir =
    BharosaConfig.get("vcrypt.user.image.imagedir.obsoleteimagedir");
  private static String prevBaseImgDir =
    BharosaConfig.get("vcrypt.user.image.imagedir.previousbase");
  private static Map imageDirCache = new Hashtable();
  private static BharosaPropertyBoolean cacheImages =
    new BharosaPropertyBoolean("vcrypt.user.image.cache", true);
  private static HashMap imageCache = new HashMap();

  /**
   * This method gets the File object for the fileName/filePath. The method will try to find the file assuming it is an
   * absolute path. If it fails, then it will look in the class path to get absolute file path.
   *
   * @param fileName The file name. It could contain the part of the file path also.
   * @return a <code>File</code> object if the file is found. Else it will return a null object.
   */
  public static File getFile(String fileName) {
      if(StringUtil.isEmpty(fileName)) {
          if (logger.isDebugEnabled() &&
              BharosaConfig.getBoolean("bharosa.logger.debug.full", false)) {
            logger.debug("File Name passed is null or empty.");
          }
          return null;
      }
    File file = FileUtil.getFile(fileName);
    if (file != null) {
      if (logger.isDebugEnabled() &&
          BharosaConfig.getBoolean("bharosa.logger.debug.full", false)) {
        logger.debug("File " + fileName + " found in " +
                     file.getAbsolutePath());
      }
    }
    return file;
  }

  public static void createEncryptedKeyPad(AuthentiPad keypad) throws ObjectNotCreatedException {
      if (keypad == null) {
        logger.error("createEncryptedKeyPad() keypad is null");
        throw ObjectNotCreatedException.createInvalidInputDataException();
      }
    createEncryptedKeyPad(keypad, keypad.getAuthentiConfig());
  }


  public static void createEncryptedKeyPad(AuthentiPad keypad,
                                           AuthentiConfig authConfig) throws ObjectNotCreatedException {

    if (keypad == null) {
      logger.error("createEncryptedKeyPad() keypad is null");
      throw ObjectNotCreatedException.createInvalidInputDataException();
    }


    String frameFileName = keypad.getFrameFileName();
    KeyDetail[][] keys = authConfig.getKeys();
    String skinDirList = authConfig.getSkinDirList();
    int colSpace = authConfig.getColSpace();
    int topMargin = authConfig.getTopMargin();
    int leftMargin = authConfig.getLeftMargin();
    int rightMargin = authConfig.getRightMargin();
    int bottomMargin = authConfig.getBottomMargin();
    int iconGap = authConfig.getIconGap();
    boolean jitterEncryptFlag = authConfig.getJitterEncryptFlag();
    boolean filesizeEncryptFlag = authConfig.getFileSizeEncryptFlag();
    boolean dataEncryptFlag = authConfig.getDataEncryptFlag();
    boolean randomizeKeysFlag = authConfig.getRandomizeKeysFlag();


    int w = 0;
    int h = 0;


    if (frameFileName != null) {
      File frameFile = KeyPadUtil.getFile(frameFileName);


      if (frameFile == null) {
        logger.error("createEncryptedKeyPad() frameFilePath=" + frameFileName +
                     " not found in classpath");
        throw ObjectNotCreatedException.createInvalidInputDataException();
      }

      if (!frameFile.exists()) {
        logger.error("createEncryptedKeyPad() frameFile " +
                     frameFile.getAbsolutePath() + " doesn't exist");
        throw ObjectNotCreatedException.createInvalidInputDataException();
      }

      if (logger.isDebugEnabled())
        logger.debug("createEncryptedKeyPad() frameFile=" +
                     frameFile.getAbsolutePath());

      Image frameImage = new ImageIcon(frameFile.getAbsolutePath()).getImage();

      w = frameImage.getWidth(null);
      h = frameImage.getHeight(null);

      //frameImage.flush();
    } else {
      if (logger.isDebugEnabled())
        logger.debug("createEncryptedKeyPad() frameFileName is null");
    }

    AuthentiKey authKey = new AuthentiKey();
    authKey.setADACompliant(keypad.isADACompliant);
    authKey.setDecodable(keypad instanceof DecodablePad);


    if (keys != null) {
      int noRows = keys.length;
      int noCols = keys[0].length;
      int keyCount = noRows * noCols;

      short[] keyLocations = new short[keyCount * 4];
      short[] keyIndexes = new short[keyCount * 2];
      String[] keyCodes = new String[keyCount];

      /*  		  	
            String[] keyFiles= new String[keyCount * 2];
            String[] keyValues = new String[keyCount * 2];
  		  	boolean[] keyActiveFlags= new boolean[keyCount];
*/
      String skinDir = getSkinDir(skinDirList);

      Vector skinsDirVect = getVectorData(skinDirList);

      if (randomizeKeysFlag) {
        int skinIndex = randomizeKeys(skinsDirVect.size());
        skinDir = (String)skinsDirVect.get(skinIndex);
      }

      String imageFilePath = keys[0][0].getFileName();
      if (skinDir != null && skinDir.length() > 0) {
        imageFilePath = skinDir + File.separator + imageFilePath;
      }

      File iconFile = KeyPadUtil.getFile(imageFilePath);
      if (iconFile == null) {
        logger.error("createEncryptedKeyPad() iconFile " + imageFilePath +
                     " not found");
        throw ObjectNotCreatedException.createInvalidInputDataException();
      }

      Image iconImage = new ImageIcon(iconFile.getAbsolutePath()).getImage();

      int iconWidth = iconImage.getWidth(null);
      int iconHeight = iconImage.getHeight(null);

      //iconImage.flush();

      //FileSize Encryption

      if (filesizeEncryptFlag) {
        double fileSizeEncryptValue =
          getFileSizeEncryptValue((double)w, (double)h);
        w = w * (int)fileSizeEncryptValue;
        h = h * (int)fileSizeEncryptValue;

        keypad.setFileSizeEncryptValue(fileSizeEncryptValue);
      }

      int actualWidth = w - (leftMargin + rightMargin);
      int actualHeight = h - (topMargin + bottomMargin);

      //Ignore the text area and the bottom portion but leave the sides as is
      Rectangle keyPadArea =
        new Rectangle(leftMargin, topMargin, actualWidth, actualHeight);

      int xBegin = leftMargin;
      int yBegin = topMargin;
      int maxKeyWidthJitter =
        (int)(keys[0][0].getWidthJitter() / 100.0 * iconWidth);
      int maxKeyHeightJitter =
        (int)(keys[0][0].getHeightJitter() / 100.0 * iconHeight);

      if (((iconWidth + maxKeyWidthJitter + iconGap) * noCols) >=
          (actualWidth - colSpace))
        maxKeyWidthJitter =
            ((actualWidth - colSpace) - ((iconWidth + iconGap) * noCols) -
             iconGap) / noCols;

      if (((iconHeight + maxKeyHeightJitter + colSpace) * noRows) >=
          (actualHeight - colSpace))
        maxKeyHeightJitter =
            ((actualHeight - colSpace) - ((iconHeight + iconGap) * noRows) -
             iconGap) / noRows;

      //Jitter Encryption
      if (jitterEncryptFlag) {
        xBegin =
            leftMargin + colSpace + random.nextInt(actualWidth - ((iconWidth +
                                                                   maxKeyWidthJitter +
                                                                   iconGap) *
                                                                  noCols));
        yBegin =
            topMargin + colSpace + random.nextInt(actualHeight - ((iconHeight +
                                                                   maxKeyHeightJitter +
                                                                   iconGap) *
                                                                  noRows));
      }

      int xPtr = xBegin;
      int yPtr = yBegin;

      String keyData;
      int k = 0;


      for (int i = 0; i < noRows; i++) {
        xPtr = xBegin;

        for (int j = 0; j < keys[i].length; j++, k++) {

          int widthJitter = 0;
          int heightJitter = 0;

          if (maxKeyWidthJitter != 0)
            widthJitter = random.nextInt(maxKeyWidthJitter);

          if (maxKeyHeightJitter != 0) {
            heightJitter = random.nextInt(maxKeyHeightJitter);
            int minYPtr = yPtr;

            KeyDetail[] prevRow = (i > 0) ? keys[i - 1] : null;

            int prevCol = j - 1;
            int nextCol = j + 1;

            if (prevRow != null) {
              if (prevCol == -1 && nextCol != keys[i].length) // first column
              {
                // check with above and above-right keys
                if (prevRow[j].area.y > prevRow[nextCol].area.y)
                  minYPtr = prevRow[j].area.y + prevRow[j].area.height;
                else
                  minYPtr =
                      prevRow[nextCol].area.y + prevRow[nextCol].area.height;
              } else if (prevCol != -1 &&
                         (nextCol == keys[i].length)) // last column
              {
                // check with above and above-left keys
                if (prevRow[j].area.y > prevRow[prevCol].area.y)
                  minYPtr = prevRow[j].area.y + prevRow[j].area.height;
                else
                  minYPtr =
                      prevRow[prevCol].area.y + prevRow[prevCol].area.height;
              } else if (prevCol != -1 &&
                         (nextCol != keys[i].length)) // in-between column
              {
                // check with above, above-left, above-right keys
                if (prevRow[j].area.y > prevRow[prevCol].area.y)
                  minYPtr = prevRow[j].area.y + prevRow[j].area.height;
                else
                  minYPtr =
                      prevRow[prevCol].area.y + prevRow[prevCol].area.height;

                // check with the right-side column
                if (minYPtr <
                    (prevRow[nextCol].area.y + prevRow[nextCol].area.height))
                  minYPtr =
                      prevRow[nextCol].area.y + prevRow[nextCol].area.height;
              }
            }

            if (yPtr < minYPtr)
              yPtr = minYPtr;
          }

          Rectangle rectangle =
            new Rectangle(xPtr + widthJitter, yPtr + heightJitter, iconWidth,
                          iconHeight);
          keys[i][j].setArea(rectangle);

          //Data Encryption
          if (dataEncryptFlag) {
            keyData = generateOTPHash();
          } else {
            keyData = keys[i][j].getKeyValue();
          }

          KeyDetail keyDetail = keys[i][j];

          keyCodes[k] = keyData;

          keyLocations[(k * 4)] = (short)keyDetail.getArea().getX();
          keyLocations[(k * 4) + 1] = (short)keyDetail.getArea().getY();
          keyLocations[(k * 4) + 2] = (short)keyDetail.getArea().getWidth();
          keyLocations[(k * 4) + 3] = (short)keyDetail.getArea().getHeight();

          keyIndexes[(k * 2)] = (short)i;
          keyIndexes[(k * 2) + 1] = (short)j;

          xPtr = xPtr + maxKeyWidthJitter + iconWidth + iconGap;
        }

        yPtr = yPtr + maxKeyHeightJitter + iconHeight + iconGap;
      }

      authKey.setKeyCodes(keyCodes);
      authKey.setKeyLocations(keyLocations);
      authKey.setKeyIndexes(keyIndexes);

      keypad.setAuthentiPadArea(keyPadArea);
    }
    keypad.setAuthKey(authKey);
  }

  public static BufferedImage getEncryptedBufferedImage(AuthentiPad keypad) throws ObjectNotCreatedException {
    return getEncryptedBufferedImage(keypad, keypad.getAuthentiConfig());
  }

  /**
   * Finds and returns image file required for the pad.
   *
   * Starting 11g Pad image path will be relative to base directory.
   * This methods incorporates logic to check all base directories for the specified file.
   * Finally checks obsolete images directory Configuration property (vcrypt.user.image.imagedir.obsolete) for old images that are not active
   * 11g image path: $base/allpads/keypad/image.gif
   *
   * This method is backward compatibable to support older image paths.
   * Absolute image path is first reduced to relative path and then try to locate the file in all base directories and obsolete images directory
   * New configuration property vcrypt.user.image.imagedir.previousbase, provides previous base directory
   *
   * Finally try to locate the file using specified path in pad
   *
   * @param pad AuthentiPad
   * @return File, null if can't find
   * @since 11.1.1.2.0
   */
  private static File getImageFile(AuthentiPad pad) {

    if (pad == null) {
      logger.error("getImageFile invalid keypad");
      return null;
    }

    if (pad.getImageFileName() == null) {
      logger.error("getImageFile invalid keyPad Image");
      return null;
    }

    String fileName = pad.getImageFileName().trim();

    // Logic to update pad directory
    File tmpfile = new File(fileName);
    File parent = tmpfile.getParentFile();
    if (logger.isDebugEnabled())
      logger.debug("getImageFile " + fileName);
    if (parent != null &&
        !parent.getName().equals(pad.getParentImageDir().getDirectory())) {
      // Need to update path with appropriate pad location
      if (PadImageDirectory.getDirectoryList().contains(parent.getName())) {
        File newFile =
          new File(new File(parent.getParentFile(), pad.getParentImageDir().getDirectory()),
                   tmpfile.getName());
        fileName = newFile.getPath();
        if (logger.isDebugEnabled())
          logger.debug("getImageFile updated filename=" + fileName);
      }
    }


    File file = null;
    // 11g format
    if (fileName.startsWith(IMAGE_BASE_DIR)) {
      fileName = fileName.substring(IMAGE_BASE_DIR.length());
      file = findImageFile(fileName);
    } else {
      // pre 11g format - image directories moved
      if (!StringUtil.isEmpty(prevBaseImgDir) &&
          fileName.startsWith(prevBaseImgDir)) {
        fileName = fileName.substring(prevBaseImgDir.length());
        file = findImageFile(fileName);
      }
    }

    if (file == null)
      file = getFile(fileName);

    if (file == null) {
      logger.info("getImageFile image file=" + fileName +
                  " Could NOT be located.");
    } else if (logger.isDebugEnabled())
      logger.debug("getImageFile keyPad " + fileName + ", file=" + file);

    return file;
  }

  private static File findImageFile(String fileName) {
    List imageDirList = getImageDirectoryList();
    String baseDir;
    for (int i = 0; i < imageDirList.size(); i++) {
      baseDir = (String)imageDirList.get(i);
      File file = new File(baseDir, fileName);
      if (file.exists())
        return file;
    }
    logger.info("findImageFile image file=" + fileName +
                ", NOT found in any of following Locations=" + imageDirList);
    return null;
  }

  public static BufferedImage getEncryptedBufferedImage(AuthentiPad keypad,
                                                        AuthentiConfig authConfig) throws ObjectNotCreatedException {
    if (keypad == null) {
      logger.debug("getEncryptedBufferedImage() keypad is null");
      throw ObjectNotCreatedException.createInvalidInputDataException();
    }

    String frameFileName = keypad.getFrameFileName();
    AuthentiKey authKey = keypad.getAuthKey();
    String[] codes = authKey.getKeyCodes();
    KeyDetail[] controls = authConfig.getControls();
    KeyDetail[] textElements = authConfig.getTextElements();
    String skinDirList = authConfig.getSkinDirList();
    boolean filesizeEncryptFlag = authConfig.getFileSizeEncryptFlag();
    boolean checksumEncryptFlag = authConfig.getCheckSumEncryptFlag();

    File backgroundFile = getImageFile(keypad);
    if (backgroundFile == null) {
      logger.error("getEncryptedBufferedImage() backgroundFilePath=" +
                   keypad.getImageFileName() + " not found in classpath");
      throw ObjectNotCreatedException.createInvalidInputDataException();
    }

    if (!backgroundFile.exists()) {
      logger.error("getEncryptedBufferedImage() backgroundFile " +
                   backgroundFile.getAbsolutePath() + " doesn't exist");
      throw ObjectNotCreatedException.createInvalidInputDataException();
    }

    Image backgroundImage =
      new ImageIcon(backgroundFile.getAbsolutePath()).getImage();

    int imageWidth = backgroundImage.getWidth(null);
    int imageHeight = backgroundImage.getHeight(null);

    Image frameImage = null;

    if (frameFileName != null) {

      File frameFile = KeyPadUtil.getFile(frameFileName);

      if (frameFile == null) {
        logger.error("getEncryptedBufferedImage() frameFilePath=" +
                     frameFileName + " not found in classpath");
        throw ObjectNotCreatedException.createInvalidInputDataException();
      }

      if (!frameFile.exists()) {
        logger.error("getEncryptedBufferedImage() frameFile " +
                     frameFile.getAbsolutePath() + " doesn't exist");
        throw ObjectNotCreatedException.createInvalidInputDataException();
      }

      frameImage = new ImageIcon(frameFile.getAbsolutePath()).getImage();

      imageWidth = frameImage.getWidth(null);
      imageHeight = frameImage.getHeight(null);
    } else {
      logger.error("getEncryptedBufferedImage() frameFileName is null");
    }

    // create a temporary image
    BufferedImage bufBackgroundImage;

    String outputType = authConfig.getOutputType();

    Graphics2D g;
    //FileSize Encryption
    if (filesizeEncryptFlag) {
      bufBackgroundImage =
          fileSizeEncryptProcess(keypad.getFileSizeEncryptValue(),
                                 backgroundImage, outputType);
      //g = bufBackgroundImage.createGraphics();
    } else {
      int rgbType = BufferedImage.TYPE_INT_ARGB;

      if (outputType != null &&
          (outputType.equalsIgnoreCase("jpeg") || outputType.equalsIgnoreCase("jpg"))) {
        rgbType = BufferedImage.TYPE_INT_RGB;
      }

      bufBackgroundImage = new BufferedImage(imageWidth, imageHeight, rgbType);

      g = bufBackgroundImage.createGraphics();

      g.setComposite(AlphaComposite.Src);
      g.drawImage(backgroundImage, 0, 0, null);

    }

    //backgroundImage.flush();

    if (checksumEncryptFlag) {
      bufBackgroundImage = checkSumEncryptProcess(bufBackgroundImage);
    }

    g = bufBackgroundImage.createGraphics();


    if (frameImage != null) {
      g.drawImage(frameImage, 0, 0, null);
      //frameImage.flush();
    }


    if (textElements != null) {

      for (int textPtr = 0; textPtr < textElements.length; textPtr++) {
        KeyDetail textDetail = textElements[textPtr];

        if (textDetail != null) {
          String text = textDetail.getKeyName();

          String fontName = textDetail.getTextFontName();
          String fontColor = textDetail.getTextFontColor();
          int fontType = textDetail.getTextFontType();
          int fontSize = textDetail.getTextFontSize();
          boolean enableFrame = textDetail.getTextFrameFlag();
          boolean enableWrap = textDetail.getTextWrapFlag();

          float detailX =
            (float)(textElements[textPtr]).getArea().getLocation().getX();
          float detailY =
            (float)((textElements[textPtr]).getArea().getLocation().getY());
          float detailWidth =
            (float)(textElements[textPtr].getArea().getWidth());
          float detailHeight =
            (float)(textElements[textPtr].getArea().getHeight());

          Color fColor = new Color(Integer.parseInt(fontColor, 16));

          g =
drawBoxedString(g, enableFrame, text, fontName, fontType, fontSize, Color.gray,
                fColor, detailX, detailY, detailWidth, detailHeight);
        }
      }
    }

    if (codes != null) {
      int noRows = codes.length;

      String skinDir = getSkinDir(skinDirList);

      for (int i = 0; i < noRows; i++) {
        KeyDetail keyDetail = KeyPadUtil.getKeyDetail(authKey, authConfig, i);
        String imageFilePath = keyDetail.getFileName();
        if (skinDir != null && skinDir.length() > 0) {
          imageFilePath = skinDir + File.separator + imageFilePath;
        }

        File iconFile = getFile(imageFilePath);

        if (iconFile == null) {
          logger.error("getEncryptedBufferedImage() iconFile " +
                       imageFilePath + " not found");
          throw ObjectNotCreatedException.createInvalidInputDataException();
        }

        Image iconImage = new ImageIcon(iconFile.getAbsolutePath()).getImage();
        if (iconImage == null) {
          logger.error("image path not found. path=" +
                       iconFile.getAbsolutePath(),
                       new Throwable().fillInStackTrace());
        }
        g.setComposite(AlphaComposite.SrcOver);
        g.drawImage(iconImage, authKey.getX(i), authKey.getY(i), null);
      }
    }

    if (authConfig.getEnableLogoFlag()) {
      displayLogo(g, keypad, authConfig);
    }


    if (controls != null) {
      int controlKeysImageXOffset = 0;
      int controlKeysImageYOffset = 4;

      for (int i = 0; i < controls.length; i++) {
        KeyDetail keyDetail = controls[i];

        if ((keyDetail != null) && (keyDetail.isEmbedded())) {
          Rectangle keyArea = keyDetail.getArea();

          if (keyArea != null) {
            String controlFilePath = keyDetail.getFileName();

            String skinDir = getSkinDir(skinDirList);

            if (skinDir != null && skinDir.length() > 0) {
              controlFilePath = skinDir + File.separator + controlFilePath;
            }

            File controlFile = getFile(controlFilePath);

            if (controlFile == null) {
              logger.error("getEncryptedBufferedImage() controlFile " +
                           controlFilePath + " not found");
              throw ObjectNotCreatedException.createInvalidInputDataException();
            }

            Image controlImage =
              new ImageIcon(controlFile.getAbsolutePath()).getImage();

            g.setComposite(AlphaComposite.SrcOver);

            g.drawImage(controlImage,
                        (int)keyArea.getLocation().getX() - controlKeysImageXOffset,
                        (int)keyArea.getLocation().getY() -
                        controlKeysImageYOffset, null);

            //controlImage.flush();
          }
        }
      }
    }

    g.dispose();

    return bufBackgroundImage;
  }

  public static OutputStream encryptImageToStream(AuthentiPad keyPad,
                                                  OutputStream os) throws ObjectNotCreatedException {
      if(keyPad == null || os == null) {
          logger.error("encryptImageToStream() keyPad or OutPutStream is null.");
          throw ObjectNotCreatedException.createInvalidInputDataException();
      }
    return encryptImageToStream(keyPad, keyPad.getAuthentiConfig(), os);
  }

  public static OutputStream encryptImageToStream(AuthentiPad keyPad,
                                                  AuthentiConfig authConfig,
                                                  OutputStream os) throws ObjectNotCreatedException {
    if ((keyPad != null) && (os != null)) {
      BufferedImage newSource = getEncryptedBufferedImage(keyPad, authConfig);
      String outputType = authConfig.getOutputType();

      if ((newSource != null) && (outputType != null)) {

        try {
          // Send back image
          ImageIO.write(newSource, outputType, os);
        } catch (Exception exp) {
          logger.error("encryptImageToStream() keyPad " + keyPad +
                       " Exception ", exp);
          throw ObjectNotCreatedException.createInvalidInputDataException();
        }
      } else {
        logger.error("encryptImageToStream() newSource || outputType not found:" +
                     outputType);
        throw ObjectNotCreatedException.createInvalidInputDataException();
      }
    } else {
      logger.error("encryptImageToStream() keyPad || os not found");
      throw ObjectNotCreatedException.createInvalidInputDataException();
    }

    return os;
  }

  public static OutputStream encryptImageToStream(File imageFile,
                                                  String outputType,
                                                  OutputStream os) throws ObjectNotCreatedException {
    try {
      if (imageFile != null) {
        BufferedImage newSource;

        // Send back image
        newSource = convertPNG(imageFile);
        ImageIO.write(newSource, outputType, os);
      } else {
        logger.error("encryptImageToStream() imageFile " + imageFile +
                     " not found");
        throw ObjectNotCreatedException.createInvalidInputDataException();
      }
    } catch (Exception exp) {
      logger.error("encryptImageToStream() imageFile " + imageFile, exp);
      throw ObjectNotCreatedException.createInvalidInputDataException();
    }
    return os;
  }

  private static BufferedImage convertPNG(File aIconFile) {
    logger.debug("convertPNG() filePath=" + aIconFile.getAbsolutePath());
    Image iconImage = new ImageIcon(aIconFile.getAbsolutePath()).getImage();

    double w = iconImage.getWidth(null);
    double h = iconImage.getHeight(null);

    // create a temporary image
    BufferedImage newSource =
      new BufferedImage((int)w, (int)h, BufferedImage.TYPE_INT_ARGB);

    Graphics2D g = newSource.createGraphics();
    Color backgroundColor = new Color(0, 0, 0, 0);
    g.setBackground(backgroundColor);
    g.setPaint(backgroundColor);

    g.drawImage(iconImage, 0, 0, null);

    //iconImage.flush();
    g.dispose();

    return newSource;
  }
/*
  private static BufferedImage convertJPEG(File aIconFile) {
    try {
      FileInputStream inFile = new FileInputStream(aIconFile);
      JPEGImageDecoder decoder = JPEGCodec.createJPEGDecoder(inFile);
      BufferedImage newSource = decoder.decodeAsBufferedImage();
      inFile.close();
      return newSource;
    } catch (Exception exp) {
      logger.error("convertJPEG " + aIconFile, exp);
      return null;
    }
  }
*/
  private static Graphics2D displayLogo(Graphics2D g2, AuthentiPad keyPad,
                                        AuthentiConfig authConfig) {

    String logoFileName = authConfig.getLogoFileName();

    File logoFile = getFile(logoFileName);

    boolean pirate = true;

    if (logoFile != null) {

      if (logoFile.exists()) {

        if (logger.isDebugEnabled())
          logger.debug("displayLogo() logoFile=" + logoFile.getAbsolutePath());

        Image logoImage = new ImageIcon(logoFile.getAbsolutePath()).getImage();

        int logoImageWidth = logoImage.getWidth(null);
        int logoImageHeight = logoImage.getHeight(null);


        if ((logoImageWidth != 65) ||
            (logoImageHeight != 19)) // Piracy blocker - adjust variables to map exact logo
        {
          pirate = true;
        } else {
          g2.setComposite(AlphaComposite.SrcOver);
          g2.drawImage(logoImage, authConfig.getLogoXPtr(),
                       authConfig.getLogoYPtr(), null);
          pirate = false;
        }

        //logoImage.flush();
      } else {
        logger.error("displayLogo() logoFileName " +
                     logoFile.getAbsolutePath() + " doesn't exist");
      }
    } else {
      logger.error("displayLogo() logoFileName=" + logoFileName +
                   " not found in classpath");
    }

    if (pirate) {
      drawBoxedString(g2, false, "Powered By Bharosa",
                      authConfig.getLogoFontName(),
                      authConfig.getLogoFontType(),
                      authConfig.getLogoFontSize(), Color.gray, Color.white,
                      authConfig.getLogoXPtr(), authConfig.getLogoYPtr(),
                      authConfig.getLogoWidth(), authConfig.getLogoHeight());
      return g2;
    }

    return g2;
  }


  private static Graphics2D drawBoxedString(Graphics2D g2, boolean enableFrame,
                                            String text, String fontName,
                                            int fontType, int fontSize,
                                            Color c1, Color c2, double x,
                                            double y, double width,
                                            double height) {
    if (!StringUtil.isEmpty(text)) {

      // Calculate the width of the string.
      if (enableFrame) {
        // Fill the background rectangle.
        g2.setPaint(c1);

        Rectangle2D back = new Rectangle2D.Double(x - 2, y, width, height);

        g2.fill(back);
      }

      // Draw the string over the gradient rectangle.
      g2.setPaint(c2);
      g2.setFont(new Font(fontName, fontType, fontSize));

      drawWrappedText(g2, text, (float)x, (float)(y), (float)width);
    }

    return g2;
  }

  /**
   * Draw text in wrapped fashion
   *
   * @param g2    Graphics object
   * @param text  text to draw
   * @param x     x-coordinate
   * @param y     y-coordinate
   * @param width width
   */
  private static void drawWrappedText(Graphics2D g2, String text, float x,
                                      float y, float width) {

    AttributedString attString = new AttributedString(text);
    attString.addAttribute(TextAttribute.FONT, g2.getFont());

    LineBreakMeasurer linebreaker =
      new LineBreakMeasurer(attString.getIterator(),
                            g2.getFontRenderContext());

    while (linebreaker.getPosition() < text.length()) {
      TextLayout textLayout = linebreaker.nextLayout(width);
      y += textLayout.getAscent();
      textLayout.draw(g2, x, y);
      y += textLayout.getDescent() + textLayout.getLeading();
    }
  } // end drawWrapedText

  /**
   * This method decodes the user input and returns the raw data entered.
   *
   * @param authPad        a <code>AuthentiPad</code> which was presented to the user.
   * @param vCryptPinData The encrypted data the user entered.
   * @return The raw translated data entered by the user
   */
  public static String decodeKeyPadCode(AuthentiPad authPad,
                                        String vCryptPinData) {

    if (authPad != null) {
      AuthentiKey authKey = authPad.getAuthKey();
      AuthentiConfig authConfig = authPad.getAuthentiConfig();

      if (authKey == null) {
        logger.info("authKey null in authPad, AuthentiPad may not have been initialized (call getHTML()).");
      }

      return decodeKeyPadCode(authKey, authConfig, vCryptPinData);
    }
    return null;

  }

  /**
   * This method decodes the user input and returns the raw data entered.
   *
   * @param authKey        an <code>AuthentiKey</code> which contains the required information to decode the AuthentiPad displayed to the user.
   * @param vCryptPinData The encrypted data the user entered.
   * @return The raw translated data entered by the user
   */
  public static String decodeKeyPadCode(AuthentiKey authKey,
                                        AuthentiConfig authConfig,
                                        String vCryptPinData) {

    if (authKey == null) {
      logger.info("authKey null in decodeKeyPadCode().");
      return null;
    }

    if (!(authKey.isDecodable())) {
      if (logger.isDebugEnabled()) {
        logger.debug("decodeKeyPadCode(): Pad does not require decoding.");
      }
      return vCryptPinData;
    }

    if (vCryptPinData == null) {
      logger.info("vCryptPinData null in decodeKeyPadCode().");
      return null;
    }

    try {
      StringBuffer pincodeBuffer = new StringBuffer();

      String colonDelims = ":";
      String semicolonDelims = ";";
      StringTokenizer parser = new StringTokenizer(vCryptPinData, colonDelims);
      String token;
      while (parser.hasMoreTokens()) {
        token = parser.nextToken(colonDelims);
        if (!StringUtil.isEmpty(token)) {
          if (!authKey.isADACompliant()) // NonCompliant decoder
          {
            String currentDelimsNONADA = ",";

            StringTokenizer parserNONADA =
              new StringTokenizer(token, currentDelimsNONADA);

            String tokenXNONADA;
            String tokenYNONADA;
            int keyXNONADA = 0;
            int keyYNONADA = 0;

            boolean altValue = false;

            while (parserNONADA.hasMoreTokens()) {
              tokenXNONADA = parserNONADA.nextToken(currentDelimsNONADA);

              if (!StringUtil.isEmpty(tokenXNONADA)) {
                keyXNONADA =
                    Integer.parseInt(tokenXNONADA); // - keyPad.getLeftMargin()+ keyPad.getLeftFrame();
              }

              tokenYNONADA = parserNONADA.nextToken(currentDelimsNONADA);

              if (!StringUtil.isEmpty(tokenYNONADA)) {
                try {
                  keyYNONADA =
                      Integer.parseInt(tokenYNONADA); //- (keyPad.getIconHeight());
                } catch (Exception exp) {
                  StringTokenizer parserCAPS =
                    new StringTokenizer(tokenYNONADA, semicolonDelims);
                  while (parserCAPS.hasMoreTokens()) {
                    String resultToken = parserCAPS.nextToken(semicolonDelims);
                    keyYNONADA =
                        Integer.parseInt(resultToken); //- (keyPad.getIconHeight());
                    altValue = true;
                  }
                }
              }

              boolean keyFound = false;
              String[] codes = authKey.getKeyCodes();
              for (int i = 0; !keyFound && i < codes.length; i++) {
                KeyDetail keyDetail =
                  KeyPadUtil.getKeyDetail(authKey, authConfig, i);

                if (keyDetail.getArea().contains(keyXNONADA, keyYNONADA)) {
                  if (altValue) {
                    pincodeBuffer.append(keyDetail.getAltKeyValue());
                  } else {
                    pincodeBuffer.append(keyDetail.getKeyValue());
                  }

                  keyFound = true;
                }
              }

              /*
                            // handle SPACE KEY
                            if (!keyFound) {
                                for (int ptr = 0; ptr < keyPad.controls.length; ptr++) {
                                    KeyDetail tmpKey = keyPad.controls[ptr];
                                    if ((tmpKey != null) && (tmpKey.getKeyValue().equals("SPACE"))) {
                                        if (tmpKey.getArea().contains(keyXNONADA, keyYNONADA)) {
                                            if (tmpKey.isActive()) {
                                                pincodeBuffer.append(" ");
                                            }
                                        }

                                        break;
                                    }
                                }
                            }
  */
            }
          } else // Compliant decoder
          {

            String[] keyCodes = authKey.getKeyCodes();

            StringTokenizer parserCAPS =
              new StringTokenizer(token, semicolonDelims);
            while (parserCAPS.hasMoreTokens()) {
              String resultToken = parserCAPS.nextToken(semicolonDelims);
              if (!StringUtil.isEmpty(resultToken)) {
                if (resultToken.equals("SPACE")) {
                  pincodeBuffer.append(" ");
                } else {

                  boolean keyFound = false;

                  for (int i = 0; !keyFound && i < keyCodes.length; i++) {

                    String keyId = keyCodes[i];
                    KeyDetail keyDetail =
                      KeyPadUtil.getKeyDetail(authKey, authConfig, i);

                    if (logger.isDebugEnabled()) {
                      logger.debug("DecodeKeyPadCode - keyId = " + keyId);
                    }


                    if (StringUtil.equalsIgnoreCase(keyId, resultToken)) {

                      try {
                        Integer.parseInt(token);
                        pincodeBuffer.append(keyDetail.getKeyValue());
                      } catch (Exception exp) {
                        pincodeBuffer.append(keyDetail.getAltKeyValue());
                      }

                      keyFound = true;
                    }

                  }
                }
              } else {
                logger.info("Invalid token sent. decode() " +
                            "compliantFlag=" + authKey.isADACompliant() +
                            ", token=" + token);
                return null;
              }
            }
          }
        }
      }
      return pincodeBuffer.toString();
    } catch (Exception ex) {
      logger.info("Caught exception while decoding userInput compliantFlag=" +
                  authKey.isADACompliant(), ex);
    }
    return null;

  }

  static String generateOTPHash() {
    float param = random.nextFloat() * 10000000;
    return String.valueOf((int)param);
  }

  static int randomizeKeys(int totalKeySets) {
    return random.nextInt(totalKeySets);
  }

  static public String assignCaptionTextToUser(Locale aLocale) {
      // if locale is null, it will be set to default locale.
      if(aLocale == null) {
          aLocale = BharosaLocale.getCurrentLocale();
      }
    return assignCaptionTextToUser(word2PropertyName, word1PropertyName,
                                   aLocale);
  }

  /**
   * @deprecated
   */
  static public String assignCaptionTextToUser() {
    return assignCaptionTextToUser(BharosaLocale.getDefaultLocale());
  }

  static protected String assignCaptionTextToUser(String word2ListProp,
                                                  String word1ListProp,
                                                  Locale aLocale) {
    Vector word1Vector =
      getVectorDataFromProp(word1ListProp, aLocale, authentiPadMessageResource);
    if (word1Vector == null || word1Vector.isEmpty()) {
      // Backwards compatability
      word1Vector =
          getVectorDataFromProp("bharosa.user.adj.list", aLocale, authentiPadMessageResource);
    }

    Vector word2Vector =
      getVectorDataFromProp(word2ListProp, aLocale, authentiPadMessageResource);
    if (word2Vector == null || word2Vector.isEmpty()) {
      // Backwards compatability
      word2Vector =
          getVectorDataFromProp("bharosa.user.noun.list", aLocale, authentiPadMessageResource);
    }


    String[] word1Array =
      (String[])word1Vector.toArray(new String[word1Vector.size()]);
    String[] word2Array =
      (String[])word2Vector.toArray(new String[word2Vector.size()]);

    return assignCaptionTextToUser(word2Array, word1Array);
  }

  static protected String assignCaptionTextToUser(String[] word2List,
                                                  String[] word1List) {
    logger.debug("In assignCaptionTextToUser");

    String captionText = null;

    if (word2List != null && word2List.length > 0 && word1List != null &&
        word1List.length > 0) {

      captionText =
          word1List[random.nextInt(word1List.length)] + " " + word2List[random.nextInt(word2List.length)];
    }

    return captionText;
  }

  static public String assignImageToUser() {
    return assignImageToUser(imageDirListPropertyName);
  }

  static public String assignImageToUser(String imageDirsProp) {

    if (logger.isDebugEnabled())
      logger.debug("assignImageToUser imageDirsProp=" + imageDirsProp);

    String imageFileName = null;
    List imageDirVector = getImageDirectoryList(imageDirsProp);
    if (imageDirVector != null && !imageDirVector.isEmpty()) {
      List allImages = null;
      String cacheKey = null;
      if (cacheImages.getValue()) {
        TreeSet set = new TreeSet(imageDirVector);
        Iterator itr = set.iterator();
        StringBuffer cacheKeyBuf = new StringBuffer("#");
        while (itr.hasNext())
          cacheKeyBuf.append(itr.next()).append("#");
        cacheKey = cacheKeyBuf.toString();
        allImages = (List)imageCache.get(cacheKey);
        if (logger.isDebugEnabled())
          logger.debug("assignImageToUser Reading images from cache key" +
                       cacheKey);
      }

      if (allImages == null) {
        allImages = new ArrayList();
        for (int i = 0; i < imageDirVector.size(); i++) {
          String imgDir = null;
          try {
            imgDir = (String)imageDirVector.get(i);
            File dir = new File(imgDir);
            if (!dir.isDirectory()) {
              if (logger.isDebugEnabled())
                logger.debug("assignImageToUser Checking classpath for directory=" +
                             dir);

              ClassLoader classLoader =
                Thread.currentThread().getContextClassLoader();
              URL url = classLoader.getResource(imgDir);
              if (url != null) {
                String urlPath = url.getPath();
                urlPath = urlPath.replaceAll("%20", " ");
                dir = new File(urlPath);
              }

              if (!dir.isDirectory()) {
                logger.warn("assignImageToUser Not a directory=" + imgDir);
                continue;
              }
            }
            allImages.addAll(getAllImages(dir, IMAGE_BASE_DIR));
          } catch (Throwable e) {
            logger.error("assignImageToUser error while processing directory=" +
                         imgDir, e);
          }
        }
        if (cacheImages.getValue()) {
          logger.info("assignImageToUser Caching images cacheKey=" + cacheKey +
                      " images=" + allImages.size());
          imageCache.put(cacheKey, allImages);
        }
      }

      if (allImages.size() > 0) {
        if (logger.isDebugEnabled())
          logger.debug("assignImageToUser Randomly choosing an image from a base of " +
                       allImages.size() + " files");
        imageFileName =
            (String)allImages.get(random.nextInt(allImages.size()));
      }

      if (imageFileName == null)
        logger.error("assignImageToUser No images found in the directory list:" +
                     imageDirVector);

    } else {
      logger.error("assignImageToUser Image directory list was null imageDirsProp=" +
                   imageDirsProp);
    }
    return imageFileName;
  }


  static BufferedImage checkSumEncryptProcess(BufferedImage origSource) {
    if (logger.isDebugEnabled()) {
      logger.debug("In checkSumEncryptProcess");
    }

    int param = 0;
    int minParam =
      BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad.checksum.min",
                                                   authentiPadResource, 100);
    int maxParam =
      BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad.checksum.max",
                                                   authentiPadResource, 200);
    int totalParamChange =
      BharosaConfig.getLocalizedIntFromNamedBundle("bharosa.authentipad.checksum.total",
                                                   authentiPadResource, 300);

    while (param <= minParam || param >= maxParam) {
      param = random.nextInt(totalParamChange);
    }

    float kData[] = new float[9];

    float alpha;
    if (param > 150) {
      alpha = (param - 125.0f) / 25.0f;
    } else {
      alpha = param / 150.0f;
    }
    float beta = (1.0f - alpha) / 8.0f;
    for (int i = 0; i < 9; i++) {
      kData[i] = beta;
    }
    kData[4] = alpha;

    BufferedImageOp checkSumOp =
      new ConvolveOp(new Kernel(3, 3, kData), ConvolveOp.EDGE_NO_OP, null);
    if (logger.isDebugEnabled())
      logger.debug("checkSumEncryptProcess() alpha=" + alpha + ", beta=" +
                   beta);
    return checkSumOp.filter(origSource, null);
  }


  static double getFileSizeEncryptValue(double w, double h) {
    if (logger.isDebugEnabled()) {
      logger.debug("In fileSizeEncryptValue");
    }

    double param = 0.8;
    double offset = 0.1;
    double minOffset = 0.2;
    double maxOffset = 0.21;

    while (offset <= minOffset || offset >= maxOffset) {
      offset = random.nextDouble(); // 0.0-1.0
    }

    //This is not used, so commenting
    //param = param + offset;  // (0.0 - 1.0)

    return 1.0; //param is set to 1.0 to eliminate change in image sizes
  }


  static BufferedImage fileSizeEncryptProcess(double aParam, Image origSource,
                                              String outputType) {
    if (logger.isDebugEnabled()) {
      logger.debug("In fileSizeEncryptProcess");
    }

    if (origSource != null) {
      double w = aParam * origSource.getWidth(null);
      double h = aParam * origSource.getHeight(null);

      int rgbType = BufferedImage.TYPE_INT_ARGB;
      if (outputType != null &&
          (outputType.equalsIgnoreCase("jpeg") || outputType.equalsIgnoreCase("jpg"))) {
        rgbType = BufferedImage.TYPE_INT_RGB;
      }
      // create a temporary image
      BufferedImage newSource = new BufferedImage((int)w, (int)h, rgbType);
      Graphics2D g = newSource.createGraphics();

      // draw the image scaled
      g.setComposite(AlphaComposite.Src);
      AffineTransform aft = AffineTransform.getScaleInstance(aParam, aParam);
      g.drawImage(origSource, aft, null);

      if (logger.isDebugEnabled())
        logger.debug("fileSizeEncryptProcess() param=" + aParam);

      g.dispose();

      return newSource;
    }

    return null;
  }

  private static List getImageDirectoryList() {
    return getImageDirectoryList(imageDirListPropertyName);
  }

  private static List getImageDirectoryList(String imageDirListProperty) {
    List retImageList = (List)imageDirCache.get(imageDirListProperty);
    if (retImageList == null) {
      List imageDirList = getVectorDataFromProp(imageDirListProperty);
      if (obsoleteImgDir != null)
        imageDirList.add(obsoleteImgDir);
      retImageList = new ArrayList(imageDirList.size());
      for (int i = 0; i < imageDirList.size(); i++) {
        String directory = (String)imageDirList.get(i);
        retImageList.add(expandHomeDir(directory));
      }
      imageDirCache.put(imageDirListProperty, retImageList);
      if (logger.isDebugEnabled())
        logger.debug("getImageDirectoryList imageDir=" + imageDirList +
                     ", retImageList=" + retImageList);
    }
    return retImageList;
  }

  private static String expandHomeDir(final String dir) {

    if (dir == null)
      return dir;

    String directory = dir.trim();
    Matcher matcher = Pattern.compile("(\\$\\{(.*?)\\})").matcher(directory);
    if (matcher.find() && matcher.start() == 0) {
      String propertyToCheck = matcher.group(2);
      String propertyValue = BharosaConfig.get(propertyToCheck);
      if (propertyValue == null) {
        if (logger.isDebugEnabled())
          logger.debug("expandHomeDir no configuration for variable=" +
                       propertyToCheck + ", returning=" + dir);
        return directory;
      }
      File f = new File(propertyValue, directory.substring(matcher.end()));
      propertyValue = f.getAbsolutePath();
      if (logger.isDebugEnabled())
        logger.debug("expandHomeDir original=" + dir + ", new=" +
                     propertyValue);
      return f.getAbsolutePath();
    }
    return directory;
  }

  static Vector getVectorDataFromProp(String propName) {
    if (logger.isDebugEnabled()) {
      logger.debug("In getVectorDataFromProp");
    }
    return getVectorDataFromProp(propName, authentiPadResource);
  }

  static Vector getVectorDataFromProp(String propName, String resourceName) {
    if (logger.isDebugEnabled()) {
      logger.debug("In getVectorDataFromProp");
    }
    return stringListToVector(BharosaConfig.getLocalizedFromNamedBundle(propName,
                                                                        resourceName));
  }

  static Vector getVectorDataFromProp(String propName, Locale aLocale) {
    return getVectorDataFromProp(propName, aLocale, authentiPadResource);
  }

  static Vector getVectorDataFromProp(String propName, Locale aLocale,
                                      String resourceName) {
    if (logger.isDebugEnabled()) {
      logger.debug("In getVectorDataFromProp");
    }
    return stringListToVector(BharosaConfig.getLocalizedFromNamedBundleAndLocale(propName,
                                                                                 resourceName,
                                                                                 aLocale));
  }


  static Vector stringListToVector(String stringList) {
    Vector dirVector = new Vector();
    if (stringList != null && stringList.length() > 0) {
      StringTokenizer st = new StringTokenizer(stringList, ",");
      while (st.hasMoreTokens()) {
        String stringToken = st.nextToken();
        if (stringToken != null && stringToken.trim().length() > 0) {
          dirVector.add(stringToken.trim());
        }
      }
    }
    return dirVector;
  }

  public static Vector getVectorData(String stringList) {
    if (logger.isDebugEnabled()) {
      logger.debug("In getVectorData");
    }

    Vector dirVector = stringListToVector(stringList);

    return dirVector;

  }

  /**
   * @param imageDir Directory to recursively scan for image files
   * @param parent name of the parent directory
   * @return list of all image names in the base directory with path relative to imageDir
   */
  static private List getAllImages(File imageDir, String parent) {
    if (logger.isDebugEnabled())
      logger.debug("getAllImages imageDir=" + imageDir + ", parent=" + parent);

    if (!imageDir.isDirectory()) {
      if (logger.isDebugEnabled())
        logger.debug("getAllImages Not a directory! " +
                     imageDir.getAbsolutePath());
      return Collections.EMPTY_LIST;
    }

    List imageFiles = new ArrayList();
    File[] allFiles = imageDir.listFiles();
    boolean isPadImagesDir = PadImageDirectory.getDirectoryList().contains(imageDir.getName());
    boolean scannedPadDirectory = false;
    for (int i = 0; i < allFiles.length; i++) {
      File current = allFiles[i];
      if (current.isDirectory()) {
        if (!scannedPadDirectory ||
            !PadImageDirectory.getDirectoryList().contains(current.getName())) {
          if (logger.isDebugEnabled())
            logger.debug("getAllImages sub directory " + current.getName());
          List imgList =
            getAllImages(current, parent + File.separatorChar + current.getName());
          imageFiles.addAll(imgList);
          if (PadImageDirectory.getDirectoryList().contains(current.getName())) {
            scannedPadDirectory = true;
          }
        }
      } else if (isPadImagesDir) {
        String fileName = current.getName();
        if (FileUtil.isImageFile(fileName)) {
          imageFiles.add(parent + File.separatorChar + current.getName());
        }
      }
    }
    return imageFiles;
  }

  static public String getSkinDir(String skinDirList) throws ObjectNotCreatedException {
    //Get the skins directory
    Vector skinsDirVect = getVectorData(skinDirList);
    if (skinsDirVect.size() == 0) {
      logger.error("createEncryptedKeyPad() Skins directory list is empty. Property name is bharosa.authentipad.XXXX.skins.dirlist. skinDirList=" +
                   skinDirList);
      throw ObjectNotCreatedException.createInvalidInputDataException();
    }

    return (String)skinsDirVect.get(random.nextInt(skinsDirVect.size()));
  }

  public static boolean isUseDefaultImage() {
    return useDefaultImage;
  }

  public static boolean isUseDefaultCaption() {
    return useDefaultCaption;
  }

  public static String getDefaultImage() {
    if (useDefaultImage) {
      String imagePath = assignImageToUser(imageDirListPropertyName);
      if (imagePath == null) {
        logger.error("Image path is null. Dir=" + imageDirListPropertyName);
      }
      return imagePath;
    }
    return null;
  }

  public static String getDefaultCaption() {
    return getDefaultCaption(BharosaLocale.getDefaultLocale());
  }

  public static String getDefaultCaption(Locale aLocale) {
    if (useDefaultCaption) {
      String caption =
        assignCaptionTextToUser(word2PropertyName, word1PropertyName, aLocale);
      if (caption == null) {
        logger.error("Caption is null. Dir=" + word2PropertyName + " / " +
                     word1PropertyName);
      }
      return caption;
    }
    return null;
  }

  public static TimeZone getTimezone(String offsetStr) {
    float offset;
    Calendar cal = Calendar.getInstance();
    Date timeStamp = new Date();
    boolean inDST = cal.getTimeZone().inDaylightTime(timeStamp);

    boolean useTZEstimation =
      BharosaConfig.getLocalizedBooleanFromNamedBundle("bharosa.authentipad.use.timezone.estimation",
                                                       authentiPadResource,
                                                       true);

    TimeZone tz = cal.getTimeZone();

    if (!StringUtil.isEmpty(offsetStr)) {
      offset = StringUtil.toFloatValue(offsetStr);
      if (inDST && useTZEstimation) {
        offset--;
      }
      int rawOffSet = (int)(offset * 3600000);
      String[] zoneIds = TimeZone.getAvailableIDs(rawOffSet);
      if (useTZEstimation && zoneIds != null && zoneIds.length > 0) {
        boolean usTzFound = false;
        for (int j = 0; j < zoneIds.length && !usTzFound; j++) {
          String tmpTz = zoneIds[j];
          if (tmpTz.startsWith("US/")) {
            tz = TimeZone.getTimeZone(tmpTz);
            if (tz.useDaylightTime() == inDST) {
              usTzFound = true;
            }
          }
        }
        if (!usTzFound) {
          tz = TimeZone.getTimeZone(zoneIds[0]);
        }
      } else {
        if (offset >= 0) {
          // If offset is positive it will not have a sign, so set one.
          offsetStr = "+" + offset;
        }
        tz = TimeZone.getTimeZone("GMT" + offsetStr);

      }
    }
    return tz;
  }

  public static KeyDetail getKeyDetail(AuthentiKey authKey,
                                       AuthentiConfig authConfig, int index) {
    int xIndex = authKey.getXIndex(index);
    int yIndex = authKey.getYIndex(index);

    KeyDetail[][] keys = authConfig.getKeys();

    KeyDetail keyDetail = keys[xIndex][yIndex];
    Rectangle area =
      new Rectangle(authKey.getX(index), authKey.getY(index), authKey.getWidth(index),
                    authKey.getHeight(index));
    keyDetail.setArea(area);


    return keyDetail;
  }


}

