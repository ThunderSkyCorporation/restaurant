package com.bharosa.uio.util;
/*
 * Copyright (c) 2006 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * Description
 * Date: Nov 9, 2006
 *
 * @author dan
 */
public interface BharosaUIOConstants {

    public static String ENUM_AUTH_STATUS = "auth.status.enum";
    public static String ENUM_TRX_STATUS = "tracker.transaction.status.enum";
    public static String ENUM_PROFILE_TYPE = "profile.type.enum";
    public static String ENUM_CLIENT_TYPE = "auth.client.type.enum";

    public static String AUTH_STATUS = "Login-Status";
    public static String FORGOT_PASSWORD_STATUS = "BH_FP-Status";
    public static String APP_ID = "BharosaAppId";
    public static String CUSTOMER_ID = "BH_CustomerId";
    public static String USER_GROUP = "User-Group";
    public static String PHASE = "WebUIOPhase";
    public static String USER_HOST_ADDRESS = "BharosaUserHostAddress";
    public static String USER_HOST_NAME = "BharosaUserHostName";
    public static String USER_INPUT = "BH_UserInput";
    public static String PAGE_ID = "BH_PageId";
    public static String CLIENT_LOCALE = "BH_ClientLocale";
    
    public static String PROPERTY_KEYS = "BH_PropKeys";
    public static String PROPERTY_RESPONSE_PREFIX = "BH_Property-";

    public static String AUTH_STATUS_SUCCESS = "success";
    public static String AUTH_STATUS_INVALID_USER = "invalid_user";
    public static String AUTH_STATUS_WRONG_PASSWORD = "wrong_password";
    public static String AUTH_STATUS_WRONG_ANSWER = "wrong_answer";
    public static String AUTH_STATUS_DISABLED_USER = "user_disabled";
    public static String AUTH_STATUS_PENDING = "pending";
    public static String AUTH_STATUS_EXPIRED_PASSWORD = "expired_password";
    public static String AUTH_STATUS_SYSTEM_ERROR = "system_error";

    public static String PROXY_RESULT = "Rules-Result";
    public static String FORGOT_PASSWORD_RESULT = "BH_FP-Rules-Result";
    public static String PROXY_RESULT_ALLOW = "allow";
    public static String PROXY_RESULT_BLOCK = "block";
    
    public static String PROP_PROXY_MODE_FLAG = "bharosa.uio.proxy.mode.flag";

    public static String TRX_TYPE = "BH_Trx_Type";
    public static String TRX_PARAM_PREFIX = "BH_Trx_Param_";
    public static String TRX_RULE_RESULT = "BH_Trx_Rules-Result";
    
    public static String RULE_ACTION_LIST_PREFIX = "BH_Rule-Action-List_";

}
