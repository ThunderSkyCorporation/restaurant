package com.bharosa.client;

import com.bharosa.client.enums.BharosaEnumChallengeType;
import com.bharosa.common.logger.Logger;
import com.bharosa.common.util.BharosaLocale;
import com.bharosa.vcrypt.auth.intf.VCryptAuthUser;
import com.bharosa.vcrypt.auth.intf.VCryptLocalizedString;
import com.bharosa.vcrypt.auth.intf.VCryptWheel;
import com.bharosa.vcrypt.tracker.util.CookieSet;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Locale;
import java.util.Enumeration;

/**
 * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
 * Oracle disclaims all express and implied warranties, including, the implied warranties of 
 * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
 * including, direct, indirect, incidental, special or consequential damages for loss of 
 * profits, revenue, data or data use, incurred by you or any third party 
 * in connection with the use of these materials.
 */
public class BharosaSession implements Serializable {

    static Logger logger = Logger.getLogger(BharosaSession.class);

    private String bharosaSessionId = null;
    private Long bharosaUserId = null;
    private String externalUserId = null;
    private String externalGroupName = null;
    private String loginId = null;
    private CookieSet cookieSet = null;
    transient VCryptAuthUser authUser = null;
    private VCryptLocalizedString questionText = null;
    private String otpCode = null;
    private String offset = null;
    private HashMap map = new HashMap();
    private Locale locale = BharosaLocale.getCurrentLocale();
    private String remoteIPAddr;
    private VCryptWheel slider = null;
    
    private String appId = null;
    private BharosaEnumChallengeType challengeType = null;
    private Integer challengeRiskScore = null;
    private String challengeTriggerCheckpoint = null;

    private int challengeFailureCntForSession = 0;
    private int challengeSuccesscntForSession = 0;
    private int challengeCntForSession = 0; // if user attempts all then should be challengeFailureCntForSession+challengeSuccesscntForSession
    
    public BharosaSession(String bharosaSessionId) {
        this.bharosaSessionId = bharosaSessionId;
        this.appId = "default";
    }

    public String getBharosaSessionId() {
        return bharosaSessionId;
    }

    public void setBharosaSessionId(String bharosaSessionId) {
        this.bharosaSessionId = bharosaSessionId;
    }

    public Long getBharosaUserId() {
        return bharosaUserId;
    }

    public void setBharosaUserId(Long bharosaUserId) {
        this.bharosaUserId = bharosaUserId;
    }

    public String getExternalUserId() {
        return externalUserId;
    }

    public void setExternalUserId(String externalUserId) {
        this.externalUserId = externalUserId;
    }

    public String getExternalGroupName() {
        return externalGroupName;
    }

    public void setExternalGroupName(String externalGroupName) {
        this.externalGroupName = externalGroupName;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public CookieSet getCookieSet() {
        return cookieSet;
    }

    public void setCookieSet(CookieSet cookieSet) {
        this.cookieSet = cookieSet;
    }

    public BharosaAuthentiPadData getAuthentiPad(String padName) {
        return (BharosaAuthentiPadData) map.get(padName);
    }

    public void removeAuthentiPad(String padName) {
        map.remove(padName);
    }

    public void setAuthentiPadData(BharosaAuthentiPadData authPad) {
        map.put(authPad.getName(), authPad);
    }

    public VCryptAuthUser getAuthUser() {
        return authUser;
    }

    public void setAuthUser(VCryptAuthUser authUser) {
        this.authUser = authUser;
    }

    public VCryptLocalizedString getQuestionText() {
        return questionText;
    }

    public void setQuestionText(VCryptLocalizedString questionText) {
        this.questionText = questionText;
    }

    public void setOffset(String offset) {
        this.offset = offset;
    }

    public String getOffset() {
        return offset;
    }

    public int getChallengeFailureCntForSession() {
        return challengeFailureCntForSession;
    }

    public void incrementChallengeFailureCntForSession() {
        this.challengeFailureCntForSession++;
    }

    public int getChallengeSuccesscntForSession() {
        return challengeSuccesscntForSession;
    }

    public void incrementChallengeSuccesscntForSession() {
        this.challengeSuccesscntForSession++;
    }

    public int getChallengeCntForSession() {
        return challengeCntForSession;
    }

    public void incrementChallengeCntForSession() {
        this.challengeCntForSession++;
    }
    
    public Locale getLocale()
    {
    	return locale;
    }
    
    public void setLocale(Locale aLocale, Enumeration locales){
    	BharosaLocale.setCurrentLocale(aLocale, locales);
    	locale = BharosaLocale.getCurrentLocale();
    }

    public void setLocale(Locale aLocale){
    	BharosaLocale.setCurrentLocale(aLocale, null);
    	locale = BharosaLocale.getCurrentLocale();
    }

    public String getRemoteIPAddr() {
        return remoteIPAddr;
    }

    public void setRemoteIPAddr(String remoteIPAddr) {
        this.remoteIPAddr = remoteIPAddr;
    }

    public String toString() {
        return "BharosaSession{" +
                "bharosaSessionId='" + bharosaSessionId + "'" +
                ", bharosaUserId=" + bharosaUserId +
                ", externalUserId='" + externalUserId + "'" +
                ", externalGroupName='" + externalGroupName + "'" +
                ", loginId='" + loginId + "'" +
                ", cookieSet=" + cookieSet +
                ", authUser=" + authUser +
                ", questionText=" + questionText +
                ", off set='" + offset + "'" +
                ", map =" + map +
                ", challengeFailureCntForSession = " + challengeFailureCntForSession +
                ", challengeSuccesscntForSession = " + challengeSuccesscntForSession +
                ", challengeCntForSession = " + challengeCntForSession + 
                "} ";
    }

  public void setSlider(VCryptWheel slider) {
    this.slider = slider;
  }

  public VCryptWheel getSlider() {
    return slider;
  }

  public void setChallengeType(BharosaEnumChallengeType challengeType) {
    this.challengeType = challengeType;
  }

  public BharosaEnumChallengeType getChallengeType() {
    return challengeType;
  }

  public void setAppId(String appId) {
    this.appId = appId;
  }

  public String getAppId() {
    return appId;
  }

  public void setOtpCode(String otpCode) {
    this.otpCode = otpCode;
  }

  public String getOtpCode() {
    return otpCode;
  }

  public void setChallengeRiskScore(Integer challengeRiskScore) {
    this.challengeRiskScore = challengeRiskScore;
  }

  public Integer getChallengeRiskScore() {
    return challengeRiskScore;
  }

  public void setChallengeTriggerCheckpoint(String challengeTriggerCheckpoint) {
    this.challengeTriggerCheckpoint = challengeTriggerCheckpoint;
  }

  public String getChallengeTriggerCheckpoint() {
    return challengeTriggerCheckpoint;
  }
}
