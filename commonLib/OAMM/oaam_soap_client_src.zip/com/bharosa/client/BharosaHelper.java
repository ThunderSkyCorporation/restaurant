package com.bharosa.client;

import com.bharosa.client.enums.*;
import com.bharosa.common.logger.Logger;
import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.IBharosaConstants;
import com.bharosa.common.util.StringUtil;
import com.bharosa.common.util.UserDefEnum;
import com.bharosa.common.exception.BharosaException;
import com.bharosa.common.util.BharosaMail;
import com.bharosa.common.util.UserDefEnumElement;
import com.bharosa.uio.util.BharosaUIOConstants;
import com.bharosa.vcrypt.auth.intf.VCryptAuth;
import com.bharosa.vcrypt.auth.intf.VCryptAuthResult;
import com.bharosa.vcrypt.auth.intf.VCryptAuthUser;
import com.bharosa.vcrypt.auth.intf.VCryptLocale;
import com.bharosa.vcrypt.auth.intf.VCryptLocalizedString;
import com.bharosa.vcrypt.auth.intf.VCryptQuestion;
import com.bharosa.vcrypt.auth.intf.VCryptWheel;
import com.bharosa.vcrypt.auth.keypad.AuthentiPad;
import com.bharosa.vcrypt.auth.keypad.KeyPadUtil;
import com.bharosa.vcrypt.auth.util.VCryptAuthUtil;
import com.bharosa.vcrypt.common.util.VCryptCommonUtil;
import com.bharosa.vcrypt.common.util.VCryptObjectResponse;
import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.common.util.VCryptServletUtil;
import com.bharosa.vcrypt.servlet.tracker.VCryptServletTrackerUtil;
import com.bharosa.vcrypt.tracker.intf.VCryptRulesResult;
import com.bharosa.vcrypt.tracker.util.CookieSet;
import com.bharosa.vcrypt.tracker.util.VCryptTrackerUtil;
import com.bharosa.vcrypt.tracker.data.TransactionUpdateRequestData;
import com.bharosa.vcrypt.tracker.data.TransactionCreateRequestData;
import com.bharosa.vcrypt.tracker.transaction.data.EntityData;
import com.bharosa.vcrypt.tracker.transaction.data.EntityHeader;
import com.bharosa.vcryptclient.client.exceptions.BharosaClientKeyPadException;
import com.bharosa.vcryptclient.client.util.BharosaClientUtil;
import com.bharosa.vcryptclient.client.util.SliderUtil;

import javax.servlet.http.HttpServletRequest;

import java.io.File;
import java.io.OutputStream;

import java.util.*;

/**
 * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
 * Oracle disclaims all express and implied warranties, including, the implied 
 * warranties of merchantability or fitness for a particular use. 
 * Oracle shall not be liable for any damages, including, direct, indirect, 
 * incidental, special or consequential damages for loss of profits, revenue, 
 * data or data use, incurred by you or any third party in connection with the use of these materials.
 */
public class BharosaHelper {

    static Logger logger = Logger.getLogger(BharosaHelper.class);
    public static final UserDefEnum ENUM_TRANSACTION_STATUS = UserDefEnum.getEnum("tracker.transaction.status.enum");
    
    // CHANGE THESE BASED ON INSTALLATION SPECIFIC VALUES
    static List PRE_AUTH_RUNTIME_LIST = Collections.singletonList(new Integer(1));
    static List POST_AUTH_RUNTIME_LIST = Collections.singletonList(new Integer(2));
    static List CHALLEGNE_RUNTIME_LIST = Collections.singletonList(new Integer(3));
    static List REGISTRATION_RUNTIME_LIST = Collections.singletonList(new Integer(15));
    static List AUTHENTI_PAD_RUNTIME_LIST = Collections.singletonList(new Integer(10));
    static List PRE_TRANSACTION_RUNTIME_LIST = Collections.singletonList(new Integer(70));
    static List POST_TRANSACTION_RUNTIME_LIST = Collections.singletonList(new Integer(80));


    static boolean doPerfLog = BharosaConfig.getBoolean("com.bharosa.client.BharosaHelper.doPerfLog", false);

    /* Properties for default image handling
    # Pin Pad default image
    bharosa.authentipad.numeric.background.file=
    # Text pad default image
    bharosa.authentipad.textpad.background.file=
    # Alpha key pad
    bharosa.authentipad.alphanumeric.background.file=
    # Full key pad
    bharosa.authentipad.full.background.file=
    #quesion pad
    bharosa.authentipad.questionpad.background.file=


    Usage:
    Path needs to be absolute or in class path. To set 7239068.jpg as default image for textpad, add following to bharosa_client.properties
        bharosa.authentipad.textpad.background.file=/bharosa_images/allpads/textpad/7239068.jpg
    */
    private final static String SKINS_DIR = "bharosa.authentipad.images.dir";
    private static BharosaHelper instance = null;
    private final static Object lock = new Object();

    static public BharosaHelper getInstance() {
        if (instance == null) {
            synchronized (lock) {
                if (instance == null) {
                    instance = new BharosaHelper();
                }
            }
        }
        return instance;
    }

    private BharosaHelper() {
        try {
            VCryptTrackerUtil.getVCryptTrackerInstance().init("Server Warmup");
        } catch (Throwable e) {
            logger.info("Init failed to warmup server, no functionality loss",
                        e);
        }
    }

    public BharosaSession createNewBharosaSession(String clientUserSessionId) {
        return new BharosaSession(clientUserSessionId);
    }

    public BharosaSession createNewBharosaSession() {
        String uniqueId =
            VCryptCommonUtil.generateUID(String.valueOf(System.currentTimeMillis()));
        return createNewBharosaSession(uniqueId);
    }

    /**
     * Get auth user from session
     *
     * @param bharosaSession BharosaSession Object
     * @return VCryptAuthUser will create one if not exists
     */
    public VCryptAuthUser getUser(BharosaSession bharosaSession) {

        if (doPerfLog)
            logger.info("BEGIN:getUser");

        VCryptAuthUser authUser = bharosaSession.getAuthUser();
        if (authUser == null || authUser.getCustomerId() == null) {

            if (StringUtil.isEmpty(bharosaSession.getLoginId()) ||
                StringUtil.isEmpty(bharosaSession.getExternalGroupName())) {
                logger.error("getUser invalid session data=" + bharosaSession +
                             " login and group name required.");
                if (doPerfLog)
                    logger.info("END:getUser");
                return null;
            }

            VCryptAuth vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();
            authUser =
                    vCryptAuth.getUserByLoginId(bharosaSession.getLoginId(), bharosaSession.getExternalGroupName());
            if (logger.isDebugEnabled())
                logger.debug("getUser by login and group user=" + authUser +
                             ", bharosaSession=" + bharosaSession);

            if (authUser == null ||
                StringUtil.isEmpty(authUser.getCustomerId())) {
                String dummyPassword =
                    BharosaConfig.get("bharosa.uio.login.dummy.password",
                                      "test");
                String dummyPin =
                    BharosaConfig.get("bharosa.uio.login.dummy.pin", "1111");
                authUser = new VCryptAuthUser();
                authUser.setLoginId(bharosaSession.getLoginId());
                authUser.setCustomerId(bharosaSession.getExternalUserId());
                authUser.setCustomerGroupId(bharosaSession.getExternalGroupName());
                HashMap securityPreferences = new HashMap();
                securityPreferences.put("status", "1");
                securityPreferences.put("password", dummyPassword);
                securityPreferences.put("pin", dummyPin);
                authUser.setSecurityPreferences(securityPreferences);
                authUser = vCryptAuth.createUser(authUser);
                if (logger.isDebugEnabled())
                    logger.debug("getUser created user=" + authUser +
                                 ", bharosaSession=" + bharosaSession);
            }

            // Set auth user for future use
            bharosaSession.setAuthUser(authUser);
        }
        if (doPerfLog)
            logger.info("END:getUser");
        return authUser;
    } // getUser

    /**
     * @param bharosaSession BharosaSession established for this request
     * @param remoteIPAddr   remote IpAddres
     * @param remoteHost     remote Host
     * @param authStatus     Authentication status
     * @param secureCookie   Secure browser cookie
     * @param fpBrowser      browser fingerprint
     * @return CookieSet, check for CookieSet.getVCryptResponse.isSucess() before using the cookies
     * @see com.bharosa.vcrypt.common.util.VCryptServletUtil#getBrowserFingerPrint(javax.servlet.http.HttpServletRequest)
     */
    public CookieSet fingerPrintBrowser(BharosaSession bharosaSession,
                                        String remoteIPAddr, String remoteHost,
                                        BharosaEnumAuthStatus authStatus,
                                        String secureCookie,
                                        String fpBrowser) {
        return fingerPrintFlash(bharosaSession, remoteIPAddr, remoteHost,
                                authStatus, secureCookie, fpBrowser, null,
                                null);
    } // fingerPrintBrowser

    /**
     * @param bharosaSession BharosaSession established for this request
     * @param remoteIPAddr   remote IpAddres
     * @param remoteHost     remote Host
     * @param authStatus     Authentication status
     * @param secureCookie   Secure browser cookie
     * @param fpBrowser      Browser fingerprint
     * @param flashCookie    Flash Cookie
     * @param fpFlash        Flash fingerprint
     * @return CookieSet, check for CookieSet.getVCryptResponse.isSucess() before using the cookies
     * @see com.bharosa.vcrypt.common.util.VCryptServletUtil#getBrowserFingerPrint(javax.servlet.http.HttpServletRequest)
     * @see com.bharosa.vcrypt.common.util.VCryptServletUtil#getFlashFingerPrint(javax.servlet.http.HttpServletRequest)
     */
    public CookieSet fingerPrintFlash(BharosaSession bharosaSession,
                                      String remoteIPAddr, String remoteHost,
                                      BharosaEnumAuthStatus authStatus,
                                      String secureCookie, String fpBrowser,
                                      String flashCookie, String fpFlash) {

        if (doPerfLog)
            logger.info("BEGIN:fingerPrintFlash");

        CookieSet cookiSet = null;
        if (StringUtil.isEmpty(bharosaSession.getBharosaSessionId())) {
            logger.error("fingerPrintFlash Session id cant be null BharosaSession=" +
                         bharosaSession);
            if (doPerfLog)
                logger.info("END:fingerPrintFlash");
            return cookiSet;
        }

        if (StringUtil.isEmpty(bharosaSession.getLoginId()) &&
            StringUtil.isEmpty(bharosaSession.getExternalGroupName())) {
            logger.error("fingerPrintFlash login and group name combination can't be null BharosaSession=" +
                         bharosaSession);
            if (doPerfLog)
                logger.info("END:fingerPrintFlash");
            return cookiSet;
        }

        if (bharosaSession.getCookieSet() != null && fpFlash == null) {
            if (logger.isDebugEnabled())
                logger.debug("fingerPrintFlash BharosaSession=" +
                             bharosaSession +
                             ", already fingerprinted returning existing cookieset.");
            if (doPerfLog)
                logger.info("END:fingerPrintFlash");
            return bharosaSession.getCookieSet();
        }

        int fpTypeSecure = 1;
        int fpTypeFlash = 2;
        boolean secureDevice = false;
        String clientVerion = "4";

        // asynchronous requests to flash fingerprint due to flash
        synchronized (bharosaSession) {
            cookiSet =
                    VCryptTrackerUtil.getVCryptTrackerInstance().updateLog(bharosaSession.getBharosaSessionId(),
                                                                           remoteIPAddr,
                                                                           remoteHost,
                                                                           secureCookie,
                                                                           flashCookie,
                                                                           bharosaSession.getExternalGroupName(),
                                                                           bharosaSession.getExternalUserId(),
                                                                           bharosaSession.getLoginId(),
                                                                           secureDevice,
                                                                           authStatus.getValue(),
                                                                           BharosaEnumClientType.LOGIN.getValue(),
                                                                           clientVerion,
                                                                           fpTypeSecure,
                                                                           fpBrowser,
                                                                           fpTypeFlash,
                                                                           fpFlash);
        }

        if (cookiSet == null || !cookiSet.getVCryptResponse().isSuccess())
            logger.error("Error fingerprinting bharosaSession=" +
                         bharosaSession + ", retVal=" + cookiSet);

        if (doPerfLog)
            logger.info("END:fingerPrintFlash");

        return cookiSet;
    } // fingerPrintFlash

    public Object[] createOrUpdateEntity(String requestId,
                                             String entityType,
                                             Map entityParameterMap){
      Object[] returnObj= new Object[2];
      if (doPerfLog)
          logger.info("BEGIN:createOrUpdateEntity");
      VCryptResponse response = null;
      VCryptObjectResponse objectResponse= null;
      EntityData entityData= new EntityData(entityType,entityParameterMap);
      EntityData[] entityRequestData = new EntityData[1];
      entityRequestData[0]= entityData;
        objectResponse = VCryptTrackerUtil.getVCryptTrackerInstance().createOrUpdateEntities(entityRequestData, false, 1, requestId);
        if(objectResponse!=null){
          if(objectResponse.isSuccess()){
            VCryptObjectResponse[] responseArray = new VCryptObjectResponse[1];
            VCryptObjectResponse innerResponse= new VCryptObjectResponse();
            responseArray=(VCryptObjectResponse[])objectResponse.getObject();
            innerResponse = responseArray[0];
            if(innerResponse.isSuccess()){
              returnObj[0]=BharosaEnumAction.ALLOW;
              EntityHeader entityHeader= (EntityHeader)innerResponse.getObject();
              returnObj[1]=entityHeader.getEntityId(); 
              return returnObj;
            }
            else{
              returnObj[0]=BharosaEnumAction.SYSTEM_ERROR;
              returnObj[1]=innerResponse.getErrorMessage();
              return returnObj;
            }
          }
          else{
              returnObj[0]= BharosaEnumAction.SYSTEM_ERROR;
              returnObj[1]= objectResponse.getErrorMessage();
              return returnObj;
          }
        }
        else{
          returnObj[0]= BharosaEnumAction.SYSTEM_ERROR;
          returnObj[1]= "Error in creating entity";
          return returnObj;
        }
     
    }
  public Object[] searchEntity(String entityType,
                                           Map entityParameterMap){
    Object[] returnObj= new Object[2];
    if (doPerfLog)
        logger.info("BEGIN:createOrUpdateEntity");
    VCryptResponse response = null;
    VCryptObjectResponse objectResponse= null;
    EntityData entityData= new EntityData(entityType,entityParameterMap);
      objectResponse = VCryptTrackerUtil.getVCryptTrackerInstance().searchEntityByKey(entityData);
      if(objectResponse!=null){
        if(objectResponse.isSuccess()){
          EntityHeader entityHeader= (EntityHeader)objectResponse.getObject();
          returnObj[0]=BharosaEnumAction.ALLOW;
          returnObj[1]=entityHeader.getEntityId();
          return returnObj;
        }
        else{
            returnObj[0]= BharosaEnumAction.SYSTEM_ERROR;
            returnObj[1]= objectResponse.getErrorMessage();
            return returnObj;
        }
      }
      else{
        returnObj[0]= BharosaEnumAction.SYSTEM_ERROR;
        returnObj[1]= "Error in searching entity";
        return returnObj;
      }
   
  }

    /**
     * @deprecated use handleTransactionLog(BharosaSession, Date, Integer, String, Map, Boolean) instead.
     */
    public VCryptResponse handleTransactionLog(BharosaSession session,
                                               Date requestTime,
                                               Integer status,
                                               String transactionDefKey,
                                               Map map) {
        return handleTransactionLog(session, requestTime, status, transactionDefKey, map, Boolean.FALSE);
    }

    public VCryptResponse handleTransactionLog(BharosaSession session,
                                               Date requestTime,
                                               Integer status,
                                               String transactionDefKey,
                                               Map map, Boolean analyzePatterns) {
        if (doPerfLog)
            logger.info("BEGIN:handleTransactionLog");
        Integer trxStatus =
            status != null ? status : new Integer(ENUM_TRANSACTION_STATUS.getElementValue("pending"));
        String externalTransactionId = null;
        VCryptResponse response = null;
        try {
            TransactionCreateRequestData trxUpdData =
                new TransactionCreateRequestData(session.getBharosaSessionId(),
                                                 requestTime,
                                                 transactionDefKey,
                                                 externalTransactionId,
                                                 trxStatus, map, analyzePatterns);
            response =
                    VCryptTrackerUtil.getVCryptTrackerInstance().createTransaction(trxUpdData);
        } catch (BharosaException e) {
            logger.error("handleTransactionLog session=" + session, e);
            return VCryptResponse.getUnexpectedErrorResponse();
        }
        if (doPerfLog)
            logger.info("END:handleTransactionLog");
        return response;
    }

    public VCryptResponse updateTransactionStatus(BharosaSession session,
                                                  Date requestTime,
                                                  Long transactionId,
                                                  Integer status, Map map) {
        if (doPerfLog)
            logger.info("BEGIN:updateTransactionStatus ");
        int trxStatus =
            status != null ? status.intValue() : ENUM_TRANSACTION_STATUS.getElementValue("success");
        VCryptResponse response = null;
        try {
            TransactionUpdateRequestData trxUpdData =
                new TransactionUpdateRequestData(session.getBharosaSessionId(),
                                                 requestTime, transactionId,
                                                 new Integer(trxStatus), map,
                                                 Boolean.TRUE);
            response =
                    VCryptTrackerUtil.getVCryptTrackerInstance().updateTransaction(trxUpdData);
        } catch (Exception e) {
            logger.error("updateTransactionStatus session=" + session, e);
        }
        if (doPerfLog)
            logger.info("END:updateTransactionStatus ");
        return response;
    }

    public BharosaEnumAction runPreAuthRules(BharosaSession bharosaSession) {
        return runPreAuthRules(bharosaSession, null);
    }

    public BharosaEnumAction runPreAuthRules(BharosaSession bharosaSession,
                                             Map contextMap) {
        if (doPerfLog)
            logger.info("BEGIN:runPreAuthRules");
        VCryptRulesResult result =
            runRules(bharosaSession, PRE_AUTH_RUNTIME_LIST, contextMap);
        BharosaEnumAction retValue =
            result == null ? BharosaEnumAction.ALLOW : BharosaEnumAction.getEnumAction(result.getResult());
        if (doPerfLog)
            logger.info("END:runPreAuthRules");
        return retValue;
    } // runPreAuthRules

    public BharosaEnumAction runPostAuthRules(BharosaSession bharosaSession) {
        return runPostAuthRules(bharosaSession, null);
    }

    public BharosaEnumAction runPostAuthRules(BharosaSession bharosaSession,
                                              Map contextMap) {
        if (doPerfLog)
            logger.info("BEGIN:runPostAuthRules");
        VCryptRulesResult result =
            runRules(bharosaSession, POST_AUTH_RUNTIME_LIST, contextMap);
        BharosaEnumAction retValue =
            (result == null) ? BharosaEnumAction.ALLOW :
            BharosaEnumAction.getEnumAction(result.getResult());
        if (doPerfLog)
            logger.info("END:runPostAuthRules");
        return retValue;
    } // runPostAuthRules

    public BharosaEnumAction runRegistrationRules(BharosaSession bharosaSession) {
        return runRegistrationRules(bharosaSession, null);
    }

    public BharosaEnumAction runRegistrationRules(BharosaSession bharosaSession,
                                                  Map contextMap) {
        if (doPerfLog)
            logger.info("BEGIN:runRegistrationRules");
        String requiredChallengeFields =
            getRequiredChallengeFields(bharosaSession);

        if (!StringUtil.isEmpty(requiredChallengeFields)) {
            String contextKey =
                BharosaConfig.get("oaam.otp.contact.info.context.key",
                                  "RequiredChallengeInfo");
            contextMap.put(contextKey, requiredChallengeFields);
        }

        VCryptRulesResult result =
            runRules(bharosaSession, REGISTRATION_RUNTIME_LIST, contextMap);
        BharosaEnumAction retValue =
            (result == null) ? BharosaEnumAction.ALLOW :
            BharosaEnumAction.getEnumAction(result.getResult());
        if (doPerfLog)
            logger.info("END:runRegistrationRules");
        return retValue;
    } // runRegistrationRules

    public BharosaEnumAction runPreTransactionRules(BharosaSession bharosaSession,
                                                    Map contextMap) {
        if (doPerfLog)
            logger.info("BEGIN:runPreTransactionRules");
        VCryptRulesResult result =
            runRules(bharosaSession, PRE_TRANSACTION_RUNTIME_LIST, contextMap);
        BharosaEnumAction retValue =
            (result == null) ? BharosaEnumAction.ALLOW :
            BharosaEnumAction.getEnumAction(result.getResult());
        if (doPerfLog)
            logger.info("END:runPreTransactionRuless");
        return retValue;
    }

    public BharosaEnumAction runPostTransactionRules(BharosaSession bharosaSession,
                                                     Map contextMap) {
        if (doPerfLog)
            logger.info("BEGIN:runPostTransactionRules");
        VCryptRulesResult result =
            runRules(bharosaSession, POST_TRANSACTION_RUNTIME_LIST,
                     contextMap);
        BharosaEnumAction retValue =
            (result == null) ? BharosaEnumAction.ALLOW :
            BharosaEnumAction.getEnumAction(result.getResult());
        if (doPerfLog)
            logger.info("END:runPostTransactionRuless");
        return retValue;
    }

    public BharosaEnumAction runChallengeRules(BharosaSession bharosaSession) {
        if (doPerfLog)
            logger.info("BEGIN:runChallengeRules");

        Map rulesContext = new HashMap();
        String contextKey =
            BharosaConfig.get("oaam.challengetype.context.key", "AvailableChallengeTypes");
        String availableChallengeTypes =
            getAvailableChallengeTypes(bharosaSession);

        rulesContext.put(contextKey, availableChallengeTypes);

        VCryptRulesResult result =
            runRules(bharosaSession, CHALLEGNE_RUNTIME_LIST, rulesContext);
        BharosaEnumAction retValue =
            result == null ? BharosaEnumAction.ALLOW : BharosaEnumAction.getEnumAction(result.getResult());

        if (retValue != BharosaEnumAction.BLOCK &&
            retValue != BharosaEnumAction.ALLOW) {
            bharosaSession.setChallengeType(BharosaEnumChallengeType.getBharosaEnumChallengeType(result.getResult()));
        } else {
            bharosaSession.setChallengeType(null);
        }

        if (doPerfLog)
            logger.info("END:runChallengeRules");
        return retValue;
    } // runChallengeRules

    public BharosaEnumAuthentiPad getAuthentiPad(BharosaSession bharosaSession) {
        if (doPerfLog)
            logger.info("BEGIN:getAuthentiPad");

        Map rulesContext = new HashMap();
        BharosaEnumChallengeType challengeType =
            bharosaSession.getChallengeType();
        if (challengeType != null) {
            String contextKey =
                BharosaConfig.get("oaam.challengetype.context.key",
                                  "AvailableChallengeTypes");
            rulesContext.put(contextKey, challengeType.toString());
        }

        VCryptRulesResult result =
            runRules(bharosaSession, AUTHENTI_PAD_RUNTIME_LIST, rulesContext);
        BharosaEnumAuthentiPad retValue =
            result == null ? BharosaEnumAuthentiPad.KEY_PAD :
            BharosaEnumAuthentiPad.getEnumAction(result.getResult());
        if (doPerfLog)
            logger.info("END:getAuthentiPad");
        return retValue;
    }

    public VCryptRulesResult runRules(BharosaSession bharosaSession,
                                      List runtimeList) {
        return runRules(bharosaSession, runtimeList, null);
    }

    public VCryptRulesResult runRules(BharosaSession bharosaSession,
                                      List runtimeList, Map contextDataMap) {
        return runRules(bharosaSession, runtimeList, contextDataMap, null, null);
    }

    public VCryptRulesResult runRules(BharosaSession bharosaSession,
                                      List runtimeList, Map contextDataMap,
                                      Long trxLogId, String extTrxId) {
        return runRules(bharosaSession, runtimeList, contextDataMap, trxLogId, extTrxId, null);
    }

    public VCryptRulesResult runRules(BharosaSession bharosaSession,
                                      List runtimeList, Map contextDataMap,
                                      Long trxLogId, String extTrxId, Date requestTime) {
        if (doPerfLog)
            logger.info("BEGIN:runRules");
        if (contextDataMap == null)
            contextDataMap = new HashMap();
        // Add request IP
        contextDataMap.put(IBharosaConstants.TRACKER_NODE_IP_ADDR,
                           bharosaSession.getRemoteIPAddr());

        // Add AppId
        contextDataMap.put(BharosaUIOConstants.APP_ID,
                           bharosaSession.getExternalGroupName().toLowerCase());

        // Send context details
        Locale locale = bharosaSession.getLocale();
        contextDataMap.put("browser_ip", bharosaSession.getRemoteIPAddr());
        //contextDataMap.put("browser_uas", bharosaSession.getUserAgent());
        contextDataMap.put("browser_localLang", locale.getLanguage());
        contextDataMap.put("browser_localCountry", locale.getCountry());
        contextDataMap.put("browser_localVariant", locale.getVariant());
        if (bharosaSession.getCookieSet() != null) {
            final String secureCookie =
                bharosaSession.getCookieSet().getSecureCookie();

            if (!StringUtil.isEmpty(secureCookie))
                contextDataMap.put("browser_securecookie", secureCookie);
        }
        VCryptRulesResult ruleResult =
            VCryptTrackerUtil.getVCryptRulesEngineInstance().processRules(
                                           bharosaSession.getBharosaSessionId(),
                                           trxLogId, extTrxId, requestTime,
                                           runtimeList,
                                           contextDataMap);

        if (logger.isDebugEnabled())
            logger.debug("runRules bharosaSession=" + bharosaSession +
                         ", result=" + ruleResult);

        // If rule return a challenge, store risk score and trigering  checkpoint
        if (BharosaEnumAction.getEnumAction(ruleResult.getResult()) ==
            BharosaEnumAction.CHALLENGE) {
            bharosaSession.setChallengeRiskScore(Integer.valueOf(ruleResult.getScore()));
            if (ruleResult.getRuntimeType() != null) {
                bharosaSession.setChallengeTriggerCheckpoint(UserDefEnum.getElementId(IBharosaConstants.ENUM_PROFILE_TYPE_ID,
                                                                                      ruleResult.getRuntimeType().intValue()));
            }
        }

        if (doPerfLog)
            logger.info("END:runRules");
        return ruleResult;
    } // runRules

    public boolean updateStatus(BharosaSession bharosaSession,
                                BharosaEnumAuthStatus authStatus,
                                BharosaEnumClientType clientType) {
        if (doPerfLog)
            logger.info("BEGIN:updateStatus");
        String clientVersion = "4";
        VCryptResponse response =
            VCryptTrackerUtil.getVCryptTrackerInstance().updateAuthStatus(bharosaSession.getBharosaSessionId(),
                                                                          authStatus.getValue(),
                                                                          clientType.getValue(),
                                                                          clientVersion,
                                                                          true);
        if (!response.isSuccess())
            logger.error("Error updateStatus bharosaSession=" +
                         bharosaSession + ", clientType=" + clientType +
                         ", authStatus=" + authStatus + ", result=" +
                         response);
        else if (logger.isDebugEnabled())
            logger.debug("updateStatus bharosaSession=" + bharosaSession +
                         ", clientType=" + clientType + ", authStatus=" +
                         authStatus + ", result=" + response);
        if (doPerfLog)
            logger.info("END:updateStatus");
        return response.isSuccess();
    }

    public BharosaAuthentiPadData createPersonalizedAuthentiPad(BharosaSession bharosaSession,
                                                                BharosaEnumAuthentiPad authentipad,
                                                                String padName) {
        if (doPerfLog)
            logger.info("BEGIN:createPersonalizedAuthentiPad");
        VCryptAuthUser authUser = getUser(bharosaSession);
        String bgFile =
            (String)authUser.getSecurityPreferences().get("imagePath");
        VCryptLocalizedString caption = authUser.getCaption();

        /* ********* If user don't have personalization show generic pad - and ask for personlization after password ****

        boolean setImage = StringUtil.isEmpty(bgFile);
        boolean setCaption = StringUtil.isEmpty(caption);

        VCryptAuth vCryptAuth = null;
        if (setCaption && setImage) {
            vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();
            vCryptAuth.setImageAndCaption(authUser.getCustomerId(), null, null);
        } else if (setCaption) {
            vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();
            vCryptAuth.setCaption(authUser.getCustomerId(), null);
        } else if (setImage) {
            vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();
            vCryptAuth.setImage(authUser.getCustomerId(), null);
        }

        // update session if auth user is modified
        if (vCryptAuth != null) {
            authUser = vCryptAuth.getUser(authUser.getCustomerId());
            bharosaSession.setAuthUser(authUser);
        }
*/

        // If frameFile is passed as null, BharosaClient will use predefined frame for that pad type from authenticator properties
        boolean displayOnly = false;
        BharosaAuthentiPadData retValue =
            createAuthentiPad(bharosaSession, authentipad, padName, bgFile,
                              null, caption, displayOnly);
        if (doPerfLog)
            logger.info("END:createPersonalizedAuthentiPad");
        return retValue;
    } // createPersonalizedAuthentiPad

    public BharosaAuthentiPadData createSampleAuthentiPad(BharosaSession bharosaSession,
                                                          BharosaEnumAuthentiPad authentipad,
                                                          String padName) {
        if (doPerfLog)
            logger.info("BEGIN:createPersonalizedAuthentiPad");
        VCryptAuthUser authUser = getUser(bharosaSession);
        String bgFile =
            (String)authUser.getSecurityPreferences().get("imagePath");
        VCryptLocalizedString caption = authUser.getCaption();

        String frameFile = null;

        if (BharosaEnumAuthentiPad.KEY_PAD_FULL.equals(authentipad) ||
            BharosaEnumAuthentiPad.KEY_PAD.equals(authentipad)) {
            frameFile =
                    BharosaConfig.get("bharosa.authentipad.full.sample.frame.file",
                                      null);
        } else if (BharosaEnumAuthentiPad.TEXT_PAD.equals(authentipad)) {
            frameFile =
                    BharosaConfig.get("bharosa.authentipad.textpad.sample.frame.file",
                                      null);
        } else if (BharosaEnumAuthentiPad.PIN_PAD.equals(authentipad)) {
            frameFile =
                    BharosaConfig.get("bharosa.authentipad.numeric.sample.frame.file",
                                      null);
        } else if (BharosaEnumAuthentiPad.QUESTION_PAD.equals(authentipad)) {
            frameFile =
                    BharosaConfig.get("bharosa.authentipad.questionpad.sample.frame.file",
                                      null);
        }

        boolean displayOnly = true;
        BharosaAuthentiPadData retValue =
            createAuthentiPad(bharosaSession, authentipad, padName, bgFile,
                              frameFile, caption, displayOnly);
        if (doPerfLog)
            logger.info("END:createSampleAuthentiPad");
        return retValue;
    } // createSampleAuthentiPad


    /**
     * Create authentipad
     * <li> Store authentipad in BharosaSession for future calls to decodePadValue
     * <li> BharosaSession Object state is changed and needs to be peristed
     *
     * @param bharosaSession BharosaSession required
     * @param padType        BharosaEnumAuthentiPad required
     * @param padName        name of the pad
     * @param bgFile         background file
     * @param frameFile      frame file
     * @param caption        personlized caption
     * @param isDisplayOnly  indicates if display only
     * @return html code for the pad
     */
    private BharosaAuthentiPadData createAuthentiPad(BharosaSession bharosaSession,
                                                     BharosaEnumAuthentiPad padType,
                                                     String padName,
                                                     String bgFile,
                                                     String frameFile,
                                                     VCryptLocalizedString caption,
                                                     boolean isDisplayOnly) {
        if (doPerfLog)
            logger.info("BEGIN:createAuthentiPad");
        BharosaAuthentiPadData retValue = null;
        if (padType == null) {
            logger.error("createAuthentiPad Inalid pad type session" +
                         bharosaSession + ", padType=" + padType);
            if (doPerfLog)
                logger.info("END:createAuthentiPad");
            return retValue;
        }

        if (StringUtil.isEmpty(padName)) {
            logger.error("createAuthentiPad padName can't be empty session" +
                         bharosaSession);
            if (doPerfLog)
                logger.info("END:createAuthentiPad");
            return retValue;
        }

        // If frameFile is passed as null, BharosaClient will use predefined frame for that pad type from authenticator properties
        try {
            boolean isADACompliant =
                BharosaConfig.getBoolean("desertref.authentipad.isADACompliant",
                                         false);
            BharosaAuthentiPadData padData =
                new BharosaAuthentiPadData(padName, padType, bgFile, frameFile,
                                           caption, isADACompliant,
                                           isDisplayOnly);
            retValue = createAuthentiPad(bharosaSession, padData);
        } catch (Exception e) {
            logger.error("createKeyPad padName=" + padName + ", bgFile=" +
                         bgFile + ", caption=" + caption + ", frameFile=" +
                         frameFile, e);
        }
        if (doPerfLog)
            logger.info("END:createAuthentiPad");
        return retValue;
    } // end createAuthentiPad

    /**
     * get pad data field http param name
     * <li> Use this method to determine the data field name
     *
     * @param padName value to decode
     * @return data field http param name
     */
    public String getPadDataFieldName(String padName) {
        return padName + "DataField";
    }


    private BharosaAuthentiPadData createAuthentiPad(BharosaSession bharosaSession,
                                                     BharosaAuthentiPadData padData) throws BharosaClientKeyPadException {
        if (doPerfLog)
            logger.info("BEGIN:createAuthentiPad");
        boolean hasJS = true;
        boolean hasImgs = true;
        AuthentiPad authentiPad = null;
        if (padData.getAuthentiPadAction().equals(BharosaEnumAuthentiPad.KEY_PAD_FULL)) {
            authentiPad =
                    BharosaClientUtil.getBharosaClientInstance().getFullKeyPad(padData.getName(),
                                                                               padData.getFrameFile(),
                                                                               padData.getBgFile(),
                                                                               padData.getCaption(),
                                                                               padData.isAdaCompliant(),
                                                                               hasJS,
                                                                               hasImgs);
        } else if (padData.getAuthentiPadAction().equals(BharosaEnumAuthentiPad.KEY_PAD)) {
            authentiPad =
                    BharosaClientUtil.getBharosaClientInstance().getAlphaNumericKeyPad(padData.getName(),
                                                                                       padData.getFrameFile(),
                                                                                       padData.getBgFile(),
                                                                                       padData.getCaption(),
                                                                                       padData.isAdaCompliant(),
                                                                                       hasJS,
                                                                                       hasImgs);
        } else if (padData.getAuthentiPadAction().equals(BharosaEnumAuthentiPad.PIN_PAD)) {
            authentiPad =
                    BharosaClientUtil.getBharosaClientInstance().getPinPad(padData.getName(),
                                                                           padData.getFrameFile(),
                                                                           padData.getBgFile(),
                                                                           padData.getCaption(),
                                                                           padData.isAdaCompliant(),
                                                                           hasJS,
                                                                           hasImgs);
        } else if (padData.getAuthentiPadAction().equals(BharosaEnumAuthentiPad.TEXT_PAD)) {
            authentiPad =
                    BharosaClientUtil.getBharosaClientInstance().getTextPad(padData.getName(),
                                                                            padData.getFrameFile(),
                                                                            padData.getBgFile(),
                                                                            padData.getCaption(),
                                                                            padData.isAdaCompliant(),
                                                                            hasJS,
                                                                            hasImgs);
        } else if (padData.getAuthentiPadAction().equals(BharosaEnumAuthentiPad.QUESTION_PAD)) {
            authentiPad =
                    BharosaClientUtil.getBharosaClientInstance().getQuestionPad(padData.getName(),
                                                                                padData.getFrameFile(),
                                                                                padData.getBgFile(),
                                                                                padData.getCaption(),
                                                                                padData.isAdaCompliant(),
                                                                                hasJS,
                                                                                hasImgs);
            String questionText =
                (bharosaSession.getQuestionText() != null) ? bharosaSession.getQuestionText().getText() :
                null;
            if (StringUtil.isEmpty(questionText)) // TODO : This approach restricts only one challenge pad per session - move to paddata for making this pad specific.
                logger.error("createAuthentiPad question Text not set for Question pad " +
                             bharosaSession);
            else
                authentiPad.setQuestionText(bharosaSession.getQuestionText());
        }

        if (authentiPad == null) {
            logger.error("createAuthentiPad pad type not supported session" +
                         bharosaSession + ", padData=" + padData);
            if (doPerfLog)
                logger.info("BEGIN:createAuthentiPad");
            return null;
        }

        authentiPad.setTimeStamp(new Date());
        authentiPad.setTimeZone(KeyPadUtil.getTimezone(bharosaSession.getOffset()));
        authentiPad.setDisplayOnly(padData.isDisplayOnly());

        padData.setAuthentiPad(authentiPad);
        bharosaSession.setAuthentiPadData(padData);
        if (doPerfLog)
            logger.info("BEGIN:createAuthentiPad");
        return padData;
    }

    public BharosaAuthentiPadData assignRandomImage(BharosaSession bharosaSession,
                                                    String padName) {
        if (doPerfLog)
            logger.info("BEGIN:assignRandomImage");
        BharosaAuthentiPadData retValue = null;
        try {
            BharosaAuthentiPadData padData =
                bharosaSession.getAuthentiPad(padName);
            padData.setNewBgFile(KeyPadUtil.assignImageToUser());
            retValue = createAuthentiPad(bharosaSession, padData);
        } catch (BharosaClientKeyPadException e) {
            logger.error("assignRandomImage bharosaSession=" + bharosaSession,
                         e);
        }
        if (doPerfLog)
            logger.info("END:assignRandomImage");
        return retValue;
    }

    public BharosaAuthentiPadData assignRandomImageAndCaption(BharosaSession bharosaSession,
                                                              String padName,
                                                              Locale locale) {
        if (doPerfLog)
            logger.info("BEGIN:assignRandomImageAndCaption");
        BharosaAuthentiPadData retValue = null;
        try {
            BharosaAuthentiPadData padData =
                bharosaSession.getAuthentiPad(padName);
            padData.setNewCaption(new VCryptLocalizedString(KeyPadUtil.assignCaptionTextToUser(locale),
                                                            locale));
            padData.setNewBgFile(KeyPadUtil.assignImageToUser());
            retValue = createAuthentiPad(bharosaSession, padData);
        } catch (BharosaClientKeyPadException e) {
            logger.error("assignRandomCaption bharosaSession=" +
                         bharosaSession, e);
        }
        if (doPerfLog)
            logger.info("END:assignRandomImageAndCaption");
        return retValue;
    }

    /**
     * decode pad value
     * <li> Use this method to read inputs of pad
     * <li> Remove the pad from BharosaSession. no further successul calls to decodePadValue possible before calling createPad
     * <li> BharosaSession Object state is changed and needs to be peristed
     *
     * @param bharosaSession BharosaSession object expected to have pad in the session
     * @param padName        name of the pad
     * @param input          value to decode
     * @return BharosaAuthentiPadData with decoded input client type
     */
    public BharosaAuthentiPadData decodePadInput(BharosaSession bharosaSession,
                                                 String padName,
                                                 String input) {
        if (doPerfLog)
            logger.info("BEGIN:decodePadInput");
        if (StringUtil.isEmpty(input)) {
            logger.error("decodePadValue empty input value is empty= " +
                         input);
            bharosaSession.removeAuthentiPad(padName);
            if (doPerfLog)
                logger.info("END:decodePadInput");
            return null;
        }

        BharosaAuthentiPadData authPadData =
            bharosaSession.getAuthentiPad(padName);
        if (authPadData == null) {
            logger.error("decodePadValue no authentipad in session ");
            if (doPerfLog)
                logger.info("END:decodePadInput");
            return null;
        }

        String decodedValue =
            KeyPadUtil.decodeKeyPadCode(authPadData.getAuthentiPad(), input);
        authPadData.setDecodedInput(decodedValue);

        bharosaSession.removeAuthentiPad(padName);
        if (doPerfLog)
            logger.info("END:decodePadInput");
        return authPadData;
    } // decodePadValue

    /**
     * Set user image and caption
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @param padName        pad name
     * @return true if success
     */
    public boolean saveNewImageAndOrCaption(BharosaSession bharosaSession,
                                            String padName) {
        if (doPerfLog)
            logger.info("BEGIN:saveNewImageAndOrCaption");
        BharosaAuthentiPadData padData =
            bharosaSession.getAuthentiPad(padName);
        boolean retValue = false;
        if (padData.getNewBgFile() != null ||
            padData.getNewCaption() != null) {
            VCryptAuth vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();
            VCryptAuthUser authUser = getUser(bharosaSession);
            if (padData.getNewBgFile() != null &&
                padData.getNewCaption() != null) {
                retValue =
                        vCryptAuth.setImageAndCaption(bharosaSession.getExternalUserId(),
                                                      padData.getNewBgFile(),
                                                      padData.getNewCaption());

                authUser.getSecurityPreferences().put("imagePath",
                                                      padData.getNewBgFile());
                authUser.getSecurityPreferences().put("personalNote",
                                                      padData.getNewCaption().getText());
            } else if (padData.getNewBgFile() != null) {
                retValue =
                        vCryptAuth.setImage(bharosaSession.getExternalUserId(),
                                            padData.getNewBgFile());
                authUser.getSecurityPreferences().put("imagePath",
                                                      padData.getNewBgFile());
            } else if (padData.getNewCaption() != null) {
                retValue =
                        vCryptAuth.setCaption(bharosaSession.getExternalUserId(),
                                              padData.getNewCaption());
                authUser.getSecurityPreferences().put("personalNote",
                                                      padData.getNewCaption().getText());
            }
        }
        if (doPerfLog)
            logger.info("END:saveNewImageAndOrCaption");
        return retValue;
    } // setImageAndCaption

    /**
     * Set Contact Info in BharosaSession AuthUser and the Database
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @param key String key of user data
     * @param value String value of user data
     * @return true if success
     */
    public boolean setContactInfo(BharosaSession bharosaSession, String key,
                                  String value) {
        if (doPerfLog)
            logger.info("BEGIN:setContactInfo");
        boolean retVal = false;

        // Save contact info flag to OAAM
        if (StringUtil.isEmpty(value)) {
            retVal =
                    setUserData(bharosaSession, BharosaConfig.get("oaam.otp.contact.info.flag.prefix",
                                                                  "otpContactInfoFlag_") +
                                key, null);
        } else {
            retVal =
                    setUserData(bharosaSession, BharosaConfig.get("oaam.otp.contact.info.flag.prefix",
                                                                  "otpContactInfoFlag_") +
                                key, "true");
        }

        // Save contact info data (in this case to OAAM as well)
        retVal =
                retVal && setUserData(bharosaSession, BharosaConfig.get("oaam.otp.contact.info.prefix",
                                                                        "otpContactInfo_") +
                                      key, value);

        if (doPerfLog)
            logger.info("END:setContactInfo");
        return retVal;
    }

    /**
     * Get Contact Info in BharosaSession AuthUser
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @param key String key of user data
     * @return value String value of user data
     */
    public String getContactInfo(BharosaSession bharosaSession, String key) {
        if (doPerfLog)
            logger.info("BEGIN:getContactInfo");
        String retValue = null;

        // If contact info flag is set, get the contact info
        if (Boolean.valueOf(getUserData(bharosaSession,
                                        BharosaConfig.get("oaam.otp.contact.info.flag.prefix",
                                                          "otpContactInfoFlag_") +
                                        key))) {
            retValue =
                    getUserData(bharosaSession, BharosaConfig.get("oaam.otp.contact.info.prefix",
                                                                  "otpContactInfo_") +
                                key);
        }

        if (doPerfLog)
            logger.info("END:getContactInfo");
        return retValue;
    }


    /**
     * Set User Data in BharosaSession AuthUser and the Database
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @param key String key of user data
     * @param value String value of user data
     * @return true if success
     */
    public boolean setUserData(BharosaSession bharosaSession, String key,
                               String value) {
        if (doPerfLog)
            logger.info("BEGIN:setUserData");
        boolean retVal = false;
        VCryptAuthUser authUser = bharosaSession.getAuthUser();
        authUser.setUserData(key, value);
        // Store information into Database
        retVal = saveUserData(bharosaSession);
        if (doPerfLog)
            logger.info("END:setUserData");
        return retVal;
    }

    /**
     * Get User Data in BharosaSession AuthUser
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @param key String key of user data
     * @return value String value of user data
     */
    public String getUserData(BharosaSession bharosaSession, String key) {
        if (doPerfLog)
            logger.info("BEGIN:getUserData");
        String retValue = null;
        VCryptAuthUser authUser = bharosaSession.getAuthUser();
        retValue = authUser.getUserData(key);
        if (doPerfLog)
            logger.info("END:getUserData");
        return retValue;
    }

    /**
     * Save User Data in BharosaSession AuthUser to the database
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @return true if success
     */
    public boolean saveUserData(BharosaSession bharosaSession) {
        if (doPerfLog)
            logger.info("BEGIN:saveUserData");
        boolean retValue = false;
        VCryptAuth vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();
        VCryptAuthUser savedUser =
            vCryptAuth.setUser(bharosaSession.getAuthUser());
        if (savedUser != null &&
            !StringUtil.isEmpty(savedUser.getCustomerId())) {
            retValue = true;
        }
        if (doPerfLog)
            logger.info("END:saveUserData");
        return retValue;
    }

    /**
     * Set current user's authentication device
     *
     * @param bharosaSession Bharosa Session Object
     * @param clientType     client type to be set
     */
    public void setUserAuthDevice(BharosaSession bharosaSession,
                                  BharosaEnumClientType clientType) {
        if (doPerfLog)
            logger.info("BEGIN:setUserAuthDevice");
        VCryptAuth vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();

        vCryptAuth.setUserAuthMode(bharosaSession.getExternalUserId(),
                                   clientType.getValue());
        if (doPerfLog)
            logger.info("END:setUserAuthDevice");
    }

    /**
     * Get current question from the user
     *
     * @param bharosaSession Bharosa Session Object
     * @return VCryptQuestion
     */
    public VCryptQuestion getUserQuestion(BharosaSession bharosaSession) {
        if (doPerfLog)
            logger.info("BEGIN:getUserQuestion");
        VCryptAuth vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();
        VCryptQuestion retValue =
            vCryptAuth.getSecretQuestion(bharosaSession.getExternalUserId());
        if (doPerfLog)
            logger.info("END:getUserQuestion");
        return retValue;
    } // end getUserQuestion

    /**
     * @param bharosaSession Bharosa Session Object
     * @return VCryptQuestion data
     */
    public VCryptQuestion[][] getQuestions(BharosaSession bharosaSession) {
        if (doPerfLog)
            logger.info("BEGIN:getQuestions");
        VCryptAuth vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();

        VCryptQuestion[][] retValue =
            vCryptAuth.getSignOnQuestions(bharosaSession.getExternalUserId(),
                                          new VCryptLocale(bharosaSession.getLocale()));
        if (retValue == null || retValue.length == 0) {
            logger.error("Error getting questions for user=" +
                         bharosaSession.getAuthUser());
        }

        if (doPerfLog)
            logger.info("END:getQuestions");
        return retValue;
    } // end getQuestions

    /**
     * Method to register questions
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @param questionList   questions to add
     * @return true if success
     */
    public boolean registerAnswers(BharosaSession bharosaSession,
                                   VCryptQuestion[] questionList) {
        if (doPerfLog)
            logger.info("BEGIN:registerAnswers");
        if (bharosaSession == null) {
            logger.error("bharosaSession is null.",
                         new Throwable().fillInStackTrace());
            if (doPerfLog)
                logger.info("END:registerAnswers");
            return false;
        }
        if (questionList == null || questionList.length == 0) {
            logger.error("registerAnswers question list can't be empty session=" +
                         bharosaSession);
            if (doPerfLog)
                logger.info("END:registerAnswers");
            return false;
        }

        VCryptAuth vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();
        VCryptResponse response =
            vCryptAuth.addQuestions(bharosaSession.getBharosaSessionId(),
                                    bharosaSession.getExternalUserId(),
                                    questionList);
        if (!response.isSuccess()) {
            logger.error("registerAnswers session=" + bharosaSession +
                         ", response=" + response);
        } else {
            // Refresh User object in session to reflect any changes to user status
            VCryptAuthUser authUser = vCryptAuth.getUserByLoginId(bharosaSession.getLoginId(), bharosaSession.getExternalGroupName());
            if (authUser != null){
              bharosaSession.setAuthUser(authUser);
            }
            
            if (logger.isDebugEnabled())
                logger.debug("registerAnswers session=" + bharosaSession +
                             ", response=" + response);
        }
        if (doPerfLog)
            logger.info("END:registerAnswers");
        return response.isSuccess();
    } // end registerAnswers


    /**
     * To validate challenge answer
     *
     * @param bharosaSession BharosaSession Object
     * @param answerText     answer text
     * @param clientType     client type used to obtain answer from user
     * @return BharosaEnumChallengeResult
     */
    public BharosaEnumChallengeResult validateAnswer(BharosaSession bharosaSession,
                                                     String answerText,
                                                     BharosaEnumClientType clientType) {
        if (doPerfLog)
            logger.info("BEGIN:validateAnswer");
        if (StringUtil.isEmpty(answerText)) {
            logger.error("validateAnswer bharosaSession " + bharosaSession +
                         ", answer text cant be empty");
            if (doPerfLog)
                logger.info("END:validateAnswer");
            return BharosaEnumChallengeResult.SYSTEM_ERROR;
        }
        int challengeChannel =
            UserDefEnum.getElementValue("tracker.challenge.channel.enum",
                                        "online");

        BharosaEnumChallengeType challengeType =
            bharosaSession.getChallengeType();
        VCryptAuthResult authResult = new VCryptAuthResult();
        BharosaEnumChallengeResult challengeResult =
            BharosaEnumChallengeResult.BLOCK;

        if (challengeType == BharosaEnumChallengeType.QUESTION_CHALLENGE) {
            // Validate Quesiton challenge
            VCryptAuth vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();
            authResult =
                    vCryptAuth.authenticateQuestion(bharosaSession.getBharosaSessionId(),
                                                    new Integer(challengeChannel),
                                                    bharosaSession.getExternalUserId(),
                                                    answerText);
            if (authResult == null) {
                logger.error("validateAnswer Failed bharosaSession " +
                             bharosaSession);
                if (doPerfLog)
                    logger.info("END:validateAnswer");
                return BharosaEnumChallengeResult.SYSTEM_ERROR;
            }

            challengeResult =
                    BharosaEnumChallengeResult.getBharosaEnumChallengeResult(authResult.getResultCode());
        } else {
            // Validate OTP
            if (answerText != null &&
                answerText.equals(bharosaSession.getOtpCode())) {
                challengeResult = BharosaEnumChallengeResult.SUCCESS;
                resetOTPCounter(bharosaSession);
            } else {
                challengeResult = BharosaEnumChallengeResult.WRONG_ANSWER;
                incrementOTPCounter(bharosaSession);
            }
        }

        if (logger.isDebugEnabled())
            logger.debug("validateAnswer bharosaSession" + bharosaSession +
                         ", authResult=" + authResult);


        if (challengeResult.isValid()) {
            bharosaSession.incrementChallengeSuccesscntForSession();
            updateStatus(bharosaSession, BharosaEnumAuthStatus.SUCCESS,
                         clientType);
        } else {
            updateStatus(bharosaSession, BharosaEnumAuthStatus.WRONG_ANSWER,
                         clientType);
            bharosaSession.incrementChallengeFailureCntForSession();
        }
        if (doPerfLog)
            logger.info("END:validateAnswer");
        return challengeResult;
    } // end validateAnswer

    /**
     * Set current user's status to Active
     *
     * @param bharosaSession Bharosa Session Object
     */
    public boolean setUserRegistered(BharosaSession bharosaSession) {
        if (doPerfLog)
            logger.info("BEGIN:setUserAuthDevice");
        VCryptAuth vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();

        boolean retVal =
            vCryptAuth.setUserStatus(bharosaSession.getExternalUserId(),
                                     BharosaEnumUserStatus.STATUS_ACTIVE.getValue());
        if (doPerfLog)
            logger.info("END:setUserAuthDevice");

        return retVal;
    }

    /**
     * Set current user's status
     *
     * @param bharosaSession Bharosa Session Object
     * @param userStatus     users status to be set
     */
    public boolean setUserStatus(BharosaSession bharosaSession,
                                 BharosaEnumUserStatus userStatus) {
        if (doPerfLog)
            logger.info("BEGIN:setUserAuthDevice");
        VCryptAuth vCryptAuth = VCryptAuthUtil.getVCryptAuthInstance();

        boolean retVal =
            vCryptAuth.setUserStatus(bharosaSession.getExternalUserId(),
                                     userStatus.getValue());
        if (doPerfLog)
            logger.info("END:setUserAuthDevice");

        return retVal;
    }


    public boolean registerUserInfo(BharosaSession bharosaSession) {

        boolean retVal = true; // Call backend

        return retVal;
    }

    public boolean isImageSet(BharosaSession session) {
        return false;
    }

    public String constructBrowserFingerPrint(String userAgent,
                                              String language, String country,
                                              String variant) {
        return VCryptServletUtil.getBrowserFingerPrint(userAgent, language,
                                                       country, variant);
    }

    public String constructFlashFingerPrint(String client, String fpStr) {
        return VCryptServletUtil.getFlashFingerPrint(client, fpStr);
    }

    public boolean imageToStream(BharosaSession bharosaSession,
                                 String imageName, String padName,
                                 String outputType, OutputStream os) {
        if (doPerfLog)
            logger.info("BEGIN:imageToStream");
        boolean retValue = false;

        try {
            File iconFile;
            AuthentiPad keyPad =
                bharosaSession.getAuthentiPad(padName).getAuthentiPad();
            String skinDir = BharosaConfig.get(SKINS_DIR, "alphapad_bg");
            if (skinDir == null) {
                logger.error("No skins directory bharosaSession=" +
                             bharosaSession + ", imageName=" + imageName +
                             ", outputType=" + outputType + ", padName=" +
                             padName);
                if (doPerfLog)
                    logger.info("END:imageToStream");
                return false;
            }

            if (imageName != null) {
                String imageFilePath = skinDir + File.separator + imageName;
                iconFile = KeyPadUtil.getFile(imageFilePath);
                if (iconFile != null) {
                    KeyPadUtil.encryptImageToStream(iconFile, outputType, os);
                    retValue = true;
                } else {
                    logger.error("no iconFile bharosaSession=" +
                                 bharosaSession + ", imageName=" + imageName +
                                 ", outputType=" + outputType + ", padName=" +
                                 padName + ", imageFilePath=" + imageFilePath);
                    retValue = false;
                }
            } else {
                if (keyPad != null) {
                    KeyPadUtil.encryptImageToStream(keyPad, os);
                } else {
                    String imageFilePath =
                        skinDir + File.separator + imageName;
                    iconFile = KeyPadUtil.getFile(imageFilePath);
                    if (iconFile != null)
                        KeyPadUtil.encryptImageToStream(iconFile, outputType,
                                                        os);
                }
            }
        } catch (Exception e) {
            logger.error("imageToStream error bharosaSession=" +
                         bharosaSession + ", imageName=" + imageName +
                         ", outputType=" + outputType + ", padName=" + padName,
                         e);
        }
        if (logger.isDebugEnabled())
            logger.debug("imageToStream bharosaSession=" + bharosaSession +
                         ", imageName=" + imageName + ", outputType=" +
                         outputType + ", padName=" + padName + ", retValue=" +
                         retValue);
        if (doPerfLog)
            logger.info("END:imageToStream");
        return retValue;
    }

    public int getQuestionCount() {
        return BharosaConfig.getInt("challenge.question.registration.groups.count",
                                    3);
    }

    public static Map getHeaderContextMap(HttpServletRequest request) {
        Map map = new HashMap();
        Enumeration nameEnum = request.getHeaderNames();
        while (nameEnum.hasMoreElements()) {
            Object o = nameEnum.nextElement();
            String header = o.toString();
            if (header.toLowerCase().startsWith("brsa_hdr"))
                map.put(header.toLowerCase(), request.getHeader(header));
        }
        return map;
    }

    public void registerDevice(BharosaSession bharosaSession,
                               String regDeviceStr) {
        boolean regDeviceChecked =
            StringUtil.equalsIgnoreCase(regDeviceStr, "true");
        if (regDeviceChecked) {
            markDevice(bharosaSession, regDeviceChecked);
        }
    }

    public boolean isDeviceRegistered(BharosaSession bharosaSession) {
        return VCryptServletTrackerUtil.isDeviceMarkedSafe(bharosaSession.getBharosaSessionId());
    }

    public void unregisterDevice(BharosaSession bharosaSession) {
        // If enabled, unregister current device
        boolean deviceRegisterEnabled =
            BharosaConfig.getBoolean("registerdevice.enabled", false);
        if (deviceRegisterEnabled) {
            markDevice(bharosaSession, false);
        }
    }

    public void unregisterAllDevices(BharosaSession bharosaSession) {
        // If enabled, unregister all devices
        boolean deviceRegisterEnabled =
            BharosaConfig.getBoolean("registerdevice.enabled", false);
        if (deviceRegisterEnabled) {
            VCryptServletTrackerUtil.clearSafeDeviceList(bharosaSession.getBharosaSessionId());
        }
    }

    private void markDevice(BharosaSession bharosaSession, boolean isSafe) {
        // If enabled, check for device registration checkbox
        boolean deviceRegisterEnabled =
            BharosaConfig.getBoolean("registerdevice.enabled", false);
        if (deviceRegisterEnabled) {
            VCryptServletTrackerUtil.markDeviceSafe(bharosaSession.getBharosaSessionId(),
                                                    isSafe);

        }
    }


    /**
     * Return isPinEnabled value for this session.
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @return a <code>boolean</code> value
     */
    public boolean isPinEnabled(BharosaSession bharosaSession) {

        VCryptAuthUser authUser = getUser(bharosaSession);
        if (authUser != null) {
            String isPinEnabled =
                (String)authUser.getSecurityPreferences().get("isPinEnabled");
            return (new Boolean(isPinEnabled)).booleanValue();
        }
        return false;
    }

    /**
     * Return pin status value for this session.
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @return a <code>String</code> value
     */
    public String getUserPinStatus(BharosaSession bharosaSession) {

        VCryptAuthUser authUser = getUser(bharosaSession);
        if (authUser != null) {
            return (String)authUser.getSecurityPreferences().get("pinStatus");
        }
        return "";
    }


    /**
     * This decodes the data inputted by the user using the
     * Bharosa Slider.
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @param request a <code>HttpServletRequest</code> value
     * @return a <code>int</code> value
     */
    public int validateSlider(BharosaSession bharosaSession,
                              HttpServletRequest request) {

        VCryptWheel slider = bharosaSession.getSlider();
        Long sliderSessionId = slider.getAuthSessionId();

        return SliderUtil.authenticateSlider(request, sliderSessionId,
                                             bharosaSession.getExternalUserId());

    }


    /**
     * This is to notify the Bharosa Server that the user had opted
     * to use Slider has additional security mechanism.
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @param newPin a <code>String</code> value
     */
    public void sliderOptIn(BharosaSession bharosaSession, String newPin) {
        SliderUtil.optIn(bharosaSession.getExternalUserId(), newPin);
    }

    /**
     * This is to notify the Bharosa Server that the user had opted
     * not to use Slider has additional security mechanism.
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     */
    public void sliderOptOut(BharosaSession bharosaSession) {
        SliderUtil.optOut(bharosaSession.getExternalUserId());
    }


    /**
     * This get the HTML to be insert for the Slider
     *
     * @param bharosaSession BharosaSession object with user and session credentials
     * @return a <code>String</code> value
     */
    public String getSliderHTML(BharosaSession bharosaSession) {

        //create unique slider.
        VCryptWheel slider = SliderUtil.createSlider();
        bharosaSession.setSlider(slider);

        return SliderUtil.getSliderHTML(slider);

    }

    /**
     * This get the HTML to be insert for the Slider Tutorial
     *
     * @return a <code>String</code> value
     */
    public static String getSliderTutorialHTML() {
        return SliderUtil.getSliderTutorialHTML();
    }

    /**
     * Generate OTP code and store in bharosaSession
     *
     * @param bharosaSession
     * @return
     */
    public static String generateOTP(BharosaSession bharosaSession) {
        
        String otpCode = bharosaSession.getOtpCode();
        
        if (StringUtil.isEmpty(otpCode)){
            // No current OTP Code in session, generate new code and store in session.
            otpCode = VCryptTrackerUtil.getVCryptTrackerInstance().generateOTP(bharosaSession.getBharosaSessionId(),
                                                                     bharosaSession.getChallengeType().toString(),
                                                                     bharosaSession.getAppId());
            bharosaSession.setOtpCode(otpCode);
        }

        return otpCode;
    }

    /**
     * Increment the challenge failure counter for the current challenge type
     *
     * @param bharosaSession
     * @return
     */
    public static boolean incrementOTPCounter(BharosaSession bharosaSession) {
        VCryptResponse response =
            VCryptTrackerUtil.getVCryptTrackerInstance().incrementChallengeCounter(bharosaSession.getBharosaSessionId(),
                                                                                   bharosaSession.getChallengeType().toString());
        return response.isSuccess();
    }

    /**
     * Reset the challenge failure counter for the current challenge type
     *
     * @param bharosaSession
     * @return
     */
    public static boolean resetOTPCounter(BharosaSession bharosaSession) {
        VCryptResponse response =
            VCryptTrackerUtil.getVCryptTrackerInstance().resetChallengeCounter(bharosaSession.getBharosaSessionId(),
                                                                               bharosaSession.getChallengeType().toString());
        return response.isSuccess();
    }

    /**
     * Send OTP code to user via email
     *
     * @param bharosaSession
     * @return
     */
    public boolean sendCode(BharosaSession bharosaSession) {
        String otpCode = bharosaSession.getOtpCode();
        try {
            if (BharosaConfig.getBoolean("oaam.sample.ChallengeEmail.message.enabled",
                                         false)) {
                BharosaMail mail = new BharosaMail();
                String toAddr = this.getContactInfo(bharosaSession, "email");
                if (StringUtil.isEmpty(toAddr)) {
                    logger.error("No user email in profile.");
                    // TODO: Add specific error message for UI
                    return false;
                }
                String subject =
                    BharosaConfig.get("oaam.sample.ChallengeEmail.message.subject",
                                      "Oracle Sample OTP Code");
                String message =
                    BharosaConfig.insertValue(BharosaConfig.get("oaam.sampleChallengeEmail.message.body",
                                                                "Your ASA OTP Code: {0}"),
                                              otpCode);
                if (StringUtil.isEmpty(message))
                    message = otpCode;

                String fromAddr =
                    BharosaConfig.get("oaam.sample.ChallengeEmail.message.from.address",
                                      toAddr);
                String fromName =
                    BharosaConfig.get("oaam.sample.ChallengeEmail.message.from.name",
                                      "OAAM Sample Test");
                mail.sendMail(toAddr, fromName, fromAddr, fromAddr, subject,
                              message);
            } else {
                return false;
            }
        } catch (Exception ex) {
            logger.error("ChallengeEmail Error sending code.", ex);
            return false;
        }

        return true;
    }

    /**
     * Gets a comma seperated list of currently available challenge types based
     * on challenge type available flag and users registered data.
     *
     * @param bharosaSession
     * @return
     */
    public String getAvailableChallengeTypes(BharosaSession bharosaSession) {
        UserDefEnum challengeTypeEnum =
            UserDefEnum.getEnum(BharosaConfig.getAppPropName(bharosaSession.getAppId(),
                                                             "challenge.type.enum"));
        Enumeration enumElems = challengeTypeEnum.getEnumElements();

        String availableChallengeTypes = "";
        int i = 0;

        while (enumElems.hasMoreElements()) {
            UserDefEnumElement challengeTypeElem =
                (UserDefEnumElement)enumElems.nextElement();
            if (isChallengeTypeAvailable(bharosaSession,
                                         challengeTypeElem.getStrValue(),
                                         true)) {
                availableChallengeTypes +=
                        (i > 0 ? "," : "") + challengeTypeElem.getStrValue();
                i++;
            }
        }

        return availableChallengeTypes;
    }

    /**
     * Determine if a given challenge type is "available" based on property configuration
     * and registered user contact information
     *
     * @param bharosaSession
     * @param challengeType
     * @param checkData
     * @return
     */
    public boolean isChallengeTypeAvailable(BharosaSession bharosaSession,
                                            String challengeType,
                                            boolean checkData) {
        UserDefEnumElement challengeTypeElem =
            UserDefEnum.getElement(BharosaConfig.getAppPropName(bharosaSession.getAppId(),
                                                                "challenge.type.enum"),
                                   challengeType);
        boolean challengeTypeAvailable = false;

        if ("true".equalsIgnoreCase(challengeTypeElem.getProperty("available"))) {
            challengeTypeAvailable = true;
            String reqInfoStr = challengeTypeElem.getProperty("requiredInfo");
            if (!StringUtil.isEmpty(reqInfoStr)) {
                String[] reqInfo = reqInfoStr.split(",");

                if (checkData && reqInfo != null && reqInfo.length > 0) {
                    for (int i = 0;
                         i < reqInfo.length && challengeTypeAvailable; i++) {
                        if (StringUtil.isEmpty(getContactInfo(bharosaSession,
                                                              reqInfo[i]))) {
                            challengeTypeAvailable = false;
                        }
                    }
                }
            }
        }

        return challengeTypeAvailable;

    }

    /**
     * Get a comma seperated list of required contact information fields for all
     * challenge types that are "available" according to properties configuration
     *
     * @param bharosaSession
     * @return
     */
    public String getRequiredChallengeFields(BharosaSession bharosaSession) {
      String requiredChallengeFields = "";

      UserDefEnum userInfoEnum = UserDefEnum.getEnum(BharosaConfig.getAppPropName(bharosaSession.getAppId(), "userinfo.inputs.enum"));
      Enumeration userInfoElems = userInfoEnum.getEnumElements();
      UserDefEnum challengeTypeEnum = UserDefEnum.getEnum(BharosaConfig.getAppPropName(bharosaSession.getAppId(), "challenge.type.enum"));
      List challengeTypeElems = challengeTypeEnum.getEnumElementsAsList();

      String contactPrefix = BharosaConfig.get("oaam.otp.contact.info.flag.prefix", "otpContactInfoFlag_");
      
      while (userInfoElems.hasMoreElements()) {
        UserDefEnumElement userInfoElem = (UserDefEnumElement) userInfoElems.nextElement();
        String userInfoName = userInfoElem.getStrValue();
        
        boolean itemFound = false;
      
        for (int i=0;!itemFound && i<challengeTypeElems.size();i++) {
          UserDefEnumElement challengeTypeElem = (UserDefEnumElement)challengeTypeElems.get(i);
          String requiredInfo = challengeTypeElem.getProperty("requiredInfo");
          if (!StringUtil.isEmpty(requiredInfo) && requiredInfo.contains(userInfoName) &&  !requiredChallengeFields.contains(userInfoName)){
              requiredChallengeFields += (StringUtil.isEmpty(requiredChallengeFields) ? "" : ",") + contactPrefix + userInfoName;
              itemFound=true;
          }
        }
      }

        
        return requiredChallengeFields;
    }
}
