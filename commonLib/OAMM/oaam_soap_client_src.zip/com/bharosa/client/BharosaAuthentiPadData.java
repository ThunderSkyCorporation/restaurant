package com.bharosa.client;

import com.bharosa.client.enums.BharosaEnumAuthentiPad;
import com.bharosa.client.enums.BharosaEnumClientType;
import com.bharosa.vcrypt.auth.intf.VCryptLocalizedString;
import com.bharosa.vcrypt.auth.keypad.AuthentiPad;

import java.io.Serializable;

 /**
  * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
  * Oracle disclaims all express and implied warranties, including, the implied warranties of 
  * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
  * including, direct, indirect, incidental, special or consequential damages for loss of 
  * profits, revenue, data or data use, incurred by you or any third party 
  * in connection with the use of these materials.
  */
public class BharosaAuthentiPadData implements Serializable {

    private String name;
    private AuthentiPad authentiPad;
    private BharosaEnumAuthentiPad authentiPadEnum;
    private String decodedInput;
    private String frameFile;
    private String oldBgFile;
    private VCryptLocalizedString oldCaption;
    private String newBgFile;
    private VCryptLocalizedString newCaption;
    private boolean isAdaCompliant;
    private boolean displayOnly = false;

    public BharosaAuthentiPadData(String name, BharosaEnumAuthentiPad authentiPadEnum, String bgFile, String frameFile, VCryptLocalizedString caption, boolean adaCompliant, boolean isDisplayOnly) {
        this.name = name;
        this.authentiPadEnum = authentiPadEnum;
        oldBgFile = bgFile;
        oldCaption = caption;
        this.frameFile = frameFile;
        isAdaCompliant = adaCompliant;
        displayOnly = isDisplayOnly;
    }

    public void setAuthentiPad(AuthentiPad authentiPad) {
        this.authentiPad = authentiPad;
    }

    public AuthentiPad getAuthentiPad() {
        return authentiPad;
    }

    public String getName() {
        return name;
    }

    public BharosaEnumAuthentiPad getAuthentiPadAction() {
        return authentiPadEnum;
    }

    public String getDecodedInput() {
        return decodedInput;
    }

    public void setDecodedInput(String decodedInput) {
        this.decodedInput = decodedInput;
    }

    public BharosaEnumClientType getClientType() {
        return authentiPadEnum.getClientType();
    }

    public String getFrameFile() {
        return frameFile;
    }

    public void setFrameFile(String frameFile) {
        this.frameFile = frameFile;
    }

    public String getNewBgFile() {
        return newBgFile;
    }

    public void setNewBgFile(String newBgFile) {
        this.newBgFile = newBgFile;
    }

    public String getBgFile() {
        return newBgFile != null ? newBgFile : oldBgFile;
    }

    public void setNewCaption(VCryptLocalizedString newCaption) {
        this.newCaption = newCaption;
    }

    public VCryptLocalizedString getNewCaption() {
        return newCaption;
    }

    public VCryptLocalizedString getCaption() {
        return newCaption != null ? newCaption : oldCaption;
    }

    public boolean isAdaCompliant() {
        return isAdaCompliant;
    }

    public void setAdaCompliant(boolean adaCompliant) {
        isAdaCompliant = adaCompliant;
    }

    public boolean isDisplayOnly() {
        return displayOnly;
    }

    public void setDisplayOnly() {
        this.displayOnly = true;
    }


    public String toString() {
        return "BharosaAuthentiPadData{" +
                "name='" + name + '\'' +
                ", authentiPad=" + authentiPad +
                ", authentiPadEnum=" + authentiPadEnum +
                ", decodedInput='" + decodedInput + '\'' +
                ", frameFile='" + frameFile + '\'' +
                ", oldBgFile='" + oldBgFile + '\'' +
                ", oldCaption='" + oldCaption + '\'' +
                ", newBgFile='" + newBgFile + '\'' +
                ", newCaption='" + newCaption + '\'' +
                ", isAdaCompliant=" + isAdaCompliant +
                ", displayOnly=" + displayOnly +
                '}';
    }
}

