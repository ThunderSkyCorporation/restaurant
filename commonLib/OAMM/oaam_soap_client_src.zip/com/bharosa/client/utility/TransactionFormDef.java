package com.bharosa.client.utility;

import java.util.Set;

import com.bharosa.common.util.StringUtil;
import com.bharosa.common.util.UserDefEnum;
import com.bharosa.common.util.UserDefEnumElement;

 /**
  * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
  * Oracle disclaims all express and implied warranties, including, the implied warranties of 
  * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
  * including, direct, indirect, incidental, special or consequential damages for loss of 
  * profits, revenue, data or data use, incurred by you or any third party 
  * in connection with the use of these materials.
  */
public class TransactionFormDef {
	private UserDefEnumElement formDef;
	private  Set formFields;
	private int formNo;
	private String nextFormName;
	
	public UserDefEnumElement getFormDef(){
		return formDef;
	}
	
	public void setFormDef(UserDefEnumElement formDef){
		this.formDef = formDef;
	}
	
	public Set getFormFields(){
		return formFields;
	}
	
	public void setFormFields(Set formFields){
		this.formFields = formFields;
	}
	
	public void setFormNo(int formNo){
		this.formNo = formNo;
	}
	
	public int getFormNo(){
		return formNo;
	}
	
	public boolean hasNext(){
		return !StringUtil.isEmpty(nextFormName);
	}
	 
	public String getNextFromName(){
		return nextFormName;
	}
	
	public void setNextFormName(String nextFormName){
		this.nextFormName = nextFormName;
	}
}
