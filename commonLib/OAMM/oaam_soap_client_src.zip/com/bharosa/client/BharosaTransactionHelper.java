package com.bharosa.client;

import com.bharosa.client.enums.BharosaEnumAction;
import com.bharosa.client.utility.TransactionFormDef;
import com.bharosa.common.logger.Logger;
import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.HttpUtil;
import com.bharosa.common.util.StringUtil;
import com.bharosa.common.util.UserDefEnum;
import com.bharosa.common.util.UserDefEnumElement;
import com.bharosa.vcrypt.common.util.VCryptResponse;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import java.util.*;

/**
 * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
 * Oracle disclaims all express and implied warranties, including, the implied warranties of 
 * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
 * including, direct, indirect, incidental, special or consequential damages for loss of 
 * profits, revenue, data or data use, incurred by you or any third party 
 * in connection with the use of these materials.
 */
public class BharosaTransactionHelper {

    public static final Integer STATUS_SUCCESS = new Integer(1);
    public static final Integer STATUS_PENDING = new Integer(99);
    public static final String TRANSACTION_TYPE_KEY = "transactionType";
    public static final String TRANSACTION_FORM_NO = "formNo";
    public static final String TRACKER_TRANSACTION_API_NAME = "trackerAPIName";
    public static final String TRANSACTION_NEXT_PAGE = "nextPage";
    public static final String TRANSACTION_PARAM_TRANSACTION_ID = "Transaction.transactionId";
    public static final String TRANSACTION_FORM_PROPERTY_NAME = "form";
    public static final String TRANSACTION_NEXT_FORM_PROPERTY_NAME = "next";
    public static final String TRANSACTION_FORM_DATA_FIELD_PROPERTY_NAME = "form_fields";
    public static final String ENUM_TRACKER_TRANSACTION_TYPE = "tracker.transaction.type.enum";
    public static final String ENUM_TRACKER_TRANSACTION_FORM = "tracker.transaction.form.enum";
    public static final String ENUM_TRACKER_ENTITY_TYPE= "tracker.entity.type.enum";
    public static final String ENUM_TRACKER_ENTITY_FORM = "tracker.entity.form.enum";
    public static final String ENTITY_TYPE_KEY = "entityType";
    public static final String ENTITY_FORM_NO = "formNo";
    public static final String ENTITY_FORM_PROPERTY_NAME = "form";
    public static final String ENTITY_NEXT_FORM_PROPERTY_NAME = "next";
    public static final String ENTITY_FORM_DATA_FIELD_PROPERTY_NAME = "form_fields";
    public static final String TRACKER_ENTITY_API_NAME = "trackerAPIName";
    public static final String ENTITY_NEXT_PAGE = "nextPage";

    public static Logger logger = Logger.getLogger(BharosaTransactionHelper.class);
    private static BharosaTransactionHelper instance;
    private final static Object lock = new Object();
    private BharosaHelper bharosaHelper = BharosaHelper.getInstance();

    static public BharosaTransactionHelper getInstance() {
        if (instance == null) {
            synchronized (lock) {
                if (instance == null) {
                    instance = new BharosaTransactionHelper();
                }
            }
        }
        return instance;
    }
     
  public Object[] createOrUpdateEntity(HttpServletRequest request) {
      if (logger.isInfoEnabled()) {
          logger.info("createOrUpdateEntity: ");
      }
      BharosaSession session =
          (BharosaSession)request.getSession().getAttribute("bharosa_session");
      String requestId = session.getBharosaSessionId();
      String entityType =
              request.getParameter(ENTITY_TYPE_KEY);
      Map entityParameterMap =
          getEntityParameterMap(request);
      Object[] result =
          bharosaHelper.createOrUpdateEntity(requestId,
                                             entityType,
                                             entityParameterMap);
      return result;
     
  } 
  
  public Object[] searchEntity(HttpServletRequest request) {
      if (logger.isInfoEnabled()) {
          logger.info("searchEntity : ");
      }
      BharosaSession session =
          (BharosaSession)request.getSession().getAttribute("bharosa_session");
      String entityType =
              request.getParameter(ENTITY_TYPE_KEY);
      Map entityParameterMap =
          getEntityParameterMap(request);
      Object[] result =
          bharosaHelper.searchEntity(entityType,
                                             entityParameterMap);
      return result;
     
  } 
    public BharosaEnumAction handleTransactionAndRunRules(HttpServletRequest request) {
        if (logger.isInfoEnabled()) {
            logger.info("handleTransactionAndRunRules : ");
        }
        BharosaSession session =
            (BharosaSession)request.getSession().getAttribute("bharosa_session");
        String transactionType =
            TransactionFormUtil.getTransactionType(request);
        Map transactionParameterMap =
            getTransactionParameterMap(session.getBharosaSessionId(), request);
        VCryptResponse response =
            bharosaHelper.handleTransactionLog(session, null, STATUS_PENDING,
                                               transactionType,
                                               transactionParameterMap);
        if (logger.isInfoEnabled()) {
            logger.info("handleTransactionLog completed.response=" +
                         response);
        }
        BharosaEnumAction action = bharosaHelper.runPreTransactionRules(session,
                                                    transactionParameterMap);
        if (action != BharosaEnumAction.ALLOW) return action;
        
   	  VCryptResponse postResponse = bharosaHelper.updateTransactionStatus(session, response.getTimeStamp(), 
   			  response.getTransactionResponse().getTransactionId(), STATUS_SUCCESS, transactionParameterMap);
        if (logger.isInfoEnabled()) {
           logger.info("updataTransactionStatus completed.response=" +
                        response);
        }
        return bharosaHelper.runPostTransactionRules(session,
                                                    transactionParameterMap);
    }

    public BharosaEnumAction updateTransactionStatusAndRunRules(HttpServletRequest request) {
        if (logger.isInfoEnabled()) {
            logger.info("updateTransactionStatus : ");
        }
        BharosaSession session =
            (BharosaSession)request.getSession().getAttribute("bharosa_session");
        Map transactionParameterMap =
            getTransactionParameterMap(session.getBharosaSessionId(), request);
        Date requestTime = null;
        Long transactionId = null;
        VCryptResponse response =
            bharosaHelper.updateTransactionStatus(session, requestTime,
                                                  transactionId,
                                                  STATUS_SUCCESS,
                                                  transactionParameterMap);
        if (logger.isInfoEnabled()) {
            logger.info("updataTransactionStatus completed.response=" +
                         response);
        }
        return bharosaHelper.runPostTransactionRules(session,
                                                     transactionParameterMap);
    }
    // Retrieves the entity attribute parameter values from request
    private Map getEntityParameterMap(HttpServletRequest request) {
      Map entityParameterMap = new HashMap();
      TransactionFormDef formDef =
          EntityFormUtil.getEntityFormDef(request);

      if (formDef != null) {
          Set formFields = formDef.getFormFields();
          if (formFields != null && !formFields.isEmpty()) {
              Iterator formFieldsIterator = formFields.iterator();
              while (formFieldsIterator.hasNext()) {
                  UserDefEnumElement field =
                      (UserDefEnumElement)formFieldsIterator.next();
                  String fieldName = field.getProperty("name");
                  String fieldMapName = field.getProperty("map_name");
                  String elementType = field.getProperty("element_type");
                  if (StringUtil.isEmpty(elementType)) {
                      elementType = "text";
                  }

                  if (elementType.equalsIgnoreCase("button")) {
                      continue;
                  }

                  if (elementType.equalsIgnoreCase("template")) {
                      entityParameterMap.putAll(getTemplateParamMap(fieldName,
                                                                         fieldMapName,
                                                                         field.getProperty("template_name"),
                                                                         request));
                  } else {
                      if (StringUtil.isEmpty(fieldMapName)) {
                          logger.warn("map name could not be found for parameter=" +
                                      fieldName);
                          fieldMapName = fieldName;
                      }
                      entityParameterMap.put(fieldMapName,
                                                  request.getParameter(fieldName));
                  }
              }
          } //if
      } else {
          logger.error("Transaction form definition could not be found.");
      }

      return entityParameterMap;
    }



    //Retrieves the transaction form parameters values from request

    private Map getTransactionParameterMap(String requestId, HttpServletRequest request) {

        Map transactionParameterMap = new HashMap();
        transactionParameterMap.put(TRANSACTION_PARAM_TRANSACTION_ID,
                                    requestId);

        // Send context details
        Locale locale = request.getLocale();
        transactionParameterMap.put("browser_ip", request.getRemoteAddr());
        transactionParameterMap.put("browser_uas",
                                    request.getHeader("user-agent"));
        transactionParameterMap.put("browser_localLang", locale.getLanguage());
        transactionParameterMap.put("browser_localCountry",
                                    locale.getCountry());
        transactionParameterMap.put("browser_localVariant",
                                    locale.getVariant());
        final Cookie cookie = HttpUtil.getCookie(request, BharosaConfig.get("sample.securecookie.name", "bharosa"));
        if (cookie != null)
            transactionParameterMap.put("browser_securecookie",
                                        cookie.getValue());


        //get transaction from definition
        TransactionFormDef formDef =
            TransactionFormUtil.getTransactionFormDef(request);

        if (formDef != null) {
            Set formFields = formDef.getFormFields();
            if (formFields != null && !formFields.isEmpty()) {
                Iterator formFieldsIterator = formFields.iterator();
                while (formFieldsIterator.hasNext()) {
                    UserDefEnumElement field =
                        (UserDefEnumElement)formFieldsIterator.next();
                    String fieldName = field.getProperty("name");
                    String fieldMapName = field.getProperty("map_name");
                    String elementType = field.getProperty("element_type");
                    if (StringUtil.isEmpty(elementType)) {
                        elementType = "text";
                    }

                    if (elementType.equalsIgnoreCase("button")) {
                        continue;
                    }

                    if (elementType.equalsIgnoreCase("template")) {
                        transactionParameterMap.putAll(getTemplateParamMap(fieldName,
                                                                           fieldMapName,
                                                                           field.getProperty("template_name"),
                                                                           request));
                    } else {
                        if (StringUtil.isEmpty(fieldMapName)) {
                            logger.warn("map name could not be found for parameter=" +
                                        fieldName);
                            fieldMapName = fieldName;
                        }
                        transactionParameterMap.put(fieldMapName,
                                                    request.getParameter(fieldName));
                    }
                }
            } //if
        } else {
            logger.error("Transaction form definition could not be found.");
        }

        return transactionParameterMap;
    } //getTransactionParameterMap

    /*get the map containing the parameter map_name and their corresponding values
	   for a form template	
	 */

    private Map getTemplateParamMap(String fieldName, String fieldMapName,
                                    String templateName,
                                    HttpServletRequest request) {
        if (logger.isInfoEnabled()) {
            logger.info("getTemplateParamMap fieldName=" + fieldName +
                         ", fieldMapName=" + fieldMapName +
                         " , templateName=" + templateName);
        }

        Map templateParamMap = new HashMap();

        Set templateFields =
            TransactionFormUtil.getTemplateFields(templateName);

        if (templateFields != null) {
            if (logger.isInfoEnabled()) {
                logger.info("Retreiving field values of form template=" +
                             templateName + " fields=" + templateFields);
            }
            Iterator templateFieldIterator = templateFields.iterator();
            while (templateFieldIterator.hasNext()) {
                UserDefEnumElement templateField =
                    (UserDefEnumElement)templateFieldIterator.next();
                //String templateElementType = templateDataField.getProperty("element_type");
                String templateFieldName = templateField.getProperty("name");

                String paramName = fieldName + "_" + templateFieldName;
                String mapName;
                Object paramValue = request.getParameter(paramName);
                if (paramValue != null) {
                    String templateMapName =
                        templateField.getProperty("map_name");
                    if (!StringUtil.isEmpty(templateMapName)) {
                        mapName =
                                fieldMapName != null ? fieldMapName + "." + templateMapName :
                                templateMapName;
                    } else {
                        logger.warn("Template map name not found for template parameter " +
                                    paramName);
                        mapName =
                                fieldMapName != null ? fieldMapName + "." + templateFieldName :
                                templateFieldName;
                    }
                    templateParamMap.put(mapName, paramValue);
                } //if

            } //while
        } else {
            logger.error("Form Template definition for template=" +
                         templateName + " could not be found.");
        }

        return templateParamMap;
    }

    public static class TransactionFormUtil {
        static Logger logger = Logger.getLogger(TransactionFormUtil.class);
        public static UserDefEnum TRACKER_TRANSACTION_TYPE = UserDefEnum.getEnum(ENUM_TRACKER_TRANSACTION_TYPE);
      public static UserDefEnum TRACKER_ENTITY_TYPE = UserDefEnum.getEnum(ENUM_TRACKER_ENTITY_TYPE);
        public static UserDefEnum TRANSACTION_FORM = UserDefEnum.getEnum(ENUM_TRACKER_TRANSACTION_FORM);
        private static Map transactionFormMap = new HashMap();
        static {
            loadForms();
        }

        //gets the transaction form for a transaction type

        public static TransactionFormDef getTransactionFormDef(HttpServletRequest request) {
            TransactionFormDef transactionFormDef = null;
            String transactionType = getTransactionType(request);

            if (logger.isInfoEnabled()) {
                logger.info("Retreiving form for transaction type=" +
                             transactionType);
            }

            List formList = (List)transactionFormMap.get(transactionType);

            if (formList != null) {
                String formNoString =
                    request.getParameter(TRANSACTION_FORM_NO);
                if (!StringUtil.isEmpty(formNoString)) {
                    int formNo = Integer.parseInt(formNoString);
                    try {
                        transactionFormDef =
                                (TransactionFormDef)formList.get(formNo);
                    } catch (IndexOutOfBoundsException ie) {
                        logger.error("Error while retreiving transaction form.transactionType=" +
                                     transactionType, ie);
                    }
                } //if
            } //if

            return transactionFormDef;
        }

        public static String getTransactionType(HttpServletRequest request) {
            return request.getParameter(TRANSACTION_TYPE_KEY);
        }
        

        public static Set getTemplateFields(String templateName) {
            if (StringUtil.isEmpty(templateName)) {
                return Collections.EMPTY_SET;
            }
            Set templateFields = null;
            UserDefEnum templateFieldEnum = UserDefEnum.getEnum(templateName);
            if (templateFieldEnum != null) {
                templateFields = orderFields(templateFieldEnum);
            }
            return templateFields;
        }

        public static List getOptionList(String optionsListName) {
            if (StringUtil.isEmpty(optionsListName)) {
                return Collections.EMPTY_LIST;
            }
            List optionList = new ArrayList();
            UserDefEnum optionEnum = UserDefEnum.getEnum(optionsListName);
            if (optionEnum != null) {
                Enumeration options = optionEnum.getEnumElements();
                while (options.hasMoreElements()) {
                    optionList.add(options.nextElement());
                }
            }
            return optionList;
        }

        /*loads all the transaction forms */

        private static void loadForms() {
            Enumeration tranTypeEnum =
                TRACKER_TRANSACTION_TYPE.getEnumElements();

            while (tranTypeEnum.hasMoreElements()) {
                UserDefEnumElement transactionTypeEnumEle =
                    (UserDefEnumElement)tranTypeEnum.nextElement();
                String transactionId = transactionTypeEnumEle.getStrValue();
                String transactionFormName =
                    transactionTypeEnumEle.getProperty(TRANSACTION_FORM_PROPERTY_NAME);

                int formNo = 0;
                while (transactionFormName != null) {
                    TransactionFormDef formDef = getForm(transactionFormName);
                    transactionFormName = null;
                    if (formDef != null) {
                        formDef.setFormNo(formNo);
                        List formList =
                            (List)transactionFormMap.get(transactionId);

                        if (formList == null) {
                            formList = new ArrayList();
                            formList.add(formDef);
                            transactionFormMap.put(transactionId, formList);
                        } else {
                            formList.add(formDef);
                        }

                        formNo++;

                        transactionFormName = formDef.getNextFromName();
                    } //if
                } //while
            } //while
        }

        private static TransactionFormDef getForm(String formName) {
            TransactionFormDef formDef = null;
            UserDefEnumElement transactionForm =
                TRANSACTION_FORM.getElementById(formName);
            if (transactionForm != null) {
                formDef = new TransactionFormDef();
                formDef.setFormDef(transactionForm);
                formDef.setNextFormName(transactionForm.getProperty(TRANSACTION_NEXT_FORM_PROPERTY_NAME));
                String dataFieldEnumName =
                    transactionForm.getProperty(TRANSACTION_FORM_DATA_FIELD_PROPERTY_NAME);

                if (!StringUtil.isEmpty(dataFieldEnumName)) {
                    UserDefEnum formFields =
                        UserDefEnum.getEnum(dataFieldEnumName);

                    if (formFields != null) {
                        formDef.setFormFields(orderFields(formFields));
                    } else {
                        if (logger.isInfoEnabled()) {
                            logger.info("Data field enum is not defined for form " +
                                         formName);
                        }
                    }

                } else {
                    if (logger.isInfoEnabled()) {
                        logger.info("Data field enum name is not defined for form " +
                                     formName);
                    }
                }
            } //if

            return formDef;
        } //getForm


        private static Set orderFields(UserDefEnum formFields) {
            Set formFieldSet = new TreeSet(new FormFieldOrderComparator());
            Enumeration formFieldEnumeration = formFields.getEnumElements();
            while (formFieldEnumeration.hasMoreElements()) {
                Object ele = formFieldEnumeration.nextElement();
                formFieldSet.add(ele);
            }
            return formFieldSet;
        }

        //compares two form fields based on the order property

        private static class FormFieldOrderComparator implements Comparator {
            public int compare(Object obj1, Object obj2) {
                String obj1OrderStr =
                    ((UserDefEnumElement)obj1).getProperty("order");
                String obj2OrderStr =
                    ((UserDefEnumElement)obj2).getProperty("order");
                Double obj1Order =
                    (!StringUtil.isEmpty(obj1OrderStr)) ? new Double(obj1OrderStr) :
                    new Double(Double.MAX_VALUE);
                Double obj2Order =
                    (!StringUtil.isEmpty(obj2OrderStr)) ? new Double(obj2OrderStr) :
                    new Double(Double.MAX_VALUE);
                return obj1Order.compareTo(obj2Order);
            }
        }

    }
  public static class EntityFormUtil {
      static Logger logger = Logger.getLogger(EntityFormUtil.class);
      public static UserDefEnum TRACKER_ENTITY_TYPE = UserDefEnum.getEnum(ENUM_TRACKER_ENTITY_TYPE);
      public static UserDefEnum ENTITY_FORM = UserDefEnum.getEnum(ENUM_TRACKER_ENTITY_FORM);
      private static Map entityFormMap = new HashMap();

      static {
          loadForms();
      }
      //gets the entity form for a entity type

      public static TransactionFormDef getEntityFormDef(HttpServletRequest request) {
          TransactionFormDef entityFormDef = null;
          String entityType = getEntityType(request);

          if (logger.isInfoEnabled()) {
              logger.info("Retreiving form for entity type=" +
                           entityType);
          }

          List formList = (List)entityFormMap.get(entityType);

          if (formList != null) {
              String formNoString =
                  request.getParameter(ENTITY_FORM_NO);
              if (!StringUtil.isEmpty(formNoString)) {
                  int formNo = Integer.parseInt(formNoString);
                  try {
                      entityFormDef =
                              (TransactionFormDef)formList.get(formNo);
                  } catch (IndexOutOfBoundsException ie) {
                      logger.error("Error while retreiving entity form.entityType=" +
                                   entityType, ie);
                  }
              } //if
          } //if

          return entityFormDef;
      }

      public static String getEntityType(HttpServletRequest request) {
          return request.getParameter(ENTITY_TYPE_KEY);
      }

      public static Set getTemplateFields(String templateName) {
          if (StringUtil.isEmpty(templateName)) {
              return Collections.EMPTY_SET;
          }
          Set templateFields = null;
          UserDefEnum templateFieldEnum = UserDefEnum.getEnum(templateName);
          if (templateFieldEnum != null) {
              templateFields = orderFields(templateFieldEnum);
          }
          return templateFields;
      }

      public static List getOptionList(String optionsListName) {
          if (StringUtil.isEmpty(optionsListName)) {
              return Collections.EMPTY_LIST;
          }
          List optionList = new ArrayList();
          UserDefEnum optionEnum = UserDefEnum.getEnum(optionsListName);
          if (optionEnum != null) {
              Enumeration options = optionEnum.getEnumElements();
              while (options.hasMoreElements()) {
                  optionList.add(options.nextElement());
              }
          }
          return optionList;
      }

      /*loads all the transaction forms */

      private static void loadForms() {
          Enumeration entTypeEnum =
              TRACKER_ENTITY_TYPE.getEnumElements();

          while (entTypeEnum.hasMoreElements()) {
              UserDefEnumElement entityTypeEnumEle =
                  (UserDefEnumElement)entTypeEnum.nextElement();
              String entityId = entityTypeEnumEle.getStrValue();
              String entityFormName =
                  entityTypeEnumEle.getProperty(ENTITY_FORM_PROPERTY_NAME);

              int formNo = 0;
              while (entityFormName != null) {
                  TransactionFormDef formDef = getForm(entityFormName);
                  entityFormName = null;
                  if (formDef != null) {
                      formDef.setFormNo(formNo);
                      List formList =
                          (List)entityFormMap.get(entityId);

                      if (formList == null) {
                          formList = new ArrayList();
                          formList.add(formDef);
                          entityFormMap.put(entityId, formList);
                      } else {
                          formList.add(formDef);
                      }

                      formNo++;

                      entityFormName = formDef.getNextFromName();
                  } //if
              } //while
          } //while
      }

      private static TransactionFormDef getForm(String formName) {
          TransactionFormDef formDef = null;
          UserDefEnumElement entityForm =
              ENTITY_FORM.getElementById(formName);
          if (entityForm != null) {
              formDef = new TransactionFormDef();
              formDef.setFormDef(entityForm);
              formDef.setNextFormName(entityForm.getProperty(ENTITY_NEXT_FORM_PROPERTY_NAME));
              String dataFieldEnumName =
                  entityForm.getProperty(ENTITY_FORM_DATA_FIELD_PROPERTY_NAME);

              if (!StringUtil.isEmpty(dataFieldEnumName)) {
                  UserDefEnum formFields =
                      UserDefEnum.getEnum(dataFieldEnumName);

                  if (formFields != null) {
                      formDef.setFormFields(orderFields(formFields));
                  } else {
                      if (logger.isInfoEnabled()) {
                          logger.info("Data field enum is not defined for form " +
                                       formName);
                      }
                  }

              } else {
                  if (logger.isInfoEnabled()) {
                      logger.info("Data field enum name is not defined for form " +
                                   formName);
                  }
              }
          } //if

          return formDef;
      } //getForm


      private static Set orderFields(UserDefEnum formFields) {
          Set formFieldSet = new TreeSet(new FormFieldOrderComparator());
          Enumeration formFieldEnumeration = formFields.getEnumElements();
          while (formFieldEnumeration.hasMoreElements()) {
              Object ele = formFieldEnumeration.nextElement();
              formFieldSet.add(ele);
          }
          return formFieldSet;
      }

      //compares two form fields based on the order property

      private static class FormFieldOrderComparator implements Comparator {
          public int compare(Object obj1, Object obj2) {
              String obj1OrderStr =
                  ((UserDefEnumElement)obj1).getProperty("order");
              String obj2OrderStr =
                  ((UserDefEnumElement)obj2).getProperty("order");
              Double obj1Order =
                  (!StringUtil.isEmpty(obj1OrderStr)) ? new Double(obj1OrderStr) :
                  new Double(Double.MAX_VALUE);
              Double obj2Order =
                  (!StringUtil.isEmpty(obj2OrderStr)) ? new Double(obj2OrderStr) :
                  new Double(Double.MAX_VALUE);
              return obj1Order.compareTo(obj2Order);
          }
      }

  }
}
