package com.bharosa.client;

import com.bharosa.common.logger.Logger;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.OutputStream;

 /**
  * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
  * Oracle disclaims all express and implied warranties, including, the implied warranties of 
  * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
  * including, direct, indirect, incidental, special or consequential damages for loss of 
  * profits, revenue, data or data use, incurred by you or any third party 
  * in connection with the use of these materials.
  */
public class BharosaImageGeneratorServlet extends HttpServlet {
    static Logger logger = Logger.getLogger(BharosaImageGeneratorServlet.class);

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (logger.isDebugEnabled()) {
            logger.debug("doGet() enter");
        }

        try {
            response.setHeader("Cache-Control", "no-cache"); //HTTP 1.1
            response.setHeader("Pragma", "no-cache"); //HTTP 1.0
            response.setDateHeader("Expires", 0); //prevents caching at the proxy server
            response.setDateHeader("Max-Age", 0);

            HttpSession session = request.getSession();
            BharosaSession bharosaSession = (BharosaSession) session.getAttribute("bharosa_session");
            if (bharosaSession == null) {
                if (logger.isDebugEnabled()) logger.debug("Bharosa Session not found. Just returning.");
            } else {
                OutputStream os = response.getOutputStream();
                try {
                    //todo: Call the Image Generator util in BharosaHelper
                    BharosaHelper helper = BharosaHelper.getInstance();
                    //helper 
                } finally {
                    try {
                        os.close();
                    } catch (Throwable t) {
                        //ignore
                    }
                }
            }
        }
        catch (Exception ex) {
            logger.error("Error while generating image", ex);
        }
    }


    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

}
