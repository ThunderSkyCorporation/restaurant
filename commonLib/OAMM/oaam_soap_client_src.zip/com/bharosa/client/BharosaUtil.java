package com.bharosa.client;

import com.bharosa.common.logger.Logger;
import com.bharosa.common.util.BharosaConfig;

import java.io.*;
import javax.servlet.http.HttpSession;

 /**
  * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
  * Oracle disclaims all express and implied warranties, including, the implied warranties of 
  * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
  * including, direct, indirect, incidental, special or consequential damages for loss of 
  * profits, revenue, data or data use, incurred by you or any third party 
  * in connection with the use of these materials.
  */
public class BharosaUtil {

    static Logger logger = Logger.getLogger(BharosaUtil.class);
 
    private BharosaUtil(){}
    
    public static BharosaSession getBharosaSession(HttpSession session){
    	boolean isSerialized = BharosaConfig.getBoolean("vcrypt.sample.serialize.session.enable", false);
    	BharosaSession bharosaSession = null;
    	
    	if (!isSerialized){
    		bharosaSession = (BharosaSession) session.getAttribute("bharosa_session");
    	} else {
    		String sessionId = (String) session.getAttribute("bharosa_session_id");
			String serializePath = BharosaConfig.get("vcrypt.sample.serialize.session.file.location", "c:\\temp\\");
    		
			FileInputStream underlyingStream = null;
			ObjectInputStream serializer = null;
    		try {
       		  	underlyingStream = new FileInputStream(serializePath + sessionId);
     		    serializer = new ObjectInputStream(underlyingStream);

     		    bharosaSession = (BharosaSession) serializer.readObject();

    		} catch (Exception ex){
    			logger.error("Error retreiving serialized BharosaSession object for ", ex);
    		} finally {
    			try{
    				if (serializer != null){
    					serializer.close();
    				}
    				
    				if (underlyingStream != null){
    					underlyingStream.close();
    				}
    			} catch (IOException ioEx){
        			logger.error("Error closing input streams. ", ioEx);
    			}
    		}
    	}
    	
    	return bharosaSession;
    }
    
    public static boolean storeBharosaSession(HttpSession session, BharosaSession bharosaSession){
    	boolean toSerialize = BharosaConfig.getBoolean("vcrypt.sample.serialize.session.enable", false);
    	boolean retVal = false;
    	
    	if (!toSerialize){
    		session.setAttribute("bharosa_session", bharosaSession);
    	} else {
    		String sessionId = bharosaSession.getBharosaSessionId();
    		
    		// Storing session ID in session to be able to demonstrate serialization.
    		session.setAttribute("bharosa_session_id", sessionId); 

			String serializePath = BharosaConfig.get("vcrypt.sample.serialize.session.file.location", "c:\\temp\\");

			FileOutputStream underlyingStream = null;
			ObjectOutputStream serializer = null;
    		try {
    			// For demonstration using session id as the serialized object filename
       		  	underlyingStream = new FileOutputStream(serializePath + sessionId);
     		    serializer = new ObjectOutputStream(underlyingStream);

     		    serializer.writeObject(bharosaSession);

     		    retVal = true;
     		    
    		} catch (IOException ioE){
    			logger.error("Error serializing BharosaSession object for ", ioE);
    		} finally {
    			try {
    				if (underlyingStream != null){
    					underlyingStream.close();
    				}

    				if (serializer != null){
    					serializer.close();
    				}
    			} catch (IOException ioEx){
        			logger.error("Error closing output streams. ", ioEx);
    			}
    			
    		}

    	}
    	
    	return retVal;
    }
}
