package com.bharosa.client.enums;

/**
 * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
 * Oracle disclaims all express and implied warranties, including, the implied warranties of 
 * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
 * including, direct, indirect, incidental, special or consequential damages for loss of 
 * profits, revenue, data or data use, incurred by you or any third party 
 * in connection with the use of these materials.
 */
public class BharosaEnumUserStatus {

    public static final BharosaEnumUserStatus STATUS_PENDING_ACTIVATION = new BharosaEnumUserStatus(1);
    public static final BharosaEnumUserStatus STATUS_ACTIVE = new BharosaEnumUserStatus(2);
    public static final BharosaEnumUserStatus STATUS_DISABLED = new BharosaEnumUserStatus(3);
    public static final BharosaEnumUserStatus STATUS_DELETED = new BharosaEnumUserStatus(4);

    private final int value;

    private BharosaEnumUserStatus(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public String toString() {
        return String.valueOf(value);
    }
}
