package com.bharosa.client.enums;

import java.io.Serializable;
import java.util.HashMap;

/**
 * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
 * Oracle disclaims all express and implied warranties, including, the implied warranties of 
 * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
 * including, direct, indirect, incidental, special or consequential damages for loss of 
 * profits, revenue, data or data use, incurred by you or any third party 
 * in connection with the use of these materials.
 */
public class BharosaEnumAuthentiPad implements Serializable {  // Implement readresolve to maintain singleton status with serialization

    private static HashMap map = new HashMap();

    public static final BharosaEnumAuthentiPad TEXT_PAD = new BharosaEnumAuthentiPad("Textpad", BharosaEnumClientType.TEXT_PAD);
    public static final BharosaEnumAuthentiPad PIN_PAD = new BharosaEnumAuthentiPad("Pinpad", BharosaEnumClientType.PIN_PAD);
    public static final BharosaEnumAuthentiPad PASSWORD_PIN_PAD = new BharosaEnumAuthentiPad("PasswordPinPad", BharosaEnumClientType.PIN_PAD);
    public static final BharosaEnumAuthentiPad QUESTION_PAD = new BharosaEnumAuthentiPad("Questionpad", BharosaEnumClientType.QUESTION_PAD);
    public static final BharosaEnumAuthentiPad KEY_PAD = new BharosaEnumAuthentiPad("Keypad", BharosaEnumClientType.KEY_PAD);
    public static final BharosaEnumAuthentiPad KEY_PAD_FULL = new BharosaEnumAuthentiPad("KeypadFull", BharosaEnumClientType.KEY_PAD);

    private final String myName; // for debug only
    private final BharosaEnumClientType clientType;

    private BharosaEnumAuthentiPad(String name, BharosaEnumClientType clientType) {
        this.clientType = clientType;
        myName = name;
        map.put(name, this);
    }

    public BharosaEnumClientType getClientType() {
        return clientType;
    }

    public String toString() {
        return myName;
    }

    public static BharosaEnumAuthentiPad getEnumAction(String action) {
        BharosaEnumAuthentiPad anEnum = (BharosaEnumAuthentiPad) map.get(action);
        return anEnum == null ? TEXT_PAD : anEnum;
    }
}