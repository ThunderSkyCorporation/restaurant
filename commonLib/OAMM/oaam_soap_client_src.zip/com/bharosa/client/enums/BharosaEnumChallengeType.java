/* $Header: oaam/apps/oaam_sample/native/src/com/bharosa/client/enums/BharosaEnumChallengeType.java /main/3 2010/12/08 12:08:31 srchittu Exp $ */

/* Copyright (c) 2010, 2011, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    Predefined enums for challenge types.

   PRIVATE CLASSES    

   NOTES    

   MODIFIED    (MM/DD/YY)   
    pdorai     10/03/10 - Creation
 */

package com.bharosa.client.enums;

import java.io.Serializable;

import java.util.HashMap;

public class BharosaEnumChallengeType implements Serializable {

    private static HashMap map = new HashMap();

    public static final BharosaEnumChallengeType QUESTION_CHALLENGE = new BharosaEnumChallengeType("ChallengeQuestion");
    public static final BharosaEnumChallengeType EMAIL_CHALLENGE = new BharosaEnumChallengeType("ChallengeEmail");
    public static final BharosaEnumChallengeType SMS_CHALLENGE = new BharosaEnumChallengeType("ChallengeSMS");
    public static final BharosaEnumChallengeType IM_CHALLENGE = new BharosaEnumChallengeType("ChallengeIM");
    public static final BharosaEnumChallengeType VOICE_CHALLENGE = new BharosaEnumChallengeType("ChallengeVoice");

    private final String myName;
    
    private BharosaEnumChallengeType(String name) {
        myName = name;
        map.put(name, this);
    }
  
    public static BharosaEnumChallengeType getBharosaEnumChallengeType(String challengeType) {
      BharosaEnumChallengeType anEnum = (BharosaEnumChallengeType) map.get(challengeType);
      return anEnum == null ? QUESTION_CHALLENGE : anEnum;
    }

    public String toString() {
        return myName;
    }
}
