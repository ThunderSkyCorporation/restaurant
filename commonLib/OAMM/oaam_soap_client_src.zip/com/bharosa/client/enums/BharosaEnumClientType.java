package com.bharosa.client.enums;

import java.io.Serializable;

/**
 * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
 * Oracle disclaims all express and implied warranties, including, the implied warranties of 
 * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
 * including, direct, indirect, incidental, special or consequential damages for loss of 
 * profits, revenue, data or data use, incurred by you or any third party 
 * in connection with the use of these materials.
 */
public class BharosaEnumClientType implements Serializable { // Implement readresolve to maintain singleton status with serialization
    
    public static final BharosaEnumClientType UNKNOWN = new BharosaEnumClientType(1);
    public static final BharosaEnumClientType HTML = new BharosaEnumClientType(2);
    public static final BharosaEnumClientType PIN_PAD = new BharosaEnumClientType(3);
    public static final BharosaEnumClientType KEY_PAD = new BharosaEnumClientType(4);
    public static final BharosaEnumClientType SLIDER = new BharosaEnumClientType(5);
    public static final BharosaEnumClientType QUESTION_PAD = new BharosaEnumClientType(9);
    public static final BharosaEnumClientType TEXT_PAD = new BharosaEnumClientType(10);
    public static final BharosaEnumClientType LOGIN = new BharosaEnumClientType(11);

    private final int value;

    private BharosaEnumClientType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public String toString() {
        return String.valueOf(value);
    }
}
