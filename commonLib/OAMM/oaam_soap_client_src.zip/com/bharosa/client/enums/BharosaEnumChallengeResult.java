package com.bharosa.client.enums;

import java.util.HashMap;

/**
 * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
 * Oracle disclaims all express and implied warranties, including, the implied warranties of 
 * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
 * including, direct, indirect, incidental, special or consequential damages for loss of 
 * profits, revenue, data or data use, incurred by you or any third party 
 * in connection with the use of these materials.
 */
public class BharosaEnumChallengeResult {

    private static HashMap map = new HashMap();

    private final int status;
    private final boolean valid;

    public static final BharosaEnumChallengeResult SUCCESS = new BharosaEnumChallengeResult(0, true);
    public static final BharosaEnumChallengeResult INVALID_USER = new BharosaEnumChallengeResult(1);
    public static final BharosaEnumChallengeResult WRONG_PASSWORD = new BharosaEnumChallengeResult(2);
    public static final BharosaEnumChallengeResult USER_DISABLED = new BharosaEnumChallengeResult(6);
    public static final BharosaEnumChallengeResult PENDING_ACTIVATION = new BharosaEnumChallengeResult(7);
    public static final BharosaEnumChallengeResult WRONG_ANSWER = new BharosaEnumChallengeResult(8);
    public static final BharosaEnumChallengeResult DB_ERROR = new BharosaEnumChallengeResult(9);
    public static final BharosaEnumChallengeResult SYSTEM_ERROR = new BharosaEnumChallengeResult(10);
    public static final BharosaEnumChallengeResult BLOCK = new BharosaEnumChallengeResult(11);
    public static final BharosaEnumChallengeResult LOCKED = new BharosaEnumChallengeResult(12);
    public static final BharosaEnumChallengeResult PENDING = new BharosaEnumChallengeResult(999);

    private BharosaEnumChallengeResult(int status, boolean valid) {
        this.status = status;
        this.valid = valid;
        map.put(new Integer(status), this);
    }

    private BharosaEnumChallengeResult(int status) {
        this(status, false);
    }

    public boolean isValid() {
        return valid;
    }

    public static BharosaEnumChallengeResult getBharosaEnumChallengeResult(int status) {
        Object result =  map.get(new Integer(status));
        return result != null ? (BharosaEnumChallengeResult )result : SYSTEM_ERROR;
    }

    public String toString() {
        return String.valueOf(status);
    }
}
