package com.bharosa.client.enums;

/**
 * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
 * Oracle disclaims all express and implied warranties, including, the implied warranties of 
 * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
 * including, direct, indirect, incidental, special or consequential damages for loss of 
 * profits, revenue, data or data use, incurred by you or any third party 
 * in connection with the use of these materials.
 */
public class BharosaEnumAuthStatus {
    
    public static final BharosaEnumAuthStatus SUCCESS = new BharosaEnumAuthStatus(0);
    public static final BharosaEnumAuthStatus INVALID_USER = new BharosaEnumAuthStatus(1);
    public static final BharosaEnumAuthStatus WRONG_PASSWORD = new BharosaEnumAuthStatus(2);
    public static final BharosaEnumAuthStatus SYSTEM_ERROR = new BharosaEnumAuthStatus(10);
    public static final BharosaEnumAuthStatus BLOCK = new BharosaEnumAuthStatus(11);
    public static final BharosaEnumAuthStatus PENDING = new BharosaEnumAuthStatus(999);
    public static final BharosaEnumAuthStatus WRONG_ANSWER = new BharosaEnumAuthStatus(8);

    private final int value;

    private BharosaEnumAuthStatus(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public String toString() {
        return String.valueOf(value);
    }
}
