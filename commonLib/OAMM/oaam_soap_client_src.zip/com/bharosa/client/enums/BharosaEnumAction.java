package com.bharosa.client.enums;

import java.util.HashMap;

/**
 * Disclaimer: The materials provided here are for sample use and are provided "as-is"; 
 * Oracle disclaims all express and implied warranties, including, the implied warranties of 
 * merchantability or fitness for a particular use. Oracle shall not be liable for any damages, 
 * including, direct, indirect, incidental, special or consequential damages for loss of 
 * profits, revenue, data or data use, incurred by you or any third party 
 * in connection with the use of these materials.
 */
public class BharosaEnumAction {

    private static HashMap map = new HashMap();

    public static final BharosaEnumAction SYSTEM_ERROR = new BharosaEnumAction("SystemError");
    public static final BharosaEnumAction ALLOW = new BharosaEnumAction("Allow");
    public static final BharosaEnumAction BLOCK = new BharosaEnumAction("Block");
    public static final BharosaEnumAction LOCKED = new BharosaEnumAction("challenge_block");
    public static final BharosaEnumAction CHALLENGE = new BharosaEnumAction(new String[]{"Challenge", "ChallengeQuestion", "ChallengeEmail", "ChallengeSMS", "ChallengeQuestionPad", "ChallengeTextPad", "ChallengeHTML", "ChallengeQuestionPadGeneric"});
    public static final BharosaEnumAction REGISTER = new BharosaEnumAction("Register");
    public static final BharosaEnumAction REGISTER_USER = new BharosaEnumAction(new String[]{"RegisterUser", "RegisterUserQuestionPad", "RegisterUserTextPad", "RegisterUserHTML"});
    public static final BharosaEnumAction REGISTER_USER_OPTIONAL = new BharosaEnumAction(new String[] {"RegisterUserOptional", "RegisterUserOptionalTextPad", "RegisterUserOptionalQuestionPad", "RegisterUserOptionalHTML"});
    public static final BharosaEnumAction REGISTER_QUESTIONS = new BharosaEnumAction(new String[] {"RegisterQuestions","RegisterQuestionsTextPad", "RegisterQuestionsQuestionPad", "RegisterQuestionsHTML"});
    public static final BharosaEnumAction REGISTER_IMAGE = new BharosaEnumAction(new String[]{"RegisterImage", "RegisterImageTextPad", "RegisterImageQuestionPad"});
    public static final BharosaEnumAction REGISTER_USER_INFO = new BharosaEnumAction(new String[]{"RegisterUserInfo"});
    public static final BharosaEnumAction REGISTER_PREF = new BharosaEnumAction("RegisterPreferences");
    public static final BharosaEnumAction REGISTER_REQUIRED = new BharosaEnumAction("RegistrationRequired");
    
    private final String myName; // for debug only

    private BharosaEnumAction(String name) {
        myName = name;
        map.put(name, this);
    }

    private BharosaEnumAction(String actions[]) {
        if (actions != null && actions.length > 0) {
        	myName = actions.toString();
        	for (int i=0; i< actions.length; i++) {
        		map.put(actions[i], this);
        	}
        } else {
        	myName = "";
        }
    }
    
    public String toString() {
        return myName;
    }

    public static BharosaEnumAction getEnumAction(String action) {
    	if (action == null) {
    		return BharosaEnumAction.ALLOW;
    	}
    	
        BharosaEnumAction enumAction = (BharosaEnumAction) map.get(action);
        return enumAction == null ? BharosaEnumAction.SYSTEM_ERROR : enumAction;
    }
}
