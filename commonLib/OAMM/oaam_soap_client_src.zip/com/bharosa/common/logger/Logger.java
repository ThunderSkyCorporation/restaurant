/* $Header: oaam/apps/oaam_core/src/com/bharosa/common/logger/Logger.java /main/2 2010/12/23 03:20:58 nanantha Exp $ */

/* Copyright (c) 2008, 2010, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
   Adapts log4j calls to Java Util Logging

   PRIVATE CLASSES

   NOTES
   Consider removing this class and making the methods inline for better performance and clean logging

   MODIFIED    (MM/DD/YY)
      
      nagsrini  07/23/09 - Added code to clean log message to remove harmful
                           characters before logging it
*/
package com.bharosa.common.logger;

import java.io.IOException;
import java.io.InputStream;

import java.util.logging.Level;
import java.util.logging.LogManager;

import com.bharosa.common.util.StringUtil;

public final class Logger {

    private String className;
    private java.util.logging.Logger julLoggger;

    //Harmful characters in log messages will be replaced by ' ' before it is logged to comply with security requirements
    private static char[] harmfulCharacters = new char[]{'\n', '\r'};
    
    protected Logger(String className, java.util.logging.Logger logger) {
        this.className = className;
        this.julLoggger = logger;
    }

    protected Logger(String className, String loggerName) {
        this.className = className;
        this.julLoggger = java.util.logging.Logger.getLogger(loggerName);
    }

    public final static Logger getLogger(String className) {
        // BharosaAlert creates oracle.oaam.alert
        if (className != null && className.startsWith("oracle.oaam.model"))
            return new Logger(className, "oracle.oaam.model"); // ADF Model Logger
        if (className != null && className.startsWith("oracle.oaam.view"))
            return new Logger(className, "oracle.oaam.view"); // ADF View Logger
        return new Logger(className, "oracle.oaam");
    }

    public final static Logger getRealLogger(String logger, String className) {
        return new Logger(logger, className);
    }

    public final static Logger getLogger(Class kls) {
        return getLogger(kls.getName());
    }

    public final void info(Object object) {
        if (object != null) {
        	String message = cleanMessageBeforeLogging(object.toString());
            julLoggger.logp(Level.INFO, className, null, message);
        }
    }

    public final void info(String message) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(Level.INFO, className, null, message);
    }

    public final void info(String message, Throwable throwable) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(Level.INFO, className, null, message, throwable);
    }

    public final boolean isInfoEnabled() {
        return julLoggger.isLoggable(Level.INFO);
    }

    public final void warn(Object object) {
        if (object != null) {
        	String message = cleanMessageBeforeLogging(object.toString());
            julLoggger.logp(Level.WARNING, className, null, message);
        }
    }

    public final void warn(String message) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(Level.WARNING, className, null, message);
    }

    public final void warn(String message, Throwable throwable) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(Level.WARNING, className, null, message, throwable);
    }

    public final boolean isWarnEnabled() {
        return julLoggger.isLoggable(Level.WARNING);
    }

    public final boolean isFatalEnabled() {
        return julLoggger.isLoggable(Level.SEVERE);
    }

    public final void fatal(String message) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(Level.SEVERE, className, null, message);
    }

    public final void fatal(StringBuffer stringBuffer) {
    	String message = cleanMessageBeforeLogging(stringBuffer.toString());
        fatal(message);
    }

    public final void fatal(String message, Throwable throwable) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(Level.SEVERE, className, null, message, throwable);
    }

    public final boolean isDebugEnabled() {
        return julLoggger.isLoggable(Level.FINER);
    }

    public final void debug(Object object) {
        if (object != null) {
        	String message = cleanMessageBeforeLogging(object.toString());
            julLoggger.logp(Level.FINER, className, null, message);
        }
    }

    public final void debug(String message) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(Level.FINER, className, null, message);
    }

    public final void debug(String message, Throwable throwable) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(Level.FINER, className, null, message, throwable);
    }

    public final boolean isErrorEnabled() {
        return julLoggger.isLoggable(Level.SEVERE);
    }

    public final void error(Object object) {
        if (object != null) {
        	String message = cleanMessageBeforeLogging(object.toString());
            julLoggger.logp(Level.SEVERE, className, null, message);
        }
    }

    public final void error(String message) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(Level.SEVERE, className, null, message);
    }

    public final void error(String message, Throwable throwable) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(Level.SEVERE, className, null, message, throwable);
    }

    public final void error(Object object, Throwable throwable) {
        if (object != null) {
        	String message = cleanMessageBeforeLogging(object.toString());
            julLoggger.logp(Level.SEVERE, className, null, message, throwable);
        }
    }

    public final void error(Exception exception) {
        final String message = null;
        julLoggger.logp(Level.SEVERE, className, null, message, exception);
    }

    public final boolean isEnabledFor(BharosaLevel level) {
        return julLoggger.isLoggable(convertLevel(level));
    }

    public final boolean isEnabledFor(Level level) {
        return julLoggger.isLoggable(level);
    }

    public final void log(Level level, String message, Throwable throwable) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(level, className, null, message, throwable);
    }

    public final void log(BharosaLevel level, String message) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(convertLevel(level), className, null, message);
    }

    public final void log(Level level, String message) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(level, className, null, message);
    }

    public final void log(Level level, String message, Exception exception) {
    	message = cleanMessageBeforeLogging(message);
        julLoggger.logp(level, className, null, message, exception);
    }

    public final static void reConfigure(InputStream inputStream) throws IOException, SecurityException {
        LogManager.getLogManager().readConfiguration(inputStream);
    }

    /**
     * Provide mapping between log4j level and jul logging level
     * @param level
     * @return
     */
    static Level convertLevel(BharosaLevel level) {
        switch (level.intLevel()) {
        case 50000:
        case 40000:
            return Level.SEVERE;
        case 30000:
            return Level.WARNING;
        case 20000:
            return Level.INFO;
        case 10000:
            return Level.FINER;
        }
        return Level.ALL;        
    }
    
    /** 
     * Removes harmful characters like "\n", "\r" from log message
     * This is done to pass the security compliance tests
     * @param originalMessage
     * @return
     */
    private String cleanMessageBeforeLogging(String originalMessage) {
    	String cleanedMessage = originalMessage;
    	if (!StringUtil.isEmpty(originalMessage)) {
	    	for (int i=0; i < harmfulCharacters.length; i++) {
	    		cleanedMessage = cleanedMessage.replace(harmfulCharacters[i], ' ');
	    	}
    	}
    	return cleanedMessage;
    }
}
