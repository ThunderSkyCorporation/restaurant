/* $Header: oaam/apps/oaam_core/src/com/bharosa/common/logger/BharosaLevel.java /main/1 2009/12/02 01:00:32 bodurai Exp $ */

/* Copyright (c) 2008, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
   Alert Logging Levels

   PRIVATE CLASSES

   NOTES
   
   MODIFIED    (MM/DD/YY)
*/
package com.bharosa.common.logger;

import com.bharosa.common.util.UserDefEnum;
import com.bharosa.common.util.UserDefEnumElement;
import com.bharosa.common.util.IBharosaConstants;

/**
 * Custom logging levels for Bharosa
 *
 * @author Luke Harris
 */
public class BharosaLevel {
    
    private static UserDefEnum valueType = UserDefEnum.getEnum(IBharosaConstants.ENUM_ALERT_LEVEL_ID);
    private String levelName;
    private int level;

    protected BharosaLevel(int level, String strLevel) {
        this.level = level;
        this.levelName = strLevel;
    }

    public static BharosaLevel toLevel(String alertName) {
        UserDefEnumElement element = valueType.getElementByName(alertName);
        int alertLevel = element.getValue();
        return new BharosaLevel(alertLevel, alertName);
    }

    public static BharosaLevel toLevel(int alertLevel) throws IllegalArgumentException {
        UserDefEnumElement element = valueType.getElement(alertLevel);
        String alertName = element.getProperty("name");
        return new BharosaLevel(alertLevel, alertName);
    }
    
    public int intLevel() {
        return level;
    }
    
    public String levelName() {
        return this.levelName;
    }
}

