package com.bharosa.common.toplink;

import com.bharosa.common.exception.ValidationException;
import com.bharosa.common.util.IPUtil;
import com.bharosa.common.util.StringUtil;

public class TOPLinkIPAttributeTransformer extends TOPLinkAttributeTransformer {
	private static final long serialVersionUID = -7614932742024349871L;
	protected Object buildObjectValue(Object dataValue) {
		if (dataValue == null || !(dataValue instanceof Number)) return null;
		return IPUtil.long2ip(((Number) dataValue).longValue());
	}

	protected Object buildDatabaseValue(Object objectValue) {
		Object ip;
		if (objectValue instanceof String) {
			ip = objectValue;
		} else if (objectValue instanceof com.bharosa.common.util.IPAddress) {
			ip = ((com.bharosa.common.util.IPAddress) objectValue).getIPString();
		} else {
			ip = getValueFromObject(objectValue);
		}
		if (ip == null || StringUtil.isEmpty(ip.toString())) return null;
		try {
			if (ip.toString().indexOf('.') == -1 && ip.toString().indexOf(':') == -1 && StringUtil.isAllNumeric(ip.toString())) return new Long(ip.toString());
			return new Long(IPUtil.ip2long(ip.toString()));
		} catch (ValidationException e) {
			return null;
		}
	}

}