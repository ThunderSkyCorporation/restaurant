package com.bharosa.common.toplink;

import org.apache.commons.beanutils.BeanUtils;

import com.bharosa.common.logger.Logger;

import org.eclipse.persistence.internal.descriptors.TransformerBasedFieldTransformation;
import org.eclipse.persistence.mappings.DatabaseMapping;
import org.eclipse.persistence.mappings.converters.Converter;
import org.eclipse.persistence.mappings.foundation.AbstractTransformationMapping;
import org.eclipse.persistence.mappings.transformers.AttributeTransformer;
import org.eclipse.persistence.mappings.transformers.FieldTransformer;
import org.eclipse.persistence.sessions.Record;
import org.eclipse.persistence.sessions.Session;

public abstract class TOPLinkAttributeTransformer implements AttributeTransformer,
                                                             FieldTransformer,
                                                             Converter {
    private static final long serialVersionUID = 1L;

    private static Logger LOGGER = Logger.getLogger(TOPLinkAttributeTransformer.class);

    protected String attributeName;
    protected String fieldName;

    public TOPLinkAttributeTransformer() {
        super();
    }

    public void initialize(AbstractTransformationMapping mapping) {
        /* Since we implement both AttributeTransformer and FieldTransformer, this method gets
         * called twice.  The first time it is called, mapping.getField() returns null.
         *
         * attributeName is set on the first call.
         * fieldName is set on the second call.
         */
        attributeName = mapping.getAttributeName();
        if (!mapping.getFieldTransformations().isEmpty()) {
            fieldName = ((TransformerBasedFieldTransformation)mapping.getFieldTransformations().get(0)).getField().getName();
        }
    }

    public Object buildAttributeValue(Record record, Object instance,
                                      Session session) {
        return buildObjectValue(record.get(fieldName));
    }

    public Object buildFieldValue(Object instance, String aFieldName,
                                  Session session) {
        return buildDatabaseValue(instance);
    }

    protected abstract Object buildObjectValue(Object dataValue);

    protected abstract Object buildDatabaseValue(Object objectValue);

    protected Object getValueFromObject(Object instance) {
        if (instance == null)
            return null;
        try {
            return BeanUtils.getProperty(instance, attributeName);
        } catch (Throwable ex) {
            LOGGER.error("Error getting value from object.  Object=" +
                         instance + ", Type=" + instance.getClass().getName() +
                         ", Attribute=" + attributeName, ex);
            return null;
        }
    }

    public Object convertDataValueToObjectValue(Object dataValue, Session session) {
        return buildObjectValue(dataValue);
    }

    public Object convertObjectValueToDataValue(Object objectValue, Session session) {
        return buildDatabaseValue(objectValue);
    }

    public void initialize(DatabaseMapping mapping, Session session) {
        attributeName = mapping.getAttributeName();
        fieldName = mapping.getField().getName();
        
    }

    public boolean isMutable() {
        return true;
    }
}
