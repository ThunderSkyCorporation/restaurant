package com.bharosa.common.exception;

import com.bharosa.common.logger.Logger;

/**
 * This class throws validation exceptions.
 *
 * @author "Philomina Dorai" 
 * @version 1.0
 * @since 1.0
 * @see BharosaException
 */
public class ValidationException 
	extends BharosaException {

	static Logger logger = Logger.getLogger(ValidationException.class);
	
	/**
	 * This exception is thrown for empty field values
	 *
	 * @param field a <code>String</code> value
	 * @return a <code>ValidationException</code> value
	 */
	static public ValidationException createEmptyValueException (String field ) {
		return new ValidationException( BharosaErrorIds.FIELD_VALUE_EMPTY_ERROR,
									   new Object[] { field  });
	}

	/**
	 * This exception is thrown for null field values
	 *
	 * @param field a <code>String</code> value
	 * @return a <code>ValidationException</code> value
	 */
	static public ValidationException createNullValueException (String field ) {
		return new ValidationException( BharosaErrorIds.FIELD_VALUE_NULL_ERROR,
									   new Object[] { field  });
	}

	/**
	 * This exception is thrown for invalid email address
	 *
	 * @param invalidEmailAddr a <code>String</code> value
	 * @return a <code>ValidationException</code> value
	 */
	static public ValidationException createInvalidEmailAddress (String invalidEmailAddr,String error ) {
		return new ValidationException( BharosaErrorIds.INVALID_EMAIL_ADDRESS_ERROR,
									   new Object[] { invalidEmailAddr , error} );
	}

	/**
	 * This exception is thrown for invalid enum
	 *
	 * @param enumId enum id
	 * @return a <code>ValidationException</code> value
	 */
	static public ValidationException createInvalidEnum (String enumId) {
		return new ValidationException( BharosaErrorIds.ENUM_INVALID_ENUMID,
									   new Object[] { enumId} );
	}

	/**
	 * This exception is thrown for invalid enum value
	 *
	 * @param enumName Name of the enum
	 * @param invalidEnumValue Value of the enum
	 * @return a <code>ValidationException</code> value
	 */
	static public ValidationException createInvalidEnumValue (String enumName, Object invalidEnumValue ) {
		return new ValidationException( BharosaErrorIds.ENUM_INVALID_VALUE,
									   new Object[] { enumName,  invalidEnumValue } );
	}

	/**
	 * This exception is thrown for invalid IP address
	 *
	 * @param ipAddr IP address in string format
	 * @param errStr Error string
	 * @return a <code>ValidationException</code> value
	 */
	static public ValidationException createInvalidIPAddress (String ipAddr, String errStr ) {
		return new ValidationException( BharosaErrorIds.INVALID_IP_ADDRESS_ERROR,
									   new Object[] { ipAddr, errStr } );
	}

	/**
	 * This exception is thrown for invalid pin.
	 * A pin can be alpha-numeric.
	 *
	 * @return a <code>ValidationException</code> value
	 */
	static public ValidationException createInvalidPin ( ) {
		return new ValidationException( BharosaErrorIds.INVALID_PIN_ERROR );
	}

	/**
	 * This exception is thrown for invalid long value.
	 *
	 * @return a <code>ValidationException</code> value
	 */
	static public ValidationException createInvalidLong ( String value , String attr) {
		return new ValidationException( BharosaErrorIds.INVALID_LONG_ERROR, new Object[] {value, attr} );
	}

	/**
	 * This exception is thrown for invalid int value.
	 *
	 * @return a <code>ValidationException</code> value
	 */
	static public ValidationException createInvalidInt ( String value , String attr) {
		return new ValidationException( BharosaErrorIds.INVALID_INT_ERROR, new Object[] {value, attr} );
	}

	/////////////////////////////////////////////////////////////////////
	//These are common for all exception classes and they are private
	/////////////////////////////////////////////////////////////////////

	/**
	 * Creates an exception instance with the error id, without variables.
	 * @param errorId Error Id.
	 */
	public ValidationException( String errorId ) {
		super( errorId );
	}
	
	/**
	 * Creates an exception instance with the error id, with variables.
	 * @param errorId Error Id.
	 * @param varArray Array of objects contains the values used to substitude.
	 */
	private ValidationException( String errorId, Object[] varArray ) {
		super( errorId, varArray );
	}
}
