package com.bharosa.common.exception;
/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */


/**
 * BharosaErrorIds.java
 * Description: This contains the error ids used in common.
 * @author bosco
 */

import com.bharosa.common.logger.Logger;


public class BharosaErrorIds {
	static Logger  logger = Logger.getLogger(BharosaErrorIds.class);

	//Enum errors.
	public static final String ENUM_NOTFOUND = "ENUM_NOTFOUND";
	public static final String ENUM_ELEMENT_NOTFOUND = "ENUM_ELEMENT_NOTFOUND";
	public static final String ENUM_INVALID_VALUE = "ENUM_INVALID_VALUE";
	public static final String ENUM_INVALID_ENUMID ="ENUM_INVALID_ENUMID";

	//DB errors.
	public static final String DB_SETUP_ERROR = "DB_SETUP_ERROR";
	public static final String DB_CONN_ERROR = "DB_CONN_ERROR";
	public static final String DB_CONN_CLOSE_ERROR = "DB_CONN_CLOSE_ERROR";
	public static final String DB_OBJ_INSERT_ERROR = "DB_OBJ_INSERT_ERROR";
	public static final String DB_OBJ_UPDATE_ERROR = "DB_OBJ_UPDATE_ERROR";
	public static final String DB_OBJ_LOAD_ERROR = "DB_OBJ_LOAD_ERROR";
	public static final String DB_OBJ_QUERY_ERROR = "DB_OBJ_QUERY_ERROR";
	public static final String DB_OBJ_DELETE_ERROR = "DB_OBJ_DELETE_ERROR";
	public static final String DB_QUERY_ERROR = "DB_QUERY_ERROR";
	public static final String DB_DUPLICATE_ERROR = "DB_DUPLICATE_ERROR";
	public static final String DB_NULL_ERROR = "DB_NULL_ERROR";
	public static final String DB_NOT_FOUND = "DB_NOT_FOUND";
	public static final String DB_TRANSACTION_CREATE_ERROR = "DB_TRANSACTION_CREATE_ERROR";
	public static final String DB_TRANSACTION_COMMIT_ERROR = "DB_TRANSACTION_COMMIT_ERROR";
	public static final String DB_TRANSACTION_ROLLBACK_ERROR = "DB_TRANSACTION_ROLLBACK_ERROR";
	public static final String DB_EXCEPTION_ERROR = "DB_EXCEPTION_ERROR";
    public static final String DB_DATA_ERROR = "DB_DATA_ERROR";
	public static final String DB_ERROR = "DB_ERROR";

    //Hibernate errors.
	public static final String HIBER_CONFIG_ERROR = "HIBER_CONFIG_ERROR";
	public static final String HIBER_SESS_FACTORY_ERROR = "HIBER_SESS_FACTORY_ERROR";
	public static final String HIBER_SESS_ERROR = "HIBER_SESS_ERROR";
	public static final String HIBER_SESS_CLOSE_ERROR = "HIBER_SESS_CLOSE_ERROR";

	//Validation errors.
	public static final String INVALID_EMAIL_ADDRESS_ERROR = "INVALID_EMAIL_ADDRESS_ERROR";
	public static final String INVALID_IP_ADDRESS_ERROR = "INVALID_IP_ADDRESS_ERROR";
	public static final String FIELD_VALUE_EMPTY_ERROR = "FIELD_VALUE_EMPTY_ERROR";
	public static final String FIELD_VALUE_NULL_ERROR = "FIELD_VALUE_NULL_ERROR";
	public static final String INVALID_PIN_ERROR = "INVALID_PIN_ERROR";
	public static final String INVALID_LONG_ERROR = "INVALID_LONG_ERROR";
	public static final String INVALID_INT_ERROR = "INVALID_INT_ERROR";

	//chart errors
	public static final String CHART_RENDERING_FAILURE = "CHART_RENDERING_FAILURE";
	public static final String CHART_ENCODING_FAILURE = "CHART_ENCODING_FAILURE";
	public static final String SERVLET_RESPONSE_NULL = "SERVLET_RESPONSE_NULL";
	public static final String CHART_TYPE_NULL = "CHART_TYPE_NULL";
	public static final String CHART_TYPE_PROPERTIES_NULL = "CHART_TYPE_PROPERTIES_NULL";
	public static final String CHART_DATA_EMPTY = "CHART_DATA_EMPTY";
	public static final String AXIS_LABELS_EMPTY = "AXIS_LABELS_EMPTY";
	public static final String INVALID_AXIS_LABELS_LENGTH = "INVALID_AXIS_LABELS_LENGTH";
	public static final String INVALID_LEGEND_LABELS_LENGTH = "INVALID_LEGEND_LABELS_LENGTH";
	public static final String INVALID_LEGEND_COLOR_LENGTH = "INVALID_LEGEND_COLOR_LENGTH";
	public static final String INVALID_CHART_DATA = "INVALID_CHART_DATA";

	//xml errors
	public static final String XML_FILE_PARSE_ERROR = "XML_FILE_PARSE_ERROR";
    public static final String XML_STRING_PARSE_ERROR = "XML_STRING_PARSE_ERROR";
	//access Errors
	public static final String ACCESS_FILE_NOT_FOUND = "ACCESS_FILE_NOT_FOUND";
	public static final String ACCESS_SETUP = "ACCESS_SETUP";

	//client data access errors
	public static final String CLIENT_ACCESS_SETUP = "CLIENT_DATA_ACCESS_SETUP_ERROR";
	public static final String CLIENT_ACCESS_GET_VALUE = "CLIENT_DATA_ACCESS_GET_VALUE_ERROR";
	public static final String CLIENT_ACCESS_SET_VALUE = "CLIENT_DATA_ACCESS_SET_VALUE_ERROR";
        
    public static final String INVALID_DATA_FILE = "INVALID_DATA_FILE";

	public static final String IMPORT_FAILED = "IMPORT_FAILED_ERROR";

        public static final String COND_ASSOCIATED_WITH_PROFILE = "COND_ASSOCIATED_WITH_PROFILE";
        public static final String INVALID_PROFILE_TYPE = "INVALID_PROFILE_TYPE";

	public static final String INVALID_POLICY_TYPE = "INVALID_POLICY_TYPE";

	public static final String MODEL_NO_DATA = "MODEL_NO_DATA";

	public static final String MODEL_SAME_NAME = "MODEL_SAME_NAME";

	public static final String IMPORT_NO_GROUP = "IMPORT_NO_GROUP";
  
  public static final String GROUP_CANNOT_BE_DELETED = "GROUP_CANNOT_BE_DELETED";

	public static final String IMPORT_OVERRIDE_ACTION_ERROR = "IMPORT_OVERRIDE_ACTION_ERROR";

	public static final String IMPORT_OVERRIDE_ALERT_ERROR = "IMPORT_OVERRIDE_ALERT_ERROR";

	public static final String BAD_RULE_DATA = "BAD_RULE_DATA";

	public static final String PROFILE_NOT_PRESENT = "PROFILE_NOT_PRESENT";

	public static final String ALERTGROUP_ERROR = "ALERTGROUP_ERROR";

	public static final String ACTIONGROUP_ERROR = "ACTIONGROUP_ERROR";

	public static final String EXCLUDE_GROUP = "EXCLUDE_GROUP";

	public static final String UNSUPPORTED_OPERATION = "UNSUPPORTED_OPERATION";

	public static final String PROPERTY_EVALUATION_ERROR = "PROPERTY_EVALUATION_ERROR";
        
        public static final String DATABASE_PROPERTY_EVALUATION_ERROR = "DATABASE_PROPERTY_EVALUATION_ERROR";

	public static final String FORMAT_OBJECT_ERROR = "FORMAT_OBJECT_ERROR";

	public static final String UNKNOWN_PROPERTY_ERROR = "UNKNOWN_PROPERTY_ERROR";

	public static final String UNSUPPORTED_OPERATOR_ERROR = "UNSUPPORTED_OPERATOR_ERROR";

	public static final String TOPLINK_SERVERSESSION_ERROR = "TOPLINK_SERVERSESSION_ERROR";

        public static final String LIST_ASSOCIATED_WITH_PROFILE = "LIST_ASSOCIATED_WITH_PROFILE";
        public static final String LIST_ASSOCIATED_WITH_USERGROUP = "LIST_ASSOCIATED_WITH_USERGROUP";
	public static final String INVALID_LIST_TYPE = "INVALID_LIST_TYPE";

	public static final String LIST_TYPE_DETERMINATION_ERROR = "LIST_TYPE_DETERMINATION_ERROR";

	public static final String LIST_TYPE_VERIFICATION_ERROR = "LIST_TYPE_VERIFICATION_ERROR";

	public static final String INVALID_LIST_INFORMATION = "INVALID_LIST_INFORMATION";

	public static final String IMPORT_PROPERTY_ERROR = "IMPORT_PROPERTY_ERROR";

	public static final String QUESTION_CATEGORY_NOT_FOUND = "QUESTION_CATEGORY_NOT_FOUND";

	public static final String VALIDATION_NOT_FOUND = "VALIDATION_NOT_FOUND";

	public static final String NOT_SUPPORTED = "NOT_SUPPORTED";

	public static final String AUTHENTICATE_QUESTION_NOT_SUPPORTED = "AUTHENTICATE_QUESTION_NOT_SUPPORTED";

	public static final String COULD_NOT_CONSTRUCT_CLASS = "COULD_NOT_CONSTRUCT_CLASS";

	public static final String METHOD_NOT_IMPLEMENTED = "METHOD_NOT_IMPLEMENTED";

	public static final String INVALID_CACHE = "INVALID_CACHE";

	public static final String INVALID_RESPONSE = "INVALID_RESPONSE";

	public static final String FILE_EXISTS_ERROR = "FILE_EXISTS_ERROR";
	
	public static final String FPID_DEVICEID_NOT_NULL = "FPID_DEVICEID_NOT_NULL";
        
	public static final String INVALID_LOGIN_ID = "INVALID_LOGIN_ID";
        
	public static final String INVALID_LIST_ID = "INVALID_LIST_ID";
    public static final String QUESTION_BHAROSA_LOCALE_NOT_FOUND = "QUESTION_BHAROSA_LOCALE_NOT_FOUND";
    
    public static final String RULE_XML_PARSING_ERROR = "RULE_XML_PARSING_ERROR";
    public static final String RULE_IMPORT_EXPORT_REQUIRES_ZIP_STREAM = "RULE_IMPORT_EXPORT_REQUIRES_ZIP_STREAM";
    
    public static final String DISPLAY_NAME_SCHEME_NOT_SET = "DISPLAY_NAME_SCHEME_NOT_SET";
    public static final String ID_SCHEME_NOT_SET = "ID_SCHEME_NOT_SET";
    
    public static final String TRANSACTION_NOT_FOUND = "TRANSACTION_NOT_FOUND";
    public static final String TRANSACTION_INPUT_DEF_NOT_MAPPED = "TRANSACTION_INPUT_DEF_NOT_MAPPED";
    public static final String TRANSACTION_DEF_NOT_FOUND_ACTIVE = "TRANSACTION_DEF_NOT_FOUND_ACTIVE";
    public static final String SOURCE_DATA_NOT_FOUND_ACTIVE = "SOURCE_DATA_NOT_FOUND_ACTIVE ";
    public static final String MAPPING_NOT_FOUND_ACTIVE = "MAPPING_NOT_FOUND_ACTIVE";
    public static final String MAPPING_NOT_FOUND = "MAPPING_NOT_FOUND";
    public static final String MAPPING_NOT_FOUND_ENTITY_ACTIVE = "MAPPING_NOT_FOUND_ENTITY_ACTIVE";
    public static final String EMPTY_TRANSACTION_NAME = "EMPTY_TRANSACTION_NAME";
    public static final String EMPTY_TRANSACTION_KEY = "EMPTY_TRANSACTION_KEY";
    public static final String EMPTY_TRANSACTION_DESCRIPTION = "EMPTY_TRANSACTION_DESCRIPTION";
    public static final String DUPLICATE_TRANSACTION = "DUPLICATE_TRANSACTION";
    public static final String VALIDATION_FAILED_SOURCE = "VALIDATION_FAILED_SOURCE";
    public static final String VALIDATION_FAILED_ATTRIBUTE = "VALIDATION_FAILED_ATTRIBUTE";
    public static final String VALIDATION_FAILED_DATADEF = "VALIDATION_FAILED_DATADEF";
    public static final String TRX_ID_NOT_FOUND_TO_CREATE_ENTITY = "TRX_ID_NOT_FOUND_TO_CREATE_ENTITY";
    public static final String ENTITY_ID_NOT_FOUND_TO_CREATE_ENTITY = "ENTITY_ID_NOT_FOUND_TO_CREATE_ENTITY";
    public static final String ENTITY_ID_NOT_FOUND_TO_UPDATE_ENTITY = "ENTITY_ID_NOT_FOUND_TO_UPDATE_ENTITY";
    public static final String TRX_ID_NOT_FOUND_TO_UPDATE_ENTITY = "TRX_ID_NOT_FOUND_TO_UPDATE_ENTITY";
    public static final String CREATE_ATTRIBUTE_FAILED = "CREATE_ATTRIBUTE_FAILED";
    public static final String ATTRIBUTE_NOT_FOUND = "ATTRIBUTE_NOT_FOUND";
    public static final String MAPPING_NOT_FOUND_TO_DELETE_ENTITY = "MAPPING_NOT_FOUND_TO_DELETE_ENTITY";
    public static final String TRX_ID_NULL = "TRX_ID_NULL";
    public static final String DESTINATION_ELEMENT_NULL = "DESTINATION_ELEMENT_NULL";
    public static final String SOURCE_NULL = "SOURCE_NULL";
    public static final String ENTITY_NOT_SELECTED = "ENTITY_NOT_SELECTED";
    public static final String DESTINATION_ELEMENT_NOT_SELECTED = "DESTINATION_ELEMENT_NOT_SELECTED";
    public static final String SOURCE_NOT_SELECTED = "SOURCE_NOT_SELECTED";
    public static final String ENTITIES_NOT_FOUND = "ENTITIES_NOT_FOUND";
    public static final String MAPPING_TRX_INPUT_NOT_FOUND = "MAPPING_TRX_INPUT_NOT_FOUND";
    public static final String CREATE_DATA_DEF_FAILED = "CREATE_DATA_DEF_FAILED";
    public static final String DISPLAY_SCHEME_NULL = "DISPLAY_SCHEME_NULL";
    public static final String DISPLAY_PARAMETERS_NULL = "DISPLAY_PARAMETERS_NULL";
    public static final String DATA_PROFILE_NOT_FOUND = "DATA_PROFILE_NOT_FOUND";
    public static final String DATA_DEF_PROFILE_MISMATCH = "DATA_DEF_PROFILE_MISMATCH";
    public static final String CREATE_EXT_ID_FAILED = "CREATE_EXT_ID_FAILED";
    public static final String ERROR_DELETE_CONSTRAINT_ELEMENT = "ERROR_DELETE_CONSTRAINT_ELEMENT";
    public static final String TRX_INPUT_MAPPING_NOT_FOUND = "TRX_INPUT_MAPPING_NOT_FOUND";
    public static final String EMPTY_ENTITY_NAME = "EMPTY_ENTITY_NAME";
    public static final String EMPTY_ENTITY_KEY = "EMPTY_ENTITY_KEY";
    public static final String EMPTY_ENTITY_DESCRIPTION = "EMPTY_ENTITY_DESCRIPTION";
    public static final String DUPLICATE_ENTITY_NAME = "DUPLICATE_ENTITY_NAME";
    public static final String INVALID_ENTITY_DEF_KEY = "INVALID_ENTITY_DEF_KEY";
    public static final String NO_DATA_ELEMENTS_ACTIVATE = "NO_DATA_ELEMENTS_ACTIVATE";
    public static final String DUPLICATE_DATA_DEF_ELEMENT_ACTIVATE = "DUPLICATE_DATA_DEF_ELEMENT_ACTIVATE";
    public static final String ROW_COL_NOT_UNIQUE_ACTIVATE = "ROW_COL_NOT_UNIQUE_ACTIVATE";
    public static final String INVALID_NUMERIC_INDEX_ACTIVATE = "INVALID_NUMERIC_INDEX_ACTIVATE";
    public static final String INVALID_NON_NUMERIC_INDEX_ACTIVATE = "INVALID_NON_NUMERIC_INDEX_ACTIVATE";
    public static final String NUMERIC_ENCRYPTION_NOT_SUPPORTED = "NUMERIC_ENCRYPTION_NOT_SUPPORTED";
    public static final String NO_DISPLAY_ELEMENTS_ACTIVATE = "NO_DISPLAY_ELEMENTS_ACTIVATE";
    public static final String DUPLICATE_DISPLAY_DATA_ELEMENTS_ACTIVATE = "DUPLICATE_DISPLAY_DATA_ELEMENTS_ACTIVATE";
    public static final String DUP_DISPLAY_ORDER_ACTIVATE = "DUP_DISPLAY_ORDER_ACTIVATE";
    public static final String NO_ID_ELEMENTS_ACTIVATE = "NO_ID_ELEMENTS_ACTIVATE";
    public static final String DUP_ID_DATA_ELEMENTS_ACTIVATE = "DUP_ID_DATA_ELEMENTS_ACTIVATE";
    public static final String DUP_ID_ORDER_ACTIVATE = "DUP_ID_ORDER_ACTIVATE";
    public static final String ERROR_DISABLE_ENTITY = "ERROR_DISABLE_ENTITY";
    public static final String ERROR_DELETE_ENTITY = "ERROR_DELETE_ENTITY";
    public static final String VALIDATE_INT_ID_DATA_DEF = "VALIDATE_INT_ID_DATA_DEF";
    public static final String VALIDATE_DATA_TYPE_DATA_DEF = "VALIDATE_DATA_TYPE_DATA_DEF";
    public static final String VALIDATE_DATA_DEF_ROW = "VALIDATE_DATA_DEF_ROW";
    public static final String VALIDATE_DATA_DEF_COLUMN = "VALIDATE_DATA_DEF_COLUMN";
    public static final String UNIQUE_INT_ID_DATA_DEF = "UNIQUE_INT_ID_DATA_DEF";
    public static final String UNIQUE_DATA_DEF_NAME = "UNIQUE_DATA_DEF_NAME";
    public static final String UNIQUE_DATA_DEF_ROW_COLUMN = "UNIQUE_DATA_DEF_ROW_COLUMN";
    public static final String VALIDATE_ERROR_DATA_DEF_ID = "VALIDATE_ERROR_DATA_DEF_ID";
    public static final String VALIDATION_ERROR_DATA_ELE_NUMERIC_INDEX = "VALIDATION_ERROR_DATA_ELE_NUMERIC_INDEX";
    public static final String VALIDATION_ERROR_DATA_ELE_NON_NUMERIC_INDEX = "VALIDATION_ERROR_DATA_ELE_NON_NUMERIC_INDEX";
    public static final String DELETE_TRX_NOT_ALLOWED = "DELETE_TRX_NOT_ALLOWED";
    public static final String VALIDATE_ENTITY_NAME = "VALIDATE_ENTITY_NAME";
    public static final String VALIDATE_ENTITY_RELATION = "VALIDATE_ENTITY_RELATION";
    public static final String VALIDATE_DISPLAY_ORDER = "VALIDATE_DISPLAY_ORDER";
    public static final String VALIDATE_UNIQUE_ENTITY_NAME = "VALIDATE_UNIQUE_ENTITY_NAME";
    public static final String VALIDATE_UNIQUE_ENTITY_RELATION = "VALIDATE_UNIQUE_ENTITY_RELATION";
    public static final String VALIDATE_UNIQUE_DISPLAY_ORDER = "VALIDATE_UNIQUE_DISPLAY_ORDER";
    public static final String ENTITY_VALIDATION_FAILED = "ENTITY_VALIDATION_FAILED";
    public static final String ENTITIES_LOADING_ERROR = "ENTITIES_LOADING_ERROR";
    public static final String TRANSACTIONS_LOADING_ERROR = "TRANSACTIONS_LOADING_ERROR";
    public static final String ERROR_DISABLE_TRANSACTION = "ERROR_DISABLE_TRANSACTION";
    public static final String ERROR_ACTIVATE_TRANSACTION = "ERROR_ACTIVATE_TRANSACTION";
    public static final String ERROR_UPDATING_MAPPING = "ERROR_UPDATING_MAPPING";
    public static final String SOURCE_DATA_LOADING_ERROR = "SOURCE_DATA_LOADING_ERROR";
    public static final String TXN_DATA_ELEMS_LOADING_ERROR="TXN_DATA_ELEMS_LOADING_ERROR";
    public static final String TXN_ENTITIES_LOADING_ERROR = "TXN_ENTITIES_LOADING_ERROR";
    public static final String TXN_MAPPINGS_LOADING_ERROR = "TXN_MAPPINGS_LOADING_ERROR";
    public static final String ENTITY_DISPLAY_SCHEME_UPDATE_ERROR = "ENTITY_DISPLAY_SCHEME_UPDATE_ERROR";
    public static final String ENTITY_IDSCHEME_UPDATE_ERROR = "ENTITY_IDSCHEME_UPDATE_ERROR";
    public static final String ENTITY_ELEMS_LOADING_ERROR = "ENTITY_ELEMS_LOADING_ERROR";
    public static final String TXN_DATA_MAPPING_REQUIRED_TO_ACTIVATE = "TXN_DATA_MAPPING_REQUIRED_TO_ACTIVATE";
    public static final String TXN_ENTITY_MAPPING_REQUIRED_TO_ACTIVATE = "TXN_ENTITY_MAPPING_REQUIRED_TO_ACTIVATE";
    public static final String TASK_NOT_READY = "TASK_NOT_READY";
    public static final String INVALID_TASK = "INVALID_TASK";
    public static final String ILLEGAL_TASK_STATE_CHANGE = "ILLEGAL_TASK_STATE_CHANGE";
    public static final String RA_TASK_MISSING_SESSIONSET = "RA_TASK_MISSING_SESSIONSET";
    public static final String RA_TASK_MISSING_DB_CONFIG = "RA_TASK_MISSING_DB_CONFIG";
    public static final String RA_INVALID_RUNMODE_CONSTRUCTOR = "RA_INVALID_RUNMODE_CONSTRUCTOR";
    public static final String RA_INVALID_RUNMODE_CLASS_NOT_FOUND = "RA_INVALID_RUNMODE_CLASS_NOT_FOUND";
    public static final String RA_INVALID_RUNMODE_CLASS_CAST = "RA_INVALID_RUNMODE_CLASS_CAST";
    public static final String MONITOR_DATA_ROLLUP_MISSING_TYPE = "MONITOR_DATA_ROLLUP_MISSING_TYPE";
    public static final String DYNAMIC_ACTION_NAME_EXISTS = "DYNAMIC_ACTION_NAME_EXISTS";
    public static final String FILE_IO_ERROR = "FILE_IO_ERROR";
    public static final String UNKNOWN_ERROR_DURING_IMPORT = "UNKNOWN_ERROR_DURING_IMPORT";
    public static final String EMPTY_ENTITY_MAP_NAME = "EMPTY_ENTITY_MAP_NAME";
    public static final String EMPTY_ENTITY_MAP_DESCRIPTION = "EMPTY_ENTITY_MAP_DESCRIPTION";
    public static final String EMPTY_ENTITY_RELATION_TYPE = "EMPTY_ENTITY_RELATION_TYPE";
    public static final String INVALID_ENTITY_RELATION_TYPE = "INVALID_ENTITY_RELATION_TYPE";
    public static final String EMPTY_ENTITY_MAP_DEFID_1 = "EMPTY_ENTITY_MAP_DEFID_1";
    public static final String EMPTY_ENTITY_MAP_DEFID_2 = "EMPTY_ENTITY_MAP_DEFID_2";
    public static final String INVALID_ENTITY_MAP_DEFID_1 = "INVALID_ENTITY_MAP_DEFID_1";
    public static final String INVALID_ENTITY_MAP_DEFID_2 = "INVALID_ENTITY_MAP_DEFID_2";
    public static final String INVALID_ENTITY_MAP_ID = "INVALID_ENTITY_MAP_ID";
}
