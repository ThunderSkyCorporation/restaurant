/**
 * BharosaExceptionCommon.java
 * Description: This is the Common Exception class. All the BharosaException classes delegate the methods to this class.
**/

/**
 *
 * @author udit
 */


package com.bharosa.common.exception;

import java.util.Locale;
import java.util.ResourceBundle;

import com.bharosa.common.logger.Logger;

import com.bharosa.common.util.BharosaLocale;

public class BharosaExceptionCommon {

	static Logger logger = Logger.getLogger(BharosaExceptionCommon.class);

	String fileList[] = new String [] { "com/bharosa/common/exception/BharosaErrorIds", "BharosaErrorIds"};
	
	public String errorId = "";
	public String errorMsg = "";
        public String localizedErrorMsg = "";

	Object[] varArray ;

	/**
	 *Constructor which just takes the errorId
	 *@param errorId The error id.
	 */
	public BharosaExceptionCommon( String errorId ) {
		this(errorId, new Object[] {} );
	}

	/**
	 *Constructor which takes the errorId and the variables for the exception.
	 *@param errorId The error id.
	 *@param varArray The array of variables.
	 */
	public BharosaExceptionCommon( String errorId, Object [] varArray ) {
		this.errorId = errorId;
		if( varArray == null ) {
			this.varArray = new Object[0];
		} else {
			this.varArray = varArray;
		}
	}
  

	/**
	 * This returns the errorId for this exception.
	 * @return String errorId
	 */
	public String getErrorId( ) {
		return errorId;
	}

	/**
	 * This returns the array of values to be substituted for this exception.
	 * @return Object Array
	 */
	public Object[] getInsertValuesArray( ) {
		return this.varArray;
	}
	
	/**
	 * This returns the error message for this exception.
	 * @return String Error message
	 */
	public String getMessage( ) {
            logger.debug("Inside getMessage()");
            String retMsg = getMessage(Locale.getDefault(),false);
            logger.debug("getMessage() returning : "+retMsg);
            return retMsg;
	}
  
      	/**
	 * This returns the error message for this exception.
	 * @return String Error message
	 */
	public String getLocalizedMessage( ) {
            logger.info("Inside getLocalizedMessage()");
            String retMsg = getMessage(BharosaLocale.getCurrentLocale(),true);
            logger.debug("getLocalizedMessage() returning : "+retMsg);
            return retMsg;
	}
        
	/**
	 * Get error message with the given Locale
	 * @param locale The locale which needs to be used.
	 */
	public String getMessage( Locale locale,boolean getLocalized) {
        logger.debug("Inside getMessage(Locale,boolean) :Locale Locale ="+locale+" ,boolean getLocalized = "+getLocalized);
        String retMsg = "";
        
        if(getLocalized) {
		    if( localizedErrorMsg.equals("") ) {
			    localizedErrorMsg = getLocalizedMessage( errorId, varArray, locale, getLocalized);
                
                if(localizedErrorMsg == null) {
                    logger.warn("getMessage(errorId=" + errorId + "): localizedErrorMsg is null");
                    
                    localizedErrorMsg = "";
                }
		    }
            retMsg = localizedErrorMsg;
        }
        else {
            if(errorMsg.equals("")) {
                errorMsg = getLocalizedMessage( errorId, varArray, locale,getLocalized);

                if(errorMsg == null) {
                    logger.warn("getMessage(errorId=" + errorId + "): errorMsg is null");
                    
                    errorMsg = "";
                }
            }
            
            retMsg = errorMsg;
        }
        
        logger.debug("getMessage(Locale,boolean) returning : " + retMsg);
        
        return retMsg;
	}
  
	/**
	 * Returns the localized error message
	 * @param exceptionId Id of the exception.
	 * @param args List of objects.
	 * @param locale The locale when needs to be used.
	 */
    private String getLocalizedMessage(String exceptionId,
            Object[] args,
            Locale locale,
            boolean getLocalized) {
         logger.debug("Inside getLocalizedMessage(String, Object[], Locale, boolean) :"
                 + "String exceptionId =" + exceptionId
                 + ", Object[] args = " + args
                 + ", Locale locale = "+ locale
                 + ", boolean getLocalized = "+ getLocalized);
        boolean idMissing = false;
        ResourceBundle exc = null;
        for (int i = 0; i < fileList.length; i++) {
         			try {
                                    if(!getLocalized) {
                                    exc = ResourceBundle.getBundle(fileList[i], locale);
                                    }else {
                                     exc = ResourceBundle.getBundle("bharosa_resources",locale);
                                    }
                                    
				try {
					String msg = exc.getString(exceptionId);
					if( msg == null ) {
						idMissing = true;
						//logger.error(exceptionId + " not defined in error property file");
						break;
					}
                                        String returnMsg = substituteValues( msg, args);
                                        logger.debug("getLocalizedMessage(String, Object[],Locale,boolean) returning : " + returnMsg);
					return returnMsg;
				} catch( Exception ex ) {
					idMissing = true;
					//logger.error(exceptionId + " not defined in error property file");
					break;
				}
				
			} catch (Exception e) {
				//logger.error("Error while mapping errorId to message", e);
			}
		}
		
		if( !idMissing ) {
			logger.error( "Id mapping for " + exceptionId + " not found.");
		}
		
		String message = exceptionId;
		if( varArray != null && varArray.length != 0) {
			message += "=";
			for( int v = 0; v < varArray.length; v++) {
				if( v > 0 ) {
					message += ", ";
				}
				message += varArray[v];
			}
		}
		return message;
	}

	/**
	 * This returns the string representation of the exception.
	 * @return message Error message with the variables substituded.
	 */
	public String toString( ) {
		return getMessage();
	}
	
	/**
	 * This method substitudes the variables in the error message string.
	 * @str The message string
	 * @args The variable values.
	 * @return Returns the substituded message.
	 */
	private String substituteValues( String str, Object[] args) {
	if(args != null) {	
            for( int i = 0; i < args.length; i++) {
			str = str.replaceAll("\\{"+i+"\\}",
								 args[i] != null?args[i].toString():"null");
		}
        }
		return str;
	}
	
}
