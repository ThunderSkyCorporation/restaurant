/**
 * BharosaRuntimeException.java
 * Description: This is the base exception class. All Bharosa runtime exceptions should
 * extend this class.
**/

/**
 *
 * @author udit
 */


package com.bharosa.common.exception;


import com.bharosa.common.logger.Logger;
import java.util.Locale;
public class BharosaRuntimeException extends RuntimeException {
    
    	static Logger logger = Logger.getLogger(BharosaRuntimeException.class);

    	private BharosaExceptionCommon exceptionObj;

    	/**
    	 *Constructor which just takes the errorId
    	 *@param errorId The error id.
    	 */
    	public BharosaRuntimeException( String errorId ) {
    		exceptionObj = new BharosaExceptionCommon(errorId, new Object[] {} );
    	}

    	/**
    	 *Constructor which takes the errorId and the variables for the exception.
    	 *@param errorId The error id.
    	 *@param varArray The array of variables.
    	 */
    	public BharosaRuntimeException( String errorId, Object [] varArray ) {
    		exceptionObj = new BharosaExceptionCommon(errorId, varArray);
    	}
      

    	/**
    	 * Constructor which takes the errorId and the variables for the exception
    	 * and also the cause.
    	 * @param errorId The error id.
    	 * @param varArray The array of variables.
    	 * @param cause a <code>Throwable</code> value
    	 */
    	public BharosaRuntimeException( String errorId, Object [] varArray, Throwable cause ) {
    		super(cause);
    		exceptionObj = new BharosaExceptionCommon(errorId,varArray);
    	}

    	/**
    	 *Constructor which just takes the errorId and a nested exception
    	 *@param errorId The error id.
    	 *@param varArray The array of variables.
    	 *@param cause nested exception
    	 */
    	public BharosaRuntimeException( String errorId , Object [] varArray, Exception cause) {
    		super(cause);
    		exceptionObj = new BharosaExceptionCommon(errorId,varArray);
    		this.setStackTrace(cause.getStackTrace());
    	}

    	/**
    	 * This returns the errorId for this exception.
    	 * @return String errorId
    	 */
    	public String getErrorId( ) {
    		return exceptionObj.getErrorId();
    	}

    	/**
    	 * This returns the array of values to be substituted for this exception.
    	 * @return Object Array
    	 */
    	public Object[] getInsertValuesArray( ) {
    		return exceptionObj.getInsertValuesArray();
    	}
    	
    	/**
    	 * This returns the error message for this exception.
    	 * @return String Error message
    	 */
    	public String getMessage( ) {
    		return exceptionObj.getMessage();
    	}
      
          	/**
    	 * This returns the error message for this exception.
    	 * @return String Error message
    	 */
    	public String getLocalizedMessage( ) {
                return exceptionObj.getLocalizedMessage();
    	}
            
    	/**
    	 * Get error message with the given Locale
    	 * @param locale The locale which needs to be used.
    	 */
    	public String getMessage( Locale locale,boolean getLocalized) {
            return exceptionObj.getMessage(locale, getLocalized);
    	}
      

    	/**
    	 * This returns the string representation of the exception.
    	 * @return message Error message with the variables substituded.
    	 */
    	public String toString( ) {
    		return getMessage();
    	}
    	
}
