package com.bharosa.common.exception;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */



import com.bharosa.common.logger.Logger;

/**
 * Exceptions thrown during enum operations.
 * @author bosco
 */

public class EnumException extends BharosaException {

	static Logger logger = Logger.getLogger(EnumException.class);
	
	/**
	 * This exception is thrown when the enum is not found.
	 *
	 * @param element enum Element
	 * @return a <code>EnumException</code> value
	 */
	static public EnumException createEnumNotFoundException (String element ) {
		return new EnumException( BharosaErrorIds.ENUM_NOTFOUND,
									   new Object[] { element  });
	}

	/**
	 * This exception is thrown when the enum element is not found.
	 *
	 * @param element enum Element
	 * @return a <code>EnumException</code> value
	 */
	static public EnumException createElementNotFoundException (String element ) {
		return new EnumException( BharosaErrorIds.ENUM_ELEMENT_NOTFOUND,
									   new Object[] { element  });
	}

	/**
	 * Creates an exception instance with the error id, without variables.
	 * @param errorId Error Id.
	 */
	private EnumException( String errorId ) {
		super( errorId );
	}
	
	/**
	 * Creates an exception instance with the error id, with variables.
	 * @param errorId Error Id.
	 * @param varArray Array of objects contains the values used to substitude.
	 */
	private EnumException( String errorId, Object[] varArray ) {
		super( errorId, varArray );
	}
	
	/**
	 * Creates an exception instance with the error id, with variables
	 * and .
	 * @param errorId Error Id.
	 * @param varArray Array of objects contains the values used to substitude.
	 * @param cause Exception for stack trace
	 */
	private EnumException( String errorId, Object[] varArray, Exception cause ) {
		super( errorId, varArray );
	}
}
