package com.bharosa.common.exception;

import com.bharosa.common.logger.Logger;

/**
 * This class throws data exceptions.
 * It throws exceptions when the necessary data is empty/null etc.
 *
 * @author "Philomina Dorai" 
 * @version 1.0
 * @since 1.0
 * @see Exception
 */
public class DataException 
	extends Exception {

	static Logger logger = Logger.getLogger(DataException.class);
        String localizedErrorMsg = "";
	/**
	 * Creates an exception instance with the error msg passed as argument.
	 * @param errormsg Error Message.
	 */
	public DataException( String errormsg ) {
		super( errormsg );
	}
        
        public DataException(String errorMsg, String localizedErrorMsg) {
            super( errorMsg);
            this.localizedErrorMsg = localizedErrorMsg;
        }

    public String getLocalizedMessage() {
        if (logger.isDebugEnabled()) {
            logger.debug("Inside getLocalizedMessage()");
        }
        String returnMsg = "";
        if(localizedErrorMsg!=null&&localizedErrorMsg.length()!=0) {
            returnMsg = localizedErrorMsg;
        }else {
            returnMsg = getMessage();
        }
        if (logger.isDebugEnabled()) {
            logger.debug("getLocalizedMessage() returning : "+returnMsg);
        }
        return returnMsg;
    }
}
