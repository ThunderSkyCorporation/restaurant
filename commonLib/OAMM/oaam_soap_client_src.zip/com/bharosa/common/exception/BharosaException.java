package com.bharosa.common.exception;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */


/**
 * BharosaException.java
 * Description: This is the base exception class. All Bharosa exception should
 * extend this class.
 * @author bosco
 */

import com.bharosa.common.logger.Logger;

import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;
import com.bharosa.common.util.BharosaLocale;

public class BharosaException extends Exception {
	static Logger logger = Logger.getLogger(BharosaException.class);

	private BharosaExceptionCommon exceptionObj;

	/**
	 *Constructor which just takes the errorId
	 *@param errorId The error id.
	 */
	public BharosaException( String errorId ) {
		exceptionObj = new BharosaExceptionCommon(errorId, new Object[] {} );
	}

	/**
	 *Constructor which takes the errorId and the variables for the exception.
	 *@param errorId The error id.
	 *@param varArray The array of variables.
	 */
	public BharosaException( String errorId, Object [] varArray ) {
		exceptionObj = new BharosaExceptionCommon(errorId, varArray);
	}
  

	/**
	 * Constructor which takes the errorId and the variables for the exception
	 * and also the cause.
	 * @param errorId The error id.
	 * @param varArray The array of variables.
	 * @param cause a <code>Throwable</code> value
	 */
	public BharosaException( String errorId, Object [] varArray, Throwable cause ) {
		super(cause);
		exceptionObj = new BharosaExceptionCommon(errorId,varArray);
	}

	/**
	 *Constructor which just takes the errorId and a nested exception
	 *@param errorId The error id.
	 *@param varArray The array of variables.
	 *@param cause nested exception
	 */
	public BharosaException( String errorId , Object [] varArray, Exception cause) {
		super(cause);
		exceptionObj = new BharosaExceptionCommon(errorId,varArray);
		this.setStackTrace(cause.getStackTrace());
	}

	/**
	 * This returns the errorId for this exception.
	 * @return String errorId
	 */
	public String getErrorId( ) {
		return exceptionObj.getErrorId();
	}

	/**
	 * This returns the array of values to be substituted for this exception.
	 * @return Object Array
	 */
	public Object[] getInsertValuesArray( ) {
		return exceptionObj.getInsertValuesArray();
	}
	
	/**
	 * This returns the error message for this exception.
	 * @return String Error message
	 */
	public String getMessage( ) {
		return exceptionObj.getMessage();
	}
  
      	/**
	 * This returns the error message for this exception.
	 * @return String Error message
	 */
	public String getLocalizedMessage( ) {
            return exceptionObj.getLocalizedMessage();
	}
        
	/**
	 * Get error message with the given Locale
	 * @param locale The locale which needs to be used.
	 */
	public String getMessage( Locale locale,boolean getLocalized) {
        return exceptionObj.getMessage(locale, getLocalized);
	}
  

	/**
	 * This returns the string representation of the exception.
	 * @return message Error message with the variables substituded.
	 */
	public String toString( ) {
		return getMessage();
	}
}
