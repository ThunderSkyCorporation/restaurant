package com.bharosa.common.util;
/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;

/**
 * This is the interface for anyone who wants to implement their own
 * password encryption logic.
 * @author bosco
 */

public interface Password {

    static final String UNICODE_FORMAT = "UTF-8";

    /**
	 * This method encrypts the given password
	 *
	 * @param password Raw password
	 * @return the encrypted password
	 */
	public String encrypt( String password );

	/**
	 * This method decrypts the given password. If the class doesn't
	 * support two encryption, then the encyrpted password passed as 
	 * parameter is  return without change.
	 * @param password Encrypted password
	 * @return decrypted password if decryption supported. Else the
	 * encrypted password is return without change.
	 */
	public String decrypt( String password );
}
