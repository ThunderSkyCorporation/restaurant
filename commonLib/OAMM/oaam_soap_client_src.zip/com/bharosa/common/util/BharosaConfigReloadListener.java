package com.bharosa.common.util;
/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;

/**
 * This class reads all the configuration values and gives easy access to
 * them. It also monitors the property files for any changes and if it
 * detects one, then it will reload them. This class also loads the System
 * properties. System properties has the least precedence.
 * @author bosco
 * @see BharosaConfig
 */

public interface BharosaConfigReloadListener {
	/**
	 * This method is called everytime the properties files are reloaded.
	 */
	public void configReloaded( );
}
