package com.bharosa.common.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.GregorianCalendar;

import com.bharosa.common.logger.Logger;

/**
 * This has some utility methods for manipulating Dates
 * 
 * @author bosco
 */

public class DateUtil {

	static Logger logger = Logger.getLogger(DateUtil.class);

	public static final String DATE = "MM/dd/yyyy"; // SimpleDateFormat.SHORT
	public static final String DATE_TIME = "MM/dd/yyyy HH:mm";
	public static final String DATE_TIMESEC = "MM/dd/yyyy HH:mm:ss";
	public static final String DATE_TIME_MILLISEC = "MM/dd/yyyy HH:mm:ss.SSS";
	public static final String DATE_TIME_TZ = "MM/dd/yyyy HH:mm (zzz)";
	public static final String DATE_24HOUR_TZ = "E, dd MMM yyyy HH:mm Z (zzz)";
	public static final String DATE_12HOUR_TZ = "E, dd MMM yyyy KK:mm a Z (zzz)";
	public static final String DATE_FILE_FORMAT = "MMddyyyy_HHmmssS";
	public static final String DATE_TIME_TOSTRING_FORMAT = "EEE MMM dd HH:mm:ss zzz yyyy";
	public static final String YEAR_FIRST_DATE_TIME_MILLISEC = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final String DAY_MONTH_YEAR = "dd-MM-yyyy";
	public static final String BI_PUBLISHER_WITH_TIMEZONE = "yyyy-MM-dd'T'HH:mm:ss.SSSz";

	public static final String TIME = "HH:mm";
	public static final String TIME_WITH_SECS = "HH:mm:ss";
	public static final String TIME_WITH_MILLISECS = "HH:mm:ss.SSS";
	public static final String TIME_TZ = "HH:mm (zzz)";
	public static final String TIME_24HOUR_TZ = "HH:mm Z (zzz)";
	public static final String TIME_12HOUR_TZ = "KK:mm a Z (zzz)";

	public static final String GLOBAL_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss Z" ;

	public static final long TWENTYFOUR_HOURS_IN_MILLISECONDS = 24 * 60 * 60 * 1000;

	public static final int[] dateFormats = new int[]{DateFormat.SHORT, DateFormat.MEDIUM, DateFormat.FULL};

	public static final String[] timeFormats = new String[]{TIME, TIME_WITH_SECS, TIME_WITH_MILLISECS, TIME_TZ, TIME_24HOUR_TZ, TIME_12HOUR_TZ};

	public static final BharosaPropertyInt weekBegin = new BharosaPropertyInt("bharosa.week.begin", 2);

	/**
	 * Takes the time and resets the time part (hours, minutes, seconds and
	 * milliseconds) to zero.
	 * 
	 * @param inDate
	 *            the reference date object. This object is not modified.
	 * @return a newly created Date object with the time reset.
	 */
	static public Date resetTimeToAM(Date inDate) {
		if (inDate == null) {
			if (logger.isDebugEnabled())
				logger.debug("resetTimeToAM(inDate=null)");
			return null;
		}
		Calendar inCal = Calendar.getInstance();
		inCal.setTime(inDate);
		Calendar cal = resetTimeToAM(inCal);
		return cal.getTime();
	}

	public static Calendar resetTimeToAM(Calendar inCal) {
		Calendar cal = Calendar.getInstance();
		cal.clear();
		cal.set(inCal.get(Calendar.YEAR), inCal.get(Calendar.MONTH), inCal.get(Calendar.DATE));
		return cal;
	}

	static public Date resetTimeToMidnight(Date inDate) {
		if (inDate == null) {
			if (logger.isDebugEnabled())
				logger.debug("resetTimeToMidnight(inDate=null)");
			return null;
		}
		Calendar inCal = Calendar.getInstance();
		inCal.setTime(inDate);
		inCal = resetTimeToMidnight(inCal);
		return inCal.getTime();
	}

	public static Calendar resetTimeToMidnight(Calendar inCal) {
		inCal.set(Calendar.HOUR_OF_DAY, 23);
		inCal.set(Calendar.MINUTE, 59);
		inCal.set(Calendar.SECOND, 59);
		inCal.set(Calendar.MILLISECOND, 999);
		return inCal;
	}

	static public boolean isSameDay(Date date1, Date date2) {
		if (date1 == null && date2 == null) {
			if (logger.isDebugEnabled())
				logger.debug("isSameDay(date1=null, date2=null)");
			return true;
		}
		if (date1 == null || date2 == null) {
			return false;
		}
		if (date1.equals(date2)) {
			return true;
		}

		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date1);

		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);

		return (cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) && cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH) && cal1.get(Calendar.DATE) == cal2
				.get(Calendar.DATE));
	}

	static public Date getFloorDate(int days) {
		Calendar cal = Calendar.getInstance();
		if (days > 0) {
			cal.add(Calendar.DATE, -1 * days);
		}
		return resetTimeToAM(cal.getTime());
	}

	static public Date getExtendedDate(int durationInHrs) {
		if (durationInHrs > 0) {
			Calendar fromCal = Calendar.getInstance();
			fromCal.add(Calendar.HOUR, durationInHrs);
			return fromCal.getTime();
		}
		return null;
	}

	/**
	 * Returns formatted string for the given milliseconds
	 * 
	 * @param milliseconds
	 *            date in milliseconds.
	 * @return a <code>String</code> value
	 */
	public static String getTimeInSecsAndMillisecs(long milliseconds) {
		if (milliseconds < 0) {
			return HttpUtil.formatForWeb(null);
		}
		Date date = new Date(milliseconds);
		SimpleDateFormat formatter = new SimpleDateFormat("ss.S");
		return formatter.format(date);
	}

	/**
	 * Returns formatted string for the given time.
	 * 
	 * @param pTime
	 *            a <code>long</code> value
	 * @return a <code>String</code> value
	 */
	public static String getTimeString(long pTime) {
		if (pTime < 0) {
			return BharosaConfig.get("not.available", "");
		}
		SimpleDateFormat formatter = new SimpleDateFormat(TIME);

		return formatter.format(new Date(pTime));
	}

	/**
	 * Returns time in HH:mm:ss format
	 * 
	 * @param pTime
	 *            a long value
	 * @return a String value
	 */
	public static String getTimeStringWithSeconds(long pTime) {
		if (pTime < 0) {
			return BharosaConfig.get("not.available", "");
		}
		SimpleDateFormat formatter = new SimpleDateFormat(TIME_WITH_SECS);
		return formatter.format(new Date(pTime));
	}

	/**
	 * Returns formatted string for file name for the given date/timestamp
	 * 
	 * @param pDate
	 *            a <code>Date</code> value
	 * @return a <code>String</code> value
	 */
	public static String getDateStringForFile(Date pDate) {
		if (pDate == null || pDate.getTime() == 0) {
			return BharosaConfig.get("not.available", "");
		}
		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FILE_FORMAT);
		return formatter.format(pDate);
	}

	public static String getFromattedDateString(Date pDate, String dateFormat) {
		if (pDate == null || pDate.getTime() == 0) {
			return null;
		}
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
		return formatter.format(pDate);

	}
	/**
	 * Returns formatted string for the given date/timestamp
	 * 
	 * @param pDate
	 *            a <code>Date</code> value
	 * @return a <code>String</code> value
	 */
	public static String getDateString(Date pDate) {
		if (pDate == null || pDate.getTime() == 0) {
			return BharosaConfig.get("not.available", "");
		}
		DateFormat formatter = DateFormat.getDateInstance(DateFormat.SHORT, BharosaLocale.getCurrentLocaleForFormatting());

		return format4DigitYear(formatter, pDate); // formatter.format(pDate);
	}

	/**
	 * Returns formatted string for the given date/timestamp
	 * 
	 * @param pDate
	 *            a <code>Date</code> value
	 * @return a <code>String</code> value
	 */
	public static String getFormattedDate(Date pDate) {
		if (pDate == null || pDate.getTime() == 0) {
			return BharosaConfig.get("not.available", "");
		}
		DateFormat formatter = new SimpleDateFormat(TIME);

		String dateString = getDateString(pDate);
		String timeString = formatter.format(pDate);

		return dateString + " " + timeString;
	}

	/**
	 * Returns formatted string for the given date/timestamp
	 * 
	 * @param pDate
	 *            a <code>Date</code> value
	 * @param pTz
	 *            a <code>TimeZone</code> value
	 * @return a <code>String</code> value
	 */
	public static String getFormattedDate(Date pDate, TimeZone pTz) {
		if (pDate == null || pDate.getTime() == 0) {
			return BharosaConfig.get("not.available", "");
		}

		DateFormat dateFormatter = DateFormat.getDateInstance(DateFormat.SHORT, BharosaLocale.getCurrentLocaleForFormatting());
		SimpleDateFormat timeFormatter = new SimpleDateFormat(TIME);

		if (pTz != null) {
			dateFormatter.setTimeZone(pTz);
			timeFormatter.setTimeZone(pTz);
		} else {
			dateFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
			timeFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
		}
		return format4DigitYear(dateFormatter, pDate) + " " + timeFormatter.format(pDate); // dateFormatter.format(pDate)
	}

	/**
	 * Returns formatted string for the given date/timestamp
	 * 
	 * @param pDate
	 *            a <code>Date</code> value
	 * @return a <code>String</code> value
	 */
	public static String getFormattedDateWithTZ(Date pDate) {
		if (pDate == null || pDate.getTime() == 0) {
			return BharosaConfig.get("not.available", "");
		}

		SimpleDateFormat formatter = new SimpleDateFormat(TIME_TZ);

		String dateString = getDateString(pDate);
		String timeString = formatter.format(pDate);

		return dateString + " " + timeString;
	}

	/**
	 * Returns formatted string for the given date/timestamp
	 * 
	 * @param pDate
	 *            a <code>Date</code> value
	 * @param pTz
	 *            a <code>TimeZone</code> value
	 * @return a <code>String</code> value
	 */
	public static String getFormattedDateWithTZ(Date pDate, TimeZone pTz) {
		DateFormat dateFormatter = DateFormat.getDateInstance(DateFormat.SHORT, BharosaLocale.getCurrentLocaleForFormatting());
		SimpleDateFormat timeFormatter = new SimpleDateFormat(TIME_TZ);

		if (pTz != null) {
			dateFormatter.setTimeZone(pTz);
			timeFormatter.setTimeZone(pTz);
		} else {
			dateFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
			timeFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
		}
		return format4DigitYear(dateFormatter, pDate) + " " + timeFormatter.format(pDate);
	}

	/**
	 * Returns formatted string for the given date/timestamp with secs
	 * 
	 * @param pDate
	 *            a <code>Date</code> value
	 * @return a <code>String</code> value
	 */
	public static String getFormattedDateWithSecs(Date pDate) {
		if (pDate == null || pDate.getTime() == 0) {
			return BharosaConfig.get("not.available", "");
		}

		DateFormat formatter = new SimpleDateFormat(TIME_WITH_SECS);

		String dateString = getDateString(pDate);
		String timeString = formatter.format(pDate);

		return dateString + " " + timeString;
	}

	/**
	 * Returns formatted string for the given date/timestamp with secs
	 * 
	 * @param pDate
	 *            a <code>Date</code> value
	 * @return a <code>String</code> value
	 */
	public static String getFormattedDateWithMilliSecs(Date pDate) {
		if (pDate == null || pDate.getTime() == 0) {
			return BharosaConfig.get("not.available", "");
		}

		DateFormat formatter = new SimpleDateFormat(TIME_WITH_MILLISECS);

		String dateString = getDateString(pDate);
		String timeString = formatter.format(pDate);

		return dateString + " " + timeString;
	}

	/**
	 * Returns formatted string for the given date/timestamp with timezone wrt
	 * 24hrs clock.
	 * 
	 * @param pDate
	 *            a <code>Date</code> value
	 * @return a <code>String</code> value
	 */
	public static String getFormattedDateWithTimezone(Date pDate) {
		if (pDate == null || pDate.getTime() == 0) {
			return BharosaConfig.get("not.available", "");
		}
		DateFormat dateFormatter = DateFormat.getDateInstance(DateFormat.SHORT, BharosaLocale.getCurrentLocaleForFormatting());
		SimpleDateFormat timeFormatter = new SimpleDateFormat(TIME_24HOUR_TZ);

		return format4DigitYear(dateFormatter, pDate) + " " + timeFormatter.format(pDate);
	}

	/**
	 * Returns formatted string for the given date/timestamp with timezone wrt
	 * 12hrs clock
	 * 
	 * @param pDate
	 *            a <code>Date</code> value
	 * @return a <code>String</code> value
	 */
	public static String getFormatted12hrsDateWithTimezone(Date pDate) {
		if (pDate == null || pDate.getTime() == 0) {
			return BharosaConfig.get("not.available", "");
		}
		DateFormat dateFormatter = DateFormat.getDateInstance(DateFormat.SHORT, BharosaLocale.getCurrentLocaleForFormatting());
		SimpleDateFormat timeFormatter = new SimpleDateFormat(TIME_12HOUR_TZ, BharosaLocale.getCurrentLocaleForFormatting());

		return format4DigitYear(dateFormatter, pDate) + " " + timeFormatter.format(pDate);
	}

	/**
	 * get the Date for the string (without minutes) passed as argument..
	 * 
	 * @param value
	 *            Date value in "MM/dd/yyyy" format
	 * @return Date value
	 */
	public static Date getDateFromStringNoTimeAtAll(String value) {
		return getDate(value);
	}

	/**
	 * get the Date for the string (without minutes) passed as argument..
	 * 
	 * @param value
	 *            Date value in "MM/dd/yyyy" format
	 * @return Date value
	 */
	public static Date getDateFromStringNoTime(String value) {
		return getDate(value);
	}

	/**
	 * get the Date for the string (upto minutes) passed as argument..
	 * 
	 * @param value
	 *            Date value in "MM/dd/yyyy HH:mm" format
	 * @return Date value
	 */
	public static Date getDateFromString(String value) {
		return getDate(value);
	}

	/**
	 * get the timestamp for the date string passed as argument..
	 * 
	 * @param value
	 *            Date value in "MM/dd/yyyy HH:mm:ss" format
	 * @return Date value
	 */
	public static Date getDateFromStringWithSecs(String value) {
		return getDate(value);
	}

	/**
	 * get the timestamp for the date string passed as argument..
	 * 
	 * @param value
	 *            Date value in "MM/dd/yyyy HH:mm:ss (TMZ)" format
	 * @return Date value
	 */
	public static String removeTZFromDateString(String value) {
		if (value == null) {
			return null;
		}
		value = value.replaceAll("\\([A-Z]{3}\\)", "");
		return value.trim();
	}

	/**
	 * Get the timestamp for the date string passed as argument..
	 * 
	 * @param value
	 *            Date value in one of the following format "MM/dd/yyyy
	 *            HH:mm:ss.SSS", "MM/dd/yyyy HH:mm:ss", "MM/dd/yyyy HH:mm",
	 *            "MM/dd/yyyy" format
	 * @return Date value
	 */
	public static Date getDate(String value) {
		return getDate(value, false);
	}
	
	public static Date getDate(String value, boolean useDefaultLocale) {
		if (StringUtil.isEmpty(value))
			return null;

		String dateString = value;
		String timeString = null;
		boolean useTime = false;

		// Split date and time
		int lastSpaceIndex = value.lastIndexOf(" ");
		if (lastSpaceIndex > 0) {
			dateString = value.substring(0, lastSpaceIndex);
			timeString = value.substring(lastSpaceIndex + 1);
		}

		Date dateObj = null;
		Date timeObj = null;

		// Parse Time
		if (!StringUtil.isEmpty(timeString)) {
			useTime = true;
			for (int i = 0; i < timeFormats.length; i++) {
				String timeFormat = timeFormats[i];
				SimpleDateFormat timeFormatter = new SimpleDateFormat(timeFormat);
				try {
					timeObj = timeFormatter.parse(timeString);
				} catch (Exception e) {
					logger.debug("getDate value=" + value + ", timeFormat used=" + timeFormat, e);
				}
				if (timeObj != null)
					break;
			}
			if (timeObj == null) {
				// TODO replace the following code when we switch to a modern
				// java version.
				// logger.error("getDate unsupported time format value=" + value
				// + " Supported format are "
				// + Arrays.toString(timeFormats), new
				// Throwable().fillInStackTrace());
				StringBuffer buf = new StringBuffer();

				for (int i = 0; i < timeFormats.length; i++) {
					if (i == 0)
						buf.append('[');
					else
						buf.append(", ");

					buf.append(String.valueOf(timeFormats[i]));
				}

				buf.append("]");
				logger.error("getDate unsupported time format value=" + timeString + " Supported format are " + buf.toString(), new Throwable()
						.fillInStackTrace());
			}
		} else {
			logger.debug("getDate value=" + value + ", No time component found.");
		}

		// Parse Date
		for (int i = 0; i < dateFormats.length; i++) {
			int dateFormat = dateFormats[i];
			SimpleDateFormat dateFormatter = null;
			Locale locale = null;
			if (useDefaultLocale)
				locale = Locale.getDefault();
			else
				locale = BharosaLocale.getCurrentLocaleForFormatting();
			
			if (logger.isDebugEnabled()) {
				logger.debug("getDate(): Using locale = ["+locale.toString()+"]");
			}
			
			dateFormatter = get4DigitYearFormat(DateFormat.getDateInstance(dateFormat, locale));
			try {
				dateObj = dateFormatter.parse(dateString.trim());
			} catch (Exception e) {
				logger.debug("getDate value=" + dateString + ", dateFormat used=" + dateFormat, e);
			}
			if (dateObj != null)
				break;
		}
		if (dateObj == null) {
			// TODO replace the following code when we switch to a modern java
			// version.
			// logger.error("getDate unsupported format value=" + value + "
			// Supported format are "
			// + Arrays.toString(dateFormats), new
			// Throwable().fillInStackTrace());
			StringBuffer buf = new StringBuffer();

			for (int i = 0; i < dateFormats.length; i++) {
				if (i == 0)
					buf.append('[');
				else
					buf.append(", ");

				buf.append(String.valueOf(dateFormats[i]));
			}

			buf.append("]");
			logger.error("getDate unsupported date format value=" + dateString + " Supported format are " + buf.toString(), new Throwable().fillInStackTrace());

		} else {

			// Combine date and time if both are present
			if (timeObj != null) {
				Calendar timeCal = Calendar.getInstance();
				timeCal.setTime(timeObj);
				int hours = timeCal.get(Calendar.HOUR_OF_DAY);
				int minutes = timeCal.get(Calendar.MINUTE);
				int seconds = timeCal.get(Calendar.SECOND);
				int millisecs = timeCal.get(Calendar.MILLISECOND);

				Calendar dateCal = Calendar.getInstance();
				dateCal.setTime(dateObj);
				dateCal.set(Calendar.HOUR_OF_DAY, hours);
				dateCal.set(Calendar.MINUTE, minutes);
				dateCal.set(Calendar.SECOND, seconds);
				dateCal.set(Calendar.MILLISECOND, millisecs);
				dateObj = dateCal.getTime();
			} else if (useTime) {
				// If time was present, but unable to be parsed return null.
				dateObj = null;
			}
		}
		
		// Handle Date strings from BI Publisher, ex = 2007-09-07T17:41:00.000-05:00
		if (dateObj == null && value.length() == 29 && value.lastIndexOf(':') == 26) {
			try {
				dateObj = new SimpleDateFormat(BI_PUBLISHER_WITH_TIMEZONE).parse(value.substring(0,26) + value.substring(27,29));
			} catch (ParseException pe) {
				// guess it wasn't BIP format after all.
			}
		}

		return dateObj;
	}

	public static Date getDateMinusSeconds(Date date, long seconds) {
		if (date == null) {
			date = new Date();
		}
		return new Date(date.getTime() - (seconds * 1000));
	}

	public static Date getDateMinusSeconds(long seconds) {
		return getDateMinusSeconds(new Date(), seconds);
	}

	/**
	 * calculate day and hrs from the hours values
	 * 
	 * @param hours
	 *            an <code>int</code> value
	 * @return a <code>statis</code> value
	 */
	public static String getDayHourString(int hours) {
		int day = hours / 23;
		hours = hours % 23;
		// hours = hours - (day*23);
		if (day <= 0 && hours <= 0)
			return "0 hr";
		if (day <= 0)
			return hours + " hr(s)";
		if (hours <= 0)
			return day + " day(s)";
		return day + " day(s), " + hours + " hr(s)";
	}

	public static Date getBeginYear(Date date) {
		Calendar calCur = Calendar.getInstance();
		calCur.setTime(date);

		Calendar newCal = Calendar.getInstance();
		newCal.clear();
		newCal.set(Calendar.YEAR, calCur.get(Calendar.YEAR));
		return newCal.getTime();
	}

	public static Date getBeginQuarter(Date date) {
		Calendar calCur = Calendar.getInstance();
		calCur.setTime(date);

		Calendar newCal = Calendar.getInstance();
		newCal.clear();
		newCal.set(Calendar.YEAR, calCur.get(Calendar.YEAR));
		newCal.set(Calendar.MONTH, getQuarter(calCur.get(Calendar.MONTH)));
		return newCal.getTime();
	}

	public static Date getBeginMonth(Date date) {
		Calendar calCur = Calendar.getInstance();
		calCur.setTime(date);

		Calendar newCal = Calendar.getInstance();
		newCal.clear();
		newCal.set(Calendar.YEAR, calCur.get(Calendar.YEAR));
		newCal.set(Calendar.MONTH, calCur.get(Calendar.MONTH));
		return newCal.getTime();
	}

	public static Date getBeginWeek(Date date) {
		Calendar calCur = Calendar.getInstance();
		calCur.setTime(date);

		Calendar newCal = Calendar.getInstance();
		newCal.clear();
		newCal.set(Calendar.YEAR, calCur.get(Calendar.YEAR));
		newCal.set(Calendar.MONTH, calCur.get(Calendar.MONTH));
		newCal.set(Calendar.DAY_OF_MONTH, calCur.get(Calendar.DAY_OF_MONTH));
		getWeekBeginDate(newCal);
		return newCal.getTime();
	}

	public static Date getBeginDay(Date date) {
		Calendar calCur = Calendar.getInstance();
		calCur.setTime(date);

		Calendar newCal = Calendar.getInstance();
		newCal.clear();
		newCal.set(Calendar.YEAR, calCur.get(Calendar.YEAR));
		newCal.set(Calendar.MONTH, calCur.get(Calendar.MONTH));
		newCal.set(Calendar.DAY_OF_MONTH, calCur.get(Calendar.DAY_OF_MONTH));
		return newCal.getTime();
	}

	public static Date getBeginHour(Date date) {
		Calendar calCur = Calendar.getInstance();
		calCur.setTime(date);

		Calendar newCal = Calendar.getInstance();
		newCal.clear();
		newCal.set(Calendar.YEAR, calCur.get(Calendar.YEAR));
		newCal.set(Calendar.MONTH, calCur.get(Calendar.MONTH));
		newCal.set(Calendar.DAY_OF_MONTH, calCur.get(Calendar.DAY_OF_MONTH));
		newCal.set(Calendar.HOUR_OF_DAY, calCur.get(Calendar.HOUR_OF_DAY));
		return newCal.getTime();
	}

	/**
	 * If you give 5 minute has the interval, then if the intput is 6:43, 5 then
	 * the output will be 6:40.
	 * 
	 * @param date
	 *            Date that needs to be floored
	 * @param minuteInterval
	 *            floor interval
	 * @return floored date
	 */
	static public Date getMinutesBeginDate(Date date, int minuteInterval) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		int minutes = cal.get(Calendar.MINUTE);
		int mod = minutes % minuteInterval;
		int subract = mod * -1;
		cal.add(Calendar.MINUTE, subract);
		return cal.getTime();
	}

	static public int getMinute(Date pDate) {
		return getDatePortion(pDate, Calendar.MINUTE);
	}

	static public int getHourOfDay(Date pDate) {
		return getDatePortion(pDate, Calendar.HOUR_OF_DAY);
	}

	static public int getDayOfWeek(Date pDate) {
		return getDatePortion(pDate, Calendar.DAY_OF_WEEK);
	}

	static public int getDayOfMonth(Date pDate) {
		return getDatePortion(pDate, Calendar.DAY_OF_MONTH);
	}

	static public int getWeekOfMonth(Date pDate) {
		return getDatePortion(pDate, Calendar.WEEK_OF_MONTH);
	}

	static public int getWeekOfYear(Date pDate) {
		return getDatePortion(pDate, Calendar.WEEK_OF_YEAR);
	}
	
	static public int getMonth(Date pDate) {
		return getDatePortion(pDate, Calendar.MONTH);
	}
	
	static public int getDatePortion(Date pDate, int field) {
		if (pDate == null) {
			return 0;
		} else {
			Calendar cal = Calendar.getInstance();
			cal.setTime(pDate);
			return cal.get(field);
		}		
	}
	
	static public int getQuarter(int month) {
		int quarter = (month) / 3;
		return (quarter * 3);
	}

	static public void getWeekBeginDate(Calendar cal) {
		int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
		// Week begin date. Sunday=1 and Saturday=7 (default is Monday)
		int weekBeginDay = weekBegin.getValue();
		int subract = (weekBeginDay - dayOfWeek - 7) % 7;
		cal.add(Calendar.DAY_OF_MONTH, subract);
	}

	public static String getFormattedDateWithYearFirst(Date pDate) {
		if (pDate == null || pDate.getTime() == 0) {
			return BharosaConfig.get("not.available", "");
		}

		SimpleDateFormat formatter = new SimpleDateFormat(YEAR_FIRST_DATE_TIME_MILLISEC);
		return formatter.format(pDate);

	}

	public static String getDateTimeInGlobalFormat(Date pDate) {
		if (pDate == null || pDate.getTime() == 0) {
			return BharosaConfig.get("not.available", "");
		}

		SimpleDateFormat formatter = new SimpleDateFormat(GLOBAL_DATE_TIME_FORMAT);
		return formatter.format(pDate);
	}

	/*
	 * If the format uses only a 2 digit year, attempt to modify pattern to
	 * include a 4 digit year. Then return the formatted date.
	 * 
	 * @param format DateFormat to use in formatting @param date Date that needs
	 * to be format @return formatted date String
	 */
	protected static String format4DigitYear(DateFormat format, Date date) {
		SimpleDateFormat sFormat = get4DigitYearFormat(format);
		return(sFormat == null) ? format.format(date) : sFormat.format(date);
	}

	public static SimpleDateFormat get4DigitYearFormat(DateFormat format) {

		SimpleDateFormat sFormat = null;

		if (format instanceof SimpleDateFormat) {
			sFormat = (SimpleDateFormat) format;
			String tempPattern = sFormat.toPattern();

			if (tempPattern.indexOf("yyyy") >= 0) {
				return sFormat;
			} else if (tempPattern.indexOf("yy") >= 0) {
				int patternLength = tempPattern.length();
				int yearIndex = tempPattern.lastIndexOf("y") + 1;

				String newPattern = tempPattern.substring(0, yearIndex) + "yy";

				if (yearIndex < patternLength) {
					newPattern += tempPattern.substring(yearIndex, patternLength);
				}

				sFormat.applyPattern(newPattern);
			}
		}

		return sFormat;
	}

	public static String get4DigitYearPattern(DateFormat format) {

		SimpleDateFormat sFormat = get4DigitYearFormat(format);

		if (sFormat == null) {
			return null;
		}

		return sFormat.toPattern();
	}

	public static String getLocalizedDatePattern() {
		DateFormat dateFormatter = DateFormat.getDateInstance(DateFormat.SHORT, BharosaLocale.getCurrentLocaleForFormatting());
		return get4DigitYearPattern(dateFormatter);
	}

	public static String[] getShortWeekDays() {
		DateFormatSymbols dfs = new DateFormatSymbols(BharosaLocale.getCurrentLocaleForFormatting());
		return dfs.getShortWeekdays();
	}

	public static String[] getWeekDays() {
		DateFormatSymbols dfs = new DateFormatSymbols(BharosaLocale.getCurrentLocaleForFormatting());
		return dfs.getWeekdays();
	}

	public static String[] getShortMonths() {
		DateFormatSymbols dfs = new DateFormatSymbols(BharosaLocale.getCurrentLocaleForFormatting());
		return dfs.getShortMonths();
	}

	public static String[] getMonths() {
		DateFormatSymbols dfs = new DateFormatSymbols(BharosaLocale.getCurrentLocaleForFormatting());
		return dfs.getMonths();
	}

	public static int getFirstDayOfWeek() {
		Calendar cal = Calendar.getInstance(BharosaLocale.getCurrentLocaleForFormatting());
		return cal.getFirstDayOfWeek();
	}

	public static Date addDays(Date fromDate, int noOfDays) {
		Calendar cl = Calendar.getInstance();
		if (fromDate != null)
			cl.setTime(fromDate);
		cl.add(Calendar.DATE, noOfDays);
		return cl.getTime();
	}

  public static Date getDate(String value, String timeFormat, boolean useDefaultLocale) {
    if (StringUtil.isEmpty(value))
      return null;

    String dateString = value;
    String timeString = null;
    boolean useTime = false;

    // Split date and time
    int lastSpaceIndex = value.lastIndexOf(" ");
    if (lastSpaceIndex > 0) {
      dateString = value.substring(0, lastSpaceIndex);
      timeString = value.substring(lastSpaceIndex + 1);
    }

    Date dateObj = null;
    Date timeObj = null;

    // Parse Time
    if (!StringUtil.isEmpty(timeString)) {
      useTime = true;
      SimpleDateFormat timeFormatter = new SimpleDateFormat(timeFormat);
      try {
        timeObj = timeFormatter.parse(timeString);
      } catch (Exception e) {
        logger.debug("getDate value=" + value + ", timeFormat used=" + timeFormat, e);
      }
    } else {
      logger.debug("getDate value=" + value + ", No time component found.");
    }

    // Parse Date
    for (int i = 0; i < dateFormats.length; i++) {
      int dateFormat = dateFormats[i];
      SimpleDateFormat dateFormatter = null;
      Locale locale = null;
      if (useDefaultLocale)
        locale = Locale.getDefault();
      else
        locale = BharosaLocale.getCurrentLocaleForFormatting();
      
      if (logger.isDebugEnabled()) {
        logger.debug("getDate(): Using locale = ["+locale.toString()+"]");
      }
      
      dateFormatter = get4DigitYearFormat(DateFormat.getDateInstance(dateFormat, locale));
      try {
        dateObj = dateFormatter.parse(dateString.trim());
      } catch (Exception e) {
        logger.debug("getDate value=" + dateString + ", dateFormat used=" + dateFormat, e);
      }
      if (dateObj != null)
        break;
    }
    if (dateObj == null) {
      // TODO replace the following code when we switch to a modern java
      // version.
      // logger.error("getDate unsupported format value=" + value + "
      // Supported format are "
      // + Arrays.toString(dateFormats), new
      // Throwable().fillInStackTrace());
      StringBuffer buf = new StringBuffer();

      for (int i = 0; i < dateFormats.length; i++) {
        if (i == 0)
          buf.append('[');
        else
          buf.append(", ");

        buf.append(String.valueOf(dateFormats[i]));
      }

      buf.append("]");
      logger.error("getDate unsupported date format value=" + dateString + " Supported format are " + buf.toString(), new Throwable().fillInStackTrace());

    } else {

      // Combine date and time if both are present
      if (timeObj != null) {
        Calendar timeCal = Calendar.getInstance();
        timeCal.setTime(timeObj);
        int hours = timeCal.get(Calendar.HOUR_OF_DAY);
        int minutes = timeCal.get(Calendar.MINUTE);
        int seconds = timeCal.get(Calendar.SECOND);
        int millisecs = timeCal.get(Calendar.MILLISECOND);

        Calendar dateCal = Calendar.getInstance();
        dateCal.setTime(dateObj);
        dateCal.set(Calendar.HOUR_OF_DAY, hours);
        dateCal.set(Calendar.MINUTE, minutes);
        dateCal.set(Calendar.SECOND, seconds);
        dateCal.set(Calendar.MILLISECOND, millisecs);
        dateObj = dateCal.getTime();
      } else if (useTime) {
        // If time was present, but unable to be parsed return null.
        dateObj = null;
      }
    }
    
    // Handle Date strings from BI Publisher, ex = 2007-09-07T17:41:00.000-05:00
    if (dateObj == null && value.length() == 29 && value.lastIndexOf(':') == 26) {
      try {
        dateObj = new SimpleDateFormat(BI_PUBLISHER_WITH_TIMEZONE).parse(value.substring(0,26) + value.substring(27,29));
      } catch (ParseException pe) {
        // guess it wasn't BIP format after all.
      }
    }

    return dateObj;
  }
  
  /*
   * @param date Date that needs to be convert @return java.util.Calendar object
  */  
  public static Calendar getCalendarFromDate(Date date){
  	if (date==null){
	   return null;
	}	
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	Calendar gCal = new GregorianCalendar(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH),cal.get(Calendar.HOUR),cal.get(Calendar.MINUTE),cal.get(Calendar.SECOND));
	 return gCal;
  } 
  
  	
}
