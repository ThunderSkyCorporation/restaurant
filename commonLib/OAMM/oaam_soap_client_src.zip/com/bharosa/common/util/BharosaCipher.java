package com.bharosa.common.util;

/*
 * Copyright (c) 2006 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.cipher.KeyRetrievalIntf;
import com.bharosa.common.util.cipher.ClientKeyRetrieval;
import com.bharosa.common.logger.Logger;

import java.lang.reflect.Constructor;
import java.util.HashMap;

/**
 * Utility class provides encryption / decryption facilities
 *
 * @since 3.0
 */
public class BharosaCipher {

    private static final BharosaPropertyInt MAX_CIPHER_CACHE = new BharosaPropertyInt("tracker.cipher.cache.maxSize", 500);

    private static BharosaPropertyBoolean mKeyRetrievalKlsCache = new BharosaPropertyBoolean("tracker.cipher.keyretrieval.cacheclass", true);
    private static Logger logger = Logger.getLogger(BharosaCipher.class);
    private static HashMap mCiphers = new HashMap();
    private static HashMap mKeyRetrievalMap = new HashMap();
    private Password mCipher = null;
    private String mKeyStr = null;

    //Flag that indicates whether cipher is initialized or not
    private static boolean isCipherInitialized = true;
    
    private BharosaCipher(int pEncryptionAlgorithmId, KeyRetrievalIntf pKeyRetrievalIntf, boolean isClientKey) {
        init(pEncryptionAlgorithmId, pKeyRetrievalIntf, isClientKey);
    }

    private void init(int pEncryptionAlgorithmId, KeyRetrievalIntf pKeyRetrievalIntf, boolean isClientKey) {

        String classNameStr = UserDefEnum.getPropertyByElementValue(
                IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM,
                pEncryptionAlgorithmId,
                "classname");

        String classNameProp = UserDefEnum.getPropertyByElementValue(
                IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM,
                pEncryptionAlgorithmId,
                "classnameProperty");

        if (logger.isDebugEnabled())
            logger.debug("init pEncryptionAlgorithmId=" + pEncryptionAlgorithmId + ", classNameStr=" + classNameStr
                    + ", classNameProp=" + classNameProp + ", isClientKey=" + isClientKey);

        // Lets give preference to classnameProperty
        if (!StringUtil.isEmpty(classNameProp)) {
            String lClassNameStr = BharosaConfig.get(classNameProp);
            if (logger.isDebugEnabled())
                logger.debug("init pEncryptionAlgorithmId=" + pEncryptionAlgorithmId + ", classNameStr=" + classNameStr
                        + ", classNameProp=" + classNameProp + ", isClientKey=" + isClientKey);
            if (!StringUtil.isEmpty(lClassNameStr))
                mCipher = initCipher(pEncryptionAlgorithmId, pKeyRetrievalIntf, lClassNameStr, isClientKey);
        }

        if (mCipher == null && !StringUtil.isEmpty(classNameStr))
            mCipher = initCipher(pEncryptionAlgorithmId, pKeyRetrievalIntf, classNameStr, isClientKey);

        if (mCipher == null) {
        	//Set Initialized flag as false
        	isCipherInitialized = false;
            throw new RuntimeException("Cipher could not be initialized with"
                    + " Enum Id [" + pEncryptionAlgorithmId + "]"
                    + " KeyRetrievalIntf [" + pKeyRetrievalIntf + "]");
        }
    }

    private Password initCipher(int pEncryptionAlgorithmId, KeyRetrievalIntf pKeyRetrievalIntf, String pEncAlgoClassnameStr, boolean isClientKey) {

        String lPrefix = UserDefEnum.getPropertyByElementValue(
                IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM,
                pEncryptionAlgorithmId,
                isClientKey ? "prefix.client" : "prefix.system");
        if (logger.isDebugEnabled())
            logger.debug("initCipher pEncryptionAlgorithmId=" + pEncryptionAlgorithmId + ", pEncAlgoClassnameStr="
                    + pEncAlgoClassnameStr + ", isClientKey=" + isClientKey + ", lPrefix=" + lPrefix);

        Password retCipher;
        try {
            retCipher = getPasswordClass(pEncAlgoClassnameStr, pKeyRetrievalIntf, lPrefix);
        } catch (Throwable e) {
            logger.error("initCipher pEncryptionAlgorithmId=" + pEncryptionAlgorithmId + ", pEncAlgoClassnameStr="
                    + pEncAlgoClassnameStr + ", isClientKey=" + isClientKey + ", lPrefix=" + lPrefix, e);
            retCipher = null;
        }
        return retCipher;
    }

    private synchronized static BharosaCipher getCipherObject(int pEncryptionAlgorithmId, KeyRetrievalIntf pKeyRetrievalIntf,  boolean isClientKey) {

        // isValidAlgorithm would throw an exception if wrong algorithm is used.
        isValidAlgorithm(pEncryptionAlgorithmId);

        if ((pKeyRetrievalIntf == null)) {
        	//Set Initialized flag as false
        	isCipherInitialized = false;

            throw new RuntimeException("getCipher::EncryptionAlgorithmId ["
                    + pEncryptionAlgorithmId
                    + "]. KeyRetrievalIntf cannot be null");
        }
        return getCipherFromCache(pEncryptionAlgorithmId, pKeyRetrievalIntf, isClientKey);
    }

    /**
     * @param pEncryptionAlgorithmId Algo id
     * @param pKeyRetrievalIntf      key retrieval
     * @param isClientKey            is client key
     * @return a <code> BharosaCipher </code> object
     */
    private static BharosaCipher getCipherFromCache(int pEncryptionAlgorithmId, KeyRetrievalIntf pKeyRetrievalIntf, boolean isClientKey) {

        BharosaCipher retBharosaCipher;
        byte[] keyBytes = pKeyRetrievalIntf.getKeyBytes();
        String lCacheKey = pEncryptionAlgorithmId + (isClientKey ? "-1-" : "-0-") + (keyBytes != null ? new String(keyBytes) : "");
        try {
            Object lCipherObj = mCiphers.get(lCacheKey);
            if (logger.isDebugEnabled())
                logger.debug("getCipherFromCache  size=" + mCiphers.size() + ", lCipherObj=" + lCipherObj
                        + ", pEncryptionAlgorithmId=" + pEncryptionAlgorithmId + ", pKeyRetrievalIntf="+pKeyRetrievalIntf);

            if (lCipherObj instanceof BharosaCipher) {
                retBharosaCipher = (BharosaCipher) lCipherObj;
                if (logger.isDebugEnabled())
                    logger.debug("getCipherFromCache using cached cipher size=" + mCiphers.size() + ", lCipherObj=" + lCipherObj
                            + ", pEncryptionAlgorithmId=" + pEncryptionAlgorithmId+ ", pKeyRetrievalIntf="+pKeyRetrievalIntf);
            } else {
                retBharosaCipher = new BharosaCipher(pEncryptionAlgorithmId, pKeyRetrievalIntf, isClientKey);
                if (mCiphers.size() < MAX_CIPHER_CACHE.getValue()) {
                    if (logger.isDebugEnabled())
                        logger.debug("getCipherFromCache caching cipher size=" + mCiphers.size() + ", lCipherObj=" + lCipherObj
                                + ", pEncryptionAlgorithmId=" + pEncryptionAlgorithmId+ ", pKeyRetrievalIntf="+pKeyRetrievalIntf);
                    mCiphers.put(lCacheKey, retBharosaCipher);
                } else {
                    if (logger.isDebugEnabled())
                        logger.debug("getCipherFromCache CACHE FULL cipher size=" + mCiphers.size() + ", lCipherObj=" + lCipherObj
                                + ", pEncryptionAlgorithmId=" + pEncryptionAlgorithmId+ ", pKeyRetrievalIntf="+pKeyRetrievalIntf);
                }
            }
        } catch (Exception e) {
            logger.error("getCipherFromCache caching cipher size=" + mCiphers.size() + ", pEncryptionAlgorithmId="
                    + pEncryptionAlgorithmId+ ", pKeyRetrievalIntf="+pKeyRetrievalIntf, e);
            throw new RuntimeException("Error fetching BharosaCipher for pEncryptionAlgorithmId=" + pEncryptionAlgorithmId);
        }
        return retBharosaCipher;
    }

    /**
     * This method returns a <code>BharosaCipher</code> object based on
     * the encryption algorithm and the class implementation of keyRetrievalIntf
     *
     * @param pEncryptionAlgorithmId encryption algorithm Id
     * @param pKeyRetrievalIntf      Key Retrieval
     * @param isClientKey            client key
     * @return a <code>BharosaCipher</code> object
     */
    public static BharosaCipher getCipher(int pEncryptionAlgorithmId, KeyRetrievalIntf pKeyRetrievalIntf, boolean isClientKey) {
        return getCipherObject(pEncryptionAlgorithmId, pKeyRetrievalIntf, isClientKey);
    }

    // Construct BharosaCipher based on the enumId. Construct
    // BharosaEncryptionIntf if bharosaIntf.classnameProperty is present.
    /**
     * This method returns a <code>BharosaCipher</code> object based on
     * the encryption algorithm
     *
     * @param pEncryptionAlgorithmId Encryption Algorithm
     * @return a <code>BharosaCipher</code> object
     */
    public static BharosaCipher getCipher(int pEncryptionAlgorithmId) {

        BharosaCipher retBharosaCipher;

        // isValidAlgorithm would throw an exception if wrong algorithm is used.
        isValidAlgorithm(pEncryptionAlgorithmId);
        KeyRetrievalIntf lKeyRetrievalClass = null;
        UserDefEnumElement lEnumElement = UserDefEnum.getElement(
                IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM,
                pEncryptionAlgorithmId);
        String lIntfClassnameProp = lEnumElement.getProperty("keyRetrieval.classnameProperty");
        String lIntfClassname = lEnumElement.getProperty("keyRetrieval.classname");

        // lets try to get the Cipher using keyRetrievalIntf
        // only if classname or classnameProperty is having some value.
        String lDefIntfClassname = "com.bharosa.common.util.cipher.BharosaEncryptionImpl";
        if (StringUtil.isEmpty(lIntfClassname))
            lIntfClassname = lDefIntfClassname;

        if (!StringUtil.isEmpty(lIntfClassnameProp))
            lKeyRetrievalClass = getKeyRetrievalClass(pEncryptionAlgorithmId, BharosaConfig.get(lIntfClassnameProp), null);

        if (lKeyRetrievalClass == null)
            lKeyRetrievalClass = getKeyRetrievalClass(pEncryptionAlgorithmId, lIntfClassname, null);

        retBharosaCipher = getCipherObject(pEncryptionAlgorithmId, lKeyRetrievalClass,  false);

        if (logger.isDebugEnabled())
            logger.debug("getCipher pEncryptionAlgorithmId=" + pEncryptionAlgorithmId + ", lKeyRetrievalClass="
                    + lKeyRetrievalClass + ", lIntfClassname" + lIntfClassname + ", ret=" + retBharosaCipher);

        return retBharosaCipher;
    }

    // Construct BharosaCipher based on the enumId. Construct
    // BharosaEncryptionIntf based on pBharosaIntfClassnameProperty.
    /**
     * This method returns a <code>BharosaCipher</code> object based on
     * the encryption algorithm and a property name which provides the classname for KeyRetrievalIntf implementation
     *
     * @param pEncryptionAlgorithmId Algorithm Id
     * @param pKeyIntfClassProp      Key Retrieval
     * @return a <code>BharosaCipher</code> object
     */
    public static BharosaCipher getCipherWithIntfClassProp(int pEncryptionAlgorithmId, String pKeyIntfClassProp) {

        KeyRetrievalIntf lBhEncryptionClass = null;
        BharosaCipher retBharosaCipher;
        // isValidAlgorithm would throw an exception if wrong algorithm is used.
        isValidAlgorithm(pEncryptionAlgorithmId);
        if (!StringUtil.isEmpty(pKeyIntfClassProp)) {
            String lBhIntfClasname = BharosaConfig.get(pKeyIntfClassProp);
            if (!StringUtil.isEmpty(pKeyIntfClassProp))
                lBhEncryptionClass = getKeyRetrievalClass(pEncryptionAlgorithmId, lBhIntfClasname, null);
        }

        if (lBhEncryptionClass == null)
            throw new RuntimeException("Error getting the BharosaEncryption from property [" + pKeyIntfClassProp + "]");

        retBharosaCipher = getCipher(pEncryptionAlgorithmId, lBhEncryptionClass, false);
        if (logger.isDebugEnabled())
            logger.debug("getCipherWithIntfClassProp pEncryptionAlgorithmId=" + pEncryptionAlgorithmId
                    + ", pKeyIntfClassProp=" + pKeyIntfClassProp + ", lBhEncryptionClass=" + lBhEncryptionClass
                    + ", ret=" + retBharosaCipher);

        return retBharosaCipher;
    }

    /**
     * This method returns a <code>BharosaCipher</code> with default encryption
     *
     * @return a <code>BharosaCipher</code> object
     */
    public static BharosaCipher getCipher() {
        String lEncAlgo = BharosaConfig.get("bharosa.cipher.encryption.algorithm.default", "DES");
        int lEncAlgoId = UserDefEnum.getElementValue(IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM, lEncAlgo);
        return getCipher(lEncAlgoId);
    }

    /**
     * This method returns Default <code>BharosaCipher</code> object based on
     * the property name which provides the classname for BharosaEncryptionIntf implementation
     *
     * @param pBharosaIntfClassnameProperty Intf ClassnameProperty
     * @return BharosaCipher
     */
    public static BharosaCipher getCipherWithIntfClassProp(String pBharosaIntfClassnameProperty) {
        String lEncAlgo = BharosaConfig.get("bharosa.cipher.encryption.algorithm.default", "AES");
        int lEncAlgoId = UserDefEnum.getElementValue(IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM, lEncAlgo);
        return getCipherWithIntfClassProp(lEncAlgoId, pBharosaIntfClassnameProperty);
    }

    /**
     * This method returns a <code>BharosaCipher</code> object with the system default encryption
     *
     * @return a <code>BharosaCipher</code> object
     */
    public static BharosaCipher getSystemCipher() {
        String lEncAlgo = BharosaConfig.get("bharosa.cipher.encryption.algorithm.system.default", "DESede");
        Integer lEncAlgoId = new Integer(UserDefEnum.getElementValue(IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM, lEncAlgo));
        KeyRetrievalIntf lkeyRetIntf = null;
        String lClassName = UserDefEnum.getPropertyByElementValue(
                IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM,
                lEncAlgoId.intValue(),
                "keyRetrieval.classname");
        if (logger.isDebugEnabled())
            logger.debug("getSystemCipher Instantiating " + lClassName + ", lEncAlgo=" + lEncAlgo + ", lEncAlgoId=" + lEncAlgoId);

        try {
            Constructor constructor = Class.forName(lClassName).getConstructor(new Class[]{lEncAlgoId.getClass()});
            Object lEncKeyObj = constructor.newInstance(new Object[]{lEncAlgoId});
            if (lEncKeyObj instanceof KeyRetrievalIntf) {
                lkeyRetIntf = (KeyRetrievalIntf) lEncKeyObj;
            }
        } catch (Exception e) {
            logger.error("getSystemCipher class" + lClassName + ", lEncAlgo=" + lEncAlgo + ", lEncAlgoId=" + lEncAlgoId);
            throw new RuntimeException("Could not construct class [" + lClassName + "]");
        }
        return getCipher(lEncAlgoId.intValue(), lkeyRetIntf, false);
    }

    /**
     * This method returns a <code>BharosaCipher</code> object based on
     * the Key string provided for the encryption
     *
     * @param pKeyStr key string
     * @return a <code>BharosaCipher</code> object
     */
    public static BharosaCipher getSystemCipher(String pKeyStr) {
        String lEncAlgo = BharosaConfig.get("bharosa.cipher.encryption.algorithm.system.default.with.key", "DESede");
        int lEncAlgoId = UserDefEnum.getElementValue(IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM, lEncAlgo);
        KeyRetrievalIntf lkeyRetIntf = new ClientKeyRetrieval(lEncAlgoId, pKeyStr.getBytes());
        return getCipher(lEncAlgoId, lkeyRetIntf, true);
    }

    /**
     * Migrates the encrypted string with the help of Source and Target BharosaCipher
     *
     * @param pSourceCipher          source cipher
     * @param pTargetCipher          target cipher
     * @param pSourceEncryptedString encrypted source
     * @return new encrypted string
     */
    public static String migrateString(BharosaCipher pSourceCipher, BharosaCipher pTargetCipher, String pSourceEncryptedString) {
        if ((pSourceCipher == null) || (pTargetCipher == null) || (StringUtil.isEmpty(pSourceEncryptedString))) {
            throw new IllegalArgumentException("Invalid Parameter :"
                    + " Source Cipher [" + pSourceCipher + "]"
                    + " Target Cipher [" + pTargetCipher + "]"
                    + " Source Encrypted String [" + pSourceEncryptedString + "]");
        }
        String lDecrStr = pSourceCipher.decrypt(pSourceEncryptedString);
        return pTargetCipher.encrypt(lDecrStr);
    }

    /**
     * Migrates the encrypted string with the help of Default BharosaCipher using
     * Source and Target property name which provides the classname for BharosaEncryptionIntf implementation
     *
     * @param pSrcBhrosaEncClassProp  source enc class
     * @param pTrgtBhrosaEncClassProp target encryption class
     * @param pSourceEncryptedString  encrypted source
     * @return new encrypted string
     */
    public static String migrateString(String pSrcBhrosaEncClassProp, String pTrgtBhrosaEncClassProp, String pSourceEncryptedString) {
        if ((StringUtil.isEmpty(pSrcBhrosaEncClassProp)) || (StringUtil.isEmpty(pTrgtBhrosaEncClassProp)) || (StringUtil.isEmpty(pSourceEncryptedString))) {
            throw new IllegalArgumentException("Invalid Parameter :"
                    + " Source Cipher BharosaEncryption Classname Property [" + pSrcBhrosaEncClassProp + "]"
                    + " Target Cipher BharosaEncryption Classname Property [" + pTrgtBhrosaEncClassProp + "]"
                    + " Source Encrypted String [" + pSourceEncryptedString + "]");
        }
        BharosaCipher lSrcCipher = BharosaCipher.getCipherWithIntfClassProp(pSrcBhrosaEncClassProp);
        BharosaCipher lTrgtCipher = BharosaCipher.getCipherWithIntfClassProp(pTrgtBhrosaEncClassProp);
        return migrateString(lSrcCipher, lTrgtCipher, pSourceEncryptedString);
    }

    /**
     * Checks the whether the Encryption Algorithm Id is valid or not.
     * If not then a RuntimeException would be raised.
     *
     * @param pEncryptionAlgorithmId Enc Algorithm
     * @return a <code>boolean</code>
     */
    private static boolean isValidAlgorithm(int pEncryptionAlgorithmId) {
        UserDefEnumElement lEnumElement = UserDefEnum.getElement(IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM, pEncryptionAlgorithmId);
        if (lEnumElement == null) {
            throw new RuntimeException("Error fetching the enum for bharosa cipher algorithm ["
                    + IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM + "]");
        }
        return true;
    }

    /**
     * Instantiates KeyRetrievalIntf Object based on the Classname String.
     *
     * @param pEncryptionAlgorithmId encryption algo enum id
     * @param classNameStr class name
     * @param pKey         key
     * @return a <code>KeyRetrievalIntf</code> object
     */
    private static KeyRetrievalIntf getKeyRetrievalClass(int pEncryptionAlgorithmId, String classNameStr, String pKey) {
        Integer lEncAlgo = new Integer(pEncryptionAlgorithmId);
        Object lEncKeyObj = mKeyRetrievalKlsCache.getValue() ? mKeyRetrievalMap.get(lEncAlgo) : null;
        if (lEncKeyObj == null) {
            try {
                if (StringUtil.isEmpty(pKey)) {
                    Constructor constructor = Class.forName(classNameStr).getConstructor(new Class[]{(lEncAlgo.getClass())});
                    lEncKeyObj = constructor.newInstance(new Object[]{lEncAlgo});
                } else {
                    Constructor constructor = Class.forName(classNameStr).getConstructor(new Class[]{(lEncAlgo.getClass()), pKey.getClass()});
                    lEncKeyObj = constructor.newInstance(new Object[]{lEncAlgo, pKey});
                }
            } catch (Exception e) {
                logger.error("getKeyRetrievalClass Error instantiating class= [" + classNameStr + "[");
            }
        }

        if (logger.isDebugEnabled())
            logger.debug("getKeyRetrievalClass class=" + classNameStr + ", lEncKeyObj=" + lEncKeyObj);

        if (lEncKeyObj instanceof KeyRetrievalIntf) {
            if (mKeyRetrievalKlsCache.getValue())
                mKeyRetrievalMap.put(lEncAlgo, lEncKeyObj);
            return (KeyRetrievalIntf) lEncKeyObj;
        } else {
            return null;
        }
    }

    /**
     * Instantiates Password Object based on the Classname String and other parameters.
     *
     * @param pClassNameStr     class name
     * @param pKeyRetrievalIntf key interface
     * @param pPrefix           prefix
     * @return a <code>Password</code> object
     * @throws Exception on error
     */
    private Password getPasswordClass(String pClassNameStr, KeyRetrievalIntf pKeyRetrievalIntf, String pPrefix) throws Exception {
        if (logger.isDebugEnabled())
            logger.debug("getPasswordClass : Instantiating : ClassName [" + pClassNameStr + "]"
                    + " Prefix [" + pPrefix + "] KeyRetrievalIntf [" + pKeyRetrievalIntf + "]");
        Password retPassword = null;
        Constructor lConstructor;
        Object lCipherObj = null;

        if (!StringUtil.isEmpty(pClassNameStr)) {
            if ((pKeyRetrievalIntf != null)) {
                try {
                    lConstructor = Class.forName(pClassNameStr).getConstructor(new Class[]{KeyRetrievalIntf.class, String.class});
                    lCipherObj = lConstructor.newInstance(new Object[]{pKeyRetrievalIntf, pPrefix});
                } catch (Exception e) {
                    logger.error("getPasswordClass class Name=" + pClassNameStr + ", pKeyRetrievalIntf="+pKeyRetrievalIntf +", prefix="+pPrefix, e);
                }
            }

            // Lets try to instantiate class using default constructor
            if (lCipherObj == null) {
                lConstructor = Class.forName(pClassNameStr).getConstructor(new Class[]{});
                lCipherObj = lConstructor.newInstance(new Object[]{});
            }
        }

        // check the instance of Object returned by newInstance
        if (lCipherObj instanceof Password) {
            retPassword = (Password) lCipherObj;
        }  else {
            logger.error("getPasswordClass Invalid password class Name=" + pClassNameStr + ", pKeyRetrievalIntf="+pKeyRetrievalIntf +", prefix="+pPrefix+", retPassword="+retPassword);
        }

        if (logger.isDebugEnabled())
            logger.debug("getPasswordClass class Name=" + pClassNameStr + ", pKeyRetrievalIntf="+pKeyRetrievalIntf +", prefix="+pPrefix+", retPassword="+retPassword);

        return retPassword;
    }

    /**
     * Encrypt given string. Retunred string is guaranteed to be in BASE64 format
     *
     * @param toEncrypt string to encrypt
     * @return encrypted BASE64 string
     */
    public String encrypt(String toEncrypt) {
        if (StringUtil.isEmpty(toEncrypt)) {
            throw new IllegalArgumentException("unencrypted string was null or empty");
        }
        return mCipher.encrypt(toEncrypt);
    }

    /**
     * Decrypt a given encrypted string
     *
     * @param encryptedString encrypted strring
     * @return decryptedString decrypted string
     */
    public String decrypt(String encryptedString) {
        if (StringUtil.isEmpty(encryptedString)) {
            return encryptedString;
        }
        return mCipher.decrypt(encryptedString);
    }

    /**
     * Returns true if there were no errors during Cipher initialization
     * @return
     */
    public static boolean isCipherInitialized() {
    	try {
	    	//Force initialization if not initialized already
	    	getCipher();
    	} catch (Throwable t) {
    		logger.error("Error during Cipher Initialization. Setting isCipherInitialized flag to false", t);
    		isCipherInitialized = false;
    	}
    	return isCipherInitialized;
    }
    
    public String toString() {
        return "BharosaCipher: Password [" + mCipher + "] Key [" + mKeyStr + "]";
    }

}