package com.bharosa.common.util.cipher;

/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.BharosaPropertyBoolean;
import com.bharosa.common.util.Password;
import com.bharosa.common.util.StringUtil;
import com.bharosa.common.logger.Logger;
import com.bharosa.common.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEParameterSpec;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;

/**
 * @author Atul V
 *         Aug 29, 2007
 */
public class DESCipher implements Password {

    static private Logger logger = Logger.getLogger(DESCipher.class);

    static final BharosaPropertyBoolean useDefaultProvider
            = new BharosaPropertyBoolean("bharosa.security.provider.use.default", false);

    //	encryption variables
    Key key = null;
    PBEParameterSpec ps = null;
    byte[] salt = {(byte) 0xa3, (byte) 0x21, (byte) 0x24, (byte) 0x2c,
            (byte) 0xf2, (byte) 0xd2, (byte) 0x3e, (byte) 0x19};

    private final Cipher eCipher;
    private final Cipher dCipher;

    private String mPrefix;

    public DESCipher(KeyRetrievalIntf pKeyRetrievalIntf, String pPrefix) {

        byte[] mKeyBytes;
        if (pKeyRetrievalIntf != null) {
            mKeyBytes = pKeyRetrievalIntf.getKeyBytes();
            key = generateKey(mKeyBytes); //pKeyRetrievalIntf.getKey();
        }
        if (key == null) {
            String lMsg = "Could not initialize DESCipher with pKeyRetrievalIntf [" + pKeyRetrievalIntf + "]";
            throw new RuntimeException(lMsg);
        }
        mPrefix = pPrefix;
        //initialize encryption
        try {
            ps = new PBEParameterSpec(salt, 5);

            eCipher = Cipher.getInstance("PBEWithMD5AndDES/CBC/PKCS5Padding");
            eCipher.init(Cipher.ENCRYPT_MODE, key, ps);

            dCipher = Cipher.getInstance("PBEWithMD5AndDES/CBC/PKCS5Padding");
            dCipher.init(Cipher.DECRYPT_MODE, key, ps);

        } catch (Exception e) {
            logger.fatal("Error initializing encryption: ", e);
            throw new RuntimeException(e);
        }
    }

    private Key generateKey(byte[] pKeyBytes) {
        Key lKey = null;
        try {
            SecretKeyFactory kf = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
            lKey = kf.generateSecret(new javax.crypto.spec.PBEKeySpec((new String(pKeyBytes, UNICODE_FORMAT)).toCharArray()));
        } catch (Exception e) {
            logger.error("Error retrieving the Key for DES encryption", e);
        }
        return lKey;
    }

    public String encrypt(String password) {
        synchronized (eCipher) {
            try {
                byte[] utf8 = password.getBytes();
                byte[] enc = eCipher.doFinal(utf8);
                return mPrefix + new String(Base64.encodeBase64(enc));
            }
            catch (Throwable e) {
                try {
                    eCipher.init(Cipher.ENCRYPT_MODE, key, ps);
                } catch (InvalidKeyException e1) {
                    logger.error("encrypt failed to re-init the cipher after error", e1);
                } catch (InvalidAlgorithmParameterException e1) {
                    logger.error("encrypt failed to re-init the cipher after error", e1);
                }
                logger.error("Error encrypting, password length=" + (password != null ? password.length() : 0), e);
                throw new SecurityException("EncryptionException. error=" + e.toString());
            }
        }
    }

    public String decrypt(String password) {
        synchronized (dCipher) {
            try {
                if (!StringUtil.isEmpty(mPrefix)) {
                    if (!password.startsWith(mPrefix)) {
                        if (logger.isDebugEnabled()) logger.debug("decrypt invalid prefix=" + mPrefix + ", supplied="+password);
                        return password;
                    }
                    if (password.equals(mPrefix)) {
                        logger.info("decrypt nothing to decrypt prefix=" + mPrefix + ", supplied="+password);
                        return password;
                    } else {
                        password = password.substring(mPrefix.length());
                    }
                }                
                byte[] dec = Base64.decodeBase64(password.getBytes());
                byte[] utf8 = dCipher.doFinal(dec);
                return new String(utf8, UNICODE_FORMAT);            
            } 
            catch (Throwable e) {
                try {
                    dCipher.init(Cipher.DECRYPT_MODE, key, ps);
                } catch (InvalidKeyException e1) {
                    logger.error("decrypt failed to re-init the cipher after error", e1);
                } catch (InvalidAlgorithmParameterException e1) {
                    logger.error("decrypt failed to re-init the cipher after error", e1);
                }
                logger.error("Error decrypting.", e);
                throw new SecurityException("DecryptionException. error=" + e.toString());
            }
        }
    }
}
