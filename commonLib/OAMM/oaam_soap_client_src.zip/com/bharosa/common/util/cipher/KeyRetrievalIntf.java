package com.bharosa.common.util.cipher;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * This is the interface for implementing a class which 
 * is responsible for Key retrieval. 
 * @author Atul V 
 * Aug 30, 2007
 */
public interface KeyRetrievalIntf {

    static final String DEFAULT_ENCODING = "UTF-8";

    /**
	 * This method returns the key bytes required for encryption.
     * Invoked everytime key is required. Implementation need to cache the key as applicable
	 * @return a <code>byte[]</code> 
	 */
	public byte[] getKeyBytes();
	
}
