package com.bharosa.common.util.cipher;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * @author Atul V
 *         Sep 14, 2007
 */
public class ClientKeyRetrieval implements KeyRetrievalIntf {

    private int mAlgorithmId = -1;
    private byte[] mKeyBytes;

    public ClientKeyRetrieval(int pAlgorithmId, byte[] pKeyBytes) {
        this.mKeyBytes = pKeyBytes;
        this.mAlgorithmId = pAlgorithmId;
    }

    public byte[] getKeyBytes() {
        return mKeyBytes;
    }

    public String toString() {
        return "AlgorithmId=" + mAlgorithmId + ", KeyBytes length=" + (mKeyBytes != null ? mKeyBytes.length : 0);
    }
}