package com.bharosa.common.util.cipher;

import com.bharosa.common.util.BharosaPropertyInt;
import com.bharosa.common.util.Password;
import com.bharosa.common.util.StringUtil;
import com.bharosa.common.logger.Logger;
import com.bharosa.common.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.spec.KeySpec;

/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
/**
 * @author Atul V
 *         Aug 29, 2007
 */
public class DESedeCipher implements Password {

    private static Logger logger = Logger.getLogger(DESedeCipher.class);
    private static final String DESEDE_ENCRYPTION_SCHEME = "DESede";

    private final Cipher mEncryptCipher;
    private final Cipher mDecryptCipher;
    private final String mPrefix;
    private Key mKey = null;

    private static final BharosaPropertyInt mMinKeySize = new BharosaPropertyInt("tracker.cipher.desede.minkeysize", 24);

    protected static String PROP_CLIENT_CIPHER_KEY = "bharosa.cipher.client.key";

    public DESedeCipher(KeyRetrievalIntf pKeyRetrievalIntf, String pPrefix) {
        byte[] mKeyBytes;
        if (pKeyRetrievalIntf != null) {
            mKeyBytes = pKeyRetrievalIntf.getKeyBytes();
            mKey = generateKey(mKeyBytes);
        }

        if (mKey == null) {
            String lMsg = "Could not initialize DESedeCipher with pKeyRetrievalIntf [" + pKeyRetrievalIntf + "]";
            throw new RuntimeException(lMsg);
        }

        mPrefix = pPrefix != null ? pPrefix.trim() : "";
        try {
            mEncryptCipher = Cipher.getInstance(DESEDE_ENCRYPTION_SCHEME);
            mEncryptCipher.init(Cipher.ENCRYPT_MODE, mKey);

            mDecryptCipher = Cipher.getInstance(DESEDE_ENCRYPTION_SCHEME);
            mDecryptCipher.init(Cipher.DECRYPT_MODE, mKey);
        } catch (Exception e) {
            logger.error("Error instantiating DESede cipher with key", e);
            throw new RuntimeException(e);
        }
    }

    private Key generateKey(byte[] pKey) {
        if (pKey.length < mMinKeySize.getValue()) {
            throw new IllegalArgumentException("Encryption key is less than " + mMinKeySize.getValue() + " characters");
        }
        SecretKey key = null;
        try {
            KeySpec keySpec = new DESedeKeySpec(pKey);
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DESEDE_ENCRYPTION_SCHEME);
            key = keyFactory.generateSecret(keySpec);
        } catch (Exception e) {
            logger.error("Error generating the Key for DESede encryption", e);
        }
        return key;
    }

    public String encrypt(String password) {
        String retResult;
        if (StringUtil.isEmpty(password))
            throw new IllegalArgumentException("unencrypted string was null or empty");

        synchronized (mEncryptCipher) {
            try {
                byte[] text = password.getBytes(UNICODE_FORMAT);
                byte[] encryptedText = mEncryptCipher.doFinal(text);
                retResult = mPrefix + new String(Base64.encodeBase64(encryptedText));                
            } catch (Throwable e) {
                logger.error("encrypt password length="+(password != null ? password.length() : 0), e);
                try {
                    mEncryptCipher.init(Cipher.ENCRYPT_MODE, mKey);
                } catch (InvalidKeyException e1) {
                    logger.error("encrypt reinit error. Cipher may not be usable restart the server if errors persist", e1);
                }
                throw new RuntimeException(e);
            }
        }
        return retResult;
    }

    public String decrypt(String password) {
        String retResult;
        if (StringUtil.isEmpty(password))
            return password;

        synchronized (mDecryptCipher) {
            try {
                if (!StringUtil.isEmpty(mPrefix)) {
                    if (!password.startsWith(mPrefix)) {
                        if (logger.isDebugEnabled()) logger.debug("decrypt invalid prefix=" + mPrefix + ", supplied="+password);
                        return password;
                    }
                    if (password.equals(mPrefix)) {
                        logger.info("decrypt nothing to decrypt prefix=" + mPrefix + ", supplied="+password);
                        return password;
                    } else
                        password = password.substring(mPrefix.length());
                }                                
                byte[] cleartext = Base64.decodeBase64(password.getBytes());
                byte[] ciphertext = mDecryptCipher.doFinal(cleartext);
                retResult = new String(ciphertext, UNICODE_FORMAT);
            } catch (Throwable e) {
                try {
                    mDecryptCipher.init(Cipher.DECRYPT_MODE, mKey);
                } catch (InvalidKeyException e1) {
                    logger.error("decrypt reinit error. Cipher may not be usable restart the server if errors persist", e1);
                }
                logger.error("decrypt error decrypting [" + password + "]", e);
                throw new RuntimeException(e);
            }
        } // end synchronized
        return retResult;
    }

}
