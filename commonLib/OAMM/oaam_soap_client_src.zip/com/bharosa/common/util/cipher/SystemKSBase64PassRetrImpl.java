package com.bharosa.common.util.cipher;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
import com.bharosa.common.util.Base64;

/**
 * @author Atul V Sep 18, 2007
 */
public class SystemKSBase64PassRetrImpl extends SystemKSPassRetrImpl {

    public SystemKSBase64PassRetrImpl(Integer pAlgorithmId){
        super(pAlgorithmId);
    }

    public String getKeyPassword() {
        return decode(super.getKeyPassword());
    }

    public String getKeyStorePassword() {
        return decode(super.getKeyStorePassword());
    }

    private String decode(String toDecode) {
        try {
            String decoded = Base64.decodeBase64(toDecode);
            if (decoded != null && !decoded.trim().equals(""))
                toDecode = decoded;
        } catch (Throwable ignore) {}
        return toDecode;
    }

}