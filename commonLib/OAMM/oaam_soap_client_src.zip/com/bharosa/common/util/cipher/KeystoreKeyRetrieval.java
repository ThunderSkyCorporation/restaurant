package com.bharosa.common.util.cipher;

import com.bharosa.common.util.*;
import com.bharosa.common.logger.Logger;

import java.lang.reflect.Constructor;
import java.security.Key;
import java.security.KeyStore;
import java.util.Hashtable;

/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
/**
 * @author Atul V
 *         Sep 18, 2007
 */
public class KeystoreKeyRetrieval implements KeyRetrievalIntf {

    private static Logger logger = Logger.getLogger(KeystoreKeyRetrieval.class);
    private int mAlgorithmId = -1;
    private byte[] mKeyBytes;
    private String mKeyStorePassword = null;
    private String mCacheKey;
    private static Hashtable cachedKeyMap = new Hashtable();

    public KeystoreKeyRetrieval(Integer pAlgorithmId) {
        mAlgorithmId = pAlgorithmId.intValue();
        init();
    }

    private void init() {
        UserDefEnumElement lEnumElement = UserDefEnum.getElement(IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM, mAlgorithmId);
        if (lEnumElement == null)
            throw new RuntimeException("Error fetching the enum for bharosa cipher algorithm=" + IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM
                    + ", encryptionAlgorithmId=" + mAlgorithmId);

        String lKSPassClassName = null;
        String lKSPassClassNameProp = null;
        try {
            lKSPassClassName = lEnumElement.getProperty("passwordRetrieval.classname");
            lKSPassClassNameProp = lEnumElement.getProperty("passwordRetrieval.classnameProperty");
            KeyStorePasswordIntf lKSPass = null;

            // Lets give preference to classnameProperty
            if (!StringUtil.isEmpty(lKSPassClassNameProp)) {
                String lClassNameStr = BharosaConfig.get(lKSPassClassNameProp);
                if (!StringUtil.isEmpty(lClassNameStr))
                    lKSPass = getKSPasswordClass(lClassNameStr);
            }

            if (lKSPass == null && !StringUtil.isEmpty(lKSPassClassName))
                lKSPass = getKSPasswordClass(lKSPassClassName);

            if (lKSPass == null)
                throw new RuntimeException("Error getting the KeyStorePassword. Make sure to specify [passwordRetrieval.classname] property for cipher the Class=" + lKSPassClassName + ", algorithmId=" +mAlgorithmId);

            mKeyStorePassword = lKSPass.getKeyStorePassword();
            String mKeyPassword = lKSPass.getKeyPassword();
            String vm =  System.getProperty("java.vm.vendor").toLowerCase().replaceAll("[ \\.]","");
            
            String keyStoreFilename = lEnumElement.getProperty("keystoreFile_" + vm);
            if( keyStoreFilename == null) {
                keyStoreFilename = lEnumElement.getProperty("keystoreFile");
            } else {
                logger.info("Using keystoreFile for vm=" + vm);
            }
            if(logger.isDebugEnabled() ) 
		logger.debug("VM=" + vm + ", Keystore file=" + keyStoreFilename);
            
            String keyStoreType = lEnumElement.getProperty("keystoreType");
            if (StringUtil.isEmpty(keyStoreType))
                keyStoreType = BharosaConfig.get("bharosa.cipher.encryption.keystore.default.type", "JCEKS");
            String keyStoreAlias = lEnumElement.getProperty("alias");
            if (StringUtil.isEmpty(keyStoreAlias)) {
                logger.error("getAlias Error no alias for encryption algorithm [" + mAlgorithmId + "]");
                throw new RuntimeException("No alias for encryption algorithm [" + mAlgorithmId + "]");
            }

            // Cache fore next use
            mCacheKey = keyStoreFilename + "-" + keyStoreType + "-" + (mKeyPassword == null ?"":Base64.encodeBase64(mKeyPassword)) + "-" + keyStoreAlias;
            byte[] keyBytes = (byte[]) cachedKeyMap.get(mCacheKey);
            if (keyBytes == null) {
                KeyStore keyStore = getKeystore(keyStoreFilename, keyStoreType);
                keyBytes = getKey(keyStore, mKeyPassword, keyStoreAlias);
                cachedKeyMap.put(mCacheKey, keyBytes);
            }

            mKeyBytes = keyBytes;
        } catch (Exception e) {
            logger.error("Error init algorithm=" + mAlgorithmId + ", lKSPassClassName=" + lKSPassClassName + ", lKSPassClassNameProp=" + lKSPassClassNameProp, e);
        }
    }

    public byte[] getKeyBytes() {
        return mKeyBytes;
    }

    /**
     * Extracts the key from the keystore
     *
     * @param pKeyStore keystore
     * @param pPassword password
     * @param pAlias    alias
     * @return a <code>byte[]</code> representing the Key
     */
    private byte[] getKey(KeyStore pKeyStore, String pPassword, String pAlias) {
        byte[] retKey = null;
        try {
            if (logger.isDebugEnabled())
                logger.debug("getKey pAlias=" + pAlias + ", alogrithmId=" + mAlgorithmId);
            if (pKeyStore.isKeyEntry(pAlias)) {
                if (logger.isDebugEnabled())
                    logger.debug("getKey has entry pAlias=" + pAlias + ", alogrithmId=" + mAlgorithmId);
                Key lKey = pKeyStore.getKey(pAlias, pPassword.toCharArray());
                retKey = lKey.getEncoded();
            }
            if (retKey == null) {
                logger.error("Key not found for alias=" + pAlias + ", alogrithmId=" + mAlgorithmId, new Throwable().fillInStackTrace());
            } else {
                if (logger.isDebugEnabled())
                    logger.debug("getKey returning entry pAlias=" + pAlias + ", alogrithmId=" + mAlgorithmId);
            }
        } catch (Exception e) {
            logger.error("Exception while retrieving the Key pAlias=" + pAlias + ", alogrithmId=" + mAlgorithmId, e);
        }
        return retKey;
    }

    /**
     * This method fetches a Keystore from the classpath
     * based on the filename
     *
     * @param pKeyStoreFilename KeyStore file name
     * @param pType type of KeyStore
     * @return a <code>Keystore</code> object
     */
    private KeyStore getKeystore(String pKeyStoreFilename, String pType) {
        String lPassword = mKeyStorePassword;
        KeyStore retKeyStore = null;
        try {
            retKeyStore = KeyStore.getInstance(pType);
            retKeyStore.load(FileUtil.getInputStream(pKeyStoreFilename), lPassword.toCharArray());
        } catch (Exception e) {
            logger.error("getKeystore error Type=" + pType + ", KeyStoreFilename=" + pKeyStoreFilename
                    + ", lPassword length=" + (lPassword != null ? lPassword.length() : 0), e);
        }
        return retKeyStore;
    }

    /**
     * Instantiates KeystorePasswordIntf Object based on the Classname String.
     *
     * @param pClassNameStr class name
     * @return a <code>KeystorePasswordIntf</code> object
     */
    private KeyStorePasswordIntf getKSPasswordClass(String pClassNameStr) {
        if (logger.isDebugEnabled())
            logger.debug("getKSPasswordClass : Instantiating : ClassName [" + pClassNameStr + "]");
        Constructor lConstructor;
        Object lCipherObj = null;
        if (!StringUtil.isEmpty(pClassNameStr)) {
            try {
                Integer algorithmId = new Integer(mAlgorithmId);
                lConstructor = Class.forName(pClassNameStr).getConstructor(new Class[]{algorithmId.getClass()});
                lCipherObj = lConstructor.newInstance(new Object[]{algorithmId});
            } catch (Exception e) {
                logger.error("getKSPasswordClass error Instantiating class name=" + pClassNameStr, e);
            }
        }
        KeyStorePasswordIntf retKSPassword = (KeyStorePasswordIntf) lCipherObj;
        if (logger.isDebugEnabled())
            logger.debug("getKSPasswordClass Instantiating " + pClassNameStr
                    + " Returning KeystorePasswordIntf Object [" + retKSPassword + "]");
        return retKSPassword;
    }

    public String toString() {
        return mCacheKey;
    }
}
