package com.bharosa.common.util.cipher;

import com.bharosa.common.logger.Logger;

import com.bharosa.common.util.*;

/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
/**
 * @author Atul V
 *         Sep 14, 2007
 */
public class SystemKeyRetrieval implements KeyRetrievalIntf {

    private static Logger logger = Logger.getLogger(SystemKeyRetrieval.class);
    private int mAlgorithmId = -1;
    private String mAlias;
    private byte[] mKeyBytes;

    public SystemKeyRetrieval(Integer pAlgorithmId) {
        mAlgorithmId = pAlgorithmId.intValue();
        init();
    }

    private void init() {
        UserDefEnumElement lEnumElement = UserDefEnum.getElement(IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM, mAlgorithmId);
        if (lEnumElement == null)
            throw new RuntimeException("isValidAlgorithm Error fetching the enum for AlgorithmId=" + mAlgorithmId);

        mAlias = lEnumElement.getProperty("alias");
        if (StringUtil.isEmpty(mAlias)) {
            logger.error("alias required. algorithm=" + mAlgorithmId + ", alias=" + mAlias);
            throw new RuntimeException("Invalid encryption algorithm. alias required algorithm=" + mAlgorithmId + ", alias=" + mAlias);
        }
        try {
            String key = BharosaConfig.get(mAlias);
            if (StringUtil.isEmpty(key))
                throw new RuntimeException("Invalid system key alias=" + mAlias + ", AlgorithmId=" + mAlgorithmId);
            mKeyBytes = key.getBytes(DEFAULT_ENCODING);
        } catch (Exception e) {
            logger.error("init Error setting the default system key for encryption algorithm=" + mAlgorithmId + ", alias=" + mAlias, e);
        }
    }

    public byte[] getKeyBytes() {
        return mKeyBytes;
    }

    public String toString() {
        return mAlias;
    }
}
