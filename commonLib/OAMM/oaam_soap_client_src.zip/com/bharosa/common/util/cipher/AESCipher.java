package com.bharosa.common.util.cipher;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.util.Base64;
import com.bharosa.common.util.Password;
import com.bharosa.common.util.StringUtil;
import com.bharosa.common.logger.Logger;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.Key;

/**
 * Support for Advanced Encryption Standard
 * <p/>
 * Note: To use 192, 256 bit keys,  Unlimited Strength policy files are required with Java.
 * These can be downloaded from Java provider.
 * Default java installations are shipped with strong policy files with default support for 128 bit key
 *
 * @author Atul V
 *         Aug 29, 2007
 */
public class AESCipher implements Password {

    static private Logger logger = Logger.getLogger(AESCipher.class);
    private Key mKey;
    private final Cipher mEncryptCipher;
    private final Cipher mDecryptCipher;
    private String mPrefix;

    public AESCipher(KeyRetrievalIntf pBharosaEncryptionIntf, String pPrefix) {
        if (pBharosaEncryptionIntf != null) {
            byte[] mKeyBytes = pBharosaEncryptionIntf.getKeyBytes();
            mKey = generateKey(mKeyBytes);
        }
        if (mKey == null) {
            String lMsg = "Could not initialize AESCipher with pKeyRetrievalIntf [" + pBharosaEncryptionIntf + "]";
            throw new RuntimeException(lMsg);
        }
        mPrefix = pPrefix;
        try {
            mEncryptCipher = Cipher.getInstance("AES");
            mEncryptCipher.init(Cipher.ENCRYPT_MODE, mKey);

            mDecryptCipher = Cipher.getInstance("AES");
            mDecryptCipher.init(Cipher.DECRYPT_MODE, mKey);
        } catch (Exception e) {
            logger.fatal("Error creating the AES Ciphers", e);
            throw new RuntimeException(e);
        }
    }

    private Key generateKey(byte[] pKey) {
        return new SecretKeySpec(pKey, "AES");
    }

    public String encrypt(String password) {
        synchronized (mEncryptCipher) {
            String retResult = "";
            try {
                byte[] encrypted = mEncryptCipher.doFinal((password).getBytes());
                retResult = mPrefix + new String(Base64.encodeBase64(encrypted));
            } catch (Throwable ex) {
                try {
                    mEncryptCipher.init(Cipher.ENCRYPT_MODE, mKey);
                } catch (InvalidKeyException e) {
                    logger.error("Failed re-init the encryption cipher", e);
                }
                logger.error("Failed to encrypt", ex);
            }
            return retResult;
        }
    }

    public String decrypt(String password) {
        String retResult = "";
        synchronized (mDecryptCipher) {
            try {
                if (!StringUtil.isEmpty(mPrefix)) {
                    if (!password.startsWith(mPrefix)) {
                        if (logger.isDebugEnabled()) logger.debug("decrypt invalid prefix=" + mPrefix + ", supplied="+password);
                        return password;
                    }
                    if (password.equals(mPrefix)) {
                        logger.info("decrypt nothing to decrypt prefix=" + mPrefix + ", supplied="+password);
                        return password;
                    } else {
                        password = password.substring(mPrefix.length());
                    }
                }
                byte[] encrypted = Base64.decodeBase64(password.getBytes());
                byte[] original = mDecryptCipher.doFinal(encrypted);
                retResult = new String(original, UNICODE_FORMAT);
            } catch (Throwable ex) {
                try {
                    mDecryptCipher.init(Cipher.DECRYPT_MODE, mKey);
                } catch (InvalidKeyException e) {
                    logger.error("Failed to re-init decrypt cipher ", e);
                }
                logger.error("Failed to decrypt", ex);
            }
        }
        return retResult;
    }

}
