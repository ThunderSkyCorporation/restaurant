package com.bharosa.common.util.cipher;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
/**
 * @author Atul V 
 * Sep 18, 2007
 */
public interface KeyStorePasswordIntf {

	/**
	 * This method returns the password to open
	 * the keystore file for encryption key retrieval
	 * @return a cleartext password
	 */
	public String getKeyStorePassword();
	
	/**
	 * This method returns the password to open
	 * the key from the keystore
	 * @return a cleartext password
	 */
	public String getKeyPassword();
}
