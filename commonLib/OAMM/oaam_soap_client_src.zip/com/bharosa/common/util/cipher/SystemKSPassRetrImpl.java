package com.bharosa.common.util.cipher;

import com.bharosa.common.util.IBharosaConstants;
import com.bharosa.common.util.UserDefEnum;

/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
/**
 * @author Atul V
 *         Sep 18, 2007
 */
public class SystemKSPassRetrImpl implements KeyStorePasswordIntf {

	private int algorithmId;
	
	public SystemKSPassRetrImpl(Integer pAlgorithmId){
		this.algorithmId = pAlgorithmId.intValue();
	}
	
    public String getKeyPassword() {
        return UserDefEnum.getPropertyByElementValue(
                IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM, algorithmId, "aliasPassword");

    }

    public String getKeyStorePassword() {
        return UserDefEnum.getPropertyByElementValue(
                IBharosaConstants.BHAROSA_CIPHER_ENCRYPTION_ALGORITHM, algorithmId, "keystorePassword");
    }
}
