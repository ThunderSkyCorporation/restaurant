package com.bharosa.common.util;
/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;

import java.io.*;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * This has some utility methods for file operations
 *
 * @author bosco
 */

public class FileUtil {
    static Logger logger = Logger.getLogger(FileUtil.class);

    static public String readTextFile(File inFile) throws IOException {
        FileInputStream f = new FileInputStream(inFile);
        int inBytes = f.available();
        byte inBuf[] = new byte[inBytes];
        try {
            int i = f.read(inBuf, 0, inBytes);
            if (logger.isDebugEnabled())
                logger.debug("readTextFile read " + i + " file=" + inFile);
        } finally {
          closeStream(f);
        }
        return new String(inBuf);
    }

    /**
     * This method gets the File object for the fileName/filePath. The method will try to find the file assuming it is
     * an absolute path. If it fails, then it will look in the class path to get absolute file path.
     *
     * Additionally checks in bharosa_properties sub directory
     *
     * @param fileName The file name. It could contain the part of the file path also.
     * @return a <code>File</code> object if the file is found. Else it will return a null object.
     * @see #getURL(String)
     */
    public static File getFile(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            URL url = getURL(fileName);
            if (url != null) {
                String urlPath = url.getPath();
                urlPath = urlPath.replaceAll("%20", " ");
                if (logger.isDebugEnabled())
                    logger.debug("getfile found file [" + fileName +
                                 "] resource [" + urlPath + "]");
                file = new File(urlPath);
                if (!file.exists()) {
                    logger.debug("getFile File not found in [" +
                                 url.getPath() + "]");
                    return null;
                }
            } else {
                logger.info("getFile file [" + fileName +
                            "] not found in disk nor in classpath");
                // Returning null, since file not found in disk or in classpath.
                return null;
            }
        }
        /*
            Don't call BharosaConfig here, because BharosaConfig::init() calls this
            and the code can go in a loop.
          if( file != null ) {
              if( logger.isDebugEnabled()
                  && BharosaConfig.getBoolean("bharosa.logger.debug.full", false)) {
                  logger.debug("File " + fileName
                               + " found in "
                               + file.getAbsolutePath());
              }
          }
          */
        return file;
    }

    public static FileMonitor setFileMonitor(String pStrFilename,
                                             FileMonitorCallBack pCallback,
                                             int pSeconds) throws IOException {
        URL lFileUrl = getURL(pStrFilename);
        FileMonitor lMonitor = null;
        if (lFileUrl != null) {
            File lFile = new File(lFileUrl.getPath().replaceAll("%20", " "));
            if (lFile.exists()) {
                lMonitor = new FileMonitor(lFile, pCallback, pSeconds * 1000);
            }
        }
        return lMonitor;
    }

    public static FileMonitor setFileMonitorSafe(String pStrFilename,
                                                 FileMonitorCallBack pCallback,
                                                 int pSeconds) {
        FileMonitor lMonitor = null;
        try {
            lMonitor = setFileMonitor(pStrFilename, pCallback, pSeconds);
        } catch (IOException e) {
            logger.warn("Error setting file monitor: " + pStrFilename, e);
        } // end of try-catch
        return lMonitor;
    }

    public static URL getURL(String fileName) {

        File file = new File(fileName);
        URL url = null;
        if (file.exists()) {
            try {
                url = file.toURL();
            } catch (MalformedURLException e) {
                logger.error("getURL ", e);
            }
        }

        if (url == null) {
            String fileNameNormalized = fileName.replaceAll("\\\\", "/");
            //If not found, check the classpath
            ClassLoader classLoader = getClassLoader();

            if (classLoader == null) {
                logger.info("getFile():ClassLoader cannot be retrieved from the current thread. This could be because of security reason. Dynamic loading of properties file won't work. Please hardcode the fullpath of all properties files.");
            } else {
                if (!fileName.equals(fileNameNormalized)) {
                    if (logger.isDebugEnabled())
                        logger.debug("getURL trying to get normalized filePath [" +
                                     fileNameNormalized + "]");
                    url = classLoader.getResource(fileNameNormalized);
                    if (url == null) {
                        String altFileName =
                            "bharosa_properties/" + fileNameNormalized;
                        if (logger.isDebugEnabled())
                            logger.debug("getURL trying to look for normalized file [" +
                                         altFileName + "]");
                        url = classLoader.getResource(altFileName);
                    }
                }
                if (url == null) {
                    if (logger.isDebugEnabled())
                        logger.debug("getURL trying to get filePath [" +
                                     fileName + "]");
                    url = classLoader.getResource(fileName);
                    if (url == null) {
                        String altFileName = "bharosa_properties/" + fileName;
                        if (logger.isDebugEnabled())
                            logger.debug("getURL trying to look for file [" +
                                         altFileName + "]");
                        url = classLoader.getResource(altFileName);
                    }
                }
            }
        }
        return url;
    }

    private static ClassLoader getClassLoader() {
        ClassLoader classLoader =
            Thread.currentThread().getContextClassLoader();
        if (classLoader == null) {
            if (logger.isDebugEnabled())
                logger.debug("Trying class loader of " + FileUtil.class);
            classLoader = FileUtil.class.getClassLoader();
        }
        return classLoader;
    }

    public static InputStream getInputStream(String pFilename) throws IOException {
        InputStream lInputStream = null;
        File lFile = getFile(pFilename);
        if (lFile != null && lFile.exists()) {
            if (logger.isDebugEnabled())
                logger.debug("Found file " + pFilename + ", filePath=" +
                             lFile.getAbsolutePath());
            lInputStream = new FileInputStream(lFile);
        } else {
            if (logger.isDebugEnabled())
                logger.debug("Trying load file as resource file . FileName=" +
                             pFilename);
            try {
                ClassLoader classLoader = getClassLoader();
                if (classLoader == null) {
                    logger.info("Class loader is null, so won't try reading file " +
                                pFilename + " from resource stream");
                } else {
                    lInputStream = classLoader.getResourceAsStream(pFilename);
                    if (lInputStream == null) {
                        String altFileName = "bharosa_properties/" + pFilename;
                        if (logger.isDebugEnabled())
                            logger.debug("Opening " + altFileName +
                                         " as resource");
                        lInputStream =
                                classLoader.getResourceAsStream(altFileName);
                    }
                }
            } catch (Throwable t) {
                if (logger.isDebugEnabled())
                    logger.debug("Error while loading file " + pFilename +
                                 " as resource");
            }
        }
        if (lInputStream != null) {
            if (logger.isDebugEnabled())
                logger.debug("Inputstream opened for " + pFilename);
        }
        return lInputStream;
    }

    public static InputStreamReader getInputStreamReader(String pFilename) throws IOException {
        InputStreamReader lReader = null;
        File lFile = getFile(pFilename);
        if (lFile != null && lFile.exists()) {
            if (logger.isDebugEnabled())
                logger.debug("Found file " + pFilename + ", filePath=" +
                             lFile.getAbsolutePath());
            try {
                lReader = new FileReader(lFile);
            } catch (Throwable t) {
                if (logger.isDebugEnabled())
                    logger.debug("Error opening the file using FileReader. Will try to load using resource reader. file=" +
                                 pFilename + ". error=" + t.toString());
                try {
                    ClassLoader classLoader = getClassLoader();
                    if (classLoader == null) {
                        logger.info("Class loader is null, so won't try reading file " +
                                    pFilename + " from resource stream");
                    } else {
                        InputStream lInputStream = getInputStream(pFilename);
                        if (lInputStream != null) {
                            lReader = new InputStreamReader(lInputStream);
                        }
                    }
                } catch (Throwable tt) {
                    if (logger.isDebugEnabled())
                        logger.debug("Error while loading file " + pFilename +
                                     " as resource. error=" + tt.toString());
                }
            }
        }
        return lReader;
    }

    public static String readFileToString(String fileName) throws IOException {
        if (StringUtil.isEmpty(fileName)) {
            logger.error("Filename is empty.",
                         new Throwable().fillInStackTrace());
            return null;
        }

        InputStream iStr = getInputStream(fileName);
        if (iStr == null) {
            logger.error("Unable to locate file="+fileName);
            return null;
        }
        
        ByteArrayOutputStream oStr = new ByteArrayOutputStream();
        try {
            int bufSize = 1024 * 4;
            byte[] buffer = new byte[bufSize];

            while (iStr.available() > 0) {
                int len = iStr.read(buffer);
                if (len == -1)
                    break;

                oStr.write(buffer, 0, len);
            }
        } finally {
          closeStream(iStr);
          closeStream(oStr);
        }
        return oStr.toString();
    }

    public static boolean isImageFile(String fileName) {
        return fileName.toLowerCase().endsWith(".jpg") ||
            fileName.toLowerCase().endsWith(".png") ||
            fileName.toLowerCase().endsWith(".gif");
    }

    public static boolean isXmlFile(String fileName) {
        return fileName.toLowerCase().endsWith(".xml");
    }

    public static boolean isZipFile(String fileName) {
        return fileName.toLowerCase().endsWith(".zip");
    }

    public static boolean isGZipFile(String fileName) {
        return fileName.toLowerCase().endsWith(".gz");
    }

    public static boolean isPropertiesFile(String fileName) {
        return fileName.toLowerCase().endsWith(".properties");
    }
    
    public static void closeStream(Closeable closeable ) {
      if (closeable != null) {
        try {
          closeable.close();
        } catch (Throwable t) {
          logger.info("Error closing Stream", t);
        }
      }
    } // end closeStream
}

