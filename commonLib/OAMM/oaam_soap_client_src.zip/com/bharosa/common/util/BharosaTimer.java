package com.bharosa.common.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;

import java.util.Timer;

/**
 * This is a wrapper class to take manage Timer.
 * @author bosco
 */

public class BharosaTimer extends Timer {
	static Logger  logger = Logger.getLogger(BharosaTimer.class);
	static BharosaTimer instance = null;
	static Object lock = new Object();
	private BharosaTimer( ) {
		super(true);
	}
	
	public static BharosaTimer getInstance( ) {
		if( instance == null ) {
			synchronized( lock ) {
				if( instance == null ) {
					instance = new BharosaTimer();
				}
			}
		}
		return instance;
	}

}
