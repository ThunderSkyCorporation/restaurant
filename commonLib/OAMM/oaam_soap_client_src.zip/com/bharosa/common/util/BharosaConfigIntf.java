/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
package com.bharosa.common.util;

import java.util.Map;

/**
 * 
 * @author kuldeep <kuldeep@bharosa.com>
 * Date: Jul 11, 2007
 * Time: 10:30:21 AM
 *
 */
public interface BharosaConfigIntf {

    /**
     * This method is used to register a callback, which is called everytime the property file is reloaded.
     * 
     * @param reloadListener
     */
    public void registerReloadCallback(BharosaConfigReloadListener reloadListener) ;

    /**
     * This method is used to remove a Config reload callback.
     * 
     * @param reloadListener
     */
    public void removeReloadCallback(BharosaConfigReloadListener reloadListener) ;

	/**
	 * Initialize load object 
	 */
	public void init() ;
	
	/**
	 * Decrypt Properties present in the Load
	 * 
	 */
	public void decryptProperties() ;
	
	/**
     * Be absolutely sure before setting this value. This will override values read from the property file.
     *
     * @param propertyName Name of the property
     * @param value        Value of the property.
     */

    public void setProperty(String propertyName, String value) ;
    
    /**
     * Sets passed BharosaProperty in the BharosaConfig 
     * 
     * @param pBharosaProperty
     * @return
     */
    public void setProperty(BharosaProperty pBharosaProperty);
    
	/**
     * Removes property from db
     *
     * @param propertyName Name of the property
     */

    public void removeProperty(String propertyName) ;
    
    /**
     * Adds property to Map
     * 
     * @param pProperty
     */
    public void addProperty(BharosaProperty pProperty) ; 
    	
	/**
	 * Returns value for the given property name
	 * 
	 * @param property name
	 * @return value for the given property name
	 */
	public String getPropertyValue(String name);

	/**
	 * Returns Property object for the given name
	 * 
	 * @param property name
	 * @return Property object for the given name
	 */
	public BharosaProperty getProperty(String name);
	
	/**
     * Describe <code>getValue</code> method here.
     * <p/>
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index0_value value to be inserted at index 0
     * @param index1_value value to be inserted at index 1
     * @param index2_value value to be inserted at index 2
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    public String getValue(String propertyName, String index0_value,
                                  String index1_value, String index2_value) ;

    /**
     * Describe <code>getValue</code> method here.
     * <p/>
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index0_value value to be inserted at index 0
     * @param index1_value value to be inserted at index 1
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    public String getValue(String propertyName, String index0_value,
                                  String index1_value) ;

    /**
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index0_value value to be inserted at index 0
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    public String getValue(String propertyName, String index0_value) ;

    /**
     * insert values in the property_value at the index placeholders
     *
     * @param propertyValue a <code>String</code> value
     * @param indexVal      a <code>String</code> value
     * @param index         an <code>int</code> value
     * @return a <code>String</code> value
     */
    public String insertValue(String propertyValue, String indexVal, int index) ;

    /**
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    public String get(String propertyName) ;

    /**
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param defaultValue Default value to return if the property is not found.
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    public String get(String propertyName, String defaultValue) ;

    /**
     * This prints all the property values.
     *
     * @return propery Map as string
     */
    public String getStringRepresentation() ;

	/**
	 * Returns Map of the Properties.
	 * 
	 * @return
	 */
	public Map getMap();

	/**
	 * Returns flag to state whether property override is supported by this instance.
	 * 
	 * @return whether property override is supported or not.
	 */
	public boolean isPropertyOverrideSupported();

}
