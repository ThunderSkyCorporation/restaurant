/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
package com.bharosa.common.util;

import java.util.Map;
import java.util.regex.PatternSyntaxException;

import com.bharosa.common.logger.Logger;

public class BharosaConfigCommonImpl extends BharosaConfigCommon 
	implements BharosaConfigReloadListener {

	private Logger logger = Logger.getLogger(BharosaConfigCommonImpl.class) ;
	
	protected BharosaConfigLoadIntf bharosaConfigLoad = null ;
	
	BharosaConfigCommonImpl(BharosaConfigLoadIntf pBharosaConfigLoad) {
		logger.info("Constructing BharosaConfigCommonImpl :"
				+ " with BharosaConfigLoadIntf [" + pBharosaConfigLoad + "]") ;
		bharosaConfigLoad = pBharosaConfigLoad ;
	}
	
	public void init() {
		bharosaConfigLoad.init() ;
	}
	
	/**
	 * Decrypt Properties present in the Load
	 * 
	 */
	public void decryptProperties() {
		bharosaConfigLoad.decryptProperties();
	}

	
    /**
     * Be absolutely sure before setting this value. This will override values read from the property file.
     *
     * @param propertyName Name of the property
     * @param value        Value of the property.
     */
    public void setProperty(String propertyName, String value) {
        if (logger.isDebugEnabled()) 
            logger.debug("setProperty( name=" + propertyName + ", value=" + BharosaProperty.getMaskedValue(propertyName, value) + ")");
        bharosaConfigLoad.setProperty(propertyName, value) ;
    }
    
    /**
     * Sets passed BharosaProperty in the BharosaConfig 
     * 
     * @param pBharosaProperty
     * @return
     */
    public void setProperty(BharosaProperty pBharosaProperty) {
        if (logger.isDebugEnabled()) logger.debug("setProperty( BharosaProperty=" + pBharosaProperty);
        bharosaConfigLoad.setProperty(pBharosaProperty) ;
    }
    
    /**
     * Removes property
     *
     * @param propertyName Name of the property
     */
    public void removeProperty(String propertyName) {
        if (logger.isDebugEnabled()) logger.debug("removeProperty ( name=" + propertyName + " )");
        bharosaConfigLoad.removeProperty(propertyName);
    }
    
    /**
     * Adds property to Map
     * 
     * @param pProperty
     */
    public void addProperty(BharosaProperty pProperty) {
    	if (logger.isDebugEnabled()) logger.debug("addProperty( BharosaProperty=" + pProperty + ")");
    	bharosaConfigLoad.addProperty(pProperty) ;
    }
    	
    /**
     * Describe <code>getValue</code> method here.
     * <p/>
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index0_value value to be inserted at index 0
     * @param index1_value value to be inserted at index 1
     * @param index2_value value to be inserted at index 2
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    public String getValue(String propertyName, String index0_value,
                                  String index1_value, String index2_value) {
        String value = getValue(propertyName, index0_value, index1_value);
        return insertValue(value, index2_value, 2);
    }

    /**
     * Describe <code>getValue</code> method here.
     * <p/>
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index0_value value to be inserted at index 0
     * @param index1_value value to be inserted at index 1
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    public String getValue(String propertyName, String index0_value,
                                  String index1_value) {
        String value = getValue(propertyName, index0_value);
        return insertValue(value, index1_value, 1);
    }

    /**
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index0_value value to be inserted at index 0
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    public String getValue(String propertyName, String index0_value) {
        return insertValue(get(propertyName), index0_value, 0);
    }

    /**
     * insert values in the property_value at the index placeholders
     *
     * @param propertyValue a <code>String</code> value
     * @param indexVal      a <code>String</code> value
     * @param index         an <code>int</code> value
     * @return a <code>String</code> value
     */
    public String insertValue(String propertyValue, String indexVal, int index) {
        if (StringUtil.isEmpty(propertyValue)) {
            return "";
        }
        String indx = "{" + index + "}";
        int offset = propertyValue.indexOf(indx);
        if (offset != -1) {
            if (StringUtil.isEmpty(indexVal)) {
                indexVal = "";
            }
            try {
                String regExp = "\\{" + index + "\\}";
                propertyValue = propertyValue.replaceAll(regExp, indexVal);
            } catch (PatternSyntaxException e) {
                logger.info("Error in replacing property values for  literal value, propertyValue="+propertyValue, e);
            }
            catch (IllegalArgumentException ex) {
              logger.debug("This is WARNIN(IllegalArgument): Error in replacing property values for  literal value propertyValue:"+propertyValue, ex);
              String regExpLiteral = "{" + index + "}";
              propertyValue = propertyValue.replace(regExpLiteral, indexVal);  
            } // end of catch for IllegalArgumentException
            catch (StringIndexOutOfBoundsException siobx) {
              logger.debug("This is WARNIN(StringIndexOutOfBound): Error in replacing property values for  literal value, propertyValue: "+propertyValue, siobx);
              String regExpLiteral = "{" + index + "}";
              propertyValue = propertyValue.replace(regExpLiteral, indexVal);  
            } // end of catch for StringIndexOutOfBoundsException
        }
        return propertyValue;
    }

    /**
     * Returns Property value for the given property name
     * 
     * @param name
     * @return
     */
    public String getPropertyValue(String name) {
        return bharosaConfigLoad.getPropertyValue(name) ;
    }

    /**
     * Returns Property object for the given property name
     * 
     * @param name
     * @return
     */
    public BharosaProperty getProperty(String name) {
        return bharosaConfigLoad.getProperty(name);
    }

    /**
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    public String get(String propertyName) {
        return bharosaConfigLoad.getPropertyValue(propertyName);
    }

    /**
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param defaultValue Default value to return if the property is not found.
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    public String get(String propertyName, String defaultValue) {
        BharosaProperty prop = bharosaConfigLoad.getProperty(propertyName);
        if (prop != null) {
            return prop.getString(defaultValue);
        }
        return defaultValue;
    }

    /**
     * This prints all the property values.
     *
     * @return propery Map as string
     */
    public String getStringRepresentation() {
        return getMap().toString();
    }
    
    public Map getMap() {
    	return bharosaConfigLoad.getMap() ;
    }
    
	/**
	 * Returns flag to state whether property override is supported by this instance.
	 * 
	 * @return whether property override is supported or not.
	 */
	public boolean isPropertyOverrideSupported() {
		return bharosaConfigLoad.isPropertyOverrideSupported();
	}

}
