package com.bharosa.common.util;

import com.bharosa.common.logger.Logger;

public class ObjectUtil {

	static Logger logger = Logger.getLogger(ObjectUtil.class);

	public static boolean compareObjects(Object obj1, Object obj2) {
		if ((obj1 == null) && (obj2 == null))
			return true;
		if ((obj1 == null) || (obj2 == null))
			return false;
		return (obj1.equals(obj2));
	}
	public static Object getInstance(String className, Class shouldImplement, Object defaultValue) {
		try {
			Object result = Class.forName(className).newInstance();
			if (!shouldImplement.isInstance(result)) {
				throw new ClassCastException(className + " does not implement " + shouldImplement.getName());
			}
			return result;
		} catch (ClassCastException e) {
			logger.error(e);
		} catch (ClassNotFoundException e) {
			logger.error("Class " + className + " could not be found on the classpath.", e);
		} catch (InstantiationException e) {
			logger.error("Class " + className + " is not a concrete class.", e);
		} catch (IllegalAccessException e) {
			logger.error("Class " + className + " does not define a default public constructor.", e);
		}
		return defaultValue;
	}
}
