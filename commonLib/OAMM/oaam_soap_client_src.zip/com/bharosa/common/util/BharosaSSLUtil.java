package com.bharosa.common.util;

import com.bharosa.common.logger.Logger;

import javax.net.ssl.*;
import java.net.URL;
import java.net.MalformedURLException;
import java.io.*;
import java.security.KeyStore;

/**
 * To support SSL related issues.
 */
public class BharosaSSLUtil {
    static Logger logger = Logger.getLogger(BharosaSSLUtil.class);

    /**
     * White list the following URL
     *
     * @param urlString URL in string format
     * @return success or failure
     */
    static public boolean whiteList(String urlString) {
        try {
            URL url = new URL(urlString);
            return whiteList(url);
        } catch (MalformedURLException e) {
            logger.error("Error white listing url=" + urlString, e);
            return false;
        }
    }

    /**
     * White list the following URL
     *
     * @param url URL object
     * @return success or failure
     */
    static public boolean whiteList(URL url) {
        if (logger.isDebugEnabled())
            logger.debug("Whitelisting url=" + url.toString());
        try {
            createKeystore(url);
            return true;
        } catch (Throwable t) {
            logger.error("Error whitelisting URL=" + url.toString(), t);
        }
        return false;
    }

    /**
     * This method is used to create a temporary keystore and add the remote
     * resource's SSL certificate as trusted
     *
     * @param url URL object
     * @throws java.io.IOException If it fails to create temporary keystore file
     */
    static private void createKeystore(URL url) throws IOException {

        if (url.getProtocol().equalsIgnoreCase("HTTPS")) {
            if (!BharosaConfig.getBoolean("bharosa.accept.untrusted.ssl", true)) {
                if (logger.isDebugEnabled())
                    logger.debug("createKeystore() untrusted not allowed");
                return;
            }
            String keystore = BharosaConfig.get("bharosa.ssl.keystore");
            if (StringUtil.isEmpty(keystore)) {
                File tmpKeyStore = File.createTempFile("bharosa", "keystore");
                keystore = tmpKeyStore.getAbsolutePath();
                logger.info("Using temporary key store file " + keystore);
            }

            // Create a trust manager that does not validate certificate chains
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        public void checkClientTrusted(
                                java.security.cert.X509Certificate[] certs,
                                String authType) {
                        }

                        public void checkServerTrusted(
                                java.security.cert.X509Certificate[] certs,
                                String authType) {
                        }
                    }
            };

            // Install the all-trusting trust manager
            try {
                SSLContext sc = SSLContext.getInstance("SSL");
                sc.init(null, trustAllCerts, new java.security.SecureRandom());
                HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            } catch (Exception e) {
                logger.error("Error setting default HTTPS Socket Factory");
            }

          SSLSocket socket = null;
            try {
                // Create the client socket

                int port = 443;
                String hostname = url.getHost();
                SSLSocketFactory factory = HttpsURLConnection
                        .getDefaultSSLSocketFactory();
                socket = (SSLSocket) factory.createSocket(hostname, port);

                // Connect to the server
                socket.startHandshake();

                // Retrieve the server's certificate chain
                java.security.cert.Certificate[] serverCerts = socket
                        .getSession().getPeerCertificates();

                File tempkey = new File(keystore);
                if (!tempkey.isFile()) {
                    tempkey.createNewFile();
                }
                String keystorePassword = BharosaConfig.get("bharosa.ssl.keystore.password", "bharosa");
                addToKeyStore(tempkey, keystorePassword.toCharArray(), hostname, serverCerts[0]);

                // Close the socket in finally block
                // socket.close();
            } catch (Exception e) {
                logger.error("Error adding kep to KeyStore", e);
            }
            finally {
              safeClose(socket);
            }

            System.setProperty(BharosaConfig.get("bharosa.ssl.truststore", "javax.net.ssl.trustStore"),keystore);
            System.setProperty("https.protocols", "SSLv3");
        }

    }
    
    static private void safeClose (SSLSocket s) 
    {
        if (s != null && !s.isClosed()) {
          try {
            s.close();
          } catch (IOException e) {
            logger.warn("Exception closing the socket:", e);
          }
        }
    }

    static private void addToKeyStore(File keystoreFile, char[] keystorePassword,
                                      String alias, java.security.cert.Certificate cert) throws Exception {
        // Create an empty keystore object
        KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());

        // Load the keystore contents
        FileInputStream in = null;
        try {
            in = new FileInputStream(keystoreFile);
            keystore.load(in, keystorePassword);
        } catch (Exception e) {
            keystore.load(null, keystorePassword);
        } finally {
            FileUtil.closeStream(in);
        }

        // Add the certificate
        keystore.setCertificateEntry(alias, cert);

        // Save the new keystore contents
        FileOutputStream out = null;
        try {
          out = new FileOutputStream(keystoreFile);
          keystore.store(out, keystorePassword);
          out.close();
        } finally {
            FileUtil.closeStream(out);
        }
    }
}
