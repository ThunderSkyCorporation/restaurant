package com.bharosa.common.util;
/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * This provides the utility methods to access user defined enums.
 *
 * @author bosco
 */

public class UserDefEnumFactory implements BharosaConfigReloadListener {
    static Logger logger = Logger.getLogger(UserDefEnumFactory.class);
    static Object lock = new Object();
    static UserDefEnumFactory theInstance = null;

    Hashtable enumList = new Hashtable();
    Hashtable enumListForUI = new Hashtable();

    /**
     * Returns the instance of the UserDefEnumFactory.
     */
    static public UserDefEnumFactory getInstance() {
        if (theInstance != null) {
            return theInstance;
        }

        //We need to create care new instance
        synchronized (lock) {
            if (theInstance == null) {
                logger.info("Creating new instance of UserDefEnumFactory");
                theInstance = new UserDefEnumFactory();
            }
        }
        return theInstance;
    }

    /**
     * Returns the UserDefEnum object for the given enum string
     *
     * @param enumId The string identifier for the enum.
     */
    static UserDefEnum getEnum(String enumId) {

        return (UserDefEnum) getInstance().enumList.get(enumId);
    }

    /**
     * This method is called everytime the properties files are reloaded.
     */
    public void configReloaded() {
        logger.info("Reloading Enums...");
        loadEnums();
        logger.info("Done loading enums. Total enums=" + enumList.size());
    }

    /**
     * Loads the enums from the properties file.
     */
    synchronized protected void loadEnums()
    {
        logger.info("Loading Enums...");
        HashMap propMap = BharosaConfig.getHashMap();
        Set keySet = propMap.keySet();
        Hashtable tmpEnumList = new Hashtable();
        Hashtable tmpEnumListForUI = new Hashtable();
        long startTime = System.currentTimeMillis();
        final Map parsedMap = parseProperties(propMap);

        Iterator iter = parsedMap.keySet().iterator();
        while (iter.hasNext())
        {
            String enumId = (String) iter.next();
//            assert enumId.endsWith(".enum");
            final Map elementMap = (Map) parsedMap.get(enumId);
            String desc =  BharosaConfig.get(enumId);
            UserDefEnum enumObject = new UserDefEnum(enumId, desc);
            UserDefEnum enumObjectForUI = new UserDefEnum(enumId, desc);
            tmpEnumList.put(enumId, enumObject);
            tmpEnumListForUI.put(enumId, enumObjectForUI);
            final Iterator elementIterator = elementMap.keySet().iterator();
            while (elementIterator.hasNext())
            {
                final String elementKey = (String) elementIterator.next();
                final Map propertyMap = (Map) elementMap.get(elementKey);
                final String elementId = enumId + "." + elementKey;

                int value = BharosaConfig.getInt(elementId, -1);
                if (value < 0)
                {
                    logger.error("Enum element " + elementId
                            + " doesn't have integer value. value="
                            + BharosaConfig.get(elementId));
                    continue;
                }
                boolean elementEnabled = BharosaConfig.getBoolean(elementId + ".enabled", true);
                String elementName = BharosaConfig.get(elementId + ".name");
                if (StringUtil.isEmpty(elementName))
                {
                    logger.error("Enum element " + elementId
                            + " doesn't have name property set."
                            + elementId + ".name should be set.");
                    continue;
                }
                final Set propNamesSet = propertyMap.keySet();
                final Iterator propNamesItr = propNamesSet.iterator();
                List propNameList = new ArrayList();
                while (propNamesItr.hasNext())
                {
                    String propName = (String) propNamesItr.next();
                    if ("name".equalsIgnoreCase(propName)
                            || "description".equalsIgnoreCase(propName))
                    {
                        continue;
                    }
                    propNameList.add(propName);
                }

                enumObjectForUI.addElement(elementId, elementName, value, elementKey, propNameList);
                if (elementEnabled)
                {
                    enumObject.addElement(elementId, elementName, value, elementKey, propNameList);
                }
                else
                {
                    logger.debug("UserDefEnumElement " + elementName + ": DISABLED");
                }

            }
        }
        logger.info("Loaded " + tmpEnumList.size() + " user defined enums!!!");
        //Lets replace the global enum list
        enumList = tmpEnumList;
        enumListForUI = tmpEnumListForUI;
    }

    /**
     * Private constructor
     */
    private UserDefEnumFactory() {
        //Lets load the enums
        loadEnums();

        //Register self has property change listener.
        BharosaConfig.registerReloadListener(this);
    }

    /**
     * Returns a multi-level map
     * @see #testParseProperties()
     */
    private static Map/*String,Map*/ parseProperties(final Map props)
    {
        Map/*String,Map*/ map = new HashMap();
        final Iterator iter = props.keySet().iterator();
        while(iter.hasNext())
        {
            final String key = (String) iter.next();
            if(key.endsWith(".enum"))
            {
                Map elementMap = (Map) map.get(key);
                if(elementMap == null)
                {
                    final String enumKey = key;
                    elementMap = new HashMap();
                    map.put(enumKey, elementMap);
                }
            }
            else
            {
                final int keyIndex = key.indexOf(".enum.");
                if (keyIndex != -1)
                {
                    final String enumKey = key.substring(0,keyIndex+".enum".length());
                    final String suffix = key.substring(keyIndex + ".enum.".length());
                    final int propertyIndex = suffix.indexOf('.');
                    final String elementKey = propertyIndex == -1 ? suffix : suffix.substring(0, propertyIndex);
                    Map elementMap = (Map) map.get(enumKey);
                    if(elementMap == null)
                    {
                        elementMap = new HashMap();
                        map.put(enumKey, elementMap);
                    }
                    Map propertyMap = (Map) elementMap.get(elementKey);
                    if(propertyMap == null)
                    {
                        propertyMap = new HashMap();
                        elementMap.put(elementKey, propertyMap);
                    }

                    if(propertyIndex != -1)
                   {
                        final String propertyKey = suffix.substring(propertyIndex+1);
                        propertyMap.put(propertyKey,null);
                    }
                }
            }
        }
        return map;
    }

    public static void main(String[] args)
    {
        testParseProperties();
    }

    private static void testParseProperties()
    {
        Map map = new HashMap();
        map.put("a.enum","a");
        map.put("a.enum.ran","1");
        map.put("a.enum.ran.name","name");
        map.put("a.enum.ran.xyz","xyz");

        Map parsedMap = new HashMap();
        parsedMap.put("a.enum",new HashMap());
        ((Map)parsedMap.get("a.enum")).put("ran",new HashMap());
        ((Map)((Map)parsedMap.get("a.enum")).get("ran")).put("name",null);
        ((Map)((Map)parsedMap.get("a.enum")).get("ran")).put("xyz",null);
        System.out.println(parsedMap.equals(parseProperties(map)));
    }

}
