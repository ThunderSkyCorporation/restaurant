package com.bharosa.common.util;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * [Update the description of your class]
 * User: bosco
 * Date: Jun 2, 2007
 * Time: 12:40:30 AM
 */

import com.bharosa.common.logger.Logger;

public class BharosaPropertyBoolean extends BharosaPropertyBase {
    static Logger logger = Logger.getLogger(BharosaPropertyBoolean.class);
    boolean defaultValue;

    public BharosaPropertyBoolean(String name, boolean defaultValue) {
        super(name);
        this.defaultValue = defaultValue;
    }

    public boolean getValue() {
        if( getBharosaProperty() == null ) {
            return defaultValue;
        }
        return getBharosaProperty().getBoolean(defaultValue);
    }

    public String toString() {
        return ""+getValue();
    }
}
