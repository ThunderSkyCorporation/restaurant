package com.bharosa.common.util;

/**
 * Interface to hold string constants.
 *
 * @author "Philomina Dorai"
 * @version 1.0
 * @since 1.0
 */
public interface IBharosaConstants {
    String SECTION_10_PERFORMANCE_LOGGER = "com.bharosa.dashboard.section10.performance";
    String SECTION_20_PERFORMANCE_LOGGER = "com.bharosa.dashboard.section20.performance";
    String SECTION_30_PERFORMANCE_LOGGER = "com.bharosa.dashboard.section30.performance";

    //Enum id constants
    public static String OBJECT_TYPE_ENUM = "bharosa.object.type.enum";

    String ENUM_RA_SESSIONSET_TYPE_ID = "bharosa.ra.sessionset.type.enum";
    String ENUM_RA_PROPERTIES_PREFIX = "bharosa.ra.properties.";

    String ENUM_BHAROSA_SQL_HINT = "bharosa.sql.hint.enum";

    public static String ENUM_RULE_STATUS = "bharosa.arm.rule.status.enum";
    public static String ENUM_PROFILE_STATUS = "bharosa.arm.profile.status.enum";
    public static String ENUM_POLICY_STATUS = "bharosa.arm.policy.status.enum";
    public static String ENUM_MODEL_RUNMODE = "bharosa.arm.profile.runmode.enum";
    public static String ENUM_TRACKER_USER_GROUP_STATUS = "bharosa.arm.tracker.user.group.status.enum";
    public static String ENUM_REPORT_SAVED_STATUS = "bharosa.arm.report.saved.status.enum";
    public static String ENUM_TRUE_FALSE_SELECTION = "bharosa.arm.trueFalse.select.enum";

    //duration descriptor enums
    public static String ENUM_DURATION_TYPE_SELECTION = "tracker.time.durationType.enum";
    public static String ENUM_DURATION_UNIT_SELECTION = "tracker.time.durationUnit.enum";

    public static String ENUM_CHALLENGE_QUESTION_CATEGORY_ID = "bharosa.challenge.question.category.enum";

    public static String ENUM_ACTION_LOG_SESSION_TYPE_ID = "bharosa.action.log.session.type.enum";
    public static String BHAROSA_SCORING_THRESHOLD_TYPE_ID = "bharosa.scoring.scorer.default.threshold.enum";

    public static String ENUM_SECURITY_REPORT_TYPE_ID = "securityReport.type.enum";

    public static String ENUM_SUMMARY_REPORT_TYPE_ID = "summaryReport.type.enum";

    public static String ENUM_USER_REPORT_TYPE_ID = "userReport.type.enum";

    public static String ENUM_DEVICE_REPORT_TYPE_ID = "deviceReport.type.enum";

    public static String ENUM_LOCATION_REPORT_TYPE_ID = "locationReport.type.enum";

    public static String ENUM_FINGER_PRINT_TYPE_ID = "vcrypt.fingerprint.type.enum";

    public static String ENUM_CLIENT_TYPE_ID = "auth.client.type.enum";

    public static String ENUM_OTPCLIENT_TYPE_ID = "auth.otpclient.type.enum";

    public static String ENUM_AUTH_STATUS_ID = "auth.status.enum";

    public static String GENERIC_STATUS_ENUM = "bharosa.generic.status.enum";

    public static String ENUM_TRACKER_TRANSACTION_TYPE = "tracker.transaction.type.enum";

    public static String ENUM_TRACKER_TRANSACTION_ENTITY_MAP_ENUM = "tracker.transaction.entity.map.enum";

    public static String ENUM_TRACKER_TRANSACTION_DATA_DEF_DATA = "tracker.transaction.datadef.data";
    public static String ENUM_TRACKER_TRANSACTION_DATA_DEF_KEY = "tracker.transaction.datadef.key";
    public static String ENUM_TRACKER_TRANSACTION_DATA_DEF_NAME = "tracker.transaction.datadef.name";
    public static String ENUM_TRACKER_TRANSACTION_DATA_DEF_EXTID = "tracker.transaction.datadef.extid";
    public static String ENUM_TRACKER_TRANSACTION_DATA_DEF_SOURCE = "tracker.transaction.datadef.source";
    public static String ENUM_TRACKER_TRANSACTION_DATA_DEF_TRANSACTION = "tracker.transaction.datadef.transaction";

    public static String ENUM_TRACKER_TRANSACTION_STATUS = "tracker.transaction.status.enum";

    public static String ENUM_AUTH_RESULT_ID = "auth.result.enum";

    public static String ENUM_AUTH_SESSION_TYPE_ID = "auth.session.type.enum";

    public static String ENUM_VCRYPT_USER_ACCOUNT_STATUS_ID = "vcrypt.user.account.status.enum";
    public static String ENUM_VCRYPT_USER_IMAGE_STATUS_ID = "vcrypt.user.image.status.enum";
    public static String ENUM_VCRYPT_USER_PHRASE_STATUS_ID = "vcrypt.user.phrase.status.enum";
    public static String ENUM_VCRYPT_USER_QUESTION_STATUS_ID = "vcrypt.user.question.status.enum";


    public static String ENUM_VCRYPT_USER_GROUP_TYPE_ID = "vcrypt.user.group.type.enum";
    public static String ENUM_VCRYPT_USER_ROLE_TYPE_ID = "vcrypt.user.role.type.enum";

    public static String ENUM_VCRYPT_ACCOUNT_TYPE_ID = "vcrypt.account.type.enum";

    public static String ENUM_ALERT_LEVEL_ID = "alert.level.enum";
    public static String ENUM_ALERT_TYPE_ID = "alert.type.enum";
    public static String ENUM_ALERT_STATUS_ID = "alert.status.enum";
    public static String ENUM_ALERT_SOURCE_TYPE = "alert.source.enum";

    public static String ENUM_PROFILE_TYPE_ID = "profile.type.enum";

    public static String ENUM_RULE_TYPE_ID = "rule.type.enum";
    
    public static String ENUM_RULE_ACTION_ID = "rule.action.enum";
    public static String ENUM_CUSTOMER_CARE_ACTION = "rule.customercare.action.enum";

    public static String ENUM_VALUE_TYPE_ID = "value.type.enum";
    public static String ENUM_VALUE_LIST_TYPE_ID = "value.list.type.enum";

    public static String ENUM_LIST_CACHE_TYPE_ID = "value.list.cache.type.enum";

    public static String ENUM_CACHE_TYPE_ID = "vcrypt.cache.type.enum";

    public static String ENUM_LOCATION_TYPE = "location.ip.type.enum";

    public static String ENUM_LOCATION_TYPE_ID = "location.type.enum";

    public static String ENUM_FILE_TYPE_ID = "fileType.type.enum";
    public static String ENUM_FILE_NAME = "name";
    public static String ENUM_METHOD = "method";

    public static String ENUM_SLIDER_OPT_STATUS_ID = "sliderOpt.status.enum";
    public static String ENUM_SLIDER_OPT_OPTED_ID = "sliderOpt.opted.enum";

    public static String ENUM_KBA_REPORT_TYPE_ID = "kbareport.type.enum";

    public static String ENUM_BHAROSA_CONFIG_TYPE_ID = "bharosa.config.type.enum";
    public static String BHAROSA_CONFIG_KEYWORD = "bharosa.config.keyword";
    public static String BHAROSA_CONFIG_KEYNAME = "bharosa.config.keyname";
    public static String BHAROSA_CONFIG_UPDATE_KEYWORD = "bharosa.config.update.keyword";
    public static String BHAROSA_CONFIG_UPDATED_VALUE = "bharosa.config.updated.value";
    public static String BHAROSA_LOAD_TYPE = "bharosa.load.type";


    public static String ENUM_CUSTOMER_CARE_ASKQUESTIONS = "customercare.case.askquestion.lognote.enum";


    //TBD:Bosco: This should be refactored to ENUM_POLICY_TYPE_ID
    public static String ENUM_POLICY_TYPE = "policy.type.enum";
    
    public static String ENUM_DEVICE_TYPE = "device.type.enum";

    public static String ENUM_RULE_MATRIX_EXECUTE_TYPE = "rule.matrix.execute.type.enum";
    public static String ENUM_RULE_MATRIX_RETURN_TYPE = "rule.matrix.return.type.enum";

    String ENUM_SCORING_ALGORITHM = "vcrypt.scoring.engine.algorithm.enum";
    //Run status for rules
    public static String ENUM_RULE_RUN_STATUS_ID = "vcrypt.rule.run.status.enum";
    public static String ENUM_MODEL_RUN_STATUS_ID = "vcrypt.model.run.status.enum";
    public static String ENUM_POLICY_RUN_STATUS_ID = "vcrypt.policy.run.status.enum";
    public static String ENUM_POLICYSET_RUN_STATUS_ID = "vcrypt.policyset.run.status.enum";

    public static String ENUM_AUDIT_ADMIN_ACTIONS = "audit.admin.actions.enum";
    public static String ENUM_AUDIT_CUSTOMER_CARE_ACTIONS = "customercare.case.actiontype.enum";


    //ip enums
    public static String ENUM_LOCATION_ROUTING_TYPE_ID = "location.routing.type.enum";
    public static String ENUM_LOCATION_CONNECTION_TYPE_ID = "location.connection.type.enum";
    public static String ENUM_LOCATION_CONNECTION_SPEED_TYPE_ID = "location.linespeed.enum";

    //Monitor enums
    public static String ENUM_MONITOR_INTERCEPTORS_ID = "monitor.interceptors.enum";

    //Dashboard enums
    public static String ENUM_DASHBOARD_SECTION10_ID = "bharosa.dashboard.section10.enum";
    public static String ENUM_DASHBOARD_SECTION20_ID = "bharosa.dashboard.section20.enum";
    public static String ENUM_DASHBOARD_SECTION30_SUMMARY_ID = "bharosa.dashboard.section30.summary.enum";

    //Question enums
    public static String QUESTION_TYPE_ENUM = "bharosa.question.type.enum";

    //Category enums
    public static String CATEGORY_TYPE_ENUM = "bharosa.category.type.enum";


    //Report enums
    public static String ENUM_TRENDING_TYPE_ID = "bharosa.trending.interval.type.enum";

    //validation enums
    public static String VALIDATION_SCOPE_ENUM = "bharosa.question.validation.scope.enum";
    public static String VALIDATION_SCHEME_ENUM = "bharosa.question.validation.scheme.enum";

    //answer hint enums
    public static String ANSWER_HINT_SCHEME_ENUM = "bharosa.question.answerHint.scheme.enum";

    //Java enums
    //location type enum
    int LOCATION_TYPE_IP = UserDefEnum.getElementValue(IBharosaConstants.ENUM_LOCATION_TYPE_ID, "ipAddress");
    int LOCATION_TYPE_CITY = UserDefEnum.getElementValue(IBharosaConstants.ENUM_LOCATION_TYPE_ID, "city");
    int LOCATION_TYPE_STATE = UserDefEnum.getElementValue(IBharosaConstants.ENUM_LOCATION_TYPE_ID, "state");
    int LOCATION_TYPE_COUNTRY = UserDefEnum.getElementValue(IBharosaConstants.ENUM_LOCATION_TYPE_ID, "country");

    //External GroupId enum
    public static String EXT_GROUP_ID_ENUM = "bharosa.extgroupid.enum";

    //constants
    public static String FIND_FROM_SEARCH_KEY_OPER = "findFromSearchKey";
    public static int MAX_INDEX_PAGES = 3;

    //search constants
    //demoaccount
    public static String FIND_BY_DEMO_ACCOUNT_TYPE = "Account Type";
    public static String FIND_BY_DEMO_ACCOUNT_STATUS = "Account Status";
    public static String FIND_BY_DEMO_ACCOUNT_NAME = "Account Name";
    public static String LIST_ALL_DEMO_ACCOUNTS = "List all Demo Accounts";
    public static String FIND_BY_DEMO_ACCOUNT_ID = "Demo Account Id";


    public static String DEMO_ACCOUNT_NAME = "acctName";
    public static String DEMO_ACCOUNT_STATUS = "acctStatus";
    public static String DEMO_ACCOUNT_TYPE = "acctType";
    public static String DEMO_ACCOUNT_OWNER = "acctOwner";
    public static String DEMO_ACCOUNT_ID = "acctId";


    //demouser
    public static String FIND_BY_DEMO_USER_EMAIL_ADDRESS = "Email Address";
    public static String LIST_ALL_DEMO_USERS = "List all Demo Users";
    public static String FIND_BY_DEMO_USER_ID = "Demo User Id";
    public static String FIND_BY_DEMO_USER_NAME = "User Name";

    public static String DEMO_USER_NAME = "demoUserName";
    public static String DEMO_USER_STATUS = "status";
    public static String DEMO_USER_EMAIL = "emailAddress";
    public static String DEMO_USER_ID = "demoUserId";

    //demofeedback
    public static String FIND_BY_DEMO_FEEDBACK_ACTION = "Feedback Action";
    public static String LIST_ALL_DEMO_FEEDBACKS = "List all Demo Feedbacks";
    public static String FIND_BY_DEMO_FEEDBACK_ID = "Demo Feedback Id";

    //vcryptuser
    public static String FIND_BY_VCRYPT_USER_AUTHMODE = "Authorization Mode";
    public static String FIND_BY_VCRYPT_USER_AUTHTYPE = "Authorization Type";
    public static String FIND_BY_VCRYPT_USER_ISLOCKED = "Is Locked";
    public static String FIND_BY_VCRYPT_USER_STATUS = "User Status";
    public static String FIND_BY_VCRYPT_LOGIN_ID = "Login Id";
    public static String LIST_ALL_VCRYPT_USERS = "List all VCrypt Users";
    public static String FIND_BY_VCRYPT_USER_ID = "VCrypt User Id";

    public static String VCRYPT_USER_ID = "userId";
    public static String VCRYPT_USER_LOGIN_ID = "loginId";
    public static String VCRYPT_USER_NAME = "userName";
    public static String VCRYPT_USER_EMAIL = "userEmail";
    public static String VCRYPT_USER_PASSWORD = "password";
    public static String VCRYPT_USER_CREATE_TIME = "createTime";
    public static String VCRYPT_USER_SESSION_ID = "sessionId";
    public static String VCRYPT_USER_REQUEST_ID = "requestId";
    public static String VCRYPT_USER_PRE_AUTH_SCORE = "preAuthScore";
    public static String VCRYPT_USER_PRE_AUTH_ACTION = "preAuthAction";
    public static String VCRYPT_USER_POST_AUTH_SCORE = "postAuthScore";
    public static String VCRYPT_USER_POST_AUTH_ACTION = "postAuthAction";
    public static String VCRYPT_USER_AUTH_STATUS = "authStatus";
    public static String VCRYPT_USER_AUTH_CLIENT_TYPE = "authClientType";
    public static String VCRYPT_USER_DIGITAL_FINGER_PRINT_ID = "digitalFingerPrintId";
    public static String VCRYPT_USER_ALERTS = "alerts";
    public static String VCRYPT_USER_DATA_PREFIX = "user_";

    public static String VCRYPT_USER_CNFPASSWORD = "confirmPassword";

    public static String VCRYPT_USER_PIN = "pin";
    public static String VCRYPT_USER_SEC_QUESTION = "securityQuestion";
    public static String VCRYPT_USER_SEC_ANSWER = "securityAnswer";
    public static String VCRYPT_USER_SEC_WORD = "secretWord";
    public static String VCRYPT_USER_SEC_WORD_HINT = "secretWordHint";
    public static String VCRYPT_USER_PHONE_NUMBER = "phoneNumber";
    public static String VCRYPT_USER_PERSONAL_NOTE = "personalNote";
    public static String VCRYPT_USER_IMAGE_PATH = "imagePath";

    //Need to add the addresses...
    public static String VCRYPT_USER_ZIP_CODE = "zipCode";
    public static String VCRYPT_USER_TYPE = "userType";
    public static String VCRYPT_USER_AUTH_MODE = "authMode";
    public static String VCRYPT_USER_AUTH_TYPE = "authType";
    public static String VCRYPT_USER_IS_LOCKED = "isLocked";
    public static String VCRYPT_USER_STATUS = "status";
    public static String VCRYPT_USER_EXT_USER_ID = "externalUserId";
    public static String VCRYPT_USER_IS_PIN_ENABLED = "isPinEnabled";

    //vcrypt user group
    public static String VCRYPT_USER_GROUP_ID = "userGroupId";
    public static String VCRYPT_USER_GROUP_NAME = "groupName";
    public static String VCRYPT_USER_GROUP_TYPE = "groupType";
    public static String VCRYPT_USER_GROUP_STATUS = "status";

    //vcrypt user role
    public static String VCRYPT_USER_ROLE_ID = "userRoleId";
    public static String VCRYPT_USER_ROLE_NAME = "roleName";
    public static String VCRYPT_USER_ROLE_TYPE = "roleType";
    public static String VCRYPT_USER_ROLE_STATUS = "status";

    //vcrypt account
    public static String VCRYPT_ACCOUNT_ID = "acctId";
    public static String VCRYPT_ACCOUNT_NAME = "acctName";
    public static String VCRYPT_ACCOUNT_CONTACT = "acctContact";
    public static String VCRYPT_ACCOUNT_TYPE = "acctType";
    public static String VCRYPT_ACCOUNT_STATUS = "acctStatus";

    //db constants
    public static String DEMO_FEEDBACK_ID = "feedbackId";
    public static String DEMO_FEEDBACK_ACTION = "action";
    public static String FEEDBACK_1 = "feedback1";
    public static String FEEDBACK_2 = "feedback2";
    public static String FEEDBACK_3 = "feedback3";

    //common constants
    public static String SESSION_REPORT_DATES = "sessionReportDates";
    public static String COMMON_CREATE_DATE = "createDate";
    public static String COMMON_FROM_DATE = "fromDate";
    public static String COMMON_DATE_FILTER_STATUS = "dateFilterStatus";
    public static String COMMON_DATE_FILTER_STATUS_DISABLED = "disabled";
    public static String COMMON_DATE_FILTER_STATUS_ENABLED = "enabled";
    public static String IGNORE_FLAG = "ignoreFlag";
    public static String COMMON_TO_DATE = "toDate";
    public static final String COMMON_BEGIN_TIME = "beginTime";
    public static final String COMMON_END_TIME = "endTime";
    public static String COMMON_FROM_HOUR = "fromHour";
    public static String COMMON_TO_HOUR = "toHour";
    public static String COMMON_IP_ADDR = "ipAddr";
    public static String COMMON_FROM_IP_ADDR = "fromIPAddr";
    public static String COMMON_TO_IP_ADDR = "toIPAddr";
    public static String COMMON_HOST = "host";
    public static String COMMON_NOTES = "notes";
    public static String COMMON_DESC = "description";
    public static String COMMON_STATUS = "status";
    public static String COMMON_LOCALE = "locale";
    public static String ELEMENT_ID = "elementId";
    public static String ELEMENT_NAME = "elementName";
    public static String SCORING_ENGINE = "scoringType";
    public static String COMMON_WEIGHT = "weight";
    public static String CACHE_TYPE = "cacheType";
    public static String COMMON_SAMPLE_DAYS = "sampleDays";
    //vcrypt tracker node constants
    public static String TRACKER_NODE_NODE_ID = "nodeId";
    public static String TRACKER_NODE_VERSION = "nodeVersion";
    public static String TRACKER_NODE_DIG_SIG_COOKIE = "digSigCookie";
    public static String TRACKER_NODE_SECURE_COOKIE = "secureCookie";
    public static String TRACKER_NODE_IP_ADDR = "remoteIPAddr";
    public static String TRACKER_NODE_HOST = "remoteHost";

    //vcrypt tracker node history constants
    public static String TRACKER_NODEHISTORY_ID = "nodeHistoryId";

    //vcrypt tracker node log constants
    public static String TRACKER_NODE_LOGID = "nodeLogId";
    public static String TRACKER_NODE_REQUEST_ID = "requestId";
    public static String TRACKER_NODE_DIGITAL_CLIENT = "digitalClient";
    public static String TRACKER_NODE_SECURE_CLIENT = "secureClient";

    //vcrypt tracker user node log constants
    public static String TRACKER_USERNODE_LOGID = "userNodeLogId";
    public static String TRACKER_USERNODE_USERID = "userId";
    public static String TRACKER_USERNODE_LOGINID = "loginId";
    public static String TRACKER_USERNODE_AUTHSTATUS = "authStatus";
    public static String TRACKER_USERNODE_AUTH_CLIENT = "authClient";

    //auth session group constants
    public static String AUTH_SESSION_GROUP_ID = "sessionGroupId";
    public static String AUTH_SESSION_TYPE = "sessionType";

    //auth attempt constants
    public static String AUTH_ATTEMPT_ID = "attemptId";
    public static String AUTH_LOGIN_ID = "loginId";
    public static String AUTH_STATUS = "authStatus";
    public static String AUTH_REASON = "authReason";
    public static String AUTH_CLIENT_TYPE = "authClientType";

    //demo auth map constants
    public static String DEMO_AUTH_MAP_ID = "demoAuthId";
    public static String DEMO_AUTH_MAP_IS_COUNTED = "isCounted";

    //location constants
    public static String COUNTRY_STR = "Country";
    public static String STATE_STR = "State";
    public static String CITY_STR = "City";
    public static String BASEIP_STR = "baseIp";
    public static String REMOTEIP_STR = "remoteIp";

    //location-country
    public static String COUNTRY_ID = "countryId";
    public static String COUNTRY_CODE = "countryCode";
    public static String COUNTRY_NAME = "countryName";

    //location-state
    public static String STATE_ID = "stateId";
    public static String STATE_CODE = "stateCode";
    public static String STATE_NAME = "stateName";

    //location-city
    public static String CITY_ID = "cityId";
    public static String CITY_CODE = "cityCode";
    public static String CITY_NAME = "cityName";

    public static String IP_CLUSTER = "IPCluster";
    public static String IP_CLUSTER_ID = "IPClusterId";
    public static String IP_CLUSTER_LABEL = "IPClusterLabel";
    public static String IP_CLUSTER_DESC = "IPClusterDescription";
    public static String IP_CLUSTER_FROM_IP = "IPClusterFromIP";
    public static String IP_CLUSTER_TO_IP = "IPClusterToIP";
    public static String IP_CLUSTER_NOTES = "IPClusterNotes";


    //alert
    public static String ALERT_ID = "alertId";
    public static String ALERT_LEVEL = "alertLevel";
    public static String ALERT_STATUS = "alertStatus";
    public static String ALERT_TYPE = "alertType";
    public static String ALERT_SOURCE = "alertSource";
    public static String ALERT_SOURCE_TYPE = "alertSourceType";
    public static String ALERT_ACKED_BY = "ackedBy";
    public static String ALERT_CLEARED_BY = "clearedBy";
    public static String CLEAR_ALERT_ID = "clearAlertId";
    public static String ALERT_MESSAGE = "alertMessage";

    //faq category
    public static String FAQ_CATEGORY_ID = "categoryId";
    public static String FAQ_CATEGORY_NAME = "categoryName";
    public static String FAQ_CATEGORY_DESC = "description";

    //faq
    public static String FAQ_ID = "faqId";
    public static String FAQ_QUESTION = "question";
    public static String FAQ_ANSWER = "answer";
    public static String FAQ_KEYWORD = "faqQuestionKeyword";
    public static String FAQ_QUESTION_KEYWORD = "faqQuestionKeyword";
    public static String FAQ_ANSWER_KEYWORD = "faqAnswerKeyword";

    //tracker user
    public static String LOCAL_USER_ID = "localUserId";
    public static String EXT_USER_ID = "extUserId";
    public static String USER_LOGIN_ID = "loginId";
    public static String USER_IS_VALID = "isValid";
    public static String USER_IS_REAL_USER = "isRealUser";

    //tracker userGroup
    public static String LOCAL_USERGROUP_ID = "localUserGroupId";
    public static String EXT_USERGROUP_ID = "extUserGroupId";
    public static String USERGROUP_STATUS = "status";
    public static String USERGROUP_DESC = "description";

    String BROWSER = "browser";
    String OS = "os";
    String ROUTING_TYPE = "routingType";

    // monitor data
    String MONITOR_TYPE = "monitorType";
    String DATA_VALUE = "dataValue";
    String AGGREGATE_TYPE = "AGGREGATE_TYPE";
    String AGGREGATE_HOUR = "hourly";
    String AGGREGATE_DAY = "daily";
    String AGGREGATE_WEEK = "weekly";
    String AGGREGATE_MONTH = "monthly";
    String AGGREGATE_QUARTER = "quarterly";
    String AGGREGATE_YEAR = "yearly";
    String RISK_SCORE_RANGE = "riskScore";
    String ACTION_LIST = "actionList";
    String ACTION = "action";
    String ACTION_COUNT = "actionCount";
    String API_REQUEST = "apiRequest";

    //Report constants
    public static String REP_USER_ID = "userId";
    public static String REP_USER_ID_UPPER = EXT_USER_ID + "Upper";
    public static String REP_LOGIN_ID_UPPER = USER_LOGIN_ID + "Upper";
    public static String REP_GROUP_ID_UPPER = "groupIdUpper";
    //public static String REP_USER_ID = EXT_USER_ID;
    public static String REP_LOGIN_ID = USER_LOGIN_ID;
    public static String REP_GROUP_ID = "groupId";
    public static String REP_USER_NOTES = "userNotes";
    public static String REP_USER_PER_NOTES = "userPersonalNotes";
    public static String REP_USER_FIRST_LOGIN = "userFirstLogin";
    public static String REP_AUTH_STATUS = "authStatus";
    public static String REP_CHALLENGE_STATUS = "repChallengeStatus";
    public static String REP_ALERT_LEVEL = "alertLevel";
    String REP_RUNTIME = "runtimeType";
    public static String REP_AUTH_CLIENT_TYPE = "authClientType";
    public static String REP_MIN_COUNT = "minCount";
    public static String REP_LOCATION_TYPE = "locationType";
    public static String REP_LOCATION_ID = "locationId";
    public static String REP_LOCATION_LAST_USED = "locationLastUsed";
    public static String REP_IS_VALID = "isValid";
    public static String REP_LOGIN_TIME = "loginTime";
    public static String REP_METHOD_NAME = "methodName";
    public static String REP_SUCCESS_COUNT = "successCount";
    public static String REP_FAIL_COUNT = "failCount";
    public static String REP_SAVED_STATUS = "status";
    public static String REP_LOGIN_SUCCESS = "loginSuccess";
    public static String REP_LOGIN_FAILURE = "loginFailure";
    public static String REP_LOGIN_SUCCESS_COUNT = "loginSuccessCount";
    public static String REP_LOGIN_FAILURE_COUNT = "loginFailureCount";
    public static String REP_DASH_DATA = "dashData";
    public static String REP_DASH_DATA_UND = "dashDataUnD";
    public static String REP_DASH_DATA_ALERTS = "dashDataAlerts";
    public static String REP_DASH_VIEW = "dashView";
    public static String REP_DASH_VIEW_TTIME = "dashViewTotalTime";
    public static String REP_DASH_VIEW_TREND = "dashViewTrend";
    public static String REP_DASH_SAMPLE = "dashSample";
    public static String REP_DASH_SAMPLE_DIV = "dashSampleDiv";
    public static String REP_DASH_SAMPLE_WEEKLY = "dashSampleWeekly";
    public static String REP_DASH_SAMPLE_MONTHLY = "dashSampleMonthly";
    public static String REP_DASH_SAMPLE_QUARTERLY = "dashSampleQuarterly";
    public static String REP_SELECTED_FIELDS = "REP_SELECTED_FIELDS";
    public static String REP_SHOW_DEVICE = "REP_SHOW_DEVICE";
    public static String REP_SHOW_PREAUTH = "REP_SHOW_PREAUTH";
    public static String REP_SHOW_POSTAUTH = "REP_SHOW_POSTAUTH";
    String REP_SHOW_BROWSER = "REP_SHOW_BROWSER";
    String REP_SHOW_OS = "REP_SHOW_OS";
    String REP_SHOW_GROUP_ID = "REP_SHOW_GROUP_ID";
    String REP_SHOW_RUNTIME = "REP_SHOW_RUNTIME";
    String REP_SHOW_ACTION = "REP_SHOW_ACTION";
    String REP_SHOW_ACTION_LIST = "REP_SHOW_ACTION_LIST";
    String REP_SHOW_ACTION_COUNT = "REP_SHOW_ACTION_COUNT";
    String REP_SHOW_RULE_NAME = "REP_SHOW_RULE_NAME";
    String REP_SHOW_MODEL_NAME = "REP_SHOW_MODEL_NAME";
    String REP_SHOW_COUNTRY_NAME = "REP_SHOW_COUNTRY_NAME";
    String REP_SHOW_STATE_NAME = "REP_SHOW_STATE_NAME";
    String REP_SHOW_CITY_NAME = "REP_SHOW_CITY_NAME";
    String REP_SHOW_ROUTING_TYPE = "REP_SHOW_ROUTING_TYPE";
    String REP_SHOW_SESSIONS_SUMMARY = "REP_SHOW_SESSIONS_SUMMARY";
    String REP_SHOW_DEVICES_SUMMARY = "REP_SHOW_DEVICES_SUMMARY";
    String REP_SHOW_USERS_SUMMARY = "REP_SHOW_USERS_SUMMARY";
    String REP_SHOW_ALERTS_SUMMARY = "REP_SHOW_ALERTS_SUMMARY";
    String REP_SHOW_ALERT_MESSAGE = "REP_SHOW_ALERT_MESSAGE";
    String REP_SHOW_ALERT_LEVEL = "REP_SHOW_ALERT_LEVEL";
    String REP_SHOW_ALERT_TYPE = "REP_SHOW_ALERT_TYPE";
    String REP_SHOW_PER_USER_AVERAGES = "REP_SHOW_PER_USER_AVERAGES";
    String REP_SHOW_PER_DEVICE_AVERAGES = "REP_SHOW_PER_DEVICE_AVERAGES";
    String REP_SHOW_PER_LOCATION_AVERAGES = "REP_SHOW_PER_LOCATION_AVERAGES";
    String REP_SHOW_TOTAL_COUNT = "REP_SHOW_TOTAL_COUNT";
    String REP_SHOW_TOTAL_TIME = "REP_SHOW_TOTAL_TIME";
    String REP_SHOW_AVERAGE_TIME = "REP_SHOW_AVERAGE_TIME";
    String REP_TREND_BY_FIELD = "REP_TREND_BY_FIELD";
    String REP_TREND_BY_COUNT = "REP_TREND_BY_COUNT";
    String REP_TREND_BY_AVERAGE_TIME = "REP_TREND_BY_AVERAGE_TIME";

    String REP_EXPORT_FORMAT = "REP_EXPORT_FORMAT";
    String REP_TEMP_ALLOW_RESULT = "repTempAllowResult";
    String REP_SHOW_CHALLENGE_RESULT = "REP_SHOW_CHALLENGE_RESULT";
    String REP_SHOW_TEMP_ALLOW_RESULT = "REP_SHOW_TEMP_ALLOW_RESULT";
    String REP_SHOW_CHALLENGE_TYPE = "REP_SHOW_CHALLENGE_TYPE";

    //constants for manage data
    public static String DATABASE_SOURCE_PATH = "dbSourcePath";
    public static String DATABASE_USERNAME = "dbUsername";
    public static String DATABASE_PASSWORD = "dbPassword";

    //report type constants.
    public static String REP_DEVICE_SUMMARY = "Device";
    public static String REP_LOCATION_SUMMARY = "Location";

    //Rule constants
    public static String RULE = "rule";
    public static String RULE_ID = "ruleId";
    public static String RULE_NAME = "ruleName";
    public static String RULE_TYPE = "ruleType";
    public static String RULE_STATUS = "ruleStatus";
    public static String RULE_FILE_NAME = "ruleFileName";
    public static String GLOBAL_ID = "ruleGlobalId";

    public static String RULE_LIST = "ruleList";
    public static String RULE_SELECT_LIST = "ruleSelectList";

    String LOOKUP_KEY = "lookupKey";
    String LOOKUP_VALUE = "lookupValue";
    String EACH_LOOKUP_KEY = "eachLookupKey";
    String EACH_LOOKUP_VALUE = "eachLookupValue";

    //RuleLog constants
    public static String RULE_LOG_ID = "ruleLogId";

    //Admin Groups

    public static String ADMIN_GROUP_ID = "adminGroupId";

    public static String VALUE_LIST_ID = "listId";
    public static String VALUE_LIST_NAME = "listName";
    public static String VALUE_LIST_TYPE = "listType";
    public static String VALUE_LIST_SUBTYPE = "listSubType";

    public static String GROUP_CATEGORY = "groupCategory";
    public static String LOCATION_CATEGORY = "locationCategory";
    public static String LOCATION_GEOGRAPHIC_CATEGORY = "locationGeographicCategory";

    public static String GROUP_ACTION_ID = "groupActionId";
    public static String GROUP_ALERT_ID = "groupAlertId";

    //customercare user login actions
    public static String ACTION_ALLOW_USER = "allow_user";
    public static String CC_ACTION = "ccAction";

    //Added By Derick Leo .. For Report Table

    public static String INSTANCE_NAME = "instanceName";
    public static String FILE_TYPE = "fileType";
    public static String SCHEDULE_DATE = "scheduledate";
    public static String SCHEDULE_ID = "scheduleId";
    public static String SAVED_ID = "savedId";

    public static String SCHEDULE_TIME = "fTime";
    public static String INTERVAL_TYPE = "intervalType";
    public static String INTERVAL_VALUE = "intervalValue";
    public static String DEFAULT_FILE_TYPE = "html";

    public static String DEST_TYPE = "destType";
    public static String ATTACH_FILE = "attachFile";
    public static String EMAIL_LIST = "emailList";
    public static String EXECUTION_TIME = "executionTime";
    public static String SERVER_SIDE_TIME = "serverSideTime";
    public static String NOTES = "description";

    //Added By Derick Leo For DB Settings from property
    public static String HIB_DIALECT = "hibernate.dialect";
    public static String HIB_DRIVER = "hibernate.driver";
    public static String HIB_URL = "hibernate.url";
    public static String HIB_USER = "hibernate.username";
    public static String HIB_PWD = "hibernate.password";

    public static String HIB_CONFIG_FILE = "bharosa.hibernate.config.file";
    public static String HIB_DIALECT_VAL = "bharosa.db.dialect";
    public static String HIB_DRIVER_VAL = "bharosa.db.driver";
    public static String HIB_URL_VAL = "bharosa.db.url";
    public static String HIB_USER_VAL = "bharosa.db.username";
    public static String HIB_PWD_VAL = "bharosa.db.password";

    public static String C3P0_CONFIG_FILE = "bharosa.c3p0.config.file";

    public static String CONN_POOL_FLG = "vcrypt.db.jndi.connection.pool.switch";
    public static String DEFAULT_DATA_SOURCE = "vcrypt.db.jndi.dataSource";

    public static String HIB_DATA_SOURCE = "hibernate.datasource";
    public static String FROM_RECORDS = "fromRecords";
    public static String TO_RECORDS = "toRecords";
    public static String TOTAL_RECORDS = "totalRecords";

    // constants for vcrypt user questions
    public static String VCRYPT_USER_QUESTION_ID = "questionId";
    public static String VCRYPT_USER_QA_ID = "qaId";

    //Added By Derick For the Scheduler
    public static String SCHEDULER_ACTIVATE = "vcrypt.reports.scheduler.activate";
    public static String SCAN_DATASOURCE_AT_FIXED_RATE = "vcrypt.reports.scheduler.ratescan";


    public static String WEB_SECURITY_FLG = "vcrypt.web.security.check.flag";

    public static String ROLE_NAME = "vcrypt.web.security.role_name";

    public static String WEB_SECURITY_FAIL_PAGE = "web.security.fail.page";

    //Slider OPT In Out Reports
    public static int SLIDER_OPT_INOUT_CURRENT = 1;
    public static int SLIDER_OPT_INOUT_ALL = 2;

    public static String SLIDER_OPT_STATUS = "sliderOptStatus";
    public static String SLIDER_OPT_OPTED = "sliderOptOpted";

    public static String SLIDER_OPT_TIME = "sliderOptTime";

    public static String WEB_ACCESS_FLG = "vcrypt.web.security.access.flag";


    // Model Constants
    public static String MODEL = "model";
    public static String MODEL_ID = "modelId";
    public static String POLICY_TYPE_ID = "policyTypeId";
    public static String POLICY_TYPE = "modelPolicyType";
    public static String POLICYSET_ID = "policySetId";
    public static String POLICY_ID = "policyId";
    public static String MODEL_NAME = "modelName";
    public static String MODEL_WEIGHT = "modelWeight";
    public static String MODEL_SCORING_ENGINE = "modelScoringEngine";
    public static String MODEL_DESCRIPTION = "modelDescription";
    public static String MODEL_RUNTIME = "modelRunTime";
    public static String MODEL_STATUS = "modelStatus";
    public static String MODEL_RUNMODE = "modelRunMode";

    public static String MODEL_LIST = "modelList";
    public static String MODEL_SELECT_LIST = "modelSelectList";

    public static String MODEL_RULE = "modelRule";
    public static String MODEL_RULE_ID = "modelRuleId";
    public static String MODEL_RULE_DESCRIPTION = "modelRuleDescription";

    public static String MODEL_RULE_MAP = "modelRuleMap";
    public static String MODEL_RULE_MAP_ID = "modelRuleMapId";
    public static String MODEL_RULE_MAP_NAME = "modelRuleMapName";
    public static String MODEL_RULE_MAP_SCORE = "modelRuleMapScore";
    public static String MODEL_RULE_MAP_WEIGHT = "modelRuleMapWeight";
    public static String MODEL_RULE_MAP_DEVICE_SCORE_MIN = "modelRuleMapDeviceScoreMin";
    public static String MODEL_RULE_MAP_DEVICE_SCORE_MAX = "modelRuleMapDeviceScoreMax";
    public static String MODEL_RULE_MAP_COUNTRY_SCORE_MIN = "modelRuleMapCountryScoreMin";
    public static String MODEL_RULE_MAP_COUNTRY_SCORE_MAX = "modelRuleMapCountryScoreMax";
    public static String MODEL_RULE_MAP_STATE_SCORE_MIN = "modelRuleMapStateScoreMin";
    public static String MODEL_RULE_MAP_STATE_SCORE_MAX = "modelRuleMapStateScoreMax";
    public static String MODEL_RULE_MAP_CITY_SCORE_MIN = "modelRuleMapCityScoreMin";
    public static String MODEL_RULE_MAP_CITY_SCORE_MAX = "modelRuleMapCityScoreMax";
    public static String MODEL_RULE_MAP_DESCRIPTION = "modelRuleMapDescription";
    public static String MODEL_RULE_MAP_STATUS = "modelRuleMapStatus";
    public static String MODEL_RULE_MAP_MODIFIED_DATE = "modelRuleMapModifiedDate";
    public static String MODEL_RULE_MAP_ACTION_GROUP = "modelRuleMapActionGroup";
    public static String MODEL_RULE_MAP_ALERT_GROUP = "modelRuleMapAlertGroup";
    public static String MODEL_RULE_MAP_EXCLUDED_USER_GROUP = "modelRuleMapExcludedUserGroup";
    public static String EXCLUDED_USER_GROUP_ID = "excludedUserGroupId";
    public static String MODEL_RULE_MAP_MULTI_DELETE = "modelRuleMapMultiDelete";

    public static String MODEL_RULES_LIST = "modelRulesList";
    public static String MODEL_RULES_FILTER_LIST = "modelRulesFilterList";

    public static String MODEL_GROUP = "modelGroup";
    public static String MODEL_GROUP_ID = "modelGroupId";
    public static String MODEL_GROUP_TYPE_ID = "modelGroupTypeId";
    public static String MODEL_GROUP_MULTI_DELETE = "modelGroupMultiDelete";

    public static String MODEL_GROUPS_LIST = "modelGroupsList";
    public static String MODEL_GROUPS_FILTER_LIST = "modelGroupsFilterList";

    public static String MODEL_RULE_VALUE_BASE = "modelRuleValue";

    public static String MODEL_SCORE_ID_BASE = "modelScoreId";
    public static String MODEL_SCORE_ORDER_BASE = "modelScoreOrder";
    public static String MODEL_SCORE_RESULT_TYPE_BASE = "modelScoreResultType";
    public static String MODEL_SCORE_VALUE_BASE = "modelScoreValue";
    public static String MODEL_SCORE_MODEL_BASE = "modelScoreModel";
    public static String MODEL_SCORE_ALERT_GROUP_BASE = "modelScoreAlertGroup";
    public static String MODEL_SCORE_ACTION_GROUP_BASE = "modelScoreActionGroup";
    public static String MODEL_SCORE_NOTES_BASE = "modelScoreNotes";

    public static String MODEL_SCORE_COL_ID_BASE = "modelScoreColId";
    public static String MODEL_SCORE_RULE_MAP_ID_BASE = "modelScoreRuleMap";
    public static String MODEL_SCORE_RULE_VALUE_BASE = "modelScoreRuleValue";

    public static String MODEL_SCORE_DELETE_BASE = "modelScoreDelete";

    public static String MODEL_SCORE_ROW_CNT = "modelScoreRowCnt";
    public static String MODEL_SCORE_COL_CNT = "modelScoreColCnt";

    public static String MODEL_SCORES_LIST = "modelScoresList";

    public static String MODEL_RULE_MAP_ACTION_GROUP_LIST = "modelRuleMapActionGroupList";
    public static String MODEL_RULE_MAP_ALERT_GROUP_LIST = "modelRuleMapAlertGroupList";
    public static String MODEL_RULE_MAP_EXCLUDED_USER_GROUP_LIST = "modelRuleMapExcludedUserGroupList";

    public static String MODEL_PARAM_VALUE_LIST = "modelParamValueComboList";

    public static String ACTION_GROUP_LIST = "actionGroupList";
    public static String ALERT_GROUP_LIST = "alertGroupList";

    public static String COMMON_DEVICE_SCORE_MIN = "deviceScoreMin";
    public static String COMMON_DEVICE_SCORE_MAX = "deviceScoreMax";

    //	Profile constants
    public static String PROFILE_NAME = "profileName";
    public static String PROFILE_ID = "profileId";
    public static String PROFILE_TYPE = "profileType";
    public static String PROFILE_STATUS = "profileStatus";

    //ProfileRuleMap constants
    public static String PROFILE_RULE_MAP_ID = "profileRuleMapId";
    public static String PROFILE_RULE_MAP_NAME = "profileRuleMapName";

    public static String DISABLE_DEVICE_ID_RULES = "vcrypt.tracker.rule.deviceIdentification.disable";

    public static String ENUM_TRACKER_COOKIE_TYPE = "tracker.cookie.type.enum";
    public static String ENUM_TRACKER_COOKIE_STATE = "tracker.cookie.state.enum";
    public static String ENUM_DEVICEID_COOKIE_TYPE = "tracker.deviceid.cookie.type.enum";

    // Import Export Utility Constants
    public static String UTILITY_MAX_LIST_SIZE = "importExport.arrayList.size";
    public static String UTILITY_DB_BATCH_SIZE = "importExport.dbBatch.size";

    public static String IMPORTEXPORT_VALIDATE_XML = "importExport.xsd.validate";
    public static String IMPORTEXPORT_XSD_PATH = "importExport.xsd.path";
    public static String IMPORTEXPORT_GROUPS_ALERT_XSD = "importExport.groups.alert.xsd";
    public static String IMPORTEXPORT_GROUPS_ACTION_XSD = "importExport.groups.action.xsd";
    public static String IMPORTEXPORT_GROUPS_DEVICE_XSD = "importExport.groups.device.xsd";
    public static String IMPORTEXPORT_GROUPS_USER_XSD = "importExport.groups.user.xsd";
    public static String IMPORTEXPORT_GROUPS_IP_XSD = "importExport.groups.ip.xsd";
    public static String IMPORTEXPORT_GROUPS_IPRANGE_XSD = "importExport.groups.ipRange.xsd";
    public static String IMPORTEXPORT_GROUPS_COUNTRY_XSD = "importExport.groups.country.xsd";
    public static String IMPORTEXPORT_GROUPS_STATE_XSD = "importExport.groups.state.xsd";
    public static String IMPORTEXPORT_GROUPS_CITY_XSD = "importExport.groups.city.xsd";
    public static String IMPORTEXPORT_EXPORT_DIR = "importExport.export.dir";
    public static String IMPORTEXPORT_EXPORT_GROUPS_DIR = "importExport.export.groups.dir";
    public static String IMPORTEXPORT_EXPORT_RULES_DIR = "importExport.export.rules.dir";
    public static String IMPORTEXPORT_EXPORT_MODELS_DIR = "importExport.export.models.dir";
    public static String IMPORTEXPORT_EXPORT_IPLOCATIONS_DIR = "importExport.export.iplocations.dir";

    //DiatanceCalculator constants
    public static final int EARTH_RADIUS_IN_KILOMETERS = 6371;
    public static final int EARTH_RADIUS_IN_MILES = 3959;

    public static final String VCRYPT_AUTH_RESP_ENUM = "vcrypt.auth.response.enum";
    public static final int SUCCESS_LOGIN = 1000;
    public static final int PASSWORD_EXPIRE = 1001;
    public static final int FAILED = 1002;
    public static final int INVALID = 1003;

    public static final String VCRYPT_SUPERVISOR_NAME = "SupervisorName";
    public static final String VCRYPT_AUTHORIZATION_UNIT = "AuthorizationUnit";
    public static final String VCRYPT_USER_NOTES = "userNotes";

    public static final String USER_CACHE_FINGERPRINT_SIZE = "vcrypt.tracker.usercache.fingerprint.size";

    //FingerPrint
    public static final String FINGERPRINT_ID = "fingerPrintId";
    public static final String FPRINT_TYPE = "fingerPrintType";
    public static final String BROWSER_FINGERPRINT_ID = "browserFPrintId";
    public static final String DIGITAL_FINGERPRINT_ID = "digitalFPrintId";
    
    public static final String FLASH_VERSION = "flashVersion";

    //maxBlock
    public static final String FROM_ACTION = "fromAction";
    public static final String TO_ACTION = "toAction";
    public static final String MAX_BLOCK_COUNT = "maxCountAllowed";
    public static final String MAX_BLOCK_DURATION = "duration";

    public static final String PARAM[] = { "BID", "XID", "BSN", "BAU", "CUN", "CFN", "CMN", "CLN" };

    //Audit
    public static String AUTH_UNIT = "authUnit";
    public static String SUPERVISOR_NAME = "supervisorName";
    public static String ACTION_LOG_SESS = "actionLogSess";
    public static String ACTION_LOG = "actionLog";

    //Action logs and sessions
    public static String ACTION_LOG_ACTION = "action";
    public static String ACTION_LOG_BLOCKED = "accessDenied";
    public static String ACTION_LOG_SESSION_LOGIN_ID = "adminLoginId";
    public static String ACTION_LOG_SESSION_ID = "sessionId";

    public static String AD_ENT = "adEnt";
    public static String USER_GROUP = "userGroup";
    public static String ADMIN_ACTIONS = "adminActions";
    public static String CUSTOMER_ACTIONS = "customerCareActions";

    //Application Labels (property name)
    public static String LABEL_EXT_USER_ID = "fa.label.extuserid";
    public static String LABEL_LOGIN_ID = "fa.label.loginid";
    public static String LABEL_GROUP_ID = "fa.label.groupid";
    public static String LABEL_CLIENT_TYPE = "fa.label.clientType";
    public static String LABEL_CSR_ID = "fa.label.csrid";
    public static String LABEL_CASE = "fa.label.case";
    public static String LABEL_PLURAL_CASE = "fa.label.pulral.case";
    public static String LABEL_PRE_AUTH_SCORE = "fa.label.preAuthScore";
    public static String LABEL_PRE_AUTH_ACTION = "fa.label.preAuthAction";
    public static String LABEL_POST_AUTH_SCORE = "fa.label.postAuthScore";
    public static String LABEL_POST_AUTH_ACTION = "fa.label.postAuthAction";
    public static String LABEL_CONNECTION_TYPE = "fa.label.connectionType";
    public static String LABEL_ROUTING_TYPE = "fa.label.routingType";
    public static String LABEL_CARRIER = "fa.label.carrier";
    public static String LABEL_SESSION_ID = "fa.label.sessionid";
    public static String LABEL_REQUEST_ID = "fa.label.requestid";
    public static String LABEL_NUMBER_OF_SUCCESS = "fa.label.number.of.success";
    public static String LABEL_NUMBER_OF_FAILURE = "fa.label.number.of.failure";
    String NOT_AVAILABLE_KEY = "fa.label.notapplicable";
    String NOT_APPLICABLE_KEY = "fa.label.notavailable";

    public static String LABEL_TRANSACTION_DETAIL = "fa.label.transaction.detail";

    public static String LABEL_NODE_ID = "fa.label.nodeId";

    //KBA constants
    String QUESTION_CATEGORY_ID = "questionCategoryId";
    String QUESTION_ID = "questionId";
    String QUESTION_VALUE = "questionValue";
    String QUESTION_KEYWORD = "questionKeyword";
    String QUESTION_VALIDATION_ID = "questionValidationId";
    String QUESTION_ANSWERHINT_ID = "questionAnswerHintId";
    String QUESTION_UPDATE_TIME = "questionUpdateTime";
    String KBA_QUESTION = "kbaQuestion";
    String KBA_QUESTION_CATEGORY = "kbaQuestionCategory";
    String CATEGORY_UPDATE_TIME = "categoryUpdateTime";
    String CATEGORY_NAME = "categoryName";
    String CATEGORY_DESCRIPTION = "categoryDescription";
    String CATEGORY_TYPE = "categoryType";
    String CATEGORY_ID = "categoryId";
    String KBA_CATEGORY = "kbaCategory";
    String SCORING_POLICY_ID = "scoringPolicyId";
    String KBA_SCORING_POLICY = "scoringPolicy";
    String KBA_SCORE_ATTR_WEIGHT = "scoreAttrWeight";
    String KBA_CONFIG_VALUE = "kbaConfigValue";
    String GLOBAL_VALIDATION_ID = "globalValidationId";


    String QUESTION_CATEGORY_LIST = "categories";
    String QUESTION_VALIDATION_LIST = "validations";
    String QUESTION_ANSWERHINT_LIST = "answerHintList";
    String QUESTION_VALIDATION_SELECT_LIST = "questionValidationSelectList";
    String QUESTION_ANSWERHINT_SELECT_LIST = "questionAnswerHintSelectList";
    String KBA_SCORING_POLICY_LIST = "scoringPolicyList";
    String KBA_SCORING_ATTR_LIST = "scoringAttrList";
    String KBA_CONFIG_LIST = "kbaConfigList";
    String KBA_GLOBAL_VALIDATION_LIST = "globalValidationList";

    String KBA_VALIDATION_LIST = "kbaValidationList";
    String KBA_VALIDATION = "kbaValidation";
    
    String OTP_CHALLENGE_TYPE = "challengeType";

    //show-hide label properties.

    // KBA REGISTRATIONS
    public static String LABEL_EXT_USER_ID_SHOW = "fa.label.extuserid.show";
    public static String LABEL_LOGIN_ID_SHOW = "fa.label.loginid.show";
    public static String LABEL_GROUP_ID_SHOW = "fa.label.groupid.show";
    public static String LABEL_DATE_SHOW = "fa.label.date.show";
    public static String LABEL_DEVICE_ID_SHOW = "fa.device.id.show";
    public static String LABEL_REGISTRATION_HEADER_SHOW = "fa.registration.header.show";
    public static String LABEL_OPTOUTS_HEADER_SHOW = "fa.optoputs.header.show";
    public static String LABEL_QUESTIONRESETS_HEADER_SHOW = "fa.questionresets.header.show";
    public static String LABEL_PICKSET_RESETS_SHOW = "fa.picksetsresets.header.show";
    public static String LABEL_USER_PICKSET_RESET_SHOW = "fa.userpicksetreset.header.show";
    public static String LABEL_TOTALCOUNT_SHOW = "fa.userpicksetreset.header.show";
    public static String LABEL_USERS_QUESTIONRESETS_HEADER_SHOW = "fa.userquestionreset.header.show";
    // remove above constants which are not needed
    public static String LABEL_EMPTY_HEADER_SHOW = "fa.labelheader.show";
    public static String LABEL_COUNT_HEADER_SHOW = "fa.countheader.show";
    public static String LABEL_PERCENT_HEADER_SHOW = "fa.percentheader.show";

    // KBA QUESTION STATISTICS
    public static String LABEL_IDS_HEADER_SHOW = "fa.label.ids.header.show";
    public static String LABEL_CATEGORY_HEADER_SHOW = "fa.label.category.header.show";
    public static String LABEL_QUESTION_HEADER_SHOW = "fa.label.question.header.show";
    public static String LABEL_PICKSETS_HEADER_SHOW = "fa.label.picksets.header.show";
    public static String LABEL_USERS_REGISTERED_HEADER_SHOW = "fa.label.users.registerd.header.show";
    public static String LABEL_PERCENT_UR_HEADER_SHOW = "fa.label.percent.ur.header.show";
    public static String LABEL_PERCENT_SC_HEADER_SHOW = "fa.label.percent.sc.header.show";
    public static String LABEL_PERCENT_UC_HEADER_SHOW = "fa.label.percent.uc.header.show";
    public static String LABEL_PERCENT_MAC_HEADER_SHOW = "fa.label.percent.mac.header.show";

    // KBA CHALLENGE STATISTICS
    public static String LABEL_TOTAL_CHALLENGES_SHOW = "fa.label.total.challenges.header.show";
    public static String LABEL_USERS_CHALLENGED_SHOW = "fa.label.users.challenged.header.show";
    public static String LABEL_PERCENT_USERS_CHALLENGED_SHOW = "fa.label.avg.challenges.per.user.header.show";
    public static String LABEL_AVG_CHALLENGES_PER_USER_SHOW = "fa.label.avg.challenges.per.user.header.show";
    public static String LABEL_TOTAL_SUCCESSES_SHOW = "fa.label.total.successes.header.show";
    public static String LABEL_USERS_WITH_SUCCESSES_SHOW = "fa.label.users.with.successes.header.show";
    public static String LABEL_TOTAL_FAILURES_SHOW = "fa.label.total.failures.header.show";
    public static String LABEL_USERS_WITH_FAILURES_SHOW = "fa.label.users.with.failures.header.show";
    public static String LABEL_USERS_WITH_MULTIPLE_FAILURES_SHOW = "fa.label.users.with.multiple.failures.header.show";
    public static String LABEL_TOTAL_LOCKOUTS_SHOW = "fa.label.total.lockouts.header.show";
    public static String LABEL_USERS_WITH_LOCKOUTS_SHOW = "fa.label.users.with.lockouts.header.show";

    public static String LABEL_CLIENT_TYPE_SHOW = "fa.label.clientType.show";
    public static String LABEL_CSR_ID_SHOW = "fa.label.csrid.show";
    public static String LABEL_PRE_AUTH_SCORE_SHOW = "fa.label.preAuthScore.show";
    public static String LABEL_PRE_AUTH_ACTION_SHOW = "fa.label.preAuthAction.show";
    public static String LABEL_POST_AUTH_SCORE_SHOW = "fa.label.postAuthScore.show";
    public static String LABEL_POST_AUTH_ACTION_SHOW = "fa.label.postAuthAction.show";
    public static String LABEL_CONNECTION_TYPE_SHOW = "fa.label.connectionType.show";
    public static String LABEL_ROUTING_TYPE_SHOW = "fa.label.routingType.show";
    public static String LABEL_CARRIER_SHOW = "fa.label.carrier.show";
    public static String LABEL_REQUEST_ID_SHOW = "fa.label.requestid.show";
    public static String LABEL_SESSION_ID_SHOW = "fa.label.sessionid.show";
    public static String LABEL_BROWSER_DETAILS_SHOW = "report.browser.details.show";    
    public static final String CONFIG_TRACKER_RULE_ALERT_DISABLE = "vcrypt.tracker.rule.alert.disable";
    public static final String CONFIG_TRACKER_RULES_ALLOW_OVERRIDES = "vcrypt.tracker.rules.allowOverrides";
    public static final String CONFIG_TRACKER_RULES_ALLOW_CONTROLLED_ACTIONS =
        "vcrypt.tracker.rules.allowControlledActions";

    public static String LABEL_IP_ADDRESS_SHOW = "fa.label.ipaddress_show";
    public static String LABEL_LOCATION_SHOW = "fa.label.location.show";
    public static String LABEL_OS_SHOW = "fa.label.os.show";
    public static String LABEL_LOGIN_TIME_SHOW = "fa.label.logintime.show";
    public static String LABEL_PRE_AUTH_STATUS_SHOW = "fa.label.preAuthStatus.show";
    public static String LABEL_ALERTS_SHOW = "fa.label.alerts.show";
    public static String LABEL_ISP_SHOW = "fa.label.isp.show";

    public static final String CONFIG_TRACKER_IMPORT_ELEMENTS = "tracker.import.model.includeElementsGroupTypes";
    public static final String CONFIG_TRACKER_EXPORT_ELEMENTS = "tracker.export.model.includeElementsGroupTypes";

    public static final String CONFIG_TRACKER_AUTH_CHALLENGE_COUNTER = "vcrypt.tracker.auth.challenge.counter";
    public static final String CONFIG_TRACKER_AUTH_OTP_COUNTER = "vcrypt.tracker.auth.otp.counter";
    public static final String CONFIG_TRACKER_RESET_CHALLENGE_COUNTER_ON_TEMP_ALLOW =
        "vcrypt.tracker.challenge.counter.resetOnTempallow";
    public static final String CONFIG_TRACKER_CHALLENGE_IGNORE_PENDING_STATUS = "vcrypt.tracker.challenge.counter.ignorePendingStatus";
    public static final String CONFIG_TRACKER_RESET_QUESTIONS_ON_UNLOCK =
        "vcrypt.tracker.challenge.unlock.resetQuestions";

    public static final String CONFIG_TRACKER_AUTH_CHALLENGE_COUNTER_RESET_SECS =
        "vcrypt.tracker.auth.challenge.counter.resetSecs";
    public static final String CONFIG_TRACKER_AUTH_OTP_COUNTER_RESET_SECS =
        "vcrypt.tracker.auth.otp.counter.resetSecs";

    public static final String LOCATION_IP_MAP_ATTRIBUTE_ENUM = "location.ipmap.attrib.enum";
    public static final String TRX_TRANSACTION_DATA_ENUM = "tracker.transaction.data.enum";
    public static final String TRX_ENTITY_PROFILE_DATA_ENUM = "tracker.transaction.entity.profile.data.enum";
    public static final String TRX_REQUEST_ID = "requestId";
    public static final String TRX_LOG_ID = "logId";
    public static final String TRX_LOG_LIST = "transactionLogList";
    public static final String TRX_INFO = "transactionInfo";
    public static final String TRX_SELECTED = "selectedTransaction";

    //Rule Template
    public static final String CONDITION_GLOBAL_ID = "conditionGlobalId";
    public static final String PARAMETER_NAME = "parameterName";
    public static final String PARAMETER_LABEL = "parameterLabel";
    public static final String PARAMETER_DEFAULT_VALUE = "parameterDefaultValue";
    public static final String RULE_DESCRIPTION = "description";
    public static final String RULE_NOTES = "notes";
    public static final String RULE_GLOBAL_ID = "global_id";
    public static final String RULE_TYPE_ID = "ruleTypeId";
    public static final String CONFIG_RULE_LOG_NOT_TRIGGERED = "vcrypt.tracker.rules.trace.notTriggered";
    public static final String CONFIG_RULE_LOG_NOT_TRIGGERED_LOG_MILLIS = "vcrypt.tracker.rules.trace.notTriggered.logMillis";
    public static final String CONFIG_RULE_LOG_DISABLE_READING_FP_LOGS = "vcrypt.tracker.rules.trace.disableReadingFingerprint";
    public static final String CONFIG_RULE_LOG_DISABLE_READING_RULE_LOG_TABLES = "vcrypt.tracker.rules.trace.disableReadingRuleLogTables";

    public static String RULE_CONDITIONS_LIST = "ruleConditionsList";
    public static String RULE_CONDITIONS_FILTER_LIST = "ruleConditionsFilterList";
    public static String RULE_CONDITION = "ruleCondition";
    public static String RULE_CONDITIONS = "ruleConditions";
    public static String RULE_CONDITION_MAP = "ruleConditionMap";
    public static String RULE_CONDITION_MAP_ID = "ruleConditionId";
    public static String CONDITION_TYPE = "conditionType";

    //Constants for RuleAuthoring

    public static final String PARAMETER_TAG = "Parameter";
    public static final String PARAMETERS_TAG = "Parameters";
    public static final String IDENTIFIER_ATTRIBUTE = "identifier";
    public static final String CLASS_TAG = "class";
    public static final String CONDITION_TAG = "Condition";
    public static final String CONDITIONS_TAG = "Conditions";
    public static final String GLOBAL_ID_ATTRIBUTE = "global_id";
    public static final String NAME_TAG = "Name";
    public static final String LABEL_TAG = "Label";
    public static final String DESCRIPTION_TAG = "Description";
    public static final String JAVA_CONDITION_TAG = "java:condition";
    public static final String JAVA_CONSEQUENCE_TAG = "java:consequence";
    public static final String IDENTIFIER_TAG = "Identifier";
    public static final String PARAMS_TAG = "Params";
    public static final String PARAM_TAG = "Param";
    public static final String PARAM_ORDER_TAG = "ParamOrder";
    public static final String JAVA_TAG = "JavaClass";
    public static final String VALUE_TYPE_TAG = "ValueType";
    public static final String VALUE_SUB_TYPE_TAG = "ValueSubType";
    public static final String NOTES_TAG = "Notes";
    public static final String DEFAULT_TAG = "Default";
    public static final String VALIDATIONS_TAG = "Validations";
    public static final String JAVA_CLASS_TAG = "JavaClass";
    public static final String BHAROSA_RULE_TAG = "BharosaRule";
    public static final String RULE_NAME_TAG = "name";
    public static final String RULE_DESCRIPTION_TAG = "description";
    public static final String RULE_TYPE_TAG = "type";
    public static final String RULE_NOTES_TAG = "notes";
    public static final String RULE_PARAM_TAG = "param";
    public static final String RULE_LABEL_TAG = "label";
    public static final String RULE_ORDER_TAG = "order";
    public static final String RULE_JAVA_CLASS_TAG = "javaclass";
    public static final String RULE_VALUE_TYPE_TAG = "valuetype";
    public static final String RULE_VALUE_SUB_TYPE_TAG = "valuesubtype";
    public static final String RULE_DEFAULT_VALUE_TAG = "default";
    public static final String RULE_VALIDATIONS_TAG = "validations";
    public static final String RULE_RULE_TAG = "rule";
    public static final String RULE_NAME_ATTRIBUTE = RULE_NAME_TAG;
    public static final String RULE_NO_LOOP_ATTRIBUTE = "no-loop";
    public static final String RULE_SALIENCE_ATTRIBUTE = "salience";
    public static final String RULE_PARAMETER_TAG = "parameter";
    public static final String INSTANCE_ID_COMMENT = "instance_id";
    public static final String CONDITION_INSTANCE_ID = "condition_instance_id";
    public static final String PARAM_META_GLOBAL_ID = "param_meta_global_id";

    public static final String VERSION_TAG = "version";
    public static final String CONDITION_TYPE_TAG = "ConditionType";
    public static final String COMPATIBLE_TAG = "compatible";
    public static final String OAAMSERVER_TAG = "OAAM_Server";
    public static final String RULE_CONDITION_TAG = "RuleCondition";
    public static final String NAMERBKEY_TAG = "NameRBKey";
    public static final String DESCRIPTIONRBKEY_TAG = "DescriptionRBKey";
    public static final String TYPELIST_TAG = "TypeList";
    public static final String TYPE_TAG = "Type";
    public static final String LABELRBKEY_TAG = "LabelRBKey";
    public static final String USER_TYPE = "user";
    public static final String DEVICE_TYPE = "device";    
    public static final String LOCATION_TYPE = "location";
    public static final String SESSION_TYPE = "session";
    public static final String EXT_DEVICE_ID = "extDeviceId";

    //risk analyzer constants.
    String RA_RUN_SESSION = "raRunSession";

    //RA enums
    public static final String RA_RUN_MODE = "runMode";
    public static final String RA_RUN_STATUS = "runStatus";
    public static final String RA_RUN_SESSION_NAME = "runSessionName";
    public static final String RA_RUN_SESSION_ID = "runSessionId";

    public static final String RA_SCHEDULE_INTERVAL_TYPE = "raScheduleType";
    public static final String RA_SCHEDULE_INTERVAL_VALUE = "raScheduleValue";
    public static final String RA_SCHEDULE_SUSPEND_TIME = "raSuspendTime";

    public static final String RA_SESSION_SET = "raSessionSet";
    public static final String RA_SESSION_SET_ID = "raSessionSetId";
    public static final String RA_SESSION_SET_TYPE = "raSessionSetType";
    public static final String RA_SESSION_SET_NAME = "raSessionSetName";
    public static final String RA_SESSION_SET_LIST = "raSessionSetList";
    public static final String RA_SESSION_SET_SELECT_LIST = "raSessionSetSelectList";
    String RA_SESSION_SET_GLOBAl_ID = "raSessionSetGlobalId";

    // Risk Analyzer Run type enum
    public static final String RA_RUN_TYPE_ENUM = "bharosa.ra.run.type.enum";

    // Risk Analyzer Config enum
    public static final String RA_CONFIG_STATUS_ENUM = "bharosa.ra.config.status.enum";

    //RA Config constants
    public static final String RA_CONFIG_ID = "raConfigId";
    public static final String RA_CONFIG_NAME = "raConfigName";
    public static final String RA_CONFIG_TYPE = "raConfigType";
    public static final String RA_CONFIG_STATUS = "raConfigStatus";
    public static final String RA_CONFIG_GLOBAL_ID = "raConfigGlobalId";
    public static final String RA_CONFIG_PROPERTY_ID = "raConfigPropertyId";
    public static final String RA_CONFIG_PROPERTY_NAME = "raConfigPropertyName";
    public static final String RA_CONFIG_PROPERTY_VALUE = "raConfigPropertyValue";
    public static final String RA_CONFIG_PROPERTY_GLOBAL_ID = "raConfigPropertyGlobalId";
    public static final String RA_CONFIG_PROPERTY_NOTES = "raConfigPropertyNotes";

    public static final String RA_CONFIG = "raConfig";
    public static final String RA_CONFIG_LIST = "raConfigList";
    public static final String RA_CONFIG_SELECT_LIST = "raConfigSelectList";
    public static final String RA_CONFIG_PROPERTY_LIST = "raConfigPropertyList";
    public static final String RA_CONFIG_PROPERTY = "raConfigProperty";

    String REPORT_LINEITEM_NEW_DEVICE = "newdevice";
    String REPORT_LINEITEM_NEW_USER = "newuser";

    // It is not necessary to say "public static final" in an interface.
    String LOADER_DATASOURCE_TABLE_NAME = "loader.datasource.tableName";
    String LOADER_DATASOURCE_REQUEST_ID_FIELD = "loader.datasource.requestIdField";
    String LOADER_DATASOURCE_BROWSER_FIELD = "loader.datasource.browserField";
    String LOADER_DATASOURCE_FLASH_FINGERPRINT_FIELD = "loader.datasource.flashFingerPrintField";
    String LOADER_DATASOURCE_IP_ADDRESS_FIELD = "loader.datasource.ipAddressField";
    String LOADER_DATASOURCE_GROUP_ID_FIELD = "loader.datasource.groupIdField";
    String LOADER_DATASOURCE_TRACKER_ID_FIELD = "loader.datasource.trackerIdField";
    String LOADER_DATASOURCE_MEMBER_ID_FIELD = "loader.datasource.memberIdField";
    String LOADER_DATASOURCE_LOGIN_ID_FIELD = "loader.datasource.loginIdField";
    String LOADER_DATASOURCE_LOGIN_TIMESTAMP_FIELD = "loader.datasource.loginTimestampField";
    String LOADER_DATASOURCE_DIGITAL_COOKIE_FIELD = "loader.datasource.digitalCookieField";
    String LOADER_DATASOURCE_SECURE_COOKIE_FIELD = "loader.datasource.secureCookieField";
    String LOADER_DATASOURCE_EXP_DIGITAL_COOKIE_FIELD = "loader.datasource.digitalCookieField";
    String LOADER_DATASOURCE_EXP_SECURE_COOKIE_FIELD = "loader.datasource.secureCookieField";
    String LOADER_DATASOURCE_AUTH_STATUS_FIELD = "loader.datasource.authStatusField";
    String LOADER_DATASOURCE_CLIENT_TYPE_FIELD = "loader.datasource.clientTypeField";
    String LOADER_DATASOURCE_EACH_DATA_FIELD = "loader.datasource.dataField";
    String LOADER_DATASOURCE_EACH_DATA_KEY = "loader.datasource.dataKey";
    String LOADER_DATASOURCE_TRX_TYPE_FIELD = "loader.datasource.trxTypeField";
    String LOADER_DATASOURCE_TRX_TYPE_KEY = "loader.datasource.trxTypeKey";
    String LOADER_DATASOURCE_TRX_STATUS_FIELD = "loader.datasource.trxStatusField";
    String LOADER_DATASOURCE_TRX_STATUS_KEY = "loader.datasource.trxStatusKey";

    public static final String BHAROSA_POLICY_TAG = "bharosa_policy";
    public static final String POLICY_TYPE_TAG = "policy_type";
    public static final String POLICY_STATUS_TAG = "policy_status";
    public static final String POLICY_SCORE_TAG = "policy_score";
    public static final String POLICY_WEIGHT_TAG = "policy_weight";
    public static final String POLICY_SCORING_TYPE_TAG = "policy_scoring_type";
    public static final String POLICY_FILENAME_TAG = "policy_filename";
    public static final String POLICY_ACTION_LIST_TAG = "policy_action_list";
    public static final String POLICY_ALERT_LIST_TAG = "policy_alert_list";
    public static final String POLICY_NOTES_TAG = "policy_notes";
    public static final String BHAROSA_POLICY_SET_TAG = "bharosa_policy_set";
    public static final String POLICY_SET_STATUS_TAG = "policy_set_status";
    public static final String POLICY_SET_SCORING_TYPE_TAG = "policy_set_scoring_type";
    public static final String POLICY_SET_NOTES_TAG = "policy_set_notes";
    public static final String POLICY_SET_FILENAME_TAG = "policy_set_filename";
    public static final String POLICY_SET_ACTION_LIST_TAG = "policy_set_action_list";
    public static final String POLICY_SET_ALERT_LIST_TAG = "policy_set_alert_list";

    public static final String BHAROSA_QUESTION_TAG = "bharosa_question";
    public static final String QUESTION_TYPE_TAG = "question_type";
    public static final String QUESTION_STATUS_TAG = "question_status";
    public static final String QUESTION_QUESTION_TAG = "question_question";
    public static final String QUESTION_CATEGORY_NAME_TAG = "question_category_name";
    public static final String QUESTION_CATEGORY_NAME_RBKEY_TAG = "question_category_name_rbkey";
    public static final String QUESTION_HELP_TAG = "question_help";
    public static final String QUESTION_ERROR_TEXT_TAG = "question_error_text";
    public static final String QUESTION_NOTES_TAG = "question_notes";

    public static final String BHAROSA_CATEGORY_TAG = "bharosa_category";
    public static final String CATEGORY_STATUS_TAG = "category_status";
    public static final String CATEGORY_TYPE_TAG = "category_type";
    public static final String CATEGORY_DESCRIPTION_TAG = "category_description";
    public static final String CATEGORY_NOTES_TAG = "category_notes";

    public static final String VALIDATION_NAME = "validationName";
    public static final String VALIDATION_NAME_RBKEY = "validationNameRBkey";
    public static final String VALIDATION_SCOPE = "validationScope";
    public static final String VALIDATION_SCHEME = "validationScheme";
    public static final String VALIDATION_ERROR_TEXT = "validationErrorText";
    public static final String VALIDATION_ERROR_TEXT_KEY = "validationErrorTextKey";
    public static final String VALIDATION_SCRIPT = "validationScript";
    public static final String VALIDATION_UPDATE_TIME = "validationUpdateTime";
    public static final String VALIDATION_ID = "validationId";
    public static final String VALIDATION_TYPE = "validationType";

    public static final String BHAROSA_VALIDATION_TAG = "bharosa_validation";
    public static final String VALIDATION_NAME_TAG = "validation_name";
    public static final String VALIDATION_NAME_RBKEY_TAG = "validation_name_rbkey";
    public static final String VALIDATION_SCOPE_TAG = "validation_scope";
    public static final String VALIDATION_SCHEME_TAG = "validation_scheme";
    public static final String VALIDATION_HELP_TAG = "validation_help";
    public static final String VALIDATION_ERROR_TEXT_TAG = "validation_error_text";
    public static final String VALIDATION_SCRIPT_TAG = "validation_script";
    public static final String VALIDATION_JAVA_CLASS_TAG = "validation_java_class";
    public static final String VALIDATION_ID_TAG = "validation_id";
    public static final String VALIDATION_DESCRIPTION_TAG = "validation_description";
    public static final String VALIDATION_DESCRIPTION_RBKEY_TAG = "validation_description_rbkey";

    public static final String BHAROSA_QUESTION_VALIDATION_MAP_TAG = "bharosa_question_validation_map";
    public static final String QUESTION_GLOBAL_ID_TAG = "question_global_id";
    public static final String VALIDATION_GLOBAL_ID_TAG = "validation_global_id";
    public static final String QUESTION_VALIDATION_MAP_VERION_NUM_TAG = "question_validation_map_version_num";
    public static final String BHAROSA_QUESTION_GLOBAL_VALIDATION_TAG = "bharosa_question_global_validation";
    public static final String GLOBAL_VALIDATION_VERION_NUM_TAG = "global_validation_verion_num";
    public static final String GLOBAL_VALIDATION_STATUS_TAG = "global_validation_status";

    public static final String BHAROSA_SCORING_POLICY_TAG = "bharosa_scoring_policy";
    public static final String SCORING_POLICY_TYPE = "scoring_policy_type";
    public static final String SCORING_POLICY_MIN_FINAL_SCORE = "scoring_policy_min_final_score";
    public static final String SCORING_POLICY_RUN_TIME_TYPE = "scoring_policy_run_time_type";
    public static final String SCORING_POLICY_VERSION_NUM = "scoring_policy_version_num";
    public static final String SCORING_POLICY_NOTES = "scoring_policy_notes";
    public static final String SCORE_ATTRIBUTE_TYPE = "score_attribute_type";
    public static final String SCORE_ATTRIBUTE_VERSION_NUM = "score_attribute_version_num";
    public static final String SCORE_ATTRIBUTE_NOTES = "score_attribute_notes";
    public static final String SCORE_ATTRIBUTE_WEIGHT = "score_attribute_weight";
    public static final String SCORE_ATTRIBUTE_SCORE = "score_attribute_score";
    public static final String SCORE_ATTRIBUTE_POLICY = "score_attribute_policy";
    public static final String SCORING_POLICY_SCORE_ATTR = "scoring_policy_score_attr";

    public static final String BHAROSA_ANSWER_HINT_TAG = "bharosa_answer_hint";
    public static final String ANSWER_HINT_NAME_TAG = "answer_hint_name";
    public static final String ANSWER_HINT_NAME_RBKEY_TAG = "answer_hint_name_rbkey";
    public static final String ANSWER_HINT_DESC_TAG = "answer_hint_desc";
    public static final String ANSWER_HINT_DESC_RBKEY_TAG = "answer_hint_desc_rbkey";
    public static final String ANSWER_HINT_SCHEME_TAG = "answer_hint_scheme";
    public static final String ANSWER_HINT_SCRIPT_TAG = "answer_hint_script";
    public static final String ANSWER_HINT_JAVA_CLASS_TAG = "answer_hint_java_class";
    public static final String ANSWER_HINT_ID_TAG = "answer_hint_id";
    public static final String ANSWER_HINT_NOTES_TAG = "answer_hint_notes";

    public static final String QUESTION_ANSWER_HINT_MAP_VERION_NUM_TAG = "question_answer_hint_map_verion_num";
    public static final String BHAROSA_QUESTION_ANSWER_HINT_MAP_TAG = "bharosa_question_answer_hint_map";
    public static final String BHAROSA_GLOBAL_ANSWER_HINT_TAG = "bharosa_global_answer_hint";
    public static final String ANSWER_HINT_GLOBAL_ID_TAG = "answer_hint_global_id";
    public static final String GLOBAL_ANSWER_HINT_VERION_NUM_TAG = "global_answer_hint_verion_num";
    public static final String GLOBAL_ANSWER_HINT_STATUS_TAG = "global_answer_hint_status";

    /*	// KBA CONSTANTS
	public static final String TOTAL_CHALLENGES = "totalChallenges";
	public static final String USERS_CHALLENGED = "usersChallenged";
	public static final String TOTAL_SUCCESSES = "totalSuccesses";
	public static final String PERCENT_USERS_CHALLENGED = "percentChallenged";
	public static final String USERS_WITH_SUCCESSES = "usersWithSuccesses";
	public static final String TOTAL_FAILURES = "totalFailures";
	public static final String USERS_WITH_FAILURES = "usersWithFailures";
	public static final String TOTAL_LOCKOUTS = "totalLockouts";
	public static final String USERS_WITH_LOCKOUTS = "usersWithLockouts";

	public static final String QUESTION_STATS_ID = "id";
	public static final String QUESTION_STATS_CATEGORY = "category";
	public static final String QUESTION_STATS_QUESTION = "question";
	public static final String QUESTION_STATS_PSETS_WITH_QUESTIONS = "pSetsWithQuestions";
	public static final String QUESTION_STATS_USERS_REG = "usersRegistered";
	public static final String QUESTION_STATS_PERCENT_USERS_REG = "percentUserReg";

	public static final String REGISTRATIONS_COUNT = "registrationsCount";
	public static final String QUESTION_RESTETS = "questionResets";
	public static final String USERS_WITH_QRESETS = "usersWithQResets";
	public static final String PICKSET_RESETS = "pickSetResets";*/

    // Scoring Policy constants
    public static String BHAROSA_SCORING_POLICY_TYPE_ID = "bharosa.scoring.policy.type.enum";

    // Score Attribute constants
    public static String BHAROSA_SCORING_SCORER_TYPE_ID = "bharosa.scoring.scorer.type.enum";

    public static final String SECURITY_QUESION_COUNT = "challenge.question.registration.groups.count";
    public static final String SECURITY_QUESION_PER_GROUP_COUNT =
        "challenge.question.registration.groups.questions.count";
    public static final String SECURITY_QUESION_PICKSET_RETRY_COUNT =
        "challenge.question.registration.pickset.retry.count";


    public static String ENUM_CHALLENGE_CHANNEL = "tracker.challenge.channel.enum";

    // Atul - Encryption engine enums
    public static final String BHAROSA_CIPHER_ENCRYPTION_ALGORITHM = "bharosa.cipher.encryption.algorithm.enum";

    public static String ENUM_ACTION_OVERRIDE = "tracker.action.override.reason.enum";

    public static String ENUM_PICK_SESSION_SCORE = "tracker.session.score.pick.enum";

    //Sumit - log4j configurations
    public static String ENUM_ADMIN_CONFIG_LOG4J = "bharosaconfig.type.enum";
    public static String LOGGER_NAME = "loggername";
    public static String LOGGER_UPDATE_KEYWORD = "loggerUpdateKeyword";
    public static String LOGGER_UPDATED_LEVEL = "loggerUpdatedLevel";


    // Bharosa Config Load Type
    public static String ENUM_BHAROSA_CONFIG_LOAD_TYPE = "bharosa.config.property.load.type.enum";
    // Lets use hard coded values so that proper values are available
    // at the time of initialization of BharosaConfig itself.
    public final int BHAROSA_CONFIG_LOAD_TYPE_PROPS = 1;
    public final int BHAROSA_CONFIG_LOAD_TYPE_DB = 2;
    public final int BHAROSA_CONFIG_LOAD_TYPE_SYSTEM = 3;

    String BHAROSA_CONFIG_BYPASS_RESOURCEBUNDLE = "bharosa.config.bypass.resourcebundle";
    String BHAROSA_CONFIG_RESOURCEBUNDLE_CLIENTOVERRIDE = "bharosa.config.resourcebundle.clientoverride";
    String BHAROSA_CONFIG_RESOURCEBUNDLE_LIST = "bharosa.config.resourcebundle.list";
    public final static String BHAROSA_LOCALE_ENUM_NAME = "bharosa.locale.enum";
    String BHAROSA_LOCALE_LIMITER = "bharosa.locale.limit.property";
    String LANGUAGE_KEY = "language";
    String COUNTRY_KEY = "country";
    String VARIANT_KEY = "variant";
    String BHAROSA_LOCALE = "bharosaLocale";
    String BHAROSA_FORMAT_LOCALE = "bharosaFormatLocale";
    String BHAROSA_USER_LOCALE = "userLocale";

    public static String ENUM_BHAROSA_CONFIG_LOGGER_LEVEL_TYPE = "bharosa.config.logger.level.type.enum";
    public static String ENUM_BHAROSA_PROPERTY_CONFIG_TYPE = "bharosa.config.property.config.type.enum";

    public static final String BHAROSA_PROPERTIES_TAG = "BharosaProperties";
    public static final String BHAROSA_PROPERTY_TAG = "BharosaProperty";
    public static final String BHAROSA_PROPERTY_NAME = "property_name";
    public static final String BHAROSA_PROPERTY_VALUE = "property_value";
    public static final String BHAROSA_PROPERTY_DESCRIPTON = "property_description";
    public static final String BHAROSA_PROPERTY_NOTES = "property_notes";
    public static final String BHAROSA_PROPERTY_CONFIG_TYPE = "property_config_type";
    public static final String BHAROSA_PROPERTY_LOAD_TYPE = "property_load_type";
    public static final String BHAROSA_PROPERTY_IS_ENCRYPTED = "property_is_encrypted";

    public static final String BHAROSA_PROPERTIES_SYSTEM_TAG = "bharosa_properties";

    //Report count constants
    public static final String REP_NUMBER_OF_LOGINS = "numberOfLogins";
    public static final String REP_NUMBER_OF_DEVICES_USED = "numberOfDevicesUsed";
    public static final String REP_NUMBER_OF_LOGINS_FAILURES = "numberOfLoginsFailures";
    public static final String REP_NUMBER_OF_ATTEMPTS = "numberOfAttempts";
    public static final String REP_NUMBER_OF_LOGINS_SUCCESS = "numberOfLoginsSuccess";
    public static final String REP_NUMBER_OF_USERS = "numberOfUsers";


    public static String ENUM_SCHEDULE_RANGE_TYPE_ID = "bharosa.queries.scheduler.edit.rangeType.enum";
    public static String ENUM_SCHEDULE_INTERVAL_TYPE_ID = "bharosa.queries.scheduler.edit.intervalType.enum";
    public static String ENUM_WEEKDAY_TYPE_ID = "bharosa.weekday.enum";

    //Condition Constants

    public static final String NEW_RULE_TEMPLATE_VERSION = "10.1.4.5";
    public static final String CONDITION = "condition";
    public static final String CONDITION_ID = "condition_id";
    public static final String CONDITION_SHOW = "condition_show";
    public static final String CONDITION_NAME = "conditionName";
    public static final String CONDITION_ID_FOR_DELETE = "condition_id_for_delete";
    public static final String PARAM_NAME = "paramName";
    public static final String PARAM_DESCRIPTION = "paramDescription";
    public static final String PARAM_LABEL = "paramLabel";
    public static final String PARAM_DEFAULT_VALUE = "paramDefaultValue";

    public static String FIND_BY_ENUM = "findByEnum";
    public static String FIND_BY_ELEMENT = "findByElement";
    public static String FIND_BY_PROPERTY = "findByProperty";

    String ENUMERATION_ID = "enumerationId";
    String ENUM_ELEMENT_ID = "enumElementId";
    String ENUM_ELEMENT_PROPERTY_ID = "enumElementpropertyId";

    public static String ENUM_ID = "enumId";
    public static String PROPERTY_ID = "propertyId";

    public static String LOCALE_KEY = "localeKey";
    public static String LOCALE = "locale";
    public static String FP_DATA = "fpdata";

    public static String ELEMENT_LIST = "elementList";
    public static String ELEMENT_SELECT_LIST = "elementSelectList";
    public static String ENUM_LIST = "enumsList";
    public static String PROPERTIES_LIST = "propertiesList";

    public static String PROPERTIES = "properties";
    public static String DATABASE_LOAD_TYPE = "database";
    public static String PROPERTIES_LOAD_TYPE = "properties";
    public static String SYSTEM_LOAD_TYPE = "system";
    public static String ALL = "All";
    public static String ENUM_SUFFIX = ".enum";

    public static String CURRENT_TAB_PARAM = "currentTab";
    public static String CURRENT_ID_PARAM = "currentId";
    public static String CURRENT_VALUE_PARAM = "currentValue";
    public static String ENUM_VALUE_PARAM = "enumValue";
    public static String ELEMENT_VALUE_PARAM = "elementValue";
    public static String PROPERTY_VALUE_PARAM = "propertyValue";
    public static String ELEMENT_NAME_PARAM = "elementName";
    public static String ELEMENT_DESCRIPTION_PARAM = "elementDescription";
    public static String KEY_PARAM = "key";
    public static String VALUE_PARAM = "value";
    public static String TARGET_ERROR = "error";
    public static String ELEMENT_DEFAULT_PROPERTY_NAME = "name";
    public static String ELEMENT_DEFAULT_PROPERTY_DESCRIPTION = "description";

    public static final String BHAROSA_LOCALE_TAG = "bharosa_locale";
    public static final String BHAROSA_LOCALE_NAME = "bharosa_locale_name";
    public static final String BHAROSA_LOCALE_NAME_RBKEY = "bharosa_locale_name_rbkey";
    public static final String BHAROSA_LOCALE_LANGUAGE = "bharosa_locale_language";
    public static final String BHAROSA_LOCALE_COUNTRY = "bharosa_locale_country";
    public static final String BHAROSA_LOCALE_NOTES = "bharosa_locale_notes";
    public static final String BHAROSA_LOCALE_KEY = "bharosa_locale_key";
    public static final String BHAROSA_LOCALE_VARIANT = "bharosa_locale_variant";
    public static final String BHAROSA_LOCALE_VERSION = "bharosa_locale_version";
    public static final String QUESTION_LOCALE_GLOBAL_ID_TAG = "question_locale_global_id";
    public static final String QUESTION_LOCALE_TAG = "question_locale";

    public static String DUP_QUESTION_ERROR_MSG = "This Question already exists in database with value ";

    public static final String BHAROSA_OAAM_QUESTIONS_TAG = "OAAMQuestions";
    public static final String BHAROSA_QUESTIONS_LOCALE_TAG = "Locale";
    public static final String BHAROSA_QUESTIONS_LOCALE_KEY_TAG = "locale";
    public static final String BHAROSA_QUESTIONS_CATEGORY_TAG = "Category";
    public static final String BHAROSA_CATEGORY_NAME_TAG = "name";
    public static final String BHAROSA_QUESTIONS_TAG = "Question";
    public static final String BHAROSA_KBA_QUESTIONS_TAG = "kba_questions";

    public static String TRACKER_TRANSACTION_DATA_GEN_SCHEME_ENUM = "tracker.transaction.data.generation.scheme.enum";

    public static String TRACKER_TRANSACTION_ENT_ID_SCHEME_ENUM =
        "tracker.transaction.entity.identification.scheme.enum";

    public static String TRACKER_TRANSACTION_PROFILE_DATA_TYPE_ENUM =
        "tracker.transaction.entity.profile.data.type.enum";
    public static String TRACKER_TRANSACTION_CONDITION_TYPE_ENUM = "tracker.transaction.data.conditions.enum";
    public static String TRACKER_TRANSACTION_FUNCTION_TYPE_ENUM = "tracker.transaction.data.functions.enum";
    public static String TRACKER_TRANSACTION_AGGREGRATE_FUNCTION_TYPE_ENUM =
        "tracker.transaction.data.aggregrate.functions.enum";
    public static String TRACKER_TRANSACTION_NESTED_COUNT_FUNCTION_TYPE_ENUM =
        "tracker.transaction.data.nestedcount.functions.enum";
    public static String TRACKER_TRANSACTION_GROUP_FUNCTION_TYPE_ENUM = 
        "tracker.transaction.data.group.functions.enum";

    public static String TRACKER_TRANSACTION_SIMPLE_FILTERS_ENUM =
        "tracker.transaction.rules.filter.simplefilter.enum";
    public static String TRACKER_TRANSACTION_CONTEXT_FILTERS_ENUM =
        "tracker.transaction.rules.filter.contextfilter.enum";
    public static String TRACKER_TRANSACTION_FILTER_KEY_TYPE_ENUM = "tracker.transaction.filter.key.type.enum";
    public static String TRACKER_TRANSACTION_FILTER_VALUE_TYPE_ENUM = "tracker.transaction.filter.value.type.enum";

    //Pattern Constants
    public static String ENUM_AUTOLEARNING_CREATION_METHOD = "bharosa.autoLearning.pattern.creationMethod.enum";
    public static String ENUM_AUTOLEARNING_PATTERN_STATUS = "bharosa.autoLearning.pattern.status.enum";
    public static String ENUM_AUTOLEARNING_PATTERN_RUNTIME = "bharosa.autoLearning.pattern.runtime.enum";
    public static String ENUM_AUTOLEARNING_PATTERN_PARAM_COMPARE =
        "bharosa.autoLearning.pattern.param.compareOperator.enum";
    public static String ENUM_AUTOLEARNING_PATTERN_PARAM_TYPE = "bharosa.autoLearning.pattern.param.type.enum";
    public static String ENUM_AUTOLEARNING_PATTERN_AUTH_MEMBER_TYPE =
        "bharosa.autoLearning.pattern.authentication.memberType.enum";
    public static String ENUM_AUTOLEARNING_RULE_WORKFLOW_INTERVAL_TYPE =
        "bharosa.autoLearning.rule.workflow.intervalType.enum";
    public static String ENUM_AUTOLEARNING_AUTH_ATTRIBUTE =
        "bharosa.autoLearning.pattern.params.attribute.authentication.enum";
    public static String ENUM_AUTOLEARNING_PATTERN_PARAM_STATUS = "bharosa.autoLearning.pattern.param.status.enum";
    public static String PATTERN_NAME = "name";
    public static String TIME_INTERVAL_TYPE_ENUM = "time.unit.enum";
    public static String TIME_INTERVAL_WORKFLOW_TYPE_ENUM = "time.unit.workflow.enum";
    String PROP_ANALYZE_TRANSACTION_PATTERNS = "oracle.oaam.transactions.analyzepatterns";

    public static String TRACKER_TXN_TRANS_OBJ_TYPE_ENUM = "tracker.transaction.transformation.object.type.enum";
    public static String TRACKER_TXN_OBJECTS_STATUS_ENUM = "tracker.transaction.objects.status.enum";

    public static final String DELETE_COMMAND = "delete";
    public static final String CREATE_COMMAND = "create";
    public static final String UPDATE_COMMAND = "update";

    public static final String NEW_RULE_TEMPLATE = "NEW_RULE_TEMPLATE";
    public static final String OAAM_KBA_QUESTIONS = "oaam_kba_questions";
    public static final String PROPERTIES_FILE_EXTENSION = ".properties";
    public static final String OAAM_QUESTION_CATEGORY = "question.c";

    // Transaction Constants

    public static String TRANSACTION_STATUS = "transactionStatus";
    public static String TRANSACTION_NAME = "transactionName";
    public static String TRANSACTION_ID = "transactionId";
    public static String TRANSACTION_DEF_KEY = "transactionDefKey";
    public static String TRX_ENT_ID = "transactionEntityId";
    public static String TRANSACTION_ID_IN_CONTEXT_MAP = "$TRANSACTION_ID";
    
    String TRANSACTION_FQKEY = "transactionFQKey";
    String ENTITY_FQKEY = "entityFQKey";
    String EXT_TRANSACTION_ID = "extTransactionId";
    String TRANSACTION_TYPE = "transactionType";
    String ENTITY_TYPE = "ENTITY_TYPE";
    String ENTITY_DATA_TYPE = "ENTITY_DATA_TYPE";
    String TRX_DATA_TYPE = "TRX_DATA_TYPE";
    String TRX_DATA_VALUE = "TRX_DATA_VALUE";
    String ENTITY_DATA_VALUE = "ENTITY_DATA_VALUE";

    String FILTER_VALUE_TYPE_GROUP_NAME = "FILTER_VALUE_TYPE_GROUP_NAME";
    String FILTER_VALUE_TYPE_SIMPLE_VALUE = "FILTER_VALUE_TYPE_SIMPLE_VALUE";
    String FILTER_VALUE_TYPE_CURRENT_TRX = "FILTER_VALUE_TYPE_CURRENT_TRX";
    String TRANSACTION_OBJ = "TRANSACTION_OBJ";
    String CONDITION_DESCRIPTOR = "CONDITION_DESCRIPTOR";

    //public static String ENTITY_DATA_EDIT_DATE = "entityDataEditDate";
    public static String TRANSACTION_DATA_ELEM_LIST = "transactionDataElemList";
    public static String TRANSACTION_ENTITIES_LIST = "transactionEntitiesList";
    public static String TRANSACTION_DATA_MAP_MULTI_DELETE = "transactionDataMapMultiDelete";
    public static String TRANSACTION_ENTITY_MAP_MULTI_DELETE = "transactionEntitiesMapMultiDelete";
    public static String TRANSACTION_ENTITY_DATA_NAME = "transactionEntityDataName";
    public static String TRANSACTION_ENTITY_KEY = "transactionEntityKey";
    public static String TRANSACTION_ENTITY_DESCRIPTION = "transactionEntityDescription";
    public static String TRANSACTION_ENTITY_ROW_CNT = "transactionEntityRowCnt";
    String TRANSACTION_TYPE_LIST = "transactionDefList";
    String TRX_DATA_TYPE_LIST = "trxDataDefList";
    String ENTITY_TYPE_LIST = "entityDefList";
    String ENTITY_DATA_TYPE_LIST = "entityDataDefList";
    String ADMIN_GROUP_LIST = "adminGroupList";
    String CURRENT_TRX_LIST = "CURRENT_TRX_LIST";
    String TRX_DB_FIELDS_FILTER_LIST = "TRX_DB_FIELDS_FILTER_LIST";
    String NUMERIC_TRX_DATA_LIST = "NUMERIC_TRX_DATA_LIST";
    String TRX_ATTRIBUTE_FILTER_LIST = "TRX_ATTRIBUTE_FILTER_LIST";
    String TRX_CONTEXT_FILTER_LIST = "TRX_CONTEXT_FILTER_LIST";
    String ALL_TRX_LIST = "ALL_TRX_LIST";

    // Entity Constants
    public static String ENTITY_ID = "entityId";
    public static String ENTITY_NAME = "entityName";
    public static String ENTITY_STATUS = "entityStatus";
    public static String ENTITY_DESCRIPTION = "entityDescription";
    public static String ENTITY_KEY = "entityKey";
    public static String ENTITY_DATA_ELEM_LIST = "entityDataElemList";
    public static String ENTITY_DATA_IS_REQUIRED = "entityDataIsRequired";
    public static String ENTITY_DATA_IS_ENCRYPTED = "entityDataIsEncrypted";
    public static String ENTITY_DATA_ROW = "entityDataRow";
    public static String ENTITY_DATA_COLUMN = "entityDataColumn";
    public static String ENTITY_DATA_DESCRIPTION = "entityDataDescription";
    public static String ENTITY_DATA_DATA_TYPE = "entityDataType";
    public static String ENTITY_DATA_LABEL = "entityDataName";
    public static String ENTITY_DATA_INT_ID = "entityDataIntID";
    public static String ENTITY_DATA_MAP_SELECT = "entityDataMapSelect";
    public static String ENTITY_DATA_DEF_ELEM_ID = "entityDataDefElemID";
    public static String DATA_DEF_ELEM_NAME = "dataDefElemName";
    public static String ORDERED_ENTITY_DATA_DEF_ELEMS = "orderedDataDefElems";
    public static String ENTITY_DATA_DEF_ELEM_ORDER = "DataDefElemOrder";
    public static String NO_OF_ORDERED_DATA_ELEMS = "NoOfDataElementsUpdated";
    public static String ENTITY_DATADEF_ELEM_ROW_CNT = "entityDataDefElemRowCnt";
    public static String ENTITY_DATADEF_ELEM_COLUMN_CNT = "entityDataDefElemColumnCnt";
    public static String IDSCHEME_DISPLAY_DATA_ELEM_LIST = "idSchemedisplayDataDefElemts";
    public static String DATA_DEF_ELEM_DELETE_LIST = "removelist";
    public static String DISPLAY_NAME_GEN_SCHEME = "nameGenScheme";
    public static String IDSCHEME_NAME_GEN_SCHEME = "keyGenScheme";
    public static String IDSCHEME_DISPLAY_NAME_GEN_SCHEME = "idSchemeDisplayNameGenScheme";
    public static String ENTITY_GEN_SCHEME = "entity_generation_scheme";

    //DB Error ID
    String DB_ERROR_ID = "bharosa.db.error.msg";
    String TECHNICAL_ERROR = "bharosa.arm.message.error.technical";

    // AUTO Learning constants
    public static String AUTOLEARN_USE_AUTH_STATUS = "vcrypt.tracker.autolearning.use.auth.status.for.analysis";
    public static String AUTOLEARN_USE_TRANS_STATUS = "vcrypt.tracker.autolearning.use.tran.status.for.analysis";
    public static String AUTOLEARN_ENABLED = "vcrypt.tracker.autolearning.enabled";
    public static String AUTO_LEARN_NUM_PRIORITIES = "vcrypt.bharosa.autolearning.numPriorities";
    public static String AUTO_LEARN_THREAD_MULTIPLIER = "vcrypt.bharosa.autolearning.threadMultiplier";
    
    public static String AUTO_LEARN_CHECK_FOR_NEW_SYSTEM = "vcrypt.bharosa.autolearning.chek.for.al.data.for.new.system";
    public static String AUTO_LEARN_CHECK_PROPERTY_BASED_PROFILE_DATA_STATUS = "vcrypt.bharosa.autolearning.chek.property.based.profile.data.status";
    public static String AUTO_LEARN_PROFILE_DATA_AVAILABLE = "vcrypt.bharosa.autolearning.profile.data.available";

    //Scheduler Constants
    public static String TSKGRP_ENABLE_VIEW = "enableView";
    public static String TSKGRP_DISABLE_VIEW = "disableView";
    public static String TSKGRP_EXECUTENOW_VIEW = "executeNowView";
    public static String TSKGRP_ID = "tskgrpId";
    public static String TSKGRP_NAME = "tskgrpName";
    public static String TSKGRP_STATUS = "tskgrpStatus";
    public static String TSKGRP_SCHEDULE_TYPE = "tskgrpScheduleType";
    public static String TSKGRP_RECURR_TYPE = "tskgrpRecurrenceType";
    public static String TSKGRP_RECURR_INTERVAL = "tskgrpRecurrenceInterval";
    public static String TSKGRP_RECURR_ENDDATE = "tskgrpRecurrenceEndDate";
    public static String TSKGRP_CREATE_TIME = "tskgrpCreateTime";
    public static String TSKGRP_BEGIN_CREATE_TIME = "tskgrpBeginCreateTime";
    public static String TSKGRP_END_CREATE_TIME = "tskgrpEndCreateTime";
    public static String TSKGRP_NEXT_EXECUTE_TIME = "tskgrpNextExecTime";
    public static String TSKGRP_BEGIN_NEXT_EXECUTE_TIME = "tskgrpBeginNextExecTime";
    public static String TSKGRP_END_NEXT_EXECUTE_TIME = "tskgrpEndNextExecTime";
    public static String TSKGRP_RECURR_STARTDATE = "tskgrpRecurrenceStartDate";
    public static String SUBTSK_ID = "subTskId";
    public static String SUBTSK_NAME = "subTskName";
    public static String SUBTSK_TYPE = "subTskType";
    public static String SUBTSK_CREATE_TIME = "subTskCreateTime";
    public static String SUBTSK_BEGIN_CREATE_TIME = "subTskBeginCreateTime";
    public static String SUBTSK_END_CREATE_TIME = "subTskEndCreateTime";
    public static String SUBTSK_STATUS = "subTskStatus";
    public static String SUBTSK_MAXEXEC_TIME = "subTskMaxExecTime";
    public static String ENUM_RECURRING_TYPE = "schedule.taskgroup.recurrtype.enum";
    public static String ENUM_TSKGRP_STATUS = "schedule.taskgroup.status.enum";
    public static String ENUM_SCHEDULE_TYPE = "schedule.taskgroup.scheduletype.enum";
    public static String ENUM_SUBTASK_TYPE = "schedule.subtask.type.enum";
    public static String ENUM_SUBTASK_STATUS = "schedule.subtask.status.enum";
    public static String ENUM_TASK_EXEC_STATUS = "schedule.task.execution.status.enum";
    String ENUM_JOB_PRIORITY = "oaam.schedule.priority.enum";
    String ENUM_TASK_CONFIG_CATEGORY_ENUM = "oaam.schedule.jobproperty.category.enum";
    String ENUM_TASK_PROPERTIES_PREFIX = "schedule.taskproperties.";
    String ENUM_TASK_PROPERTY_CRITERIA_PREFIX = "schedule.criteria.";
    String LOCKING_CONFIG_INITIAL_LEASE = "locking.config.locking.config.initialLeaseTime";
    String LOCKING_CONFIG_AUTORENEW = "locking.config.autoRenew";
    String LOCKING_AVAILIBILITY_POLLING = "locking.availibilty.polling";
    String TASKGROUP_QUEUETIME_MINUTES = "schedule.taskgroup.queuetime.minutes";
    String TASKGROUP_PROGRESS_MONITOR_INTERVAL = "schedule.taskgroup.progress.monitor.interval";
    String TASKGROUP_STATUS_MONITOR_INTERVAL = "schedule.taskgroup.status.monitor.interval";
    String ENUM_SCHEDULE_EXECUTION_LOGTYPE = "schedule.task.execution.logtype.enum";
    String ENUM_SCHEDULE_EXECUTION_INTERIM_LOGNAME = "schedule.task.execution.interim.logname.enum";
    String ENUM_SCHEDULE_EXECUTION_FINAL_LOGNAME = "schedule.task.execution.final.logname.enum";
    String ENUM_SCHEDULE_EXECUTION_PERFORMANCE_LOGNAME = "schedule.task.execution.performance.logname.enum";
    String ENUM_SCHEDULE_EXECUTION_LOGNAME_PREFIX = "schedule.task.execution.";
    String ENUM_SCHEDULE_EXECUTION_LOGNAME_SUFFIX = ".logname.enum";
    String SCHEDULE_BLOCKINGCALL_MAX_WAIT_TIME = "schedule.blockingcall.maxwaittime";
    String TASK_EXECUTOR_WAIT_IF_NO_TASKS = "schedule.taskexec.wait.if.no.tasks";
    String ENUM_LOADER_TYPE = "oaam.offline.loadertype.enum";
    String ENUM_RUN_TYPE = "oaam.offline.runtype.enum";
    String SCHEDULE_RESCHEDULE_DELAY = "oaam.schedule.reschedule.delay.minutes";
    String ENUM_OFFLINE_LOADER_DATABASEPLATFORM = "oaam.offline.loader.databaseplatform.enum";

    public static String IS_ELEMENT_ENABLED = "is_element_enabled";

    public static String TRACKER_USERNODE_POST_PROCESS_STATUS = "postProcessStatus";
    public static String AUTOLEARNING_LOG_STATUS_ENUM = "bharosa.autolearning.logstatus.enum";

    //Imported Object Enum
    public final static String ENUM_IMPORTED_OBJECT_STATUS = "imported.object.status.enum";

    String ENUM_MONITOR_ROLLUP_TYPE = "monitor.rollup.type.enum";

    // compare numeric operator enum
    public static String COMPARE_NUMERIC_OPERATOR_ENUM = "bharosa.numeric.eval.operator.enum";
    
    // date field enum
    public static String DATE_FIELD_ENUM = "date.field.enum";
    
  // date field compare enum
  public static String DATE_FIELD_COMAPRE_ENUM = "date.field.compare.enum";

    public static String SNAPSHOT_OBJECT_TYPE_ENUM = "oaam.snapshot.object.type.enum";
    public static String SNAPSHOT_OBJECT_OPER_ENUM = "oaam.snapshot.object.operation.enum";
  
    public static final String DEVICE_TYPE_ENUM = "device.type.enum";
    
    public static String PAGESIZE_STACK_TRACE_FLG = "query.pagesize.print.stacktrace.flag";
  
}

