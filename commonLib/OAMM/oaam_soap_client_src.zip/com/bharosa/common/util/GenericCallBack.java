package com.bharosa.common.util;
/**
   The users of MTQueue and other async event process classes need to
   implement this method.
   @author Don Bosco Durai
*/

/**
 *This method will be called when anything is added to the queue.
 */
public interface GenericCallBack<T> {
  public void processRequest( String eventId, T obj );
}
