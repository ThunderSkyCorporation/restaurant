package com.bharosa.common.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.StringTokenizer;
import java.util.List;

import com.bharosa.common.logger.Logger;
import com.bharosa.common.exception.ValidationException;
import com.bharosa.vcrypt.bean.VIPLocationMap;
import com.bharosa.vcrypt.bean.VIPLocationMapSplit;

/**
 * This has some utility methods for manipulating IPs
 *
 * @author bosco
 */

public class IPUtil {
    static Logger logger = Logger.getLogger(IPUtil.class);
    static boolean useLong = BharosaConfig.getBoolean("bharosa.ip.uselong", true);
    static String ipv6IPString = BharosaConfig.get("bharosa.ip.v6.string", "127.0.0.99");
    public static BharosaPropertyBoolean IGNORE_SPLITS = new BharosaPropertyBoolean("location.loader.splits.ignore", false);

    /**
     * This checks whether this is a valid IP address
     *
     * @param ipString a <code>String</code> value
     * @return a <code>boolean</code> value
     */
    static public boolean isValidIP(String ipString) {
        try {
            ip2long(ipString);
        } catch (Exception ex) {
            return false;
        }
        return true;
    }

    static public boolean isValidPartialIP(String ipString) {
        try {
            String ipMin = partialIpMin(ipString);
            return isValidIP(ipMin);
        } catch (Exception ex) {
            return false;
        }
    }

    /**
     * Converts IP in string format to long value
     *
     * @param ipString IP in string format
     * @return IP in long value
     * @throws ValidationException Describe here in what conditions, this exception is thrown.
     */
    static public long ip2long(String ipString) throws ValidationException {
        try {
            if (StringUtil.isEmpty(ipString)) {
                throw ValidationException.createInvalidIPAddress(ipString,
                        "value is null or empty string");
            }
            ipString = ipString.trim();
            ipString = iPv6toIPv4Mapping(ipString);

            StringTokenizer st = new StringTokenizer(ipString, ".");
            if (st.countTokens() != 4) {
                throw ValidationException.createInvalidIPAddress(ipString,
                        "Got only " +
                                st.countTokens() +
                                " tokens instead of 4");
            }
            int shift = 24;
            long val = 0;
            int argc = 0;
            boolean multicastCheck = false;
            while (st.hasMoreTokens()) {
                long longValue = -1;
                if (useLong) {
                    longValue = Long.parseLong(st.nextToken());
                } else {
                    longValue = Integer.parseInt(st.nextToken());
                }
                if (longValue < 0 || longValue > 255) {
                    throw ValidationException.createInvalidIPAddress(ipString,
                            "" +
                                    longValue +
                                    "Value " +
                                    longValue +
                                    " found in position " +
                                    argc +
                                    " is not between 0 to 255");
                }
                /*
                     if (argc == 0 && longValue == 0) {
                             throw ValidationException.createInvalidIPAddress( ipString,
                               "Value " + longValue
                               + " found in position "       + argc
                               + ". IP Address should not start with 0" );
                     } // end of if (argc == 0 && longValue == 0)
                     if (argc != 0 && longValue == 255) {
                             if (argc == 1 && !multicastCheck) {
                                     multicastCheck = true ;
                             } // end of if (argc == 1 && !multicastCheck)
                     } else {
                             multicastCheck = false ;
                     } // end of else
                     */
                val += longValue << shift;
                shift -= 8;
                argc++;
            }
            /*
                if (multicastCheck) {
                        throw ValidationException.createInvalidIPAddress( ipString,
                          "IP Address should not be a multicast address" );
                } // end of if (multicastCheck)
                */
            return val;
        } catch (Exception ex) {
            throw ValidationException.createInvalidIPAddress(ipString,
                    ex.toString());
        }
    }

    static public String partialIpMin(String ipString) throws ValidationException {
        ipString = iPv6toIPv4Mapping(ipString);
        StringTokenizer st = new StringTokenizer(ipString, ".");
        int tokenDiff = 4 - st.countTokens();
        while (ipString.endsWith(".")) {
            ipString = ipString.substring(0, ipString.length() - 1);
        }
        for (int i = 0; i < tokenDiff; i++) {
            ipString = ipString + ".0";
        }
        return ipString;
    }

    static public String partialIpMax(String ipString) throws ValidationException {
        ipString = iPv6toIPv4Mapping(ipString);

        StringTokenizer st = new StringTokenizer(ipString, ".");
        int tokenDiff = 4 - st.countTokens();
        while (ipString.endsWith(".")) {
            ipString = ipString.substring(0, ipString.length() - 1);
        }
        for (int i = 0; i < tokenDiff; i++) {
            ipString = ipString + ".255";
        }
        return ipString;
    }

    /**
     * Converts a long value to IP
     *
     * @param ipLong IP in long value
     * @return the string representation of the IP address
     */
    static public String long2ip(long ipLong) {
        StringBuffer b = new StringBuffer();
        b.append((ipLong >> 24) & 0xff);
        b.append(".");
        b.append((ipLong >> 16) & 0xff);
        b.append(".");
        b.append((ipLong >> 8) & 0xff);
        b.append(".");
        b.append(ipLong & 0xff);
        return b.toString();
    }

    /**
     * Parses the ip and returns the address of the
     * IP set this IP belongs to.
     * @param ipAddr IP Address
     */
    public static String getSetAddress(String ipAddr) {
        if (StringUtil.isEmpty(ipAddr)) {
            logger.info("Invalid IP address  passed to getSetAddress(). ipAddress=" + ipAddr);
            return ipAddr;
        }
        ipAddr = iPv6toIPv4Mapping(ipAddr);

        String[] splits = ipAddr.split("\\.");
        if (splits == null || splits.length != 4) {
            logger.warn("Invalid IP address  passed to getSetAddress(). ipAddress=" + ipAddr);
            return ipAddr;
        }
        return splits[0] + "." + splits[1] + "." + splits[2] + ".0";
    }


    /**
     * Parses the ip and returns the end address of the
     * IP set this IP belongs to.
     */
    public static String getSetEndAddress(String ipAddr) {
        if (StringUtil.isEmpty(ipAddr)) {
            logger.info("Invalid IP address  passed to getSetAddress(). ipAddress=" + ipAddr);
            return ipAddr;
        }

        ipAddr = iPv6toIPv4Mapping(ipAddr);
        
        String[] splits = ipAddr.split("\\.");
        if (splits == null || splits.length != 4) {
            logger.warn("Invalid IP address  passed to getSetAddress(). ipAddress=" + ipAddr);
            return ipAddr;
        }
        return splits[0] + "." + splits[1] + "." + splits[2] + ".255";
    }

    public static VIPLocationMap copyVIPLocationMap(VIPLocationMap location) {
        VIPLocationMap newLocation = new VIPLocationMap();

        newLocation.setAsn(location.getAsn());
        newLocation.setCarrier(location.getCarrier());
        newLocation.setCityCF(location.getCityCF());
        newLocation.setCityId(location.getCityId());
        newLocation.setConnectionSpeed(location.getConnectionSpeed());
        newLocation.setConnectionType(location.getConnectionType());
        newLocation.setCountryCF(location.getCountryCF());
        newLocation.setCountryId(location.getCountryId());
        newLocation.setDma(location.getDma());
        newLocation.setFromIPAddr(location.getFromIPAddr());
        newLocation.setIpRangeId(location.getIpRangeId());
        newLocation.setIpRoutingType(location.getIpRoutingType());
        newLocation.setIspId(location.getIspId());
        newLocation.setIsSplit(location.getIsSplit());
        newLocation.setMetroId(location.getMetroId());
        newLocation.setMsa(location.getMsa());
        newLocation.setNotes(location.getNotes());
        newLocation.setPhoneAreaCode(location.getPhoneAreaCode());
        newLocation.setPmsa(location.getPmsa());
        newLocation.setRegionId(location.getRegionId());
        newLocation.setSecondLevelDomain(location.getSecondLevelDomain());
        newLocation.setStateCF(location.getStateCF());
        newLocation.setStateId(location.getStateId());
        newLocation.setToIPAddr(location.getToIPAddr());
        newLocation.setTopLevelDomain(location.getTopLevelDomain());
        newLocation.setZipCode(location.getZipCode());

        return newLocation;
    }

    public static boolean isUpdate(VIPLocationMap base, VIPLocationMap upd) throws ValidationException {
        return IPUtil.ip2long(base.getFromIPAddr()) != IPUtil.ip2long(upd.getFromIPAddr())
                || IPUtil.ip2long(base.getToIPAddr()) != IPUtil.ip2long(upd.getToIPAddr())
                || base.getIsSplit() != upd.getIsSplit()
                || isUpdate(base.getCountryId(), upd.getCountryId())
                || isUpdate(base.getStateId(), upd.getStateId())
                || isUpdate(base.getCityId(), upd.getCityId())
                || isUpdate(base.getIspId(), upd.getIspId())
                || isUpdate(base.getIpRoutingType(), upd.getIpRoutingType())
                || isUpdate(base.getConnectionType(), upd.getConnectionType())
                || isUpdate(base.getConnectionSpeed(), upd.getConnectionSpeed())
                || isUpdate(base.getTopLevelDomain(), upd.getTopLevelDomain())
                || isUpdate(base.getSecondLevelDomain(), upd.getSecondLevelDomain())
                || isUpdate(base.getAsn(), upd.getAsn())
                || isUpdate(base.getCarrier(), upd.getCarrier())
                || isUpdate(base.getCountryCF(), upd.getCountryCF())
                || isUpdate(base.getStateCF(), upd.getStateCF())
                || isUpdate(base.getCityCF(), upd.getCityCF())
                || isUpdate(base.getZipCode(), upd.getZipCode())
                || isUpdate(base.getDma(), upd.getDma())
                || isUpdate(base.getMsa(), upd.getMsa())
                || isUpdate(base.getPmsa(), upd.getPmsa())
                || isUpdate(base.getRegionId(), upd.getRegionId())
                || isUpdate(base.getPhoneAreaCode(), upd.getPhoneAreaCode())
                ;
    }

    public static boolean isUpdate(List base, List upd) throws ValidationException {
        if (base == null && upd == null) {
            return false;
        } else if (base == null || upd == null) {
            return true;
        } else if (base.size() != upd.size()) {
            return true;
        } else {
            for (int i = 0; i < base.size(); i++) {
                if (isUpdate((VIPLocationMapSplit) base.get(i), (VIPLocationMapSplit) upd.get(i)))
                    return true;
            }
        }

        return false;

    }

    public static boolean isUpdate(VIPLocationMapSplit base, VIPLocationMapSplit upd) throws ValidationException {
        return IPUtil.ip2long(base.getBaseIPAddr()) != IPUtil.ip2long(upd.getBaseIPAddr())
                || IPUtil.ip2long(base.getFromIPAddr()) != IPUtil.ip2long(upd.getFromIPAddr())
                || IPUtil.ip2long(base.getToIPAddr()) != IPUtil.ip2long(upd.getToIPAddr())
                || isUpdate(base.getNotes(), upd.getNotes())
                || isUpdate(base.getSecondLevelDomain(), upd.getSecondLevelDomain())
                ;
    }

    private static boolean isUpdate(String base, String upd) {
        return upd != null && upd.length() != 0 &&
                (base == null || base.length() == 0 || (base != upd) && !base.equals(upd));
    }

    private static boolean isUpdate(Object base, Object upd) {
        return upd != null &&
                (base == null || (base != upd) && !base.equals(upd));
    }

    public static void copyVIPLocationMap(VIPLocationMap to, VIPLocationMap from) {
        if (from.getFromIPAddr() != null)
            to.setFromIPAddr(from.getFromIPAddr());

        if (from.getToIPAddr() != null)
            to.setToIPAddr(from.getToIPAddr());

        to.setIsSplit(from.getIsSplit());

        if (from.getCountryId() != null)
            to.setCountryId(from.getCountryId());

        if (from.getStateId() != null)
            to.setStateId(from.getStateId());

        if (from.getFromIPAddr() != null)
            to.setCityId(from.getCityId());

        if (from.getCityId() != null)
            to.setIspId(from.getIspId());

        if (from.getIpRoutingType() != null)
            to.setIpRoutingType(from.getIpRoutingType());

        if (from.getConnectionType() != null)
            to.setConnectionType(from.getConnectionType());

        if (from.getConnectionSpeed() != null)
            to.setConnectionSpeed(from.getConnectionSpeed());

        if (from.getTopLevelDomain() != null)
            to.setTopLevelDomain(from.getTopLevelDomain());

        if (from.getSecondLevelDomain() != null)
            to.setSecondLevelDomain(from.getSecondLevelDomain());

        if (from.getAsn() != null)
            to.setAsn(from.getAsn());

        if (from.getCarrier() != null)
            to.setCarrier(from.getCarrier());

        if (from.getCountryCF() != null)
            to.setCountryCF(from.getCountryCF());

        if (from.getStateCF() != null)
            to.setStateCF(from.getStateCF());

        if (from.getCityCF() != null)
            to.setCityCF(from.getCityCF());

        if (from.getZipCode() != null)
            to.setZipCode(from.getZipCode());

        if (from.getDma() != null)
            to.setDma(from.getDma());

        if (from.getMsa() != null)
            to.setMsa(from.getMsa());

        if (from.getPmsa() != null)
            to.setPmsa(from.getPmsa());

        if (from.getRegionId() != null)
            to.setRegionId(from.getRegionId());

        if (from.getPhoneAreaCode() != null)
            to.setPhoneAreaCode(from.getPhoneAreaCode());
    }

    public static String iPv6toIPv4Mapping(String ipAddr) {
        if (ipAddr.indexOf(':') > -1) {
            ipAddr = ipv6IPString;
        }
        return ipAddr;
    }

}
