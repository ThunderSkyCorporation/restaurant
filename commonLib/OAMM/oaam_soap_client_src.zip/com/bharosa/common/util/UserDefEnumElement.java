package com.bharosa.common.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.bharosa.common.logger.Logger;

/**
 * This provides the utility methods to access user defined enums.
 * 
 * @author bosco
 */

public class UserDefEnumElement implements Comparable, java.io.Serializable {
	static Logger logger = Logger.getLogger(UserDefEnumElement.class);

	String enumId = null;
	String name = null;
	String strValue = null;
	String elementId = null;
	int value = 0;
	List propertyNameList = null;

	public UserDefEnumElement(String enumId, String elementId, String aName, int value, String strValue, List propNameList) {
		this.enumId = enumId;
		this.name = aName;
		this.strValue = strValue;
		this.elementId = elementId;
		this.value = value;
		this.propertyNameList = propNameList;
	}
	
	public int compareTo(Object o) {
		return compareTo((UserDefEnumElement) o);
	}
	public int compareTo(UserDefEnumElement o) {
		return value - o.getValue();
	}

	/**
	 * Gets the value of logger
	 * 
	 * @return the value of logger
	 */
	public static Logger getLogger() {
		return UserDefEnumElement.logger;
	}

	/**
	 * Sets the value of logger
	 * 
	 * @param argLogger
	 *           Value to assign to this.logger
	 */
	public static void setLogger(Logger argLogger) {
		UserDefEnumElement.logger = argLogger;
	}

	/**
	 * Gets the string value of element
	 * 
	 * @return the string value of element
	 */
	public String getEnumId() {
		return this.enumId;
	}

	/**
	 * Gets the string value of element
	 * 
	 * @return the string value of element
	 */
	public String getStrValue() {
		return this.strValue;
	}

	/**
	 * Sets the value of strValue
	 * 
	 * @param argStrValue
	 *           Value to assign to this.strValue
	 */
	public void setStrValue(String argStrValue) {
		this.strValue = argStrValue;
	}

	/**
	 * Gets the value of id
	 * 
	 * @return the value of elementId
	 */
	public String getElementId() {
		return this.elementId;
	}

	/**
	 * Sets the value of elementId
	 * 
	 * @param argElementId
	 *           Value to assign to this.elementId
	 */
	public void setElementId(String argElementId) {
		this.elementId = argElementId;
	}

	/**
	 * Gets the value of name
	 * 
	 * @return the value of name
	 */
	public String getName() {
		return name;
	}
	public String getLocalizedName() {
		return getLocalizedProperty("name");
	}
	public String getLocalizedName(Locale aLocale) {
		return getLocalizedPropertyFromLocale("name", aLocale);
	}
	public String getLocalizedName(String resourceBundleName) {
		return getLocalizedPropertyFromNamedBundle("name", resourceBundleName);
	}
	public String getLocalizedName(Locale aLocale, String resourceBundleName) {
		return getLocalizedPropertyFromNamedBundleAndLocale("name", resourceBundleName, aLocale);
	}

	/**
	 * Gets the value of value
	 * 
	 * @return the value of value
	 */
	public int getValue() {
		return this.value;
	}

	/**
	 * Sets the value of value
	 * 
	 * @param argValue
	 *           Value to assign to this.value
	 */
	public void setValue(int argValue) {
		this.value = argValue;
	}

	/**
	 * Gets the value of description
	 * 
	 * @return the value of description
	 */
	public String getDescription() {
		return getLocalizedProperty("description");
	}
	public String getDescription(Locale aLocale) {
		return getLocalizedPropertyFromLocale("description", aLocale);
	}
	public String getDescription(String resourceBundleName) {
		return getLocalizedPropertyFromNamedBundle("description", resourceBundleName);
	}
	public String getDescription(Locale aLocale, String resourceBundleName) {
		return getLocalizedPropertyFromNamedBundleAndLocale("description", resourceBundleName, aLocale);
	}

	/**
	 * Gets the value for the property name for this enum element.
	 * 
	 * @param propName
	 *           Name of the property.
	 */
	public String getProperty(String propName) {
		return BharosaConfig.get(elementId + "." + propName);
	}

	public String getProperty(String propName, String aDefault) {
		return BharosaConfig.get(elementId + "." + propName, aDefault);
	}

	public String getLocalizedProperty(String propName) {
		return BharosaConfig.getLocalized(elementId + "." + propName);
	}

	public String getLocalizedPropertyFromNamedBundle(String propName, String resourceBundleName) {
		return BharosaConfig.getLocalizedFromNamedBundle(elementId + "." + propName, resourceBundleName);
	}

	public String getLocalizedPropertyFromLocale(String propName, Locale aLocale) {
		return BharosaConfig.getLocalizedFromLocale(elementId + "." + propName, aLocale);
	}

	public String getLocalizedPropertyFromNamedBundleAndLocale(String propName, String resourceBundleName, Locale aLocale) {
		return BharosaConfig.getLocalizedFromNamedBundleAndLocale(elementId + "." + propName, resourceBundleName, aLocale);
	}

	public String getLocalizedProperty(String propName, String defaultValue) {
		return BharosaConfig.getLocalized(elementId + "." + propName, defaultValue);
	}

	public String getLocalizedPropertyFromNamedBundle(String propName, String resourceBundleName, String defaultValue) {
		return BharosaConfig.getLocalizedFromNamedBundle(elementId + "." + propName, resourceBundleName, defaultValue);
	}

	public String getLocalizedPropertyFromLocale(String propName, Locale aLocale, String defaultValue) {
		return BharosaConfig.getLocalizedFromLocale(elementId + "." + propName, aLocale, defaultValue);
	}

	public String getLocalizedPropertyFromNamedBundleAndLocale(String propName, String resourceBundleName, Locale aLocale, String defaultValue) {
		return BharosaConfig.getLocalizedFromNamedBundleAndLocale(elementId + "." + propName, resourceBundleName, aLocale, defaultValue);
	}

	public int getProperty(String propName, int aDefault) {
		return BharosaConfig.getInt(elementId + "." + propName, aDefault);
	}

	public List getPropertyNameList() {
		return propertyNameList;
	}

	public void setPropertyNameList(List propertyNameList) {
		this.propertyNameList = propertyNameList;
	}
	
	public int transformPropertyUsingOtherEnum(String otherEnum, String propertyName) {
		return transformPropertyValueUsingOtherEnum(otherEnum, getProperty(propertyName));
	}
	public int transformPropertyValueUsingOtherEnum(String otherEnum, String propertyValue) {
		return UserDefEnum.getElementValue(otherEnum, propertyValue);
	}
	public String[] getPropertyAsStringArray(String listPropertyName) {
		return StringUtil.splitCSV(getProperty(listPropertyName));
	}
	public List transformPropertyListUsingOtherEnum(String otherEnum, String listPropertyName) {
		String[] filterValues = getPropertyAsStringArray(listPropertyName);
		List result = new ArrayList(filterValues.length);
		for (int i = 0; i < filterValues.length; i++) {
			result.add(String.valueOf(transformPropertyValueUsingOtherEnum(otherEnum, filterValues[i])));
		}
		return result;
	}
	public Object getInstanceOfClassProperty(String propertyName, Class shouldImplement, Object defaultValue) {
		String className = getProperty(propertyName);
		try {
			return ObjectUtil.getInstance(className, shouldImplement, defaultValue);
		} catch (NullPointerException e) {
			logger.error("No such property " + propertyName + " for " + this, e);
		} catch (Exception e) {
			logger.error("Unexpected error. className=" + className + ", enum element=" + this, e);
		}
		logger.warn("No valid value for " + propertyName + " in " + this + ".  Returning defaultValue: " + defaultValue);
		return defaultValue;
	}

	/**
	 * toString
	 */
	public String toString() {
		String str = "";
		str += "elementId={" + elementId + "} ";
		str += "name={" + getName() + "} ";
		str += "value={" + value + "} ";
		str += "strValue={" + strValue + "} ";
		str += "description={" + getDescription() + "} ";
		return str;
	}
}
