package com.bharosa.common.util;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.*;
import java.util.StringTokenizer;

import com.bharosa.common.logger.Logger;

import java.io.StringReader;

import java.util.HashSet;

/**
 * Util class to handle strings
 *
 * @author "Philomina Dorai"
 * @version 1.0
 * @since 1.0
 */
public class StringUtil {

    static Logger logger = Logger.getLogger(StringUtil.class);

    static private String delimiter = "#^#";
    static private String delimiterRegExpr = "\\#\\^\\#";

    /**
     * check if this string is non-empty and valid.
     *
     * @param str a <code>String</code> string to be checked.
     * @return a <code>boolean</code> return true if valid & non-empty.
     */
    public static boolean isEmpty(String str) {
        return str == null || str.trim().equals("") || str.equals("null") ||
            str.equals("N/A");
    }

    /**
     * @param str1 first String
     * @param str2 second String
     * @return true if both the stings are not null and equal
     */
    public static boolean isEqual(String str1, String str2) {
        return str1 != null && str2 != null && str1.equals(str2);
    }

    /**
     * @param str1 first String
     * @param str2 second String
     * @return true if both the stings are not null and equal
     */
    public static boolean equalsIgnoreCase(String str1, String str2) {
        return str1 != null && str2 != null && str1.equalsIgnoreCase(str2);
    }

    /**
     * Helper method for formating object that needs to be displayed.
     *
     * @param data to be formated
     * @return formatted string.
     */
    public static String format(Object data) {
        String empStr = "";
        if (data == null) {
            return empStr;
        }
        String content = data.toString();
        if (StringUtil.isEmpty(content) || content.equals("null")) {
            return empStr;
        }
        return content.trim();
    }

    /**
     * Helper method for formating object that needs to be displayed.
     *
     * @param data to be formated
     * @return formatted string.
     */
    public static String format(int data) {
        String empStr = "";
        if (data < 0) {
            return empStr;
        }
        return data + "";
    }

    public static int toIntValue(String value) {
        if (isEmpty(value))
            return 0;

        int returnVal = 0;

        try {
            returnVal = Integer.parseInt(value);
        } catch (Exception e) {
            logger.warn("Got an invalid string for Integer parse: " +
                        e.getLocalizedMessage(), e);
        }
        return returnVal;
    }

    public static float toFloatValue(String value) {
        if (isEmpty(value))
            return 0;

        float returnVal = 0;

        try {
            returnVal = Float.parseFloat(value);
        } catch (Exception e) {
            logger.warn("Got an invalid string for Float parse: " +
                        e.getLocalizedMessage(), e);
        }
        return returnVal;
    }

    public static double toDoubleValue(String value) {
        if (isEmpty(value))
            return 0;

        double returnVal = 0;
        try {
            returnVal = Float.parseFloat(value);
        } catch (Exception e) {
            logger.warn("Got an invalid string for Double parse: " +
                        e.getLocalizedMessage(), e);
            returnVal = Double.NaN;
        }
        return returnVal;
    }

    public static String concat(Map sortedMap) {
        return concat(sortedMap, delimiter);
    }

    public static String concat(Map sortedMap, String delim) {

        if (sortedMap == null || sortedMap.size() == 0) {
            return "";
        }

        StringBuffer str = new StringBuffer();
        Iterator iter = sortedMap.keySet().iterator();
        for (int i = 0; iter.hasNext(); i++) {
            if (i != 0) {
                str.append(delim);
            }
            Object name = iter.next();
            str.append(name.toString()).append(delim);

            Object value = sortedMap.get(name);
            String valString = (value != null) ? value.toString() : "";
            if (valString.contains(delim)) {
                str.append('"').append(valString).append('"');
            } else {
                str.append(valString);
            }
        }
        return str.toString();
    }

    public static String concat(String[] sArray) {
        return concat(sArray, delimiter);
    }

    public static String concat(String[] sArray, String delim) {
        StringBuffer str = new StringBuffer();

        if (sArray.length < 1) {
            if (logger.isDebugEnabled())
                logger.debug("String array is too short");
            return "";
        }

        for (int i = 0; i < sArray.length; i++) {
            if (i != 0) {
                str.append(delim);
            }
            if (String.valueOf(sArray[i]).contains(delim)) {
                str.append('"').append(sArray[i]).append('"');
            } else {
                str.append(sArray[i]);
            }
        }
        return str.toString();
    }

    public static Map splitAsMap(String str) {
        //Map map = new HashMap();
        Map map = new LinkedHashMap();
        String elements[] = split(str, delimiterRegExpr);
        if (elements != null) {
            for (int i = 0; i < elements.length; i = i + 2) {
                if (i + 1 < elements.length)
                    map.put(elements[i], elements[i + 1]);
                else
                    map.put(elements[i], "");
            }
        }
        return map;
    }

    public static String[] split(String str) {
        return split(str, delimiterRegExpr);
    }

    public static String[] splitCSV(String str) {
        if (StringUtil.isEmpty(str)) {
            return new String[0];
        }
        try {
            StringReader input = new StringReader(str);
            CSVReader csvReader = new CSVReader(input);
            return csvReader.readNext();
        } catch (IOException ioe) {
            // Dumb exception.  We cannot get an IOException reading from an in-memory StringReader.
            logger.error(ioe, ioe);
            return new String[0];
        }
    }

    public static String[] split(String str, String splitDelim) {
        if (StringUtil.isEmpty(str)) {
            return new String[0];
        }
        String[] tmpStr = str.split(splitDelim);
        if (tmpStr == null || tmpStr.length == 0) {
            return tmpStr;
        }
        String strArr[] = new String[tmpStr.length];
        for (int i = 0; i < tmpStr.length; i++) {
            strArr[i] = tmpStr[i].trim();
        }
        return strArr;
    }

    public static Map splitCSVtoMap(String str) {
        String[] nvArr = splitCSV(str);
        Map map = new Hashtable();
        if (nvArr != null && nvArr.length > 0) {
            for (int i = 0; i < nvArr.length; i++) {
                if (nvArr.length > (i + 1)) {
                    map.put(nvArr[i++].trim(), nvArr[i].trim());
                } else {
                    logger.error("Inbalanced csv to nv list. csv=" + str,
                                 new Throwable().fillInStackTrace());
                }
            }
        }
        return map;
    }

    public static List<String> splitCSVtoList(String str) {
        String[] strArr = splitCSV(str);
        List<String> retValue = new ArrayList<String>();
        if (strArr != null && strArr.length > 0) {
            for (int i = 0; i < strArr.length; i++) {
                retValue.add(strArr[i]);
            }
        }
        return retValue;
    }

    public static String toCSV(Collection collection) {
        return concat(collection, ",");
    }

    public static String concat(Collection collection) {
        return concat(collection, delimiter);
    }

    /**
     * @param collection of Objects
     * @param delim      delimeter
     * @return String of comma seperated string value of objects
     */
    public static String concat(Collection collection, String delim) {
        if (collection == null || collection.isEmpty())
            return "";
        StringBuffer buf = new StringBuffer();
        for (Iterator iterator = collection.iterator(); iterator.hasNext(); ) {
            Object obj = iterator.next();
            if (String.valueOf(obj).contains(delim)) {
                buf.append('"').append(obj).append('"');
            } else {
                buf.append(obj);
            }
            if (iterator.hasNext())
                buf.append(delim);
        }
        return buf.toString();
    }

    /**
     * Private constructor for non-instanceability.
     */
    private StringUtil() {
        // now try to instantiate this!!!
    }

    /**
     * <p/>
     * Removes all occurances of a character from within the source string.
     * </p>
     * <p/>
     * <p/>
     * A <code>null</code> source string will return <code>null</code>. An
     * empty ("") source string will return the empty string.
     * </p>
     * <p/>
     * <p/>
     * <pre>
     * StringUtils.remove(null, *)       = null
     * StringUtils.remove(&quot;&quot;, *)         = &quot;&quot;
     * StringUtils.remove(&quot;queued&quot;, 'u') = &quot;qeed&quot;
     * StringUtils.remove(&quot;queued&quot;, 'z') = &quot;queued&quot;
     * </pre>
     *
     * @param str    the source String to search, may be null
     * @param remove the char to search for and remove, may be null
     * @return the substring with the char removed if found, <code>null</code>
     *         if null String input
     * @since 2.1
     */
    public static String remove(String str, char remove) {
        if (isEmpty(str) || str.indexOf(remove) == -1) {
            return str;
        }
        char[] chars = str.toCharArray();
        int pos = 0;
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] != remove) {
                chars[pos++] = chars[i];
            }
        }
        return new String(chars, 0, pos);
    }

    /**
     * Flattens map and encrypts Encrypted string will not store null values
     *
     * @param map           Map
     * @param encryptionKey encryption key
     * @return encrypted String, empty string if map is null
     * @see StringUtil#splitEncrypted for restoring the map
     */
    public static String concatAndEncrypt(Map map, String encryptionKey) {

        // New map - dont change original map
        HashMap mapToUse = new HashMap();

        // Remove null values from parent map
        if (map != null && !map.isEmpty()) {
            Iterator itr = map.keySet().iterator();
            while (itr.hasNext()) {
                String key = (String)itr.next();
                String value = (String)map.get(key);
                if (value != null)
                    mapToUse.put(key, value);
            }
        }
        String toEncrypt = concat(mapToUse);
        if (StringUtil.isEmpty(toEncrypt))
            return "";

        return encryptAndEncode(toEncrypt, encryptionKey);
    }

    /**
     * Build Map from encrypted string
     *
     * @param encryptedString encrypted string
     * @param encryptionKey   encryption key
     * @return Map with key values
     * @see StringUtil#concatAndEncrypt for restoring the map
     */
    public static Map splitEncrypted(String encryptedString,
                                     String encryptionKey) {

        if (isEmpty(encryptedString)) {
            logger.info("Encrypted String is empty. This could happen if the HTTP Session has expired." +
                        " The application will logout the user and go to login page. encryptedString=" +
                        encryptedString + ", encryptionKey=" + encryptionKey);
            return Collections.EMPTY_MAP;
        }

        try {
            String toSplit = decodeAndDecrypt(encryptedString, encryptionKey);
            String[] string = split(toSplit);
            if (string.length == 0 || string.length % 2 != 0)
                return Collections.EMPTY_MAP;

            Map map = new HashMap();
            for (int i = 0; i < string.length; ) {
                String key = string[i++];
                String value = string[i++];
                map.put(key, value);
            }
            return map;
        } catch (Throwable t) {
            logger.error("Error decrypting. encryptedString=" +
                         encryptedString + ", key=" + encryptionKey);
            return Collections.EMPTY_MAP;
        }
    }

    public static String encryptAndEncode(String strToEncrypt,
                                          String encryptionKey) {
        try {
            if (strToEncrypt == null) {
                logger.error("Empty string passed for encryption.",
                             new Throwable().fillInStackTrace());
                return null;
            }
            String toEncode = null;
            if (encryptionKey == null) {
                if (logger.isDebugEnabled())
                    logger.debug("encryptAndEncode() Empty encryption key passed, so will use system key ");
                toEncode =
                        BharosaCipher.getSystemCipher().encrypt(strToEncrypt);
            } else {
                toEncode =
                        BharosaCipher.getSystemCipher(encryptionKey).encrypt(strToEncrypt);
            }
            return new String(Base64.encodeBase64(toEncode.getBytes()));
        } catch (RuntimeException t) {
            logger.error("Error encrypting and encoding. Note: This could be bad data from user. strToDecrypt=" +
                         strToEncrypt + ", encryptionKey=" + encryptionKey, t);
            return null;
        }
    }

    public static String decodeAndDecrypt(String strToDecrypt,
                                          String encryptionKey) {
        try {
            if (strToDecrypt == null) {
                logger.error("Empty string passed for decryption.",
                             new Throwable().fillInStackTrace());
                return null;
            }
            String toDecrypt =
                new String(Base64.decodeBase64(strToDecrypt.getBytes()));

            if (encryptionKey == null) {
                if (logger.isDebugEnabled())
                    logger.debug("decodeAndDecrypt() Empty encryption key passed, so will use system key ");
                return BharosaCipher.getSystemCipher().decrypt(toDecrypt);

            } else {
                return BharosaCipher.getSystemCipher(encryptionKey).decrypt(toDecrypt);
            }

        } catch (RuntimeException t) {
            logger.error("Error decoding and decrypting. Note: This could be bad data from user. strToDecrypt=" +
                         strToDecrypt + ", encryptionKey=" + encryptionKey, t);
            return null;
        }
    }

    public static String encryptAndEncodeBase32(String strToEncrypt,
                                                String encryptionKey) {
        try {
            if (strToEncrypt == null) {
                logger.error("Empty string passed for encryption.",
                             new Throwable().fillInStackTrace());
                return null;
            }
            if (encryptionKey == null) {
                logger.error("Empty encryption key passed to encrypt " +
                             strToEncrypt);
                return null;
            }
            String toEncode =
                BharosaCipher.getSystemCipher(encryptionKey).encrypt(strToEncrypt);
            return Base32.encode(toEncode.getBytes());
        } catch (RuntimeException t) {
            logger.error("Error encrypting and encoding. Note: This could be bad data from user. strToDecrypt=" +
                         strToEncrypt + ", encryptionKey=" + encryptionKey, t);
            return null;
        }
    }

    public static String decodeAndDecryptBase32(String strToDecrypt,
                                                String encryptionKey) {
        try {
            if (strToDecrypt == null) {
                logger.error("Empty string passed for decryption.",
                             new Throwable().fillInStackTrace());
                return null;
            }
            if (encryptionKey == null) {
                logger.error("Empty encryption key passed to decrypt " +
                             strToDecrypt);
                return null;
            }
            String toDecrypt = new String(Base32.decode(strToDecrypt));
            return BharosaCipher.getSystemCipher(encryptionKey).decrypt(toDecrypt);
        } catch (RuntimeException t) {
            logger.error("Error decoding and decrypting. Note: This could be bad data from user. strToDecrypt=" +
                         strToDecrypt + ", encryptionKey=" + encryptionKey, t);
            return null;
        }
    }

    public static String parseDN(String pDnString, String pName) {
        if (StringUtil.isEmpty(pDnString) || StringUtil.isEmpty(pName)) {
            if (logger.isDebugEnabled())
                logger.debug("parseDN() DN or Name is null. dn=" + pDnString +
                             ", name=" + pName);
            return null;
        }

        String pairSeparator =
            BharosaConfig.get("bharosa.util.csv.pair.name.value.pair.separator",
                              ",");
        String nameValSeparator =
            BharosaConfig.get("bharosa.util.csv.pair.name.value.separator",
                              "=");
        /* Tokenizing all nameValue Pair */
        StringTokenizer strTokPair =
            new StringTokenizer(pDnString, pairSeparator);
        while (strTokPair.hasMoreElements()) {
            /* Tokenizing name and value from nameValue pair */
            String nameVal = strTokPair.nextToken();
            StringTokenizer strTokNV =
                new StringTokenizer(nameVal, nameValSeparator);
            if (strTokNV.hasMoreElements()) {
                String name = strTokNV.nextToken().trim();
                if (name.equalsIgnoreCase(pName)) {
                    String value = null;
                    /* Returning only the first one */
                    if (strTokNV.hasMoreElements()) {
                        value = strTokNV.nextToken().trim();
                    }
                    return value;
                }
            }
        }
        return null;
    }

    /**
     * Get the String[] from comma seperated values of String. For example see :
     * KbaManager.getGlobalValidations() method.
     *
     * @param pCsvString csv String
     * @return String[]
     */
    public static String[] getStringsFromCSV(String pCsvString) {
        if (StringUtil.isEmpty(pCsvString)) {
            if (logger.isDebugEnabled())
                logger.debug("parseDN() DN or Name is null. dn=" + pCsvString);
            return null;
        }
        List retList = new ArrayList();
        String pairSeparator =
            BharosaConfig.get("bharosa.util.csv.separator", ",");
        /* Tokenizing all Values */
        StringTokenizer strTok =
            new StringTokenizer(pCsvString, pairSeparator);
        while (strTok.hasMoreElements()) {
            String lValue = strTok.nextToken().trim();
            if (!StringUtil.isEmpty(lValue)) {
                retList.add(lValue);
            }
        }
        return (String[])retList.toArray(new String[retList.size()]);
    }

    public static String removeAllWhiteSpaces(String str) {
        if (!containsWhiteSpace(str)) {
            return str;
        }

        StringBuffer buff = new StringBuffer();

        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);

            if (!Character.isWhitespace(c)) {
                buff.append(c);
            }
        }

        return buff.toString();
    }

    public static boolean containsWhiteSpace(String str) {
        if (StringUtil.isEmpty(str)) {
            return false;
        }

        for (int i = 0; i < str.length(); i++) {
            if (Character.isWhitespace(str.charAt(i))) {
                return true;
            }
        }

        return false;
    }

    /**
     * removes all special characters specified in the pattern "[\\\\\\<\\>\\(\\)\\{\\}\\,\\'\\\"\\`\\&\\*\\/\\!\\%\\|]*"
     *
     * @param str String
     * @return String with all special characters removed
     */
    public static String removeAllSpecialCharacters(String str) {
        if (StringUtil.isEmpty(str)) {
            return null;
        }
        // Satish : This function was removing all characters in a string except digits and characters using
        // pattern "[^a-zA-Z0-9\\. _\\-;:\\'\\(\\)\\[\\]\\?\\'\\\"\\\\\\/]*" , but as per the globalisation  requirement,
        // we have to remove all special characters through this function which are not allowed to be in any
        // names or notes or descriptions, so i am using pattern "[\\\\\\<\\>\\(\\)\\{\\}\\,\\'\\\"\\`\\&\\*\\/\\!\\%\\|]*",
        // which is the list of special characters which are not allowed, and to make them "" with
        // replaceAll(String regex, String replacement) function of String.class
        // This pattern "[\\\\\\<\\>\\(\\)\\{\\}\\,\\'\\\"\\`\\&\\*\\/\\!\\%\\|]*" is taken from bharosa_includeScripts.jsp
        // where it is used for  javascript validation for invalid characters used for UI.
        // I am getting this pattern string from common.properties file.
        String[] lSpecialCharacters =
            new String[] { BharosaConfig.get("import.regex.adminName_regExp") };

        for (int i = 0; i < lSpecialCharacters.length; i++) {
            str = str.replaceAll(lSpecialCharacters[i], "");
        }

        return str;
        /*
           * char[] charArray = str.toCharArray();
           *
           * int pos = 0; for (int i = 0; i < charArray.length; i++) { if (
           * Character.isLetterOrDigit(charArray[i]) ||
           * Character.isWhitespace(charArray[i]) || charArray[i] == '_' ||
           * charArray[i] == '-') { charArray[pos++] = charArray[i]; } } return
           * new String(charArray, 0, pos);
           */

    }

    public static String getDelimiter() {
        return delimiter;
    }

    /**
     * Checks if the given string matches atleast one pattern in the list of inclusion patterns and does not match any of the exclusion patterns
     * @param stringToCheck
     * @param inclusionPatternsCSV Comma seperated list of inclusion patterns using the regex syntax
     * @param exclusionPatternsCSV Comma seperated list of exclusion patterns using the regex syntax
     * @return Returns true if the stringToCheck matches atleast one inclusion pattern and none of the exclusion patterns
     */
    public static boolean matchRegex(String stringToCheck,
                                     String inclusionPatternsCSV,
                                     String exclusionPatternsCSV) {
        boolean regexMatched = false;
        //Split inclusionPatternsCSV to tokens
        String[] inclusionPatterns = inclusionPatternsCSV.split(",");
        for (int i = 0; i < inclusionPatterns.length; i++) {
            if (stringToCheck.matches(inclusionPatterns[i])) {
                if (logger.isDebugEnabled()) {
                    logger.debug("matchRegex(): Inclusion pattern [" +
                                 inclusionPatterns[i] +
                                 "] matched the string [" + stringToCheck +
                                 "]");
                }
                regexMatched = true;
                break;
            }
        }

        //Split exclusionPatternsCSV to tokens if exclusionPatternsCSV is not empty
        if (!isEmpty(exclusionPatternsCSV)) {
            String[] exclusionPatterns = exclusionPatternsCSV.split(",");
            for (int i = 0; i < exclusionPatterns.length; i++) {
                if (stringToCheck.matches(exclusionPatterns[i])) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("matchRegex(): Exclusion pattern [" +
                                     exclusionPatterns[i] +
                                     "] matched the string [" + stringToCheck +
                                     "]");
                    }
                    regexMatched = false;
                    break;
                }
            }
        }

        if (logger.isDebugEnabled()) {
            logger.debug("matchRegex() Returning [" + regexMatched +
                         "], StringToCheck = [" + stringToCheck +
                         "], InclusionPatternsCSV = [" + inclusionPatternsCSV +
                         "], ExclusionPatternsCSV = [" + exclusionPatternsCSV +
                         "]");
        }

        return regexMatched;
    }

    public static boolean matches(String pattern, String text) {
        text += '\0';
        pattern += '\0';

        int N = pattern.length();

        boolean[] states = new boolean[N + 1];
        boolean[] old = new boolean[N + 1];
        old[0] = true;

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            states = new boolean[N + 1]; // initialized to false
            for (int j = 0; j < N; j++) {
                char p = pattern.charAt(j);

                // hack to handle *'s that match 0 characters
                if (old[j] && (p == '*'))
                    old[j + 1] = true;

                if (old[j] && (p == c))
                    states[j + 1] = true;
                if (old[j] && (p == '.'))
                    states[j + 1] = true;
                if (old[j] && (p == '*'))
                    states[j] = true;
                if (old[j] && (p == '*'))
                    states[j + 1] = true;
            }
            old = states;
        }
        return states[N];
    }

    public static boolean isAllNumeric(String str) {
        if (str == null || str.length() == 0)
            return false;

        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);

            if (c < '0' || c > '9')
                return false;
        }

        return true;
    }

    public static boolean containsDigit(String str) {
        if (str == null || str.length() == 0)
            return false;

        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);

            if (c >= '0' && c <= '9')
                return true;
        }

        return false;
    }

    /**
     * @param s1 first String
     * @param s2 Seconf String
     * @return true if both strings are null or both string contain same value, ignores case
     */
    public static boolean compareStrings(String s1, String s2) {
        if (s1 == null)
            return (s2 == null);
        return (s2 != null) && s1.trim().equalsIgnoreCase(s2.trim());
    }


    /**
     * method to trim long strings.
     *
     * @param pValue a <code>String</code> value
     * @param pLen   a <code>int</code> value
     * @return a <code>String</code> value
     */
    public static String trim(String pValue, int pLen) {
        String lNewValue = pValue;
        if (!isEmpty(lNewValue)) {
            //trim the long string if length > len
            if (pValue.length() > pLen) {
                String lTruncValue = pValue.substring(0, pLen);
                lNewValue = lTruncValue + "...";
            } else {
                lNewValue = pValue;
            }
        } else {
            lNewValue = null;
        }
        return lNewValue;
    }

    /**
     * Equivalent Class.getSimpleName() method in jdk1.5
     *
     * @param kls Class object
     * @return String returning just name part of the java class. package string part is igrnored
     */
    public static String getSimpleClassName(Class kls) {
        String klsName = null;
        if (kls != null) {
            klsName = kls.getName();
            String[] klsArray = split(klsName, "\\.");
            if (klsArray != null && klsArray.length > 0)
                klsName = klsArray[klsArray.length - 1];
        }
        return klsName;
    }

    public static String replaceUnicodeEscapes(String str) {
        if (StringUtil.isEmpty(str))
            return str;

        String outStr = str;
        int pos = 0;

        while (pos < outStr.length()) {
            int nextPos = outStr.indexOf("\\u", pos);

            if (nextPos == -1) {
                nextPos = outStr.indexOf("\\U", pos);
            }

            if (nextPos == -1) {
                break;
            }

            pos = nextPos;

            int endIndex = pos + 6; // \\u1234

            if (endIndex >= outStr.length()) {
                break;
            }

            String strChar = outStr.substring(pos + 2, endIndex);

            try {
                int charVal = Integer.parseInt(strChar, 16);
                char ch = (char)charVal;

                outStr =
                        outStr.substring(0, pos) + ch + outStr.substring(endIndex);
            } catch (Exception excp) {
                // ignore
            }

            pos++;
        }

        return outStr;
    }

    public static String expandProperties(String val) {

        if (StringUtil.isEmpty(val))
            return val;

        int start = 0;
        String ret = "";

        Matcher matcher = Pattern.compile("(\\$\\{(.*?)\\})").matcher(val);

        while (matcher.find(start)) {
            String propName = matcher.group(2);
            String propVal = null;

            if (!StringUtil.isEmpty(propName)) {
                propVal = BharosaConfig.get(propName);
            }

            ret += val.substring(start, matcher.start());

            if (propVal != null) {
                ret += propVal;
            }

            start = matcher.end();
        }

        ret += val.substring(start);

        return ret;
    }

    public static String removeSubString(String str, String remove) {
        if (StringUtil.isEmpty(str) || str.indexOf(remove) == -1) {
            return str;
        }
        char[] chars = str.toCharArray();
        int count = 0;
        char[] removeChars = remove.toCharArray();
        boolean flag = false;
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] == removeChars[0] &&
                (chars.length - i) > (removeChars.length)) {
                for (int j = 1; j < removeChars.length; j++) {
                    if ((chars[i + j] == removeChars[j]) == false) {
                        chars[count++] = chars[i];
                        flag = false;
                        break;
                    } else {
                        flag = true;
                    }
                }
                if (flag) {
                    i += removeChars.length - 1;
                }
            } else {
                chars[count++] = chars[i];
            }
        }
        return new String(chars, 0, count);
    }

    /**
     * remove embedded spaces along with leading and trailing spaces
     * @param str
     * @return
     */
    public static String formatForWhitespace(String str) {        
        //remove the trailing and leading spaces
        str = format(str);
        //remove the extra embedded spaces
        String[] arr = split(str, " ");
        if (arr != null && arr.length > 1) {
            StringBuffer tempStr = new StringBuffer();
            //add the first word
            tempStr.append(arr[0]);
            for (int i = 1; i < arr.length; i++) {
                if (arr[i].isEmpty())
                    continue;               
                tempStr.append(" ");
                tempStr.append(arr[i]);
            }
            str = tempStr.toString();
        }
        return str;
    }
    
    public static boolean isInList(List<Integer> arr, Integer value) {
        if (arr == null) {
            return false;
        }
        Iterator iter = arr.iterator();
        while (iter.hasNext()) {
            Integer str = (Integer)iter.next();
            if (str.intValue() == value.intValue()) {
                return true;
            }
        }
        return false;
    }
}
