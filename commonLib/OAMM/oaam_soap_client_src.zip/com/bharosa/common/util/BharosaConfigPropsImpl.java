/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
package com.bharosa.common.util;

import com.bharosa.common.logger.Logger;

/**
 * 
 * @author kuldeep <kuldeep@bharosa.com>
 * Date: Jul 11, 2007
 * Time: 10:32:45 AM
 *
 */
public class BharosaConfigPropsImpl extends BharosaConfigCommonImpl
	implements BharosaConfigIntf {
	
	private Logger logger = Logger.getLogger(BharosaConfigPropsImpl.class) ;
	
	public BharosaConfigPropsImpl(BharosaConfigLoadIntf pBharosaConfigLoad) {
		super(pBharosaConfigLoad) ;
	}
}
