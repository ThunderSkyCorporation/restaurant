package com.bharosa.common.util;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * [Update the description of your class]
 * User: bosco
 * Date: Jun 16, 2007
 * Time: 6:34:25 PM
 */

import com.bharosa.common.logger.Logger;

abstract public class BharosaPropertyBase {
    static Logger logger = Logger.getLogger(BharosaPropertyBase.class);

    String name;
    private BharosaProperty bharosaProperty;
    long lastUpdateTime = System.currentTimeMillis();

    BharosaPropertyBase(String propName) {
        this.name = propName != null ? propName.trim() : propName;
        bharosaProperty = BharosaConfig.getProperty(name);
    }

    public String getName() {
        return bharosaProperty != null ? bharosaProperty.getName() : name;
    }


    public BharosaProperty getBharosaProperty() {
      if (bharosaProperty == null || BharosaConfig.lastUpdateTime > lastUpdateTime) 
      {
        lastUpdateTime = BharosaConfig.lastUpdateTime;
        bharosaProperty = BharosaConfig.getProperty(getName());
      }
      return bharosaProperty;
    }
}
