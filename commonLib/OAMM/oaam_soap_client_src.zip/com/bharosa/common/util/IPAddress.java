package com.bharosa.common.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;
import com.bharosa.common.exception.ValidationException;

/**
 * This constructs an IP address either using the string format (i.e a.b.c.d)
 * or long value of the IP.
 * @author bosco
 */

public class IPAddress {
	static Logger  logger = Logger.getLogger(IPAddress.class);
	long ipLong = 0;
	String ipStr = null;
	/**
	 * Constructor which takes the IP in string format. The valid
	 * format is a.b.c.d
	 * @param ipStr IP in string format. Valid format is a.b.c.d
	 * @exception ValidationException if an error occurs
	 */
	public IPAddress( String ipStr ) throws ValidationException {
		this.ipStr = ipStr;
		this.ipLong = IPUtil.ip2long( ipStr );
	}

	/**
	 * Creates a IPAddress using the long value of the IP
	 *
	 * @param ipLong the long value of the IP
	 */
	public IPAddress( long ipLong ) {
		this.ipLong = ipLong;
	}

	
	/**
	 * Sets the IPAddress using the string format
	 *
	 * @param ipStr the string format of the IP. It should be a.b.c.d
	 * @exception ValidationException if an error occurs
	 */
	public void setIPAddress( String ipStr ) throws ValidationException {
		this.ipStr = ipStr;
		this.ipLong = IPUtil.ip2long( ipStr );
	}

	/**
	 * Sets the IPAddress with the long value of the IP
	 *
	 * @param ipLong the long value of the IP
	 */
	public void setIPAddress( long ipLong ) {
		this.ipStr = null;
		this.ipLong = ipLong;
	}

	/**
	 * Returns the IP in string format. The format is a.b.c.d
	 *
	 * @return String format of the IP
	 */
	public String getIPString( ) {
		if( ipStr == null ) {
			ipStr = IPUtil.long2ip( ipLong );
		}
		return ipStr;
	}

	/**
	 * Returns the IP in long format.
	 *
	 * @return long format of the IP
	 */
	public long getIPLong( ) {
		return ipLong;
	}

	/**
	 * This overrides the toString method.
	 */
	public String toString( ) {
		return getIPString();
	}
	
	public String getTLQueryValue() {
		return String.valueOf(getIPLong());
	}
}
