/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
package com.bharosa.common.util;

import java.util.Map;

/**
 * 
 * @author kuldeep <kuldeep@bharosa.com>
 * Date: Jul 11, 2007
 * Time: 10:30:21 AM
 *
 */
public interface BharosaConfigLoadIntf {

	/**
	 * Does Initialization of Bharosa Config Load.  
	 */
	public void init() ;
	
	/**
	 * Decrypt Properties present in the Load
	 * 
	 */
	public void decryptProperties();

    /**
     * This method is used to register a callback, which is called everytime the property file is reloaded.
     * 
     * @param reloadListener
     */
    public void registerReloadCallback(BharosaConfigReloadListener reloadListener) ;

    /**
     * This method is used to remove a Config reload callback.
     * 
     * @param reloadListener
     */
    public void removeReloadCallback(BharosaConfigReloadListener reloadListener) ;

	/**
	 * 
	 * @param propertyName
	 * @param value
	 */
	public void setProperty(String propertyName, String value) ;

    /**
     * Sets passed BharosaProperty in the BharosaConfig 
     * 
     * @param pBharosaProperty
     * @return
     */
    public void setProperty(BharosaProperty pBharosaProperty);

	/**
	 * Removes property
	 * @param propertyName
	 * @param value
	 */
	public void removeProperty(String propertyName) ;

	/**
     * Adds property to Map
     * 
     * @param pProperty
     */
    public void addProperty(BharosaProperty pProperty) ; 
    	
	/**
	 * @param propertyName
	 * @return String
	 */
	public String getPropertyValue(String propertyName);

	/**
	 * 
	 * @param propertyName
	 * @return BharosaProperty
	 */
	public BharosaProperty getProperty(String propertyName);

	/**
	 * 
	 * @return HashMap
	 */
	public Map getMap();

	/**
	 * Returns flag to state whether property override is supported by this load instance.
	 * 
	 * @return whether property override is supported or not.
	 */
	public boolean isPropertyOverrideSupported();
	
	/**
	 * Returns loadType (int) associated with this instance of BharosaConfigLoad 
	 * 
	 * @return
	 */
	public int getLoadType();

}
