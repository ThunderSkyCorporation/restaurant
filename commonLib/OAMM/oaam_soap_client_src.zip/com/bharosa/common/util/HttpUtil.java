package com.bharosa.common.util;

import java.net.URLEncoder;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.bharosa.common.logger.Logger;

import java.io.IOException;

import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;


/**
 * Util class for http request/web interface.
 *
 * @author "Philomina Dorai"
 * @version 1.0
 * @since 1.0
 */
public class HttpUtil {

    private static Logger logger = Logger.getLogger(HttpUtil.class);
    private static BharosaPropertyBoolean useCookieAPI = new BharosaPropertyBoolean("oracle.oaam.httputil.usecookieapi", false);

    public static String getHeader(HttpServletRequest request, String headerName) {
        if (StringUtil.isEmpty(headerName)) {
            return null;
        }

        String value = request.getHeader(headerName);
        if (StringUtil.isEmpty(value)) {
            //Lets see whether we have case sensitive issue
            Enumeration e = request.getHeaderNames();
            while (e != null && e.hasMoreElements()) {
                String name = (String) e.nextElement();
                if (headerName.equalsIgnoreCase(name)) {
                    value = request.getHeader(name);
                }
            }
        }

        return value;
    }

    public static String getLoginId(HttpServletRequest request) {
        String loginId = null;
        if (BharosaConfig.getBoolean("bharosa.oarm.user.header.enabled", false)) {
            String loginIdHeaderName = BharosaConfig.get("bharosa.oarm.user.header.user.param");
            if (StringUtil.isEmpty(loginIdHeaderName)) {
                logger.error("getLoginId() bharosa.oarm.user.header.enabled is true, but bharosa.oarm.user.header.user.param is empty.",
                        new Throwable().fillInStackTrace());
            } else {
                loginId = getHeader(request, loginIdHeaderName);
                if (logger.isDebugEnabled())
                    logger.debug("getLoginId() from header " + loginIdHeaderName + " is " + loginId);
            }
        } else {
            if (request.getUserPrincipal() != null) {
                loginId = request.getUserPrincipal().getName();
            }
            if (logger.isDebugEnabled())
                logger.debug("getLoginId() from principal is " + loginId);

        }
        return loginId;
    }


    public static boolean isUserInRole(HttpServletRequest request, String roleName) {
        boolean isInRole = false;
        String roleMaps = BharosaConfig.get("bharosa.admin.role.mapping." + roleName, roleName);
        String roleMapDelim = BharosaConfig.get("bharosa.admin.role.mapping.delimiter", ",");

        if (logger.isDebugEnabled())
            logger.debug("isUserInRole(): roleName=" + roleName
                    + ", roleMaps=" + roleMaps
                    + ", bharosa.admin.role.mapping.delimiter=" + roleMapDelim);
        String roleMapsArr[] = StringUtil.split(roleMaps, roleMapDelim);
        for (int j = 0; roleMapsArr != null && j < roleMapsArr.length && !isInRole; j++) {
            if (BharosaConfig.getBoolean("bharosa.oarm.user.header.enabled", false)) {
                String rolesHeaderName = BharosaConfig.get("bharosa.oarm.user.header.roles.param");
                if (StringUtil.isEmpty(rolesHeaderName)) {
                    logger.error("isUserInRole() bharosa.oarm.user.header.enabled is true, but bharosa.oarm.user.header.roles.param is empty.",
                            new Throwable().fillInStackTrace());
                } else {
                    String roles = getHeader(request, rolesHeaderName);
                    if (roles != null) {
                        String delimiter = BharosaConfig.get("bharosa.oarm.user.header.roles.delimiter", ",");
                        String[] rolesArray = StringUtil.split(roles, delimiter);
                        if (rolesArray != null && rolesArray.length > 0) {
                            for (int i = 0; i < rolesArray.length; i++) {
                                if (roleMapsArr[j].equalsIgnoreCase(rolesArray[i])) {
                                    isInRole = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (logger.isDebugEnabled())
                        logger.debug("isUserInRole() roleName=" + roleMapsArr[j]
                                + " from header " + rolesHeaderName + "=" + roles
                                + " is " + isInRole);
                }
            } else {
                isInRole = request.isUserInRole(roleMapsArr[j]);
                if (logger.isDebugEnabled())
                    logger.debug("isUserInRole() rolName=" + roleMapsArr[j]
                            + " from HTTP request is " + isInRole);

            }
        }
        return isInRole;
    }

    /**
     * This populates the array for setting default search value selection
     * of enums.
     */
    public static String setUrlAppender(String queryStr) {

        if (StringUtil.isEmpty(queryStr)) {
            return "";
        }

        if (queryStr.indexOf('?') == -1) {
            return queryStr + "?";
        }

        return queryStr + "&";
    }

    /**
     * method to trim long strings.
     *
     * @param value a <code>String</code> value
     * @return a <code>String</code> value
     */
    public static String trimLongString(String value, int len) {
        String newValue = value;
        if (value != null) {
            value = value.trim();
            //trim the long string if length > len
            if (value.length() > len) {
                String lTruncValue = value.substring(0, len);
                newValue = "<a class=\"textlink\" href=\"javascript:showFullTextInNewWindow('"
                        + jsEscape(value) + "')\" ><div title=\""
                        + formatForWeb(value) + "\">"
                        + formatForWeb(lTruncValue) + "</div></a>";
            } // end of if (value.length() > len)
            else {
                newValue = "<div title=\"" + formatForWeb(value) + "\">" + formatForWeb(value) + "</div>";
            } // end of else
        } // end of if (value != null)
        else {
            newValue = formatForWeb(null);
        } // end of else
        return newValue;
    }

    /**
     * method to trim long strings.
     *
     * @param value a <code>String</code> value
     * @return a <code>String</code> value
     */
    public static String trimLongStringWoDiv(String value, int len) {
        String newValue = value;
        if (value != null) {
            value = value.trim();
            //trim the long string if length > len
            if (value.length() > len) {
                String lTruncValue = value.substring(0, len);
                newValue = "<a class=\"textlink\" href=\"javascript:showFullTextInNewWindow('"
                        + jsEscape(value) + "')\" title=\""
                        + formatForWeb(value) + "\">"
                        + formatForWeb(lTruncValue) + "</a>";
            } // end of if (value.length() > len)
            else {
                newValue = formatForWeb(value);
            } // end of else
        } // end of if (value != null)
        else {
            newValue = formatForWeb(null);
        } // end of else
        return newValue;
    }

    /**
     * method to trim long strings.
     *
     * @param value a <code>String</code> value
     * @return a <code>String</code> value
     */
    public static String trimString(String value, int len) {
        String newValue = value;
        if (value != null) {
            value = value.trim();
            //trim the long string if length > len
            if (value.length() > len) {
                String lTruncValue = value.substring(0, len);
                newValue = lTruncValue + "...";
            } else {
                newValue = value;
            }
        } else {
            newValue = null;
        }
        return formatForWeb(newValue);
    }

    /**
     * Helper method for formating object that needs to be displayed.
     *
     * @param data to be formated
     * @return formatted string.
     */
    public static String formatForWeb(Object data) {
        String nbsp = "&nbsp;";
        if (data == null) {
            return nbsp;
        }
        String content = data.toString();
        if (StringUtil.isEmpty(content) || content.equals("null")) {
            return nbsp;
        }
        return encode(content.trim());
    }

    /**
     * Helper method for url encoding(default use UTF-8 encoding scheme)
     *
     * @param data a <code>String</code> original data to be encoded
     * @return a <code>String</code> encoded result string
     */
    public static String urlEncode(String data) {
        if (StringUtil.isEmpty(data)) {
            return "";
        }
        data = data.trim();
        //get the encoding scheme dynamically as property.
        String encodeScheme = BharosaConfig.get("url.encoding.scheme", "UTF-8");

        try {
            return URLEncoder.encode(data, encodeScheme);
        } catch (UnsupportedEncodingException ignore) {
            //ignore
        }
        return data; //return original data ,if "UTF-8"/encoding scheme not supported
    }

    /**
     * Method replace all the html escape/special chars with their respective code
     *
     * @param str a <code>String</code> value
     * @return a <code>String</code> value
     */
    public static String encode(String str) {
        if (StringUtil.isEmpty(str)) {
            return "";
        }

        //replace all '&'
        str = str.replaceAll("\\&", "&amp;");
        //replace all '<'
        str = str.replaceAll("\\<", "&lt;");
        //replace all '>'
        str = str.replaceAll("\\>", "&gt;");
        //replace all '"'
        str = str.replaceAll("\"", "&quot;");
        //replace all '
        //str = str.replaceAll("\\'","&#8242;");
        str = str.replaceAll("\\'", "&#39;");
        //replace all `
        str = str.replaceAll("\\`", "&#96;");
        //replace all ','
        str = str.replaceAll("\\,", "&#44;");
        //replace all '\'
        str = str.replaceAll("\\\\", "&#92;");
        //         //replace all ';'
        // 		str = str.replaceAll("\\;","&#59;");
        //replace all '?'
        str = str.replaceAll("\\?", "&#63;");
        return str;
    }

    protected static String jsEscape(String str) {
        str = encode(str);

        //replace all /
        str = str.replaceAll("&#92;", "\\\\&#92;");
        //replace all "
        str = str.replaceAll("&quot;", "\\\\&quot;");
        //replace all '
        str = str.replaceAll("&#39;", "\\\\&#39;");


        return str;
    }

    public static void logoutUser(HttpServletRequest request) {
        logoutUser(request, null);
    }

    public static void logoutUser(HttpServletRequest request, HttpServletResponse response) {
        try {
            String userName = getLoginId(request);
            if (StringUtil.isEmpty(userName)) {
                userName = "Anonymous";
            }

            try {
                //This kills all sessions in all the webapps in this container
                Class authObj = Class.forName("weblogic.servlet.security.ServletAuthentication");
                Method invalidateAllMethod = authObj.getMethod("invalidateAll", new Class[]{HttpServletRequest.class});
                invalidateAllMethod.invoke(null, new Object[]{request});
                logger.info("User logged out successfully from all applications.userName=" + userName);
            } catch (Throwable t) {
                //ignore for now
            }

            //Logout SiteMinder
            if (BharosaConfig.getBoolean("bharosa.oarm.logout.sm", false)) {
                try {
                    String cookieValue = getCookieValue(request, "SMSESSION");
                    if (!StringUtil.isEmpty(cookieValue) && !cookieValue.equalsIgnoreCase("LOGGEDOFF")) {
                        if (logger.isDebugEnabled())
                            logger.debug("SMSESSION cookie found. Setting it to LOGGEDOFF");
                        setCookie(request, response, "SMSESSION", "LOGGEDOFF");
                    }
                } catch (Throwable t) {
                    logger.debug("Error while logging off SiteMinder.", t);
                }
            }

            //Logging out OAM
            try {
                String cookieValue = getCookieValue(request, "OBSSOCookie");
                if (!StringUtil.isEmpty(cookieValue) && !cookieValue.equalsIgnoreCase("LOGGEDOFF")) {
                    if (logger.isDebugEnabled())
                        logger.debug("OBSSOCookie cookie found. Setting it to LOGGEDOFF");
                    setCookie(request, response, "OBSSOCookie", "LOGGEDOFF");
                }
            } catch (Throwable t) {
                logger.debug("Error while logging of OAM.", t);
            }

            logger.debug("Invalidating logging session for user=" + userName);

            try {
                request.getSession().removeAttribute("actionSession");
                request.getSession().removeAttribute("bharosa_rolelist");
                request.getSession().invalidate();
            } catch (Throwable t) {
                //ignore this error
            }
        } catch (Throwable t) {
            logger.error("Error while logging out.", t);
        }
    }

    public static String getCookieValue(HttpServletRequest request, String cookieName) {
        return getCookieValue(request, cookieName, null);
    }

    public static String getCookieValue(HttpServletRequest request, String cookieName, String defaultValue) {
        Cookie cookie = getCookie(request, cookieName);
        if (cookie != null) {
            return cookie.getValue().trim();
        }
        return defaultValue;
    }

    public static Cookie getCookie(HttpServletRequest request, String cookieName) {
        Cookie cookies[] = request.getCookies();
        for (int i = 0; cookies != null && i < cookies.length; i++) {
            Cookie cookie = cookies[i];
            if (cookie.getName().equalsIgnoreCase(cookieName)) {
                return cookie;
            }
        }
        return null;
    }

    public static void setCookie(HttpServletRequest request, HttpServletResponse response, String cookieName, String cookieValue) {
        if (logger.isDebugEnabled()) logger.debug("setCookie() cookieName="
                + cookieName + ", cookieValue=" + cookieValue);

        if (StringUtil.isEmpty(cookieValue)) {
            logger.error("Trying to set null cookie to " + cookieName, new Throwable().fillInStackTrace());
        } else {
            Cookie cookie = getCookie(request, cookieName);
            if (cookie == null) {
                cookie = new Cookie(cookieName, cookieValue);
                cookie.setPath("/");
                cookie.setMaxAge(-1);
            } else {
                if (logger.isDebugEnabled())
                    logger.debug("Reusing existing cookie. oldCookie=" + cookieToString(cookie));
                cookie.setValue(cookieValue);
            }

            if (response != null) {
                if (logger.isDebugEnabled())
                    logger.debug("Added cookie=" + cookieToString(cookie));
                HttpUtil.setCookie(response, cookie);
            }
        }
    }

    public static void setCookie(HttpServletResponse response, String cookieName, String cookieValue, int maxAge, String path, String domain){
      Cookie cookie = new Cookie(cookieName, cookieValue);
      cookie.setMaxAge(maxAge);
      
      if (!StringUtil.isEmpty(path)){
        cookie.setPath(path);
      }
      
      if (!StringUtil.isEmpty(domain)){
        cookie.setDomain(domain);
      }
      
      HttpUtil.setCookie(response, cookie);
    }
    
    public static void setCookie(HttpServletResponse response, Cookie cookie){
    	setCookie(response,cookie,false);
    }
    
    public static void setCookie(HttpServletResponse response, Cookie cookie, boolean trustedPartner){
      String cookieDomain = "";
      String cookiePath = "";
      
      if (!StringUtil.isEmpty(cookie.getDomain())){
        cookieDomain = "; domain=" + cookie.getDomain();
      }

      if (!StringUtil.isEmpty(cookie.getPath())){
        cookiePath = "; path=" + cookie.getPath();
      }
      
      if (logger.isDebugEnabled())
          logger.debug("Setting cookie - " + cookieToString(cookie));

      boolean secureFlag = BharosaConfig.getBoolean("oaam.cookies.secure", false);
      cookie.setSecure(secureFlag);
      
      
      boolean httpOnlyFlag = BharosaConfig.getBoolean("oaam.cookies.httpOnly", true);
      // Causes compile error for some reason - setHttpOnly is Java 6 method
      // cookie.setHttpOnly(httpOnlyFlag);
      
      //Can't use addCookie due to compile error with cookie.setHttpOnly
      //response.addCookie(cookie);
      


      // Have to create strings since we are setting cookie manually.
      // if cookie.setHttpOnly compile issue is resolved, the following code can be removed,
      // and response.addCookie can be used.
      String cookieHttpOnly = "";
      if (httpOnlyFlag){
        cookieHttpOnly = "; HTTPOnly";
      }

      String cookieSecure = "";
      if (cookie.getSecure()){
        cookieSecure = "; secure";
      }

      String cookieName = cookie.getName();
      String cookieValue = cookie.getValue();
      
      if (!trustedPartner) {
    	  cookieName = urlEncode(cookie.getName());
    	  cookieValue = urlEncode(cookie.getValue());
      }

      if (useCookieAPI.getValue())
   		  response.addCookie(cookie);
   	  else
   		  response.setHeader("Set-Cookie", cookieName + "=" + cookieValue + "; Max-Age=" + cookie.getMaxAge() + cookieDomain + cookiePath + cookieSecure + cookieHttpOnly);
      
    }
    
    static String cookieToString(Cookie cookie) {
        if (cookie == null) {
            return "Cookie=null";
        }
        return "Cookie: name=" + cookie.getName() + ", value=" + cookie.getValue()
                + ", domain=" + cookie.getDomain() + ", path=" + cookie.getPath()
                + ", maxAge=" + cookie.getMaxAge();
    }

    public static String getParamValue(String url, String paramName) {
        String paramValue = "";
        int urlLength = url.length();
        paramName = paramName + "=";
        int paramIndex = url.indexOf(paramName);
        if (paramIndex >= 0) {
            int paramLen = paramName.length();
            String subString1 = url.substring((paramIndex + paramLen), urlLength);
            paramValue = subString1;
            int andIndex = subString1.indexOf("&");
            if (andIndex != -1) {
                paramValue = subString1.substring(0, andIndex);
            }
        }
        return paramValue;
    }

    /**
     * Creates/Appends the form query string.
     */
    public static String appendParam(String queryString,
                                     String formAttrName,
                                     Object formValue) {

        String stringValue = null;
        if (formValue instanceof Date) {
            stringValue = DateUtil.getFormattedDate(((Date) formValue));
        } else {
            stringValue = String.valueOf(formValue).trim();
        }

        if (StringUtil.isEmpty(stringValue)) {
            return queryString;
        }

        String formQueryStr = queryString;

        String formNameValuePair = formAttrName + "=" + urlEncode(stringValue);
        if (StringUtil.isEmpty(formQueryStr)) {
            formQueryStr = formNameValuePair;
        } else {
            Pattern p = Pattern.compile(formAttrName + "=[^&]*");
            Matcher m = p.matcher(formQueryStr);
            if (m.find()) {
                formQueryStr = m.replaceFirst(formNameValuePair);
            } else {
                formQueryStr += "&" + formNameValuePair;
            }
        }
        return formQueryStr;
    }

    public static String sendRedirect(HttpServletResponse response, String url) throws IOException{
        if (StringUtil.isEmpty(url)) return url;
        
        String newURL= encodeURL(url);        
        if (response != null){
            try{
                response.sendRedirect(newURL);
            } catch(java.io.IOException ioex){
                logger.error("Unabled to redirect to: " + newURL, ioex);
                throw ioex;
            }
        }
        return newURL;
    }
    
    
    public static String encodeURL(String toEnc){
        if (StringUtil.isEmpty(toEnc)) return toEnc;
        
        try{
                String decodedURL = URLDecoder.decode(toEnc, "UTF-8");
        
                URL url = new URL(decodedURL);
                URI uri = new URI(url.getProtocol(), url.getUserInfo(), url.getHost(), url.getPort(), url.getPath() , url.getQuery(), url.getRef());
                return uri.toASCIIString();
        } catch (Exception ex){
                logger.error("Unable to encode URL", ex);
                return null;
        }
    }
    /**
     * Private constructor for non-instanceability.
     */
    private HttpUtil() {
        // now try to instantiate this!!!
    }
}
