package com.bharosa.common.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.*;

import com.bharosa.common.logger.Logger;

/**
 * This provides the utility methods to access user defined enums.
 * 
 * @author bosco
 */

public class UserDefEnum implements java.io.Serializable {
	static Logger logger = Logger.getLogger(UserDefEnum.class);

	String enumId = null;
	String description = null;
	Hashtable elementsById = new Hashtable();
	Hashtable elementsByValue = new Hashtable();
	Hashtable elementsByName = new Hashtable();
	public static final int INVALID = -1;

	/**
	 * Returns the instance of the UserDefEnum.
	 */
	static public UserDefEnum getEnum(String enumId) {
		return UserDefEnumFactory.getEnum(enumId);
	}

	static public UserDefEnum getEnumOrEmptyEnumIfUndefined(String enumId) {
		UserDefEnum result = getEnum(enumId);
		if (result == null) {
			result = new UserDefEnum(enumId, "Fake enum because undefined.");
		}
		return result;
	}

	protected UserDefEnum(String enumId, String desc) {
		this.enumId = enumId;
		this.description = desc;
	}

	UserDefEnumElement addElement(String id, String name, int value, String strValue, List propNameList) {
		UserDefEnumElement elementObj = (UserDefEnumElement) elementsByName.get(name);
		if (elementObj != null && !elementObj.getElementId().equals(id)) {
			logger.error("Duplicate element name for enum=" + enumId + ", elementName=" + name + ", new id=" + id + ", existing id=" + elementObj.getElementId());
		}

		elementObj = new UserDefEnumElement(enumId, id, name, value, strValue, propNameList);
		if (logger.isDebugEnabled()) logger.debug("In enum " + enumId + " added element id=" + id + ", name=" + name + ", value=" + value);
		// Add to the list
		elementsById.put(id, elementObj);
		elementsByName.put(name, elementObj);
		elementsByValue.put(new Integer(value), elementObj);

		return elementObj;
	}

	/**
	 * Gets the value of enumId
	 * "name"
	 * @return the value of enumId
	 */
	public String getEnumId() {
		return this.enumId;
	}

	/**
	 * Sets the value of enumId
	 * 
	 * @param argEnumId
	 *           Value to assign to this.enumId
	 */
	public void setEnumId(String argEnumId) {
		this.enumId = argEnumId;
	}

	/**
	 * Gets the value of description
	 * 
	 * @return the value of description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the value of description
	 * 
	 * @param argDescription
	 *           Value to assign to this.description
	 */
	public void setDescription(String argDescription) {
		this.description = argDescription;
	}

	/**
	 * Returns the Enum element for the given integer value.
	 */
	public UserDefEnumElement getElement(int value) {
		return (UserDefEnumElement) elementsByValue.get(new Integer(value));
	}

	/**
	 * Returns the Enum element for the given integer value.
	 */
	static public UserDefEnumElement getElement(String enumId, int value) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getElement(value);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return null;
		}
	}

	/**
	 * Returns the value of the element, by enum and element name
	 * 
	 * @param enumId
	 *           Id of the enum
	 * @param name
	 *           of the element
	 * @return the value of the element. Returns -1 if not found
	 */
	public static UserDefEnumElement getElement(String enumId, String name) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getElementById(name);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return null;
		}
	}

	/**
	 * Returns the Enum element for the given element Id
	 */
	public UserDefEnumElement getElementById(String elementId) {
		Object element = elementsById.get(elementId);
		if (element == null) {
			element = elementsById.get(enumId + "." + elementId);
		}
		return (UserDefEnumElement) element;
	}

	public UserDefEnumElement getElementByIdOrEmptyElementIfUndefined(String elementId) {
		UserDefEnumElement element = getElementById(elementId);
		if (element == null) {
			List propNameList = new ArrayList();
			element = new UserDefEnumElement(enumId + ".", elementId, elementId, Integer.MAX_VALUE, "none", propNameList);
		}
		return element;
	}

	/**
	 * Returns the Enum element for the given element name
	 */
	public UserDefEnumElement getElementByName(String name) {
		return (UserDefEnumElement) elementsByName.get(name);
	}

	/**
	 * Get the Enumeration of enum elements
	 */
	public Enumeration getEnumElements() {
		return elementsById.elements();
	}

	/**
	 * Get the Enumeration of enum elements
	 */
	public Enumeration getEnumElementsByName() {
		return elementsByName.elements();
	}
	
	public List getEnumElementsAsList() {
		return new ArrayList(elementsById.values());
	}
	public List getEnumElementsSortedByValue() {
		List results = getEnumElementsAsList();
		Collections.sort(results);
		return results;
	}

	/**
	 * Get the Enumeration of enum elements
	 */
	public Enumeration getEnumElementsByValue() {
		return elementsByValue.elements();
	}

	public int getEnumElementCount() {
		return elementsByValue.size();
	}

	/**
	 * Get the orderlist of enum elements as an array of objects.
	 * 
	 * @param pOrderPropertyName a <code>String</code> value
	 * @param pIsAscending  a <code>boolean</code> value
	 * @return an <code>Object[]</code> value
	 */
	public Object[] getOrderedEnumElements(final String pOrderPropertyName,
			                               final boolean pIsAscending) {
	    return getOrderedEnumElements(pOrderPropertyName, pIsAscending, false);
	}
	
    /**
     * Get the orderlist of enum elements as an array of objects.
     * 
     * @param pOrderPropertyName a <code>String</code> value
     * @param pIsAscending a <code>boolean</code> value
     * @param pIsLocalized a <code>boolean</code> value
     * @return an <code>Object[]</code> value
     */
    private Object[] getOrderedEnumElements(final String pOrderPropertyName,
                                            final boolean pIsAscending,
                                            final boolean pIsLocalized) {
        if (logger.isDebugEnabled())
            logger.debug("getOrderedEnumElements::enter...." +
                         " orderPropertyName " + pOrderPropertyName +
                         " isAscending " + pIsAscending +
                         " isLocalized " + pIsLocalized);
        List lList ;
        if(pIsLocalized) {
            lList = getLocalizedOrderedEnumElementsAsList(pOrderPropertyName, pIsAscending);
        } else {
            lList = getOrderedEnumElementsAsList(pOrderPropertyName, pIsAscending);
        }
        Object [] lRetArr = null;
        if (lList != null) {
            lRetArr =  lList.toArray();
        }
        return lRetArr;
    }
    
    /**
     * Get the localized orderlist of enum elements as an array of objects.
     * 
     * @param pOrderPropertyName a <code>String</code> value
     * @param pIsAscending a <code>boolean</code> value
     * @return an <code>Object[]</code> value
     */
    public Object[] getLocalizedOrderedEnumElements(final String pOrderPropertyName,
                                                    final boolean pIsAscending) {
        return getOrderedEnumElements(pOrderPropertyName, pIsAscending, true);
    }    
    

	
	/**
	 * Get the orderlist of enum elements as an Enum.
	 * 
	 * @param pOrderPropertyName a <code>String</code> value
	 * @param pIsAscending a <code>boolean</code> value
	 * @return an <code>Enumeration</code> value
	 */
	public Enumeration getOrderedEnumElementsAsEnum(
			final String pOrderPropertyName, final boolean pIsAscending) {
	    return getOrderedEnumElementsAsEnum(pOrderPropertyName, pIsAscending, false);
	}

    /**
     * Get the orderlist of enum elements as an Enum.
     * 
     * @param pOrderPropertyName a <code>String</code> value
     * @param pIsAscending a <code>boolean</code> value
     * @param pIsLocalized a <code>boolean</code> value
     * @return an <code>Enumeration</code> value
     */
    public Enumeration getOrderedEnumElementsAsEnum(final String  pOrderPropertyName, 
                                                    final boolean pIsAscending,
                                                    final boolean pIsLocalized) {
        if (logger.isDebugEnabled())
            logger.debug("getOrderedEnumElementsAsEnum::enter...." +
                         " orderPropertyName " + pOrderPropertyName +
                         " isAscending " + pIsAscending +
                         " isLocalized " + pIsLocalized);
                
        List lList ;
        if(pIsLocalized) {
            lList = getLocalizedOrderedEnumElementsAsList(pOrderPropertyName, pIsAscending);
        } else {
            lList = getOrderedEnumElementsAsList(pOrderPropertyName, pIsAscending);
        }

        Vector lVector = null;
        Enumeration lRetEnum = null; 
        if (lList != null) {
            if (lList instanceof Vector) {
                lVector = (Vector) lList;
            } else {
                lVector = new Vector(lList);
            }
            lRetEnum = lVector.elements();
        }
        return lRetEnum;
    }
    
    /**
     * Get the Localized orderlist of enum elements as an Enum.
     * 
     * @param pOrderPropertyName a <code>String</code> value
     * @param pIsAscending a <code>boolean</code> value
     * @return an <code>Enumeration</code> value
     */
    public Enumeration getLocalizedOrderedEnumElementsAsEnum(final String  pOrderPropertyName, 
                                                             final boolean pIsAscending) {
        return getOrderedEnumElementsAsEnum(pOrderPropertyName, pIsAscending, true);
    }    
	
	/**
	 * Get the orderlist of enum elements as a List.
	 * 
	 * @param pOrderPropertyName
	 *           a <code>String</code> value
	 * @param pIsAscending
	 *           a <code>boolean</code> value
	 * @return an <code>List</code> Object
	 */
	public List getOrderedEnumElementsAsList(final String  pOrderPropertyName,
			                                 final boolean pIsAscending) {
	    return getOrderedEnumElementsAsList(pOrderPropertyName, pIsAscending, false);
	}
	
    /**
     * Get the orderlist of enum elements as a List.
     * 
     * @param pOrderPropertyName a <code>String</code> value
     * @param pIsAscending a <code>boolean</code> value
     * @param pIsLocalized a <code>boolean</code> value
     *           
     * @return an <code>List</code> Object
     */
    private List getOrderedEnumElementsAsList(final String  pOrderPropertyName,
                                              final boolean pIsAscending,
                                              final boolean pIsLocalized) {
        if (logger.isDebugEnabled())
            logger.debug("getOrderedEnumElementsAsList::enter...." +
                         " orderPropertyName " + pOrderPropertyName +
                         " isAscending " + pIsAscending +
                         " isLocalized " + pIsLocalized);

        Enumeration lThisenum = elementsById.elements();
        Comparator lComparator;
        if(pIsLocalized) {
            lComparator = getLocalizedEnumComparator(pOrderPropertyName, pIsAscending);
        } else {
            lComparator = getEnumComparator(pOrderPropertyName, pIsAscending);
        }
        List lRetVal = new Vector();
        while (lThisenum.hasMoreElements()) {
            UserDefEnumElement elem = (UserDefEnumElement) lThisenum.nextElement();
            lRetVal.add(elem);
        }
        Collections.sort(lRetVal, lComparator);	
               
        return lRetVal;
    }
    
    /**
     * Get the Localized orderlist of enum elements as a List.
     * 
     * @param pOrderPropertyName a <code>String</code> value
     * @param pIsAscending  a <code>boolean</code> value
     * @return an <code>List</code> Object
     */
    public List getLocalizedOrderedEnumElementsAsList(final String  pOrderPropertyName,
                                                      final boolean pIsAscending) {
        return getOrderedEnumElementsAsList(pOrderPropertyName, pIsAscending, true);
    }	
    
    /**
     * Get the Ordered Enumeration of Enum elements as an array of objects.
     * 
     * @param pEnumId a <code>String</code> value
     * @param pOrderPropertyName a <code>String</code> value
     * @param pIsAscending a <code>boolean</code> value
     * @param pIsLocalized a <code>boolean</code> value
     * @return an <code>Object[]</code> value
     */
    static public Object[] getOrderedEnumElements(String pEnumId, String pOrderPropertyName, boolean pIsAscending) {
	    return getOrderedEnumElements(pEnumId, pOrderPropertyName, pIsAscending, false);
	}
	
    /**
     * Get the Ordered Enumeration of Enum elements as an array of objects.
     * 
     * @param pEnumId a <code>String</code> value
     * @param pOrderPropertyName a <code>String</code> value
     * @param pIsAscending a <code>boolean</code> value
     * @param pIsLocalized a <code>boolean</code> value
     * @return an <code>Object[]</code> value
     */
    static private Object[] getOrderedEnumElements(String pEnumId, String pOrderPropertyName, 
                                                   boolean pIsAscending, boolean pIsLocalized ) {
        if (logger.isDebugEnabled())
            logger.debug("getOrderedEnumElements::enter...." +
                         " enumId " + pEnumId +
                         " orderPropertyName " + pOrderPropertyName +
                         " isAscending " + pIsAscending +
                         " isLocalized " + pIsLocalized);
        
        UserDefEnum userDefEnum = getEnum(pEnumId);
        if (userDefEnum != null) {
            if(pIsLocalized) {
                return userDefEnum.getLocalizedOrderedEnumElements(pOrderPropertyName, pIsAscending);
            } else {
                return userDefEnum.getOrderedEnumElements(pOrderPropertyName, pIsAscending);
            }
        } else {
            Throwable lThrowable = new Throwable();
            lThrowable.fillInStackTrace();
            logger.warn("Enum id " + pEnumId + " not found", lThrowable);
            return null;
        }
    }
    
    /**
     * Get the Localized Ordered Enumeration of Enum elements as an array of objects.
     * 
     * @param pEnumId a <code>String</code> value
     * @param pOrderPropertyName a <code>String</code> value
     * @param pIsAscending a <code>boolean</code> value
     * @param pIsLocalized a <code>boolean</code> value
     * @return an <code>Object[]</code> value
     */
    static public Object[] getLocalizedOrderedEnumElements(String pEnumId, String pOrderPropertyName, boolean pIsAscending) {
        return getOrderedEnumElements(pEnumId, pOrderPropertyName, pIsAscending, true);
    }    

	/**
	 * Get the enumeration of enum elements
	 */
	static public Enumeration getEnumElements(String enumId) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getEnumElements();
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return null;
		}
	}

	/**
	 * Get the enumeration of enum elements by name of elements
	 */
	static public Enumeration getEnumElementsByIDs(String enumId, String[] pElementIDs) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getElementsByIDs(pElementIDs);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return null;
		}
	}

	/**
	 * Get the value list of of enum elementIDs.
	 * 
	 * @param enumId
	 *           a <code>String</code> value
	 * @param pElementsIDs
	 *           a <code>String[]</code> value
	 * @return an <code>List</code> value
	 * 
	 * This method returns the List containing the elementValues of those
	 * elements which we are passing a in String array. For working see :
	 * KbaManager.getGlobalValidations() method.
	 * 
	 */
	static public List getEnumElementValues(String enumId, String[] pElementIDs) {
		List retList = new ArrayList();
		if ((!StringUtil.isEmpty(enumId)) && (pElementIDs != null) && (pElementIDs.length > 0)) {
			Enumeration lEnumn = getEnumElementsByIDs(enumId, pElementIDs);
			if (lEnumn != null) {
				while (lEnumn.hasMoreElements()) {
					UserDefEnumElement lEnum = ((UserDefEnumElement) lEnumn.nextElement());
					retList.add(new Integer(lEnum.getValue()));
				}
			}
		}
		return retList;
	}

	/**
	 * Get the value in String object of enum elementIDs.
	 * 
	 * @param enumId
	 *           a <code>String</code> value
	 * @param pElementsIDs
	 *           a <code>String[]</code> value
	 * @return an <code>String</code> value
	 * 
	 * This method returns the String containing the elementValues of those
	 * elements, which we are passing in String array. For working see :
	 * StringUtil.createUserSelectionEnum() method and kbaValidationFilter.jsp
	 * page.
	 * 
	 */
	static public String getEnumElementValuesCSV(String enumId, String[] pElementIDs) {
		String resultStr = "";
		if ((!StringUtil.isEmpty(enumId)) && (pElementIDs != null) && (pElementIDs.length > 0)) {
			Enumeration lEnumn = getEnumElementsByIDs(enumId, pElementIDs);
			if (lEnumn != null) {
				while (lEnumn.hasMoreElements()) {
					UserDefEnumElement lEnum = ((UserDefEnumElement) lEnumn.nextElement());
					if (resultStr.length() > 0) {
						resultStr += ",";
					}
					resultStr += lEnum.getValue();
				}
			}
		}
		return resultStr;
	}

	/**
	 * Get the enumeration of enum elements by elementIDs
	 */
	public Enumeration getElementsByIDs(String[] pElementIDs) {
		Enumeration retObj = null;
		if ((pElementIDs == null) || (pElementIDs.length == 0)) {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("List of elementNames is null or empty. elementNames [" + pElementIDs + "]", throwable);
			return retObj;
		}
		Vector retList = new Vector();
		for (int i = 0; i < pElementIDs.length; i++) {
			if (!StringUtil.isEmpty(pElementIDs[i])) {
				UserDefEnumElement lElement = getElementById(pElementIDs[i]);
				if (lElement != null) {
					retList.add(lElement);
				}
			}
		}
		if ((retList != null) && (retList.size() > 0)) {
			retObj = retList.elements();
		}
		return retObj;
	}

	/**
	 * Returns the number of elements in this enum.
	 */
	public int size() {
		return elementsById.size();
	}

	/**
	 * Returns the value for the given element id
	 */
	public int getElementValue(String elementId) {
		UserDefEnumElement element = getElementById(enumId + "." + elementId);
		if (element == null) {
			// lets try the id directly
			element = getElementById(elementId);
		}
		if (element == null) {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Element id " + elementId + " not found for enum " + enumId, throwable);
			return INVALID;
		}
		return element.getValue();
	}
	public int getElementValueSuppressingLogMessageIfNotFound(String elementId) {
		UserDefEnumElement element = getElementById(enumId + "." + elementId);
		if (element == null) {
			element = getElementById(elementId);
		}
		if (element == null) {
			return INVALID;
		}
		return element.getValue();
	}
/**
	 * Returns the value of the element, by enum and element id
	 * 
	 * @param enumId
	 *           Id of the enum
	 * @param elementId
	 *           If of the element
	 * @return the value of the element. Returns -1 if not found
	 */
	public static int getElementValue(String enumId, String elementId) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getElementValue(elementId);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return INVALID;
		}
	}

	/**
	 * Returns the string value for the given element id
	 */
	public String getElementStrValue(String elementId) {
		UserDefEnumElement element = getElementById(enumId + "." + elementId);
		if (element == null) {
			// lets try the id directly
			element = getElementById(elementId);
		}
		if (element == null) {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Element id " + elementId + " not found for enum " + enumId, throwable);
			return null;
		}
		return element.getStrValue();
	}

	/**
	 * Returns the string value for the given element id
	 */
	public String getElementStrValue(int intValue) {
		UserDefEnumElement element = getElement(intValue);
		if (element == null) {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Element value " + intValue + " not found for enum " + enumId, throwable);
			return null;
		}
		return element.getStrValue();
	}

    /**
     * Returns the Name for the given element id.
     * 
     * @param pElementId <code>String</code> value for element id.
     * @return element name.
     */
	public String getElementName(String pElementId) {
	    return getElementName(pElementId, false);
    }

    /**
     * Returns the Name/Localized Name for the given element id.
     * 
     * @param pElementId <code>String</code> value for element id.
     * @param pIsLocalized <code>boolean</code> value to specify whether the return value
     * should be Localized or not.
     * @return either element name or localized element name.
     */
	private String getElementName(String pElementId, boolean pIsLocalized) {
        if (logger.isDebugEnabled())
            logger.debug("getElementName::enter...." +
                         " pElementId " + pElementId +
                         " pIsLocalized " + pIsLocalized);
	    
        UserDefEnumElement lElement = getElementById(enumId + "." + pElementId);
        if (lElement == null) {
            // lets try the id directly
            lElement = getElementById(pElementId);
        }
        if (lElement == null) {
            Throwable throwable = new Throwable();
            throwable.fillInStackTrace();
            logger.warn("Element id " + pElementId + " not found for enum " + enumId, throwable);
            return null;
        }
        String lRetVal;
        if(pIsLocalized) {
            lRetVal = lElement.getLocalizedName();
        } else {
            lRetVal = lElement.getName();            
        }
        if (logger.isDebugEnabled())
            logger.debug("getElementName::returning  value:" + lRetVal);
        return lRetVal;
    }

    /**
     * Returns the Localized Name for the given element id.
     * 
     * @param pElementId <code>String</code> value for element id.
     * @return Localized element name.
     */
    public String getLocalizedElementName(String pElementId) {
        return getElementName(pElementId, true);
    }
	
    /**
     * Returns the Name for the given element value.
     * 
     * @param pElementValue <code>int</code> value for element value.
     * @return element name.
     */
	public String getElementName(int pElementValue) {
		return getElementName(pElementValue, false);
	}

    /**
     * Returns the Name/Localized Name for the given element value.
     * 
     * @param pElementValue <code>int</code> value for element value.
     * @param pIsLocalized <code>boolean</code> value to specify whether the return value
     * should be Localized or not.
     * @return either element name or localized element name.
     */
    private String getElementName(int pElementValue, boolean pIsLocalized) {
        if (logger.isDebugEnabled())
            logger.debug("getElementName::enter...." +
                         " pElementValue " + pElementValue +
                         " pIsLocalized " + pIsLocalized);
        
        UserDefEnumElement lElement = getElement(pElementValue);
        if (lElement == null) {
//            Throwable throwable = new Throwable();
//            throwable.fillInStackTrace();
            logger.warn("Element for value= " + pElementValue + " not found for enum " + enumId);
//            logger.warn("Element for value= " + pElementValue + " not found for enum " + enumId, throwable);
            return null;
        }
        String lRetVal;
        if(pIsLocalized) {
            lRetVal = lElement.getLocalizedName();
        } else {
            lRetVal = lElement.getName();            
        }
        if (logger.isDebugEnabled())
            logger.debug("getElementName::returning  value:" + lRetVal);
        
        return lRetVal;
    }
    public String getElementId(int elementValue) {
       UserDefEnumElement lElement = getElement(elementValue);
       if (lElement == null) {
           logger.warn("Element for value= " + elementValue + " not found for enum " + enumId);
           return null;
       }
       return lElement.getElementId();            
    }

    /**
     * Returns the Localized Name for the given element value.
     * 
     * @param pElementValue <code>int</code> value for element value.
     * @return Localized element name.
     */
    public String getLocalizedElementName(int pElementValue) {
        return getElementName(pElementValue, true);
    }    
    
	/**
	 * Returns the value of the element, by enum and element name
	 * 
	 * @param name
	 *           of the element
	 * @return the value of the element. Returns -1 if not found
	 */
	public int getElementValueByName(String name) {
		try {
			return getElementByName(name).getValue();
		} catch (Exception ex) {
			logger.warn("Name " + name + " in enum " + enumId + " not found", ex);
			return INVALID;
		}
	}

	/**
	 * Returns the value of the element, by enum and element name
	 * 
	 * @param enumId
	 *           Id of the enum
	 * @param name
	 *           of the element
	 * @return the value of the element. Returns -1 if not found
	 */
	public static int getElementValueByName(String enumId, String name) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getElementValueByName(name);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return INVALID;
		}
	}

	/**
	 * Returns the string value of the element, by enum and element id
	 * 
	 * @param enumId
	 *           Id of the enum
	 * @param elementId
	 *           If of the element
	 * @return the value of the element. Returns -1 if not found
	 */
	public static String getElementStrValue(String enumId, String elementId) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getElementStrValue(elementId);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return null;
		}
	}

	/**
	 * Returns the string value of the element, by enum and element value
	 * 
	 * @param enumId
	 *           Id of the enum
	 * @param intValue
	 *           value of the element
	 * @return the value of the element. Returns -1 if not found
	 */
	public static String getElementStrValue(String enumId, int intValue) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getElementStrValue(intValue);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return null;
		}
	}

	/**
	 * Returns the string value of the element, by enum and element name
	 * 
	 * @param enumId
	 *           Id of the enum
	 * @param name
	 *           of the element
	 * @return the value of the element. Returns -1 if not found
	 */
	public static String getElementStrValueByName(String enumId, String name) {
		try {
			UserDefEnum userDefEnum = getEnum(enumId);
			if (userDefEnum != null) {
				return userDefEnum.getElementByName(name).getStrValue();
			} else {
				Throwable throwable = new Throwable();
				throwable.fillInStackTrace();
				logger.warn("Enum id " + enumId + " not found", throwable);
				return null;
			}
		} catch (Exception ex) {
			logger.warn("Name " + name + " in enum " + enumId + " not found", ex);
			return null;

		}
	}

    /**
     * Returns the Name of the element, by enum and element id
     * 
     * @param pEnumId <code>String </code> Value For Id of the enum
     * @param pElementId <code>String </code> Value For Id of the element
     * @return the name of the element. Returns -1 if not found
     */
	public static String getElementName(String pEnumId, String pElementId) {
	    return getElementName(pEnumId, pElementId, false);
	}

    /**
     * Returns the Name/Localized Name of the element, by enum and element id
     * 
     * @param pEnumId <code>String </code> Value For Id of the enum
     * @param pElementId <code>String </code> Value For Id of the element
     * @param pIsLocalized <code>boolean</code> value to specify whether the return value
     * should be Localized or not.
     * @return the name/localized name of the element. Returns -1 if not found
     */
    private static String getElementName(String pEnumId, String pElementId, boolean pIsLocalized) {
        if (logger.isDebugEnabled())
            logger.debug("getElementName::enter...." +
                         " pEumId " + pEnumId +
                         " pElementId " + pElementId +
                         " pIsLocalized " + pIsLocalized);
        
        UserDefEnum userDefEnum = getEnum(pEnumId);
        if (userDefEnum != null) {
            String lRetVal;
            if(pIsLocalized) {
                lRetVal = userDefEnum.getLocalizedElementName(pElementId);
            } else {
                lRetVal = userDefEnum.getElementName(pElementId);            
            }
            if (logger.isDebugEnabled())
                logger.debug("getElementName::returning  value:" + lRetVal);
            return lRetVal;
        } else {
            Throwable throwable = new Throwable();
            throwable.fillInStackTrace();
            logger.warn("Enum id " + pEnumId + " not found", throwable);
            return null;
        }
    }	
    
    /**
     * Returns the Localized Name of the element, by enum and element id
     * 
     * @param pEnumId <code>String </code> Value For Id of the enum
     * @param pElementId <code>String </code> Value For Id of the element
     * @return the Localized name of the element. Returns -1 if not found
     */
    public static String getLocalizedElementName(String pEnumId, String pElementId) {
        return getElementName(pEnumId, pElementId, true);
    }    
	/**
	 * Returns the value of the property, by element name
	 * 
	 * @param propertyName
	 *           Name of the property.
	 * @return value of the property if set. Else returns null;
	 */
	public String getPropertyByElementName(String elementName, String propertyName) {
		try {
			return getElementByName(elementName).getProperty(propertyName);
		} catch (Exception ex) {
			logger.warn("Name " + elementName + " in enum " + enumId + " not found. propertyName=" + propertyName, ex);
			return null;
		}
	}

	/**
	 * Returns the value of the property, by element name
	 * 
	 * @param enumId
	 *           Id of the enum
	 * @param elementName
	 *           name of the element
	 * @param propertyName
	 *           name of the property
	 * @return value of the property if set. Else returns null;
	 */
	public static String getPropertyByElementName(String enumId, String elementName, String propertyName) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getPropertyByElementName(elementName, propertyName);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found. propertyName=" + propertyName, throwable);
			return null;
		}
	}
        
        /**
         * Returns the localized value of the property, by element name
         * 
         * @param propertyName
         *           Name of the property.
         * @return value of the property if set. Else returns null;
         */
        public String getLocalizedPropertyByElementName(String elementName, String propertyName) {
                try {
                        return getElementByName(elementName).getLocalizedProperty(propertyName);
                } catch (Exception ex) {
                        logger.warn("Name " + elementName + " in enum " + enumId + " not found. propertyName=" + propertyName, ex);
                        return null;
                }
        }
    
        /**
         * Returns the localized value of the property, by element name
         * 
         * @param enumId
         *           Id of the enum
         * @param elementName
         *           name of the element
         * @param propertyName
         *           name of the property
         * @return value of the property if set. Else returns null;
         */
        public static String getLocalizedPropertyByElementName(String enumId, String elementName, String propertyName) {
                UserDefEnum userDefEnum = getEnum(enumId);
                if (userDefEnum != null) {
                        return userDefEnum.getLocalizedPropertyByElementName(elementName, propertyName);
                } else {
                        Throwable throwable = new Throwable();
                        throwable.fillInStackTrace();
                        logger.warn("Enum id " + enumId + " not found. propertyName=" + propertyName, throwable);
                        return null;
                }
        }

	/**
	 * Returns the value of the property, by element id
	 * 
	 * @param propertyName
	 *           Name of the property.
	 * @return value of the property if set. Else returns null;
	 */
	public String getPropertyByElementId(String elementId, String propertyName) {
			return getPropertyByElementId(elementId, propertyName, false);
	}
	
	/**
	 * Returns the Localized value of the property, by element id
	 * 
	 * @param propertyName
	 *           Name of the property.
	 * @return value of the property if set. Else returns null;
	 */
	public String getLocalizedPropertyByElementId(String elementId, String propertyName) {
			return getPropertyByElementId(elementId, propertyName, true);
	}
	
	
	
	/**
	 * Returns the value of the property, by element id
	 * 
	 * @param propertyName
	 *           Name of the property.
	 * @return value of the property if set. Else returns null;
	 */
	private String getPropertyByElementId(String elementId, String propertyName,boolean isLocalized) {
		try {
			if(isLocalized) {
			return getElementById(elementId).getLocalizedProperty(propertyName);
			}
			else {
			return getElementById(elementId).getProperty(propertyName);
			}
			
		} catch (Exception ex) {
			logger.warn("Name " + elementId + " in enum " + enumId + " not found. propertyName=" + propertyName, ex);
			return null;
		}
	}
	
	

	/**
	 * Returns the value of the property, by element id
	 * 
	 * @param enumId
	 *           Id of the enum
	 * @param elementId
	 *           id of the element
	 * @param propertyName
	 *           name of the property
	 * @return value of the property if set. Else returns null;
	 */
	public static String getPropertyByElementId(String enumId, String elementId, String propertyName) {
			return getPropertyByElementId(enumId,elementId,propertyName,false);
	}
	
	/**
	 * Returns the Localized value of the property, by element id
	 * 
	 * @param enumId
	 *           Id of the enum
	 * @param elementId
	 *           id of the element
	 * @param propertyName
	 *           name of the property
	 * @return value of the property if set. Else returns null;
	 */
	public static String getLocalizedPropertyByElementId(String enumId, String elementId, String propertyName) {
			return getPropertyByElementId(enumId,elementId,propertyName,true);
	}
	
	
	
	/**
	 * Returns the value of the property, by element id
	 * 
	 * @param enumId
	 *           Id of the enum
	 * @param elementId
	 *           id of the element
	 * @param propertyName
	 *           name of the property
	 * @return value of the property if set. Else returns null;
	 */
	private static String getPropertyByElementId(String enumId, String elementId, String propertyName,boolean isLocalized) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			if(!isLocalized) {
			return userDefEnum.getPropertyByElementId(elementId, propertyName);
			}
			else {
			return userDefEnum.getLocalizedPropertyByElementId(elementId, propertyName);
			}
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return null;
		}
	}
	

	/**
	 * Returns the value of the property, by element value
	 * 
	 * @param value
	 *           value for the element.
	 * @param propertyName
	 *           name of the property
	 * @return value of the property if set. Else returns null;
	 */
	public String getPropertyByElementValue(int value, String propertyName) {
		try {
			return getElement(value).getProperty(propertyName);
		} catch (Exception ex) {
			logger.warn("Value " + value + " in enum " + enumId + " not found. propertyName=" + propertyName, ex);
			return null;
		}
	}

	public String getPropertyByElementValue(int value, String propertyName, boolean iWantABigWarningIfThePropertyIsNotThere) {
		try {
			return getElement(value).getProperty(propertyName);
		} catch (Exception ex) {
			if (iWantABigWarningIfThePropertyIsNotThere) {
				logger.warn("Value " + value + " in enum " + enumId + " not found. propertyName=" + propertyName, ex);
			}
			return null;
		}
	}
	
	public String getLocalizedPropertyByElementValue(int value, String propertyName) {
		try {
			return getElement(value).getLocalizedProperty(propertyName);
		} catch (Exception ex) {
			logger.warn("Value " + value + " in enum " + enumId + " not found. propertyName=" + propertyName, ex);
			return null;
		}
	}

	public String getLocalizedPropertyByElementValue(int value, String propertyName, boolean iWantABigWarningIfThePropertyIsNotThere) {
		try {
			return getElement(value).getLocalizedProperty(propertyName);
		} catch (Exception ex) {
			if (iWantABigWarningIfThePropertyIsNotThere) {
				logger.warn("Value " + value + " in enum " + enumId + " not found. propertyName=" + propertyName, ex);
			}
			return null;
		}
	}

	/**
	 * Returns the value of the property, by element id
	 * 
	 * @param enumId
	 *           Id of the enum
	 * @param value
	 *           value for the element.
	 * @param propertyName
	 *           name of the property
	 * @return value of the property if set. Else returns null;
	 */
	public static String getPropertyByElementValue(String enumId, int value, String propertyName) {
		return getPropertyByElementValue(enumId, value, propertyName, true);
	}

	public static String getPropertyByElementValue(String enumId, int value, String propertyName, boolean iWantABigWarningIfThePropertyIsNotThere) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getPropertyByElementValue(value, propertyName, iWantABigWarningIfThePropertyIsNotThere);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found. propertyName=" + propertyName, throwable);
			return null;
		}
	}

	public static String getLocalizedPropertyByElementValue(String enumId, int value, String propertyName) {
		return getLocalizedPropertyByElementValue(enumId, value, propertyName, true);
	}

	public static String getLocalizedPropertyByElementValue(String enumId, int value, String propertyName, boolean iWantABigWarningIfThePropertyIsNotThere) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getLocalizedPropertyByElementValue(value, propertyName, iWantABigWarningIfThePropertyIsNotThere);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found. propertyName=" + propertyName, throwable);
			return null;
		}
	}

    /**
     * Returns the Name of the element, by enum and element id
     * 
     * @param pEnumId <code>String </code> Value For Id of the enum
     * @param pElementValue <code>int</code> Value For Value of the element
     * @return the name of the element. Returns -1 if not found
     */
	public static String getElementName(String pEnumId, int pValue) {
	    return getElementName(pEnumId, pValue, false);
	}

    /**
     * Returns the Name/Localized Name of the element, by enum and element id
     * 
     * @param pEnumId <code>String </code> Value For Id of the enum
     * @param pElementValue <code>int</code> Value For Value of the element
     * @param pIsLocalized <code>boolean</code> value to specify whether the return value
     * should be Localized or not.
     * @return the name/localized name of the element. Returns -1 if not found
     */
    private static String getElementName(String pEnumId, int pElementValue, boolean pIsLocalized) {
        if (logger.isDebugEnabled())
            logger.debug("getElementName::enter...." +
                         " pEumId " + pEnumId +
                         " pElementValue " + pElementValue +
                         " pIsLocalized " + pIsLocalized);
        
        UserDefEnum userDefEnum = getEnum(pEnumId);
        if (userDefEnum != null) {
            String lRetVal;
            if(pIsLocalized) {
                lRetVal = userDefEnum.getLocalizedElementName(pElementValue);
            } else {
                lRetVal = userDefEnum.getElementName(pElementValue);            
            }
            if (logger.isDebugEnabled())
                logger.debug("getElementName::returning  value:" + lRetVal);
            return lRetVal;
        } else {
            Throwable throwable = new Throwable();
            throwable.fillInStackTrace();
            logger.warn("Enum id " + pEnumId + " not found", throwable);
            return null;
        }
    }
    public static String getElementId(String enumId, int elementValue) {
       UserDefEnum userDefEnum = getEnum(enumId);
       if (userDefEnum != null) {
           return userDefEnum.getElementId(elementValue);      
       } else {
           Throwable throwable = new Throwable();
           throwable.fillInStackTrace();
           logger.warn("Enum id " + enumId + " not found", throwable);
           return null;
       }
    }
	
    /**
     * Returns the Localized Name of the element, by enum and element id.
     * 
     * @param pEnumId <code>String </code> Value For Id of the enum
     * @param pElementValue <code>int</code> Value For Value of the element
     * @return the localized name of the element. Returns -1 if not found
     */
    public static String getLocalizedElementName(String pEnumId, int pValue) {
        return getElementName(pEnumId, pValue, true);
    }
    
	/**
	 * Returns all the elements which has the given property set to true.
	 */
	public int[] getElementValuesForProperty(String propertyName, String value) {
		if (StringUtil.isEmpty(value)) { return new int[0]; }
		value = value.trim();
		ArrayList intList = new ArrayList();

		Enumeration elements = getEnumElements();
		while (elements.hasMoreElements()) {
			UserDefEnumElement element = (UserDefEnumElement) elements.nextElement();
			String property = element.getProperty(propertyName);
			if (value.equalsIgnoreCase(property)) {
				intList.add(new Integer(element.getValue()));
			}
		}
		int[] retList = new int[intList.size()];
		Iterator iter = intList.iterator();
		for (int i = 0; iter.hasNext(); i++) {
			Integer intValue = (Integer) iter.next();
			retList[i] = intValue.intValue();
		}
		return retList;
	}

	/**
	 * Returns all the elements which has the given property set to true.
	 */
	static public int[] getElementValuesForProperty(String enumId, String propertyName, String value) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getElementValuesForProperty(propertyName, value);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found. propertyName=" + propertyName + ", value=" + value, throwable);
			return new int[0];
		}
	}

	/**
	 * Returns all the element ids
	 */
	public String[] getAllElementIds() {
		String[] retList = new String[elementsByValue.size()];
		Enumeration elements = getEnumElements();
		for (int i = 0; elements.hasMoreElements(); i++) {
			UserDefEnumElement element = (UserDefEnumElement) elements.nextElement();
			retList[i] = element.getElementId();
		}
		return retList;
	}

	/**
	 * Returns all the elements which has the given property set to true.
	 */
	static public String[] getAllElementIds(String enumId) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getAllElementIds();
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return new String[0];
		}
	}

	/**
	 * Returns all the element values
	 */
	public int[] getAllElementValues() {
		int[] retList = new int[elementsByValue.size()];
		Enumeration elements = getEnumElements();
		for (int i = 0; elements.hasMoreElements(); i++) {
			UserDefEnumElement element = (UserDefEnumElement) elements.nextElement();
			retList[i] = element.getValue();
		}
		return retList;
	}

	/**
	 * Returns all the elements which has the given property set to true.
	 */
	static public int[] getAllElementValues(String enumId) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getAllElementValues();
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return new int[0];
		}
	}

	/**
	 * Returns all the element names
	 */
	public String[] getAllElementNames() {
		return getAllElementNames(false);
	}

	/**
	 * Returns all the elements which has the given property set to true.
	 */
	static public String[] getAllElementNames(String enumId) {
		return getAllElementNames(enumId,false);
	}

	/**
	 * Returns all the localized elements which has the given property set to true.
	 */
	static public String[] getLocalizedAllElementNames(String enumId) {
		return getAllElementNames(enumId,true);
	}
	
	/**
	 * Returns all the elements which has the given property set to true.
	 */
	 static private String[] getAllElementNames(String enumId,boolean isLocalized) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			if(isLocalized){
				return userDefEnum.getLocalizedAllElementNames();
			}else{
				return userDefEnum.getAllElementNames();	
			}
			
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return new String[0];
		}
	}
	
	/**
	 * Returns all the element names
	 */
	private String[] getAllElementNames(boolean isLocalized) {
		String[] retList = new String[elementsByValue.size()];
		Enumeration elements = getEnumElements();
		for (int i = 0; elements.hasMoreElements(); i++) {
			UserDefEnumElement element = (UserDefEnumElement) elements.nextElement();
			if(isLocalized){
				retList[i] = element.getLocalizedName();
			}else{
				retList[i] = element.getName();
			}
		}
		return retList;
	}

	/**
	 * Returns all the localized element names
	 */
	public String[] getLocalizedAllElementNames() {
		return getAllElementNames(true);
	}
	
	/**
	 * This gets the list of element values for the enum elments which is
	 * referenced in the property
	 */
	public List getReferencedElementValuesForProperty(int value, String propertyName, String referenceEnumId) {
		ArrayList valueList = new ArrayList();
		try {
			String propValue = getElement(value).getProperty(propertyName);
			UserDefEnum refEnum = getEnum(referenceEnumId);
			if (refEnum != null && !StringUtil.isEmpty(propValue)) {
				String[] propList = propValue.split(",");
				for (int i = 0; i < propList.length; i++) {
					int refValue = refEnum.getElementValue(propList[i]);
					if (refValue >= 0) {
						valueList.add(new Integer(refValue));
					}
				}
			}
		} catch (Exception ex) {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Element value " + value + " not found in enum " + enumId, throwable);
		}
		return valueList;
	}

	/**
	 * This gets the list of element values for the enum elments which is
	 * referenced in the property
	 */
	static public List getReferencedElementValuesForProperty(String enumId, int value, String propertyName, String referenceEnumId) {
		UserDefEnum userDefEnum = getEnum(enumId);
		if (userDefEnum != null) {
			return userDefEnum.getReferencedElementValuesForProperty(value, propertyName, referenceEnumId);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Enum id " + enumId + " not found", throwable);
			return new ArrayList();
		}
	}
	
	public static Object getInstanceOfClassPropertyByName(String enumId, String name, String propertyName, Class shouldImplement, Object defaultValue) {
		UserDefEnumElement element = getElement(enumId, propertyName);
		if (element != null) {
			return element.getInstanceOfClassProperty(propertyName, shouldImplement, defaultValue);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Name " + name + " in enum " + enumId + " not found. propertyName=" + propertyName, throwable);
			return defaultValue;
		}
	}
	public static Object getInstanceOfClassPropertyByValue(String enumId, int value, String propertyName, Class shouldImplement, Object defaultValue) {
		UserDefEnumElement element = getElement(enumId, value);
		if (element != null) {
			return element.getInstanceOfClassProperty(propertyName, shouldImplement, defaultValue);
		} else {
			Throwable throwable = new Throwable();
			throwable.fillInStackTrace();
			logger.warn("Value " + value + " in enum " + enumId + " not found. propertyName=" + propertyName, throwable);
			return defaultValue;
		}
	}

	/**
	 * toString
	 */
	public String toString() {
		String str = "";
		str += "enumId={" + enumId + "} ";
		str += "ids={" + elementsById + "} ";
		str += "description={" + description + "} ";
		return str;
	}

    /**
     * This static method returns the Comparator based on the property name specified as an argument.
     * @param pOrderPropertyName The property on the basis of which the elements need to be sorted
     * @param pIsAscending Whether the properties are to be sorted in ascending order. Setting this 
     * value to false will mean that the values will be sorted in the descending order. 
     * @return Comparator
     */
    public static Comparator getEnumComparator(final String pOrderPropertyName,
                                               final boolean pIsAscending) {
        return  getEnumComparator(pOrderPropertyName, pIsAscending, false);
    }
    
    /**
     * This static method returns the Comparator based on the property name specified as an argument.
     * 
     * @param pOrderPropertyName The property on the basis of which the elements need to be sorted
     * @param pIsAscending  Whether the properties are to be sorted in ascending order. Setting this
     * value to false will mean that the values will be sorted in the descending order.
     * @param pIsGlobalized Whether to compare values on the basis of globalized property or not.
     * @return
     */
    private static Comparator getEnumComparator(final String  pOrderPropertyName,
                                                final boolean pIsAscending,
                                                final boolean pIsGlobalized) {
        return new Comparator() {
            public int compare(Object o1, Object o2) {
                if (o1 instanceof UserDefEnumElement && o2 instanceof UserDefEnumElement) {
                    String lOne,lTwo;
                    if(pIsGlobalized) {
                        lOne = ((UserDefEnumElement) o1).getLocalizedProperty(pOrderPropertyName);
                        lTwo = ((UserDefEnumElement) o2).getLocalizedProperty(pOrderPropertyName);
                    } else {
                        lOne = ((UserDefEnumElement) o1).getProperty(pOrderPropertyName);
                        lTwo = ((UserDefEnumElement) o2).getProperty(pOrderPropertyName);
                    }
                    
                    if (lOne == null && lTwo == null) {
                    	if(pIsGlobalized) {
                            lOne = ((UserDefEnumElement) o1).getLocalizedName();
                            lTwo = ((UserDefEnumElement) o2).getLocalizedName();
                        } else {
                            lOne = ((UserDefEnumElement) o1).getName();
                            lTwo = ((UserDefEnumElement) o2).getName();
                        }	
                    } 
                    
                    if (lOne != null && lTwo != null) {
                        if (StringUtil.isAllNumeric(lOne) && StringUtil.isAllNumeric(lTwo)) {
                        	try{
                            	return pIsAscending ? (Integer.parseInt(lOne.trim()) - Integer.parseInt(lTwo.trim()))
                                       : (Integer.parseInt(lTwo.trim()) - Integer.parseInt(lOne.trim()));
                            }catch(NumberFormatException e){
                            	return pIsAscending ? (lOne.compareTo(lTwo)) : (lTwo.compareTo(lOne));
                            }
                        } else {
                        	return pIsAscending ? (lOne.compareTo(lTwo)) : (lTwo.compareTo(lOne));
                        }
                    }
                }
                return -1;
            }
        };
    }

    /**
     * This static method returns the Comparator based on the localized property value.
     * 
     * @param pOrderPropertyName The property on the basis of which the elements need to be sorted
     * @param pIsAscending Whether the properties are to be sorted in ascending order. Setting this 
     * value to false will mean that the values will be sorted in the descending order. 
     * @return Comparator
     */
    public static Comparator getLocalizedEnumComparator(final String  pOrderPropertyName,
                                                         final boolean pIsAscending) {
        return  getEnumComparator(pOrderPropertyName, pIsAscending, true);
    }    
}
