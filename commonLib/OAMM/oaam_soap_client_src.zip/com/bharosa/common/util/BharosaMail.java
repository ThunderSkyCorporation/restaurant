package com.bharosa.common.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

//import java.io.*;
import java.util.*;
import java.io.*;

import javax.activation.*;
import javax.mail.*;
import javax.mail.internet.*;

import com.bharosa.common.logger.Logger;

public class BharosaMail{
	static Logger  logger = Logger.getLogger(BharosaMail.class);

	String errorMessage = null;

	Session mailSession;
	String smtphost, mailUser, mailPass;
	boolean mailAuth = false;

	public BharosaMail(){
		try{
			Properties p = new Properties();

			smtphost = BharosaConfig.get("mail.smtp.host", "localhost");
			mailUser = BharosaConfig.get("mail.smtp.user", "localuser");
			mailPass = BharosaConfig.get("mail.smtp.password", "localpwd");
			mailAuth = BharosaConfig.getBoolean("mail.smtp.auth", false);

			p.setProperty("mail.smtp.host", smtphost);
			p.setProperty("mail.smtp.user", mailUser);
			p.setProperty("mail.smtp.password", mailPass);
			p.setProperty("mail.smtp.auth", ""+mailAuth);

			if (logger.isDebugEnabled()){
				logger.debug("Email settings...");
				logger.debug("-->SMTP Host: "+smtphost);
				logger.debug("-->User: "+mailUser);
				logger.debug("-->Password: "+mailPass);
				logger.debug("-->Using authentication: "+mailAuth);
			}

			Authenticator auth = null;

			if (mailAuth){
				auth = new SMTPAuthenticator(mailUser,mailPass);
				mailSession = Session.getInstance(p, auth);
			}else{
				mailSession = Session.getDefaultInstance(p, null);
			}
		}
		catch (Exception e){
			logger.error("Unable to create BharosaMail object!", e);
		}
	}

	public String getSMTPHost(){
		return smtphost;
	}

	public String getError(){
		return errorMessage;
	}

	//convenience method for sending single emails
 	public void sendMail(String mailTo, String fromName, String from, String replyTo, String subject, String body) throws Exception{
 		if(logger.isDebugEnabled()) logger.debug("Sending a single email and checking if email addresses are comma separated");

 		String[] mt = getAddressArray(mailTo, true);
 		sendMail(mt, null, null, fromName, from, replyTo, subject, body, null);
	}

	//method to be invoked by all other classes to send mail...
	public void sendMail(String mailTo,String mailCc,String mailBcc, String fromName, String from, String replyTo, String subject, String body) throws Exception{
		if(logger.isDebugEnabled()) logger.debug("Sending a single email and checking if email addresses are comma separated");

		//setting mailTo recipients addresses
		logger.debug("mailTo:"+mailTo);
		String[] mt = getAddressArray(mailTo, true);
		logger.debug("mailCc:"+mailCc);
		String[] cc = getAddressArray(mailCc, false);
		logger.debug("mailBcc:"+mailBcc);
		String[] bcc = getAddressArray(mailBcc, false);

		sendMail(mt, cc, bcc, fromName, from, replyTo, subject, body, null);
	}

	//method to send only the to recpient without attachment--backward compatibility support
    public void sendMail(String[] mailTo, String fromName, String from, String replyTo, String subject, String body) throws Exception{
		if(logger.isDebugEnabled()) logger.debug("In sendMail");

		sendMail(mailTo, null, null, fromName, from, replyTo, subject, body, null) ;
	}

	//method to send all the recepients as String arrays - backward compatibility support
	public void sendMail(String[] mailTo, String[] mailCc, String[] mailBcc, String fromName, String from, String replyTo, String subject, String body) throws Exception{
		if(logger.isDebugEnabled()) logger.debug("In sendMail");

		sendMail(mailTo, mailCc, mailCc, fromName, from, replyTo, subject, body, null);

	}

	//method to send only the to recepient and file as attachment
	public void sendMail(String[] mailTo, String fromName, String from, String replyTo, String subject, String body, File attachment) throws Exception{
		if(logger.isDebugEnabled()) logger.debug("In sendMail");

		sendMail(mailTo, null, null, fromName, from, replyTo, subject, body, attachment) ;

	}

	//base method that does the entire processsing
	public void sendMail(String[] mailTo, String[] mailCc, String[] mailBcc, String fromName, String from, String replyTo, String subject, String body, File attachment) throws Exception{

		if(logger.isDebugEnabled()) logger.debug("In sendMail");

		if(logger.isDebugEnabled()) logger.debug("Setting up connection info");
		InternetAddress fromInet = new InternetAddress(from);
		fromInet.setPersonal(fromName);
		InternetAddress replyto = new InternetAddress(replyTo);
		InternetAddress[] r = new InternetAddress[1];
		r[0] = replyto;
 		InternetAddress[] dest = getInetAddressArray(mailTo, true);

 		InternetAddress[] destCc = getInetAddressArray(mailCc, false);

 		InternetAddress[] destBcc = getInetAddressArray(mailBcc, false);

 		//check if Primary Recepient is set
		if (dest!=null){


			if(logger.isDebugEnabled()) logger.debug("Setting up message");
			MimeMessage message = new MimeMessage(mailSession);
			message.setFrom(fromInet);
			message.setReplyTo(r);

			message.addRecipients(Message.RecipientType.TO, dest);

			if (destCc!=null){
				message.addRecipients(Message.RecipientType.CC, destCc);

			}
			if (destBcc!=null){
				message.addRecipients(Message.RecipientType.BCC, destBcc);

			}

			message.setSubject(subject, "UTF-8");

			Multipart multipart = null;
            if (attachment != null) {
			    multipart = new MimeMultipart();
		    } else {
				multipart = new MimeMultipart("alternative");
			} 

			BodyPart bodyPart = new MimeBodyPart();

			// adding text.
			bodyPart = new MimeBodyPart();
			bodyPart.setContent(body, "text/html; charset=UTF-8");
			multipart.addBodyPart(bodyPart);

			// adding attachments
			if (attachment != null) {
				bodyPart = new MimeBodyPart();
				FileDataSource fileDataSource = new FileDataSource(attachment.getPath());
				bodyPart.setDataHandler(new DataHandler(fileDataSource));
				bodyPart.setFileName(attachment.getName());
				multipart.addBodyPart(bodyPart);
			} // end of if (attachments != null)

			message.setContent(multipart);
			message.setSentDate(new Date());
			//message.setText(body);
			message.saveChanges();

			if(logger.isDebugEnabled()) logger.debug("Sending emails");
			Transport.send(message);
		}else{

			logger.error("Unable to create BharosaMail object :To Recipient Found Null");

		}
	}

	private String[] getAddressArray(String pAddressString, boolean shouldCheckNull) throws Exception {
		if (pAddressString==null){
			if (shouldCheckNull) {
				throw new Exception("Cannot send an email to a null address!");
			} // end of if (shouldCheckNull)
			return null;
		}

		//setting recipients addresses
		StringTokenizer st = new StringTokenizer(pAddressString, ",");
		String[] addressArray = new String[ st.countTokens() ];
		for( int i = 0; st.hasMoreTokens(); i++) {
			String addressStr = (st.nextToken()).trim();
            //TODO:Review:Bosco: After trimming we need to check whether the string is empty
			//Sagar: Added a check if we found just one address and that String is empty then throwing an exception
			if (StringUtil.isEmpty(addressStr) && st.countTokens() == 1) {
				if (shouldCheckNull) {
					throw new Exception("Cannot send an email to a null address!");
				} // end of if (shouldCheckNull)
				return null;
			} // end of if (StringUtil.isEmpty(addressStr))
			addressArray[i] = addressStr;
		}
		return addressArray;
	}

	private InternetAddress[] getInetAddressArray(String[] pAddressArray, boolean shouldCheckNull) throws Exception {
		if (pAddressArray == null) {
			if (shouldCheckNull) {
				throw new Exception("Cannot send an email to a null address!");
			} // end of if (shouldCheckNull)
			logger.debug("Found null receipient array");
			return null;
		} // end of if (pAddressArray == null)

		InternetAddress[] lDestAddress = new InternetAddress[pAddressArray.length] ;
		for (int i=0; i<pAddressArray.length; i++){
			if(pAddressArray[i]!=null){
				lDestAddress[i] = new InternetAddress(pAddressArray[i]);

				if (logger.isDebugEnabled()){
					logger.debug("-->To: "+pAddressArray[i]);
				}
			}else{
				logger.error("Found null value in receipient list");
			}
		}
		return lDestAddress;
	}

	private class SMTPAuthenticator extends javax.mail.Authenticator{
		private String smtpuser, smtppwd;

		public SMTPAuthenticator(String user, String pass){
			smtpuser=user;
			smtppwd = pass;
		}

		public PasswordAuthentication getPasswordAuthentication(){
			return new PasswordAuthentication(smtpuser, smtppwd);
		}
	}
}
