package com.bharosa.common.util;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * Long property value
 * User: bosco
 */

import com.bharosa.common.logger.Logger;

public class BharosaPropertyLong extends BharosaPropertyBase {
    static Logger logger = Logger.getLogger(BharosaPropertyLong.class);

    long defaultValue;

    public BharosaPropertyLong(String name, long defaultValue) {
        super(name);
        this.defaultValue = defaultValue;
    }

    public long getValue() {
        if( getBharosaProperty() == null ) {
            return defaultValue;
        }
        return getBharosaProperty().getLong(defaultValue);
    }

    public String toString() {
        return ""+getValue();
    }
}
