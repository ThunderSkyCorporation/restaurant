/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
package com.bharosa.common.util;

import java.io.File;
import java.io.InputStream;

import java.net.URL;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import com.bharosa.common.logger.Logger;

/**
 * This class reads all the configuration values and gives easy access to them. It also monitors the property files for
 * any changes and if it detects one, then it will reload them. This class also loads the System properties. System
 * properties has the least precedence.
 *
 * @author kuldeep
 * Date: Jul 11, 2007
 * Time: 10:33:49 AM
 *
 */
public class BharosaConfigLoadPropsImpl extends BharosaConfigLoadCommonImpl implements BharosaConfigLoadIntf,
                                                                                       FileMonitorCallBack {

    private Logger logger = Logger.getLogger(BharosaConfigLoadPropsImpl.class);

    //Value hardcoded here.
    private int monitorSeconds = 30;

    public BharosaConfigLoadPropsImpl() {
        if (logger.isDebugEnabled())
            logger.debug("Constructing BharosaConfigLoadPropsImpl...");
        // Nothing to be done for now.
    }

    public synchronized void init() {
        super.init();
    }

    /**
     * Default property file name which contains the list of other properties files which need to be loaded.
     */
    static String lookupPropFile = "lookup.properties";

    /**
     * Here goes the method descripton.
     */
    protected void reload_nolock() {
        logger.info("Reloading BharosaConfig property files");
        //Lets create a temporary property Map.
        Map tmpProp = new HashMap();
        tmpProp.put("lookup.properties", lookupPropFile);

        //Get seed property file
        //First check the system property values
        String fileName = (String)tmpProp.get("lookup.properties");
        if (fileName != null) {
            lookupPropFile = fileName.trim();
        }

        //Lets try to open the lookup property file.
        Properties lookupProps = loadProperties(lookupPropFile);

        if (lookupProps == null) {
            //if not found, log an error and ignore loading the files.
            logger.error("Lookup file " + lookupPropFile +
                         " not found anywhere in the system.");
            return;
        }

        //Parse the property file list
        String fileListPropName = "properties.filelist";
        String propFileList = lookupProps.getProperty(fileListPropName);
        if (propFileList == null) {
            logger.error("Lookup file " + lookupPropFile + " doesn't have " +
                         fileListPropName + " property set.");
            return;
        }

        StringTokenizer st = new StringTokenizer(propFileList, ",");
        while (st.hasMoreTokens()) {
            String pFile = st.nextToken().trim();
            Properties props = loadProperties(pFile);
            if (props == null) {
                logger.error("Couldn't load properties file " + pFile);
                continue;
            }
            //Load the property file
            load(props, tmpProp);
        }

        //load the software overloaded properties
        load(overloadedMap, tmpProp);

        //Set the global property map
        updateGlobalMap(tmpProp);

        //Load the system properties
        // load(System.getProperties(), tmpProp);
        // Load the system properties using loadSystemProperties method in CommonImpl
        loadSystemProperties(System.getProperties());


        logger.info("Done reloading BharosaConfig property files.");

        fireReloadListeners();

        updateSystemProps();
    }

    /**
     * Here goes the method descripton.
     */
    void reload() {
        synchronized (BharosaConfigLoadPropsImpl.class) {
            reload_nolock();
            decryptProperties();
        }
    }

    /**
     * This method create the properties file from the given filename. It will try to open the file from the current
     * path and if it can't, then it will try to find it in the classpath. It will return null if it can't find it.
     *
     * @param fileName Name of the file/path to open.
     * @return The instance of the Properties. It will return null if it couldn't open the file.
     */
    private Properties loadProperties(String fileName) {
        Properties lProps = loadPropertiesStream(fileName);
        if (lProps == null) {
            if (logger.isInfoEnabled())
                logger.info("Unable to load properties from file=" + fileName);
        }
        return lProps;
    }

    private Properties loadPropertiesStream(String pFilename) {
        Properties lProps = null;
        URL lFileUrl = FileUtil.getURL(pFilename);
        if (logger.isDebugEnabled())
            logger.debug("File[" + pFilename + "] FileURL[" + lFileUrl + "]");
        if (lFileUrl != null) {
            try {
                FileUtil.setFileMonitor(pFilename, this, monitorSeconds);
            } catch (java.io.IOException e) {
                logger.warn("Error setting File Monitor: " + lFileUrl, e);
            } // end of catch

            InputStream lStream = null;
            try {
                lStream = FileUtil.getInputStream(pFilename);
                if (lStream == null) {
                    //try pre pending bharosa_properties
                    String altFileName = "bharosa_properties/" + pFilename;
                    lStream = FileUtil.getInputStream(altFileName);
                    if (lStream != null) {
                        if (logger.isDebugEnabled())
                            logger.debug("Loaded as resource from " +
                                         altFileName);
                    }

                }
                if (lStream != null) {
                    if (logger.isDebugEnabled())
                        logger.debug("Loading Properties");
                    lProps = new Properties();
                    lProps.load(lStream);
                } // end of if ()
            } catch (Exception exc) {
                logger.warn("Could not get stream to file: " + pFilename, exc);
            } // end of try-catch
            finally {
                try {
                    if (lStream != null)
                        lStream.close();
                } catch (Exception e) {
                    logger.warn("Error closing stream: " + lFileUrl, e);
                } // end of try-catch
            } // end of finally
        } // end of if ()

        return lProps;
    }

    /**
     * Creates/Updates BharosaProperty objects based on passed map of name/value (key/value) pairs.
     *
     * @param map map
     */
    protected void updateGlobalMap(Map map) {
        logger.info("updateGlobalMap(): Updating global map");
        synchronized (propMap) {
            Iterator iter = map.keySet().iterator();
            while (iter.hasNext()) {
                String key = (String)iter.next();
                String value = (String)map.get(key);
                updateProperty(key, value);
            }
        }
    }

    /**
     * Creates/Updates BharosaProperty based on passed name/value (key/value) pair
     *
     * @param key key
     * @param value value
     */
    protected void updateProperty(String key, String value) {
        BharosaProperty prop = (BharosaProperty)propMap.get(key);
        if (prop == null) {
            prop = new BharosaProperty(key, value);
            propMap.put(key, prop);
        } else {
            prop.setValue(value);
        }
    }

    /**
     * This copies the contents from the source Map to the destination Map. This methods does the triming of the values
     * before copying it to the destination.
     *
     * @param src  Source file
     * @param dest Destination file.
     */
    protected void load(Map src, Map dest) {
        if (logger.isDebugEnabled())
            logger.debug("load called...");
        synchronized (propMap) {
            Iterator iter = src.keySet().iterator();
            while (iter.hasNext()) {
                String key = (String)iter.next();
                String value = (String)src.get(key);
                dest.put(key.trim(), value.trim());
            }
        }
    }

    /**
     * Be absolutely sure before setting this value. This will override values read from the property file.
     *
     * @param propertyName Name of the property
     * @param value        Value of the property.
     */
    public void setProperty(String propertyName, String value) {
        if (!initDone) {
            init();
        }
        logger.info("setProperty( name=" + propertyName + ", value=" +
                    BharosaProperty.getMaskedValue(propertyName, value) + ")");
        overloadedMap.put(propertyName, value);
        updateProperty(propertyName, value);
        fireReloadListeners();
    }

    /**
     * Sets passed BharosaProperty in the BharosaConfig
     *
     * @param pBharosaProperty
     * @return
     */
    public void setProperty(BharosaProperty pBharosaProperty) {
        if (!initDone) {
            init();
        }
        logger.info("setProperty( BharosaProperty=" + pBharosaProperty);
        if (pBharosaProperty != null) {
            overloadedMap.put(pBharosaProperty.getName(),
                              pBharosaProperty.getValue());
            updateProperty(pBharosaProperty);
            fireReloadListeners();
        }
    }

    /**
     * Removes property
     *
     * @param propertyName Name of the property
     */
    public void removeProperty(String propertyName) {
        if (!initDone) {
            init();
        }
        logger.info("setProperty( name=" + propertyName + " )");
        overloadedMap.remove(propertyName);
        propMap.remove(propertyName);
        fireReloadListeners();
    }

    /**
     * Implementing method needed by FileMonitorCallBack
     */
    public void handleFileModified(File modifiedFile) {
        reload();
    }

    /**
     * Returns flag to state whether property override is supported by this load instance.
     *
     * @return whether property override is supported or not.
     */
    public boolean isPropertyOverrideSupported() {
        return false;
    }

    public int getLoadType() {
        return IBharosaConstants.BHAROSA_CONFIG_LOAD_TYPE_PROPS;
    }
}
