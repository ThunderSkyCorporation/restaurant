package com.bharosa.common.util;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import java.util.TimerTask;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;

import com.bharosa.common.logger.Logger;

/**
 * This class monitors the file and calls the callback
 * method if the file is updated.
 * @author bosco
 */

public class FileMonitor extends TimerTask {
	static Logger  logger = Logger.getLogger(FileMonitor.class);
	static BharosaTimer myTimer = BharosaTimer.getInstance();
	static ArrayList fileList = new ArrayList();

	File file = null;
    String filePath = null;
    long lastModifiedTime = 0;
	boolean isBadFile = false;
	int period = 0;
	FileMonitorCallBack callback = null;
	
	public FileMonitor( File file, FileMonitorCallBack callback, int period ) 
		throws IOException {
		if(logger.isDebugEnabled()) logger.debug("FileMonitor() file=" + file.getAbsolutePath());
		this.file = file;
		this.callback = callback;
		this.period = period;
		if( !file.exists() ) {
			throw new IOException("File " + file.getAbsolutePath()
								  + " doesn't exist");
		}
		lastModifiedTime = file.lastModified();
		if( period > 0 ) {
			if( !fileList.contains( file.getAbsolutePath()) ) {
				myTimer.schedule( this, 0, period );
				fileList.add(file.getAbsolutePath());
                filePath = file.getAbsolutePath();
            } else {
				if(logger.isDebugEnabled()) logger.debug("File " + file.getAbsolutePath()
							 + " is already being monitored");
			}
		} else {
			logger.error("FileMonitor(). file=" + file.getAbsolutePath()
						 + ", period is zero or negative. period=" + period );
		}
	}

	public void run( ) {
		try {
			long modifiedTime = file.lastModified();
			if( modifiedTime != lastModifiedTime ) {
				lastModifiedTime = modifiedTime;
				logger.info("File " + file.getAbsolutePath() + " got modified");
				
				//Call the callback method
				if( callback != null ) {
					callback.handleFileModified( file );
				}
			}
		} catch( Throwable ex ) {
			if( !isBadFile ) {
				logger.error("Caught exception while montoring file. filePath=" + filePath, ex );
				isBadFile = true;
			}
		}
	}
}
