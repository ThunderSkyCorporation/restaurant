package com.bharosa.common.util;
/**
 *This is an implementation of multi-threaded queue. The elements in
 *the queue will be processed by the next free thread. The number of
 *the threads need to be configured at the time of instantiation of
 *the this class.
 *@author Don Bosco Durai
 */

import java.util.LinkedList;
import java.util.TimerTask;
import java.util.Vector;

import com.bharosa.common.logger.Logger;

@Deprecated
/**
 * Deprecated.  Use MTApportioningQueue instead.
 */
public class MTQueue implements Runnable {
    static Logger logger = Logger.getLogger(MTQueue.class);

    private LinkedList quList = new LinkedList();
    private Vector workers = null;
    private GenericCallBack callBackObj = null;
    String queueName = null;
    TimerTask monitor = null;
    long prevCount = 0;
    long sizeTillNow = 0;
    long reportInterval = 0;
    int resetCount = 0;

    public MTQueue(String queueName, GenericCallBack callBackObj) {
        this(queueName, callBackObj, 1);
    }

    public MTQueue(String aQueueName, GenericCallBack callBackObj,
                   int numberOfWorkerThreads) {

        reportInterval = BharosaConfig.getInt("bharosa.common.util.MTQueue.scan.interval.sec", 60);
        reportInterval = reportInterval * 1000;
        this.callBackObj = callBackObj;
        this.queueName = aQueueName;
        if (numberOfWorkerThreads <= 0) {
            logger.fatal(
                  "MTQueue constructer with invalid value. numberOfWorkerThreads="
                        + numberOfWorkerThreads);
            return;
        }
        if (callBackObj == null) {
            logger.fatal(
                  "MTQueue constructer with invalid value. CallBack object is null");
            return;
        }
        workers = new Vector(numberOfWorkerThreads);
        for (int i = 0; i < numberOfWorkerThreads; i++) {
            String threadName = queueName + "_" + i;
            Thread t = new Thread(this, threadName);
            t.setDaemon(true);
            t.start();
            workers.add(t);
        }

        //Lets monitor this queue
        monitor = new TimerTask() {
            long oldQueueCount = sizeTillNow;
            long oldQueueSize = 0;

            public void run() {
                try {
                    long queueSize = quList.size();
                    if (oldQueueCount != sizeTillNow || queueSize > 0
                          || oldQueueSize > 0) {

                        long processedCount = sizeTillNow - oldQueueCount;
                        double perSecond =  (processedCount * 1.0)/ (reportInterval / 1000);

                        logger.info(queueName
                              + ": current queue size=" + queueSize
                              + ", processed " + processedCount + " in "
                              + (reportInterval/1000)
                              + " seconds with per second=" + perSecond
                              + ", total till now=" + sizeTillNow
                              + ", reseted " + resetCount + " times");
                        oldQueueCount = sizeTillNow;
                        oldQueueSize = queueSize;
                    }
                } catch (Exception ex) {
                    logger.error("Caught exception in timer run.", ex);
                }
            }
        };

        BharosaTimer.getInstance().schedule(monitor, 0, reportInterval);
    }

    public synchronized void addItem(Object obj) {
        if (sizeTillNow == Long.MAX_VALUE) {
            sizeTillNow = 0;
            resetCount++;
        }

        sizeTillNow++;
        quList.addLast(obj);
        this.notifyAll();
    }

    public synchronized Object getNextItem() {
        if (quList.size() > 0) {
            try {
                return quList.removeFirst();
            } catch (Throwable t) {
                logger.warn("Error while getting the next item. This error is harmless.", t);
            }
        }
        return null;
    }

    public int size() {
        return quList.size();
    }

    public void run() {
        String threadName = Thread.currentThread().getName();
        try {
            while (true) {
                Object obj = null;
                try {
                    synchronized (this) {
                        if (quList.isEmpty()) {
                            wait();
                            continue;
                        } else {
                            obj = quList.removeFirst();
                        }
                    }
                } catch (Exception e) {
                    logger.warn("Caught exception, but ignored in thread "
                          + threadName + ". Exception=" + e);
                }
                if (obj != null) {
                    try {
                        callBackObj.processRequest(queueName, obj);
                    } catch (Throwable ex) {
                        logger.warn(
                              "Caught exception when executing callback in thread "
                                    + threadName, ex);
                    }
                }
            }
        } catch (Throwable ex) {
            logger.fatal(
                  "Caught exception and exiting thread queue. Thread="
                        + ". Exception=" + ex);
        }
    }
}
