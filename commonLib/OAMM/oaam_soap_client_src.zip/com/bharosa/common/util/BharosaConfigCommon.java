/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
package com.bharosa.common.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.bharosa.common.logger.Logger;


/**
 * 
 * @author kuldeep <kuldeep@bharosa.com>
 * Date: Jul 11, 2007
 * Time: 2:23:58 PM
 *
 */
public class BharosaConfigCommon {

    private Logger logger = Logger.getLogger(BharosaConfigCommon.class);

    //List of listeners who are interested in property file changes.
    private List reloadListeners = new ArrayList();
    
    protected static String PROP_CLIENT_CIPHER_KEY = "bharosa.cipher.client.key";

    static public long lastUpdateTime = System.currentTimeMillis();
    protected void fireReloadListeners() {
        lastUpdateTime = System.currentTimeMillis();

        //Fire all the listeners for config changes
        Iterator itr = reloadListeners.iterator();
        while (itr.hasNext()) {
            if (logger.isDebugEnabled()) logger.debug("Calling configReloaded( ) for ");
            BharosaConfigReloadListener reloadListener = (BharosaConfigReloadListener) itr.next();
            reloadListener.configReloaded();
        }
    }
    
    /**
     * This method is used to register a callback, which is called everytime the property file is reloaded.
     *
     * @param reloadListener An instance of BharosaConfigReloadListener is required.
     */
    public void registerReloadCallback(BharosaConfigReloadListener reloadListener) {
        if (logger.isDebugEnabled()) logger.debug("registerReloadCallback enter...");
        reloadListeners.add(reloadListener);
    }

    /**
     * This method is used to remove a Config reload callback.
     *
     * @param reloadListener An instance of BharosaConfigReloadListener is required.
     */
    public void removeReloadCallback(BharosaConfigReloadListener reloadListener) {
        if (logger.isDebugEnabled()) logger.debug("removeReloadCallback enter...");
        reloadListeners.remove(reloadListener);
    }

	public void configReloaded() {
		if (logger.isDebugEnabled()) logger.debug("configReloaded") ;
		fireReloadListeners() ;
	}
   
}
