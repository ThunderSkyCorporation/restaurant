package com.bharosa.common.util;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * Holder class for property
 * User: bosco
 */

import com.bharosa.common.logger.Logger;

import java.io.Serializable;

import java.util.Arrays;
import java.util.List;


public class BharosaProperty implements Serializable {

    static Logger logger = Logger.getLogger(BharosaProperty.class);
    static List<String> maskPropertyKeywordList  = Arrays.asList(new String[]{"password","passwd"}); // lower case keywords

    String name;
    String value;
    boolean encrypted = false ;
    int configType;
    String description;
    String notes;
    int loadType = IBharosaConstants.BHAROSA_CONFIG_LOAD_TYPE_PROPS;
    
    Boolean boolValue = null;
    Long longValue = null;
    Integer intValue = null;
    Float floatValue = null;


    public BharosaProperty(String name, String value) {
    	this(name, value, 0, false, null, null, IBharosaConstants.BHAROSA_CONFIG_LOAD_TYPE_PROPS) ;
    } 

    public BharosaProperty(String name, String value, int loadType) {
    	this(name, value, 0, false, null, null, loadType) ;
    } 

    public BharosaProperty(String name, String value, 
    			int configType, boolean encrypted, 
    			String description, String notes, 
    			int loadType) {
    	this.name = name;
      this.value = value;
    	this.configType = configType ;
    	this.encrypted = encrypted ;
    	this.description = description ;
    	this.notes = notes ;
    	this.loadType = loadType ;
      resetAll();
    }

    public String getName() {
        return name;
    }

    void setName(String name) {
    	// if (logger.isDebugEnabled()) logger.debug("setName : [" + name + "]") ; 
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    void setValue(String value) {
    	// if (logger.isDebugEnabled()) logger.debug("setValue : [" + value + "]") ;
        this.value = value;
        resetAll();
    }

    public boolean isEncrypted() {
    	return encrypted ;
    }

	public void setEncrypted(boolean encrypted) {
		// if (logger.isDebugEnabled()) logger.debug("setEncrypted : [" + encrypted + "]") ;
		this.encrypted = encrypted;
	}

	public int getConfigType() {
		return configType;
	}

	public void setConfigType(int configType) {
		// if (logger.isDebugEnabled()) logger.debug("setConfigType : [" + configType + "]") ;
		this.configType = configType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		// if (logger.isDebugEnabled()) logger.debug("setDescription : [" + description + "]") ;
		this.description = description;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		// if (logger.isDebugEnabled()) logger.debug("setNotes : [" + notes + "]") ;
		this.notes = notes;
	}

	public int getLoadType() {
		return loadType;
	}

	public void setLoadType(int loadType) {
		this.loadType = loadType;
	}

	void resetAll() {
        boolValue = null;
        longValue = null;
        intValue = null;
        floatValue = null;

    }
    
	public String getString( ) {
        return value;
    }

    public String getString( String defaultValue ) {
        if( StringUtil.isEmpty(value)) {
            return defaultValue;
        }
        return value;
    }

    boolean getBoolean(boolean defaultValue) {
        if (boolValue == null) {
            boolValue = parseBoolean(value);
        }
        if (boolValue != null) {
            return boolValue.booleanValue();
        }
        return defaultValue;
    }

    int getInt(int defaultValue) {
        try {
            if (intValue == null) {
                intValue = new Integer(value);
            }
        } catch (Exception ex) {
            logger.error("Error parsing propertyName=" +
                    name + ", propertyValue="
                    + value, ex);
        }
        if (intValue != null) {
            return intValue.intValue();
        }
        return defaultValue;
    }

    long getLong(long defaultValue) {
        try {
            if (longValue == null) {
                longValue = new Long(value);
            }
        } catch (Exception ex) {
            logger.error("Error parsing propertyName=" +
                    name + ", propertyValue="
                    + value, ex);
        }
        if (longValue != null) {
            return longValue.longValue();
        }
        return defaultValue;
    }

    float getFloat(float defaultValue) {
        try {
            if (floatValue == null) {
                floatValue = new Float(value);
            }
        } catch (Exception ex) {
            logger.error("Error parsing propertyName=" +
                    name + ", propertyValue=" + getMaskedValue(name, value), ex);
        }
        if (floatValue != null) {
            return floatValue.floatValue();
        }
        return defaultValue;
    }

    public String toString() {
        return "BharosaProperty{" +
                "name='" + name + "'" +
                ", value='" + getMaskedValue(name, value) + "'" +
                ", configType='" + configType + "'" +
                ", loadType='" + loadType + "'" +
                ", encrypted='" + encrypted + "'" +
                ", description='" + description + "'" +
                ", notes='" + notes + "'" +
                "}";
    }

    private Boolean parseBoolean(String value) {
        if (StringUtil.isEmpty(value)) {
            return null;
        }
        value = value.trim();

        if (value.equalsIgnoreCase("true") || value.equals("1") || value.equalsIgnoreCase("yes")) {
            return Boolean.TRUE;
        } else if (value.equalsIgnoreCase("false") || value.equals("0") || value.equalsIgnoreCase("no")) {
            return Boolean.FALSE;
        } else {
            logger.error("Invalid value passed for boolean. name=" + name
                    + ", value=" + getMaskedValue(name, value), new Throwable().fillInStackTrace());
            return null;
        }
    }
    
    static String getMaskedValue(String propertyName, String value) {
        if ( propertyName != null && value != null) {
            String propertyNameLowerCase = propertyName.toLowerCase();
            for (String keyword : maskPropertyKeywordList) {
              if (propertyNameLowerCase.contains(keyword))
                return "length="+value.length();
            }
        }
        return value;
    }

}
