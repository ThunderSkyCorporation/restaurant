/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */
package com.bharosa.common.util;

import com.bharosa.common.logger.Logger;


import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 
 * @author kuldeep <kuldeep@bharosa.com>
 * Date: Jul 15, 2007
 * Time: 12:18:35 PM
 *
 */
public abstract class BharosaConfigLoadCommonImpl extends BharosaConfigCommon  
	implements BharosaConfigReloadListener {

	private Logger logger = Logger.getLogger(BharosaConfigLoadCommonImpl.class) ;
	
    protected boolean initDone = false;
    //protected final Map propMap = Collections.synchronizedMap(new HashMap());
	protected final Map propMap = new ConcurrentHashMap();
    //protected final Map overloadedMap = Collections.synchronizedMap(new HashMap());
	protected final Map overloadedMap = new ConcurrentHashMap();

	// Lets keep it protected so that it can be instantiated only from this package and sub-classes.
    protected BharosaConfigLoadCommonImpl() {
    	if (logger.isDebugEnabled()) logger.debug("Constructing BharosaConfigLoadCommonImpl...") ;
		// Nothing to be done for now.
	}

    /**
     * This initializes this class and loads all the properties. 
     * It is internally called when the first time any properties is requested.
     * 
     */
    public void init() {

    	if (logger.isDebugEnabled()) logger.debug("Initializing ...");
    	if (initDone) {
    		if (logger.isDebugEnabled()) logger.debug("Initializing already done while sleeping.");
    		return;
    	}
    	if (logger.isDebugEnabled()) logger.debug("Initializing object...");
    	reload_nolock();
    	initDone = true;
    }
	
    public void decryptProperties() {
    	// Get key used by client encryption
        String cipherKey = getPropertyValue(PROP_CLIENT_CIPHER_KEY);
        if (StringUtil.isEmpty(cipherKey)) {
        	cipherKey = "" ;
        }
    	decryptProperties(propMap, cipherKey) ;
    }

    /**
     * Decrypt any encrypted properties.
     *
     * @param map             Map of properties to be decrypted
     * @param customCipherKey Key, is there are any custom properties. This is optional. <code>bharosa.cipher.key.custom</code>
     *                        property needs to be set if custom cipher is used.
     */
    protected void decryptProperties(Map map, String customCipherKey) {
        try {

            BharosaCipher systemCipher = BharosaCipher.getSystemCipher();
            decryptProperties(map, systemCipher);

            if (!StringUtil.isEmpty(customCipherKey)) {
                if (logger.isDebugEnabled()) logger.debug("Using custom Cipher");
                BharosaCipher customCipher = BharosaCipher.getSystemCipher(customCipherKey);
                decryptProperties(map, customCipher);
            }
        } catch (Exception e) {
            logger.warn("Error with encrypted properties", e);
        }

    } // decryptProperties

    /**
     * Decrypt any encrypeted properties using specified cipher
     *
     * @param map    Map of properties to be decrypted.
     * @param cipher BharosaCipher Cipher to use
     */
    protected void decryptProperties(Map map, BharosaCipher cipher) {
		synchronized (propMap) {
			Iterator itr = map.keySet().iterator();
			while (itr.hasNext()) {
				String property = (String) itr.next();
				Object valueObj = map.get(property);
				if (valueObj instanceof String) {
					String value = (String) valueObj;
					String decryptedValue = cipher.decrypt(value);
					if (!value.equals(decryptedValue)) {
						if (logger.isDebugEnabled())
							logger.debug("Dectypt. Org=" + value + " Decrypt="
									+ decryptedValue);
					}
					map.put(property, decryptedValue);
				} else if (valueObj instanceof BharosaProperty) {
					BharosaProperty bhProp = (BharosaProperty) valueObj;
					String value = bhProp.getValue();
					String decryptedValue = cipher.decrypt(value);
					if (!value.equals(decryptedValue)) {
						if (logger.isDebugEnabled())
							logger.debug("Dectypt. Org=" + value + " Decrypt="
									+ decryptedValue);
					}
					bhProp.setValue(decryptedValue);
				}
			}

		}
	}
    
    /**
	 * Adds property to Map
	 * 
	 * @param pProperty
	 *            property
	 */
    public void addProperty(BharosaProperty pProperty) {
        propMap.put(pProperty.getName(), pProperty);


    }
    	
    /**
     * Returns the hashMap of the properties. Don't misuse it.
     *
     * @return HashMap of the properties.
     */
    public Map getMap() {
        if (!initDone) {
            init();
        }
        return propMap;
    }

    public String getPropertyValue(String name) {
        if (!initDone) {
            init();
        }
        BharosaProperty prop = (BharosaProperty) propMap.get(name);
        if (prop != null) {
            return prop.getValue();
        }
        return null;
    }

    public BharosaProperty getProperty(String name) {
        if (!initDone) {
            init();
        }
        return (BharosaProperty) propMap.get(name);
    }


    /**
     * This method returns all the properties with the given value
     * @param value of the property
     * @return List of property name strings
     */
    public List getPropertyNames( String value ) {
        if(!initDone) {
            init();
        }
        List list = new ArrayList();
        Iterator iter = propMap.values().iterator();
        while(iter.hasNext()) {
            BharosaProperty prop = (BharosaProperty)iter.next();
            if(prop.getValue().equals(value)) {
                list.add(prop.getName());
            }
        }
        return list;
    }

    abstract protected void reload_nolock() ;

    protected void updateSystemProps() {
        BharosaProperty sysPropList = (BharosaProperty)propMap.get("bharosa.config.updatesysproplist");
        if (sysPropList != null && !StringUtil.isEmpty(sysPropList.getString())) {
            String csvList = sysPropList.getString().trim(); 
            String[] keys = StringUtil.splitCSV(csvList);
            for (int i = 0; i < keys.length; i++) {
                String key = keys[i];
                if (!StringUtil.isEmpty(key)) {
                    key = key.trim();
                    BharosaProperty value = (BharosaProperty)propMap.get(key);
                    if (value != null && value.getString() != null)
                        System.setProperty(key, value.getString());
                }
            }
        }
    }
    
    protected void loadSystemProperties(Map pSysPropsMap) {

        if (pSysPropsMap == null)
            return;

        if (logger.isInfoEnabled())
            logger.info("loadSystemProperties(): Updating global Map [" + pSysPropsMap + "] Size [" + pSysPropsMap.size() + "]");
        
        synchronized (propMap) {
    		Iterator iter = pSysPropsMap.keySet().iterator();
    		while (iter.hasNext()) {
    			String key = (String) iter.next();
    			Object value = pSysPropsMap.get(key);
    			if (value != null) {
    				updateSystemProperty(key, value.toString());
    			}
    		}
    	}
    }

    /**
     * Creates/Updates BharosaProperty based on passed name/value (key/value) pair
     *  
     * @param key key
     * @param value value
     */
    protected void updateSystemProperty(String key, String value) {
    	if (logger.isDebugEnabled()) 
    		logger.debug("updateSystemProperty :"
    				+ " key [" + key + "]"
    				+ " value [" + value + "]") ;
    	BharosaProperty prop = (BharosaProperty) propMap.get(key);
    	if (prop == null) {
    		prop = new BharosaProperty(key, value, 
    				IBharosaConstants.BHAROSA_CONFIG_LOAD_TYPE_SYSTEM);
    		propMap.put(key, prop);
    	} else { 
    		prop.setValue(value);
    		prop.setLoadType(IBharosaConstants.BHAROSA_CONFIG_LOAD_TYPE_SYSTEM);
    	}
    }
    
    /**
     * Creates/Updates BharosaProperty 
     *  
     * @param BharosaProperty
     */
    protected void updateProperty(BharosaProperty pBharosaProperty) {
    	if (logger.isDebugEnabled()) 
    		logger.debug("updateProperty :"
    				+ " BharosaProperty [" + pBharosaProperty + "]") ;
    	if ( (pBharosaProperty != null) && (! StringUtil.isEmpty(pBharosaProperty.getName())) ) {
        	pBharosaProperty.setLoadType(getLoadType());
            propMap.put(pBharosaProperty.getName(), pBharosaProperty);
    	}
    }
    
	/**
	 * Returns loadType (int) associated with this instance of BharosaConfigLoad 
	 * 
	 * @return
	 */
	abstract public int getLoadType();

}
