/* $Header: oaam/apps/oaam_core/src/com/bharosa/common/util/CSVReader.java /main/2 2010/04/29 08:02:11 jpdavis Exp $ */

/* Copyright (c) 2009, 2010, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jpdavis     09/25/09 - Creation
 */

/**
 *  @version $Header: oaam/apps/oaam_core/src/com/bharosa/common/util/CSVReader.java /main/2 2010/04/29 08:02:11 jpdavis Exp $
 *  @author  jpdavis 
 *  @since   release specific (what release of product did this appear in)
 */

package com.bharosa.common.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public class CSVReader {
	char delimiter = ',';
	char quote = '"';
	BufferedReader reader;
	
	public CSVReader(Reader aReader) {
		super();
		if (aReader instanceof BufferedReader) {
			reader = (BufferedReader) aReader;
		} else {
			reader = new BufferedReader(aReader);
		}
	}

	public CSVReader(Reader reader, char delimiter) {
		this(reader);
		this.delimiter = delimiter;
	}

	public CSVReader(Reader reader, char delimiter, char quote) {
		this(reader);
		this.delimiter = delimiter;
		this.quote = quote;
	}
	
	public String[] readNext() throws IOException {
		String nextLine = reader.readLine();
		if (nextLine == null) return null;
		if (nextLine.length() == 0) return new String[0];

		ParserContext context = new ParserContext(nextLine);
		for (ParserState state = ParserState.NEXT_TOKEN; state != ParserState.END; state = state.nextState(context));
		List<String> tokenList = context.getTokens();
		return tokenList.toArray(new String[tokenList.size()]);
	}
	public void close() throws IOException {
		reader.close();
	}

	class ParserContext {
		public static final char INVALID = '\uFFFF';
		List<String> tokens = new ArrayList<String>();
		StringBuilder token = new StringBuilder();
		String nextLine;
		int charIndex;
		
		public ParserContext(String nextLine) {
			super();
			this.nextLine = nextLine;
		}	
		public List<String> getTokens() {
			return tokens;
		}
		public char getCurrentChar() {
			return getChar(charIndex);
		}
		public char getNextChar() {
			return getChar(charIndex +1);
		}
		public void increment() {
			charIndex++;
		}
		char getChar(int index) {
			if (index < 0 || index >= nextLine.length()) {
				return INVALID;
			}
			return nextLine.charAt(index);
		}
		public boolean isQuote() {
			return getCurrentChar() == quote;
		}
		public boolean isDelimiter() {
			return getCurrentChar() == delimiter;
		}
		public boolean isEndQuote() {
			return getCurrentChar() == quote && (getNextChar() == delimiter || getNextChar() == INVALID);
		}
		public boolean isEnd() {
			return getCurrentChar() == INVALID;
		}
		public void closeToken() {
			tokens.add(token.toString().trim());
			if (token.length() > 0) token.delete(0, token.length());
		}
		public void addCurrentCharToToken() {
			token.append(getCurrentChar());
		}
		@Override
		public String toString() {
			return "CurrentToken=\"" + token + "\", CurrentChar='" + getCurrentChar() + "', index="+charIndex +", tokenCount="+tokens.size() +", line="+nextLine;
		}
	}
	
	enum ParserState {
		NEXT_TOKEN {
			@Override
			public ParserState nextState(ParserContext context) {
				if (context.isDelimiter()) {
					context.closeToken();
					context.increment();
					return NEXT_TOKEN;
				}
				if (context.isQuote()) {
					context.increment();
					return QUOTED_TOKEN;
				}
				if (context.isEnd()) {
					context.closeToken();
					return END;
				}
				return NAKED_TOKEN;
			}
		},
		NAKED_TOKEN {
			@Override
			public ParserState nextState(ParserContext context) {
				if (context.isDelimiter()) {
					context.closeToken();
					context.increment();
					return NEXT_TOKEN;
				}
				if (context.isEnd()) {
					context.closeToken();
					return END;
				}
				context.addCurrentCharToToken();
				context.increment();
				return NAKED_TOKEN;
			}
		},
		QUOTED_TOKEN {
			@Override
			public ParserState nextState(ParserContext context) {
				if (context.isEndQuote()) {
					context.closeToken();
					context.increment();
					if (context.isEnd()) {
						return END;
					}
					context.increment();
					return NEXT_TOKEN;
				}
				if (context.isEnd()) {
					context.closeToken();
					return END;
				}
				context.addCurrentCharToToken();
				context.increment();
				return QUOTED_TOKEN;
			}
		},
		END {
			@Override
			public ParserState nextState(ParserContext context) {
				return END;
			}
		};
		protected abstract ParserState nextState(ParserContext context);
	}
}