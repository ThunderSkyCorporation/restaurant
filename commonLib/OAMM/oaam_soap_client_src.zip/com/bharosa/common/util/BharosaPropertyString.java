package com.bharosa.common.util;
/*
 * Copyright (c) 2007 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

/**
 * This class encapsulates a single property. It automatically updates the value when the property is updated.
 * User: bosco
 */

import com.bharosa.common.logger.Logger;

public class BharosaPropertyString extends BharosaPropertyBase {
    static Logger logger = Logger.getLogger(BharosaPropertyString.class);

    String defaultValue;

    public BharosaPropertyString(String name, String defaultValue) {
        super(name);
        this.defaultValue = defaultValue;
    }

    public String getValue() {
        if (getBharosaProperty() == null) {
            return defaultValue;
        }
        return getBharosaProperty().getString(defaultValue);
    }

    public String toString() {
        return getValue();
    }
}
