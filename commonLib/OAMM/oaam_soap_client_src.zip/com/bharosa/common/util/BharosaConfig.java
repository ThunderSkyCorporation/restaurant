package com.bharosa.common.util;
/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */


import com.bharosa.common.logger.Logger;

import java.io.File;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

import java.net.InetAddress;
import java.net.UnknownHostException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;


public class BharosaConfig extends BharosaConfigCommon
        implements BharosaConfigReloadListener, FileMonitorCallBack {

    private static Logger logger = Logger.getLogger(BharosaConfig.class);

    private static BharosaConfig thisInstance = null;
    private static boolean initDone = false;
    private BharosaConfigIntf config = null;
    private BharosaConfigIntf instantiatedConfig = null;
    private boolean configInitDone = false;
    private boolean configInitInProgress = false;

    private BharosaConfigIntf fallbackConfig = null;
    private boolean fallbackConfigInitDone = false;
    public static final String SERVER = resolveHostname();

    public static final String APP_PROP_BASE = "bharosa.uio.";
    public static final String DEFAULT_APPID = "default";
    public static final String DEFAULT_APP_PROP_BASE = "bharosa.uio." + DEFAULT_APPID + ".";
    private static UserDefEnum loadTypeEnum = UserDefEnum.getEnum(IBharosaConstants.ENUM_BHAROSA_CONFIG_LOAD_TYPE);

  private static String resolveHostname() {
        try {
            return InetAddress.getLocalHost().toString();
        } catch (UnknownHostException ex) {
            return "localhost";
        }
    }

    private BharosaConfig() {
        if (logger.isDebugEnabled()) logger.debug("Constructing ...");
        fallbackConfig = new BharosaConfigPropsImpl(new BharosaConfigLoadPropsImpl());
    }

    /**
     * This initializes this class and loads all the properties. It is internally called when the first time any
     * properties is requested.
     */
    private synchronized static void init() {
        try {
            logger.info("Starting Initialization of BharosaConfig..."
                    + " hashCode [" + (BharosaConfig.class).hashCode() + "]"
                    + " initDone [" + initDone + "]"
                    + " current thisInstance [" + thisInstance + "]");
            if (thisInstance == null) {
                thisInstance = new BharosaConfig();
            }
            // Initialize Fallback BharosaConfigIntf
            if (logger.isDebugEnabled())
                logger.debug("Initializing ... Fallback BharosaConfig"
                        + " Initialization would be done if it is not yet initialized"
                        + " fallbackConfigInitDone [" + thisInstance.fallbackConfigInitDone + "]");
            if (!thisInstance.fallbackConfigInitDone) {
                if (logger.isDebugEnabled())
                    logger.debug("Initializing ... Fallback BharosaConfig"
                            + " is not yet initialized"
                            + " So now, invoking init() on [" + thisInstance.fallbackConfig + "]");
                thisInstance.fallbackConfig.init();
                thisInstance.fallbackConfigInitDone = true;
                // Register the reload listener to Config
                thisInstance.fallbackConfig.registerReloadCallback(thisInstance);
            }

            // Initialize BharosaConfigIntf
            if (logger.isDebugEnabled())
                logger.debug("Initializing ... BharosaConfig"
                        + " Initialization would be done if it is not yet initialized"
                        + " configInitDone [" + thisInstance.configInitDone + "]"
                        + " configInitInProgress [" + thisInstance.configInitInProgress + "]");
            if ((!thisInstance.configInitDone) && (!thisInstance.configInitInProgress)) {
                final BharosaConfigIntf lConfig = thisInstance.instanceConfig(thisInstance.fallbackConfig);
                if (lConfig != null) {
                    if (logger.isDebugEnabled())
                        logger.debug("Initializing ... BharosaConfig"
                                + " Lets Initialize Config object [" + lConfig + "]"
                                + " initDone [" + initDone + "]"
                                + " configInitDone [" + thisInstance.configInitDone + "]"
                                + " configInitInProgress [" + thisInstance.configInitInProgress + "]");
                    // If Config and fallbackConfig both are same then
                    // use fallbackConfig as config.
                    if (lConfig.getClass().getName().equals(thisInstance.fallbackConfig.getClass().getName())) {
                        if (logger.isDebugEnabled())
                            logger.debug("Initializing ... BharosaConfig"
                                    + " Config and fallbackConfig both are same."
                                    + " So using fallbackConfig as main config.");
                        thisInstance.config = thisInstance.fallbackConfig;
                        thisInstance.configInitDone = true;
                        initDone = true;
                    } else {
                        // Lets use the fallback config
                        // upto the time main config is not initialized.
                        thisInstance.config = thisInstance.fallbackConfig;
                        thisInstance.configInitInProgress = true;
                        initDone = true;
                        try {
                            lConfig.init();
                            thisInstance.config = lConfig;
                            // Register the reload listener to Config
                            thisInstance.config.registerReloadCallback(thisInstance);
                            thisInstance.configInitDone = true;
                            initDone = true;
                            logger.info("BharosaConfig configInitDone [" + thisInstance.configInitDone + "]"
                                    + " config [" + thisInstance.config + "]");
                        } catch (Exception e) {
                            logger.fatal("Could not initialize config.", e);
                            thisInstance.configInitInProgress = false;
                            // Init of main config got failed
                            // lets not change the configInitDone and initDone
                            // to use fallback config as main config.
                            // thisInstance.configInitDone = false ;
                            // initDone = false ;
                        }
                    }
                } else {
                    // Lets use fallback config as main config
                    // because construction of main Config is failed
                    thisInstance.config = thisInstance.fallbackConfig;
                    thisInstance.configInitDone = true;
                    initDone = true;
                }
                if (logger.isDebugEnabled())
                    logger.debug("Initializing ... BharosaConfig"
                            + " Initialization End..."
                            + " initDone [" + initDone + "]"
                            + " configInitDone [" + thisInstance.configInitDone + "]"
                            + " config [" + thisInstance.config + "]");
            }

            // Decrypt all erypted properties
            thisInstance.decryptProperties(thisInstance.fallbackConfig, thisInstance.config);

            // Monitor resource bundles for changes
            thisInstance.monitorResourceBundles();

            logger.debug("Finished Initialization of BharosaConfig...");
        } catch (Throwable t) {
            logger.error("Error while initializing BharosaConfig", t);
        }
    }

    private BharosaConfigIntf instanceConfig(BharosaConfigIntf pConfig) {
        if (logger.isDebugEnabled())
            logger.debug("instanceConfig :");
        if (instantiatedConfig == null) {
            try {
                String bharosaConfigClassName = pConfig.get(
                        "bharosa.config.impl.classname",
                        "com.bharosa.common.util.BharosaConfigPropsImpl");
                String bharosaConfigLoadClassName = pConfig.get(
                        "bharosa.config.load.impl.classname",
                        "com.bharosa.common.util.BharosaConfigLoadPropsImpl");
                if (logger.isDebugEnabled())
                    logger.debug("instanceConfig :"
                            + " bharosaConfigClassName [" + bharosaConfigClassName + "]"
                            + " bharosaConfigLoadClassName [" + bharosaConfigLoadClassName + "]");
                BharosaConfigLoadIntf lConfigLoad = (BharosaConfigLoadIntf) Class
                        .forName(bharosaConfigLoadClassName).newInstance();
                Constructor lConfigConst = Class
                        .forName(bharosaConfigClassName).getConstructor(
                        new Class[]{BharosaConfigLoadIntf.class});
                instantiatedConfig = (BharosaConfigIntf) lConfigConst.newInstance(new Object[]{lConfigLoad});
            } catch (Exception e) {
                logger.error("Could not instantiate the configured config classes", e);
            }
        }
        if (logger.isDebugEnabled())
            logger.debug("instanceConfig :"
                    + " Returning Config Object [" + instantiatedConfig + "]");
        return instantiatedConfig;
    }

    static void forceFireReloadListeners() {
        if (!initDone) return;
        thisInstance.fireReloadListeners();
    }

    public void configReloaded() {
        if (logger.isDebugEnabled()) logger.debug("configReloaded");
        fireReloadListeners();
        logger.info("Configuration files reloaded. OAAM Version=" + getProperty("bharosa.software.version"));
    }

    /**
     * This method is used to register a callback, which is called everytime the property file is reloaded.
     *
     * @param reloadListener An instance of BharosaConfigReloadListener is required.
     */
    public static void registerReloadListener(BharosaConfigReloadListener reloadListener) {
        if (logger.isDebugEnabled()) logger.debug("registerReloadCallback enter...:"
                + " reloadListener[" + reloadListener + "]");
        if (!initDone) {
            init();
        }
        thisInstance.registerReloadCallback(reloadListener);
    }

    public static BharosaProperty getProperty(String name) {
        if (!initDone) {
            init();
        }
        BharosaProperty retProp = thisInstance.config.getProperty(name);
        if (retProp == null) {
            retProp = thisInstance.fallbackConfig.getProperty(name);
            // If Property is available in fallback config
            // then lets copy that to main config.
/*            if (retProp != null) {
                thisInstance.config.addProperty(retProp);
            }*/
        }
        return retProp;
    }

    static String getPropertyValue(String name) {
        if (!initDone) {
            init();
        }
        String retPropValue = thisInstance.config.getPropertyValue(name);
        if (retPropValue == null) {
            retPropValue = thisInstance.fallbackConfig.getPropertyValue(name);
        }
        return retPropValue;
    }

    /**
     * Be absolutely sure *ra_dbefore setting this value. This will override values read from the property file.
     *
     * @param propertyName Name of the property
     * @param value        Value of the property.
     */
    static public void setProperty(String propertyName, String value) {
        if (!initDone) {
            init();
        }
        if (!StringUtil.isEmpty(propertyName)) {
          BharosaProperty prop = getProperty(propertyName);
        
          if (prop !=null 
            && (!isUpdateAllowed(prop.getLoadType()) )
           ) {
           logger.warn("Trying to modify the property which is not modifyable=" + prop);
          }
        }
        if (logger.isInfoEnabled())
          logger.info("setProperty( name=" + propertyName + ", value=" + BharosaProperty.getMaskedValue(propertyName, value) + ")");
        thisInstance.config.setProperty(propertyName, value);
    }

    /**
     * Sets passed BharosaProperty in the BharosaConfig
     *
     * @param pBharosaProperty
     * @return
     */
    public static void setProperty(BharosaProperty pBharosaProperty) {
        BharosaProperty lBharosaProperty = null;
        if (pBharosaProperty != null) {
            lBharosaProperty = pBharosaProperty;
            thisInstance.config.setProperty(lBharosaProperty);
        }
    }

    /**
     * Be absolutely sure before setting this value. This will override values read from the property file.
     *
     * @param propertyName Name of the property
     */
    static public void removeProperty(String propertyName) {
        if (!initDone) {
            init();
        }
        if (!StringUtil.isEmpty(propertyName)) {
          BharosaProperty prop = getProperty(propertyName);
          
          if (prop !=null 
              && (!isDeleteAllowed(prop.getLoadType()) )
             ) {
            logger.warn("removeProperty(): Trying to delete the property which is not deletable=" + prop);
          }
        }
        if (logger.isDebugEnabled()) logger.debug("removeProperty( name=" + propertyName + " )");
        thisInstance.config.removeProperty(propertyName);
    }

    /**
     * Describe <code>getValue</code> method here.
     * <p/>
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index0_value value to be inserted at index 0
     * @param index1_value value to be inserted at index 1
     * @param index2_value value to be inserted at index 2
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    static public String getValue(String propertyName, String index0_value,
                                  String index1_value, String index2_value) {
        if (!initDone) {
            init();
        }
        String retValue =
                thisInstance.config.getValue(propertyName, index0_value, index1_value, index2_value);
        if (StringUtil.isEmpty(retValue)) {
            retValue =
                    thisInstance.fallbackConfig.getValue(propertyName, index0_value, index1_value, index2_value);
        }
        return retValue;
    }

    /**
     * Describe <code>getValue</code> method here.
     * <p/>
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index0_value value to be inserted at index 0
     * @param index1_value value to be inserted at index 1
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    static public String getValue(String propertyName, String index0_value,
                                  String index1_value) {
        if (!initDone) {
            init();
        }
        String retValue = thisInstance.config.getValue(propertyName, index0_value, index1_value);
        if (StringUtil.isEmpty(retValue)) {
            retValue = thisInstance.fallbackConfig.getValue(propertyName, index0_value, index1_value);
        }
        return retValue;
    }

    /**
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index0_value value to be inserted at index 0
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    static public String getValue(String propertyName, String index0_value) {
        return insertValue(get(propertyName), index0_value, 0);
    }

    /**
     * This return the localized property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index0_value value to be inserted at index 0
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    static public String getLocalizedValue(String propertyName, String index0_value) {
        return insertValue(getLocalized(propertyName), index0_value, 0);
    }

    /**
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index_values to be inserted
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    static public String getValue(String propertyName, Object[] index_values) {
        return insertValues(get(propertyName), index_values);
    }

    /**
     * This return the localized property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param index_values to be inserted
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    static public String getLocalizedValue(String propertyName, Object[] index_values) {
        String retValue = getLocalized(propertyName);
        retValue = insertValues(retValue, index_values);
        return retValue;
    }

    /**
     * insert values in the property_value at the index 0
     *
     * @param propertyValue a <code>String</code> value
     * @param indexVal      a <code>String</code> value
     * @return a <code>String</code> value
     */
    static public String insertValue(String propertyValue, String indexVal) {
        return insertValue(propertyValue, indexVal, 0);
    }

    /**
     * insert values in the property_value at the index placeholders
     *
     * @param propertyValue a <code>String</code> value
     * @param indexVal      a <code>String</code> value
     * @param index         an <code>int</code> value
     * @return a <code>String</code> value
     */
    static public String insertValue(String propertyValue, String indexVal, int index) {
        if (!initDone) {
            init();
        }
        // Replace over escaping in translations to avoid extra ' in strings.
        String tmpPropertyValue = propertyValue != null ? propertyValue.replaceAll("''", "'") : null;
        String retValue = thisInstance.config.insertValue(tmpPropertyValue, indexVal, index);
        if (StringUtil.isEmpty(retValue)) {
            retValue = thisInstance.fallbackConfig.insertValue(tmpPropertyValue, indexVal, index);
        }
        return retValue;
    }

    /**
     * insert values in the property_value at the index placeholders
     *
     * @param propertyValue a <code>String</code> value
     * @param index_values  to be inserted
     * @return a <code>String</code> value
     */
    static public String insertValues(String propertyValue, Object[] index_values) {
        String retValue = propertyValue;
        try {
            if (index_values != null) {
                for (int i = 0; i < index_values.length; i++) {
                    retValue = insertValue(retValue, "" + index_values[i], i);
                }
            }
        } catch (Exception e) {
            logger.error("Error in insertValue", e);
        }
        return retValue;
    }

    /**
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    static public String get(String propertyName) {
//    	if (logger.isDebugEnabled()) 
//    		logger.debug("get : propertyName [" + propertyName + "]");
        return getPropertyValue(propertyName);
    }

    /**
     * This return the property value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param defaultValue Default value to return if the property is not found.
     * @return Return the String value of the given property name. It returns null if the property is not found.
     */
    static public String get(String propertyName, String defaultValue) {
        if (!initDone) {
            init();
        }
        BharosaProperty lBhProp = thisInstance.config.getProperty(propertyName);
        String retValue = defaultValue;
        if (lBhProp == null) {
            lBhProp = thisInstance.fallbackConfig.getProperty(propertyName);
        }
        if (lBhProp != null) {
            retValue = lBhProp.getString(defaultValue);
        }
        return retValue;
    }

    /**
     * Returns the localized value for the property name, using the
     * <b>current</b> locale and <b>default</b> bundle name.
     *
     * @param propertyName
     */
    public static String getLocalized(String propertyName) {
        return loopThroughBundles(propertyName, BharosaLocale.getCurrentLocale(), null);
    }

    public static String getLocalized(String propertyName, String defaultValue) {
        //Fix for scenarios where propertyName is passed as NULL because the related RBKey could be NULL
        if (StringUtil.isEmpty(propertyName))
            return defaultValue;

        return loopThroughBundles(propertyName, BharosaLocale.getCurrentLocale(), defaultValue);
    }

    public static int getLocalizedInt(String propertyName, int defaultValue) {
        //Fix for scenarios where propertyName is passed as NULL because the related RBKey could be NULL
        if (StringUtil.isEmpty(propertyName))
            return defaultValue;

        String value = loopThroughBundles(propertyName, BharosaLocale.getCurrentLocale(), null);

        return parseIntValueOrDefault(value, defaultValue);
    }

    public static boolean getLocalizedBoolean(String propertyName, boolean defaultValue) {
        //Fix for scenarios where propertyName is passed as NULL because the related RBKey could be NULL
        if (StringUtil.isEmpty(propertyName))
            return defaultValue;

        String value = loopThroughBundles(propertyName, BharosaLocale.getCurrentLocale(), null);

        return parseBooleanValueOrDefault(value, defaultValue);
    }

    /**
     * Returns the localized value for the property name, using the
     * <b>specified</b> locale and <b>default</b> bundle name.
     *
     * @param propertyName
     * @param aLocale
     */
    public static String getLocalizedFromLocale(String propertyName, Locale aLocale) {
        return loopThroughBundles(propertyName, aLocale, null);
    }

    public static String getLocalizedFromLocale(String propertyName, Locale aLocale, String defaultValue) {
        //Fix for scenarios where propertyName is passed as NULL because the related RBKey could be NULL
        if (StringUtil.isEmpty(propertyName))
            return defaultValue;

        return loopThroughBundles(propertyName, aLocale, defaultValue);
    }

    public static int getLocalizedIntFromLocale(String propertyName, Locale aLocale, int defaultValue) {
        //Fix for scenarios where propertyName is passed as NULL because the related RBKey could be NULL
        if (StringUtil.isEmpty(propertyName))
            return defaultValue;

        String value = loopThroughBundles(propertyName, aLocale, null);

        return parseIntValueOrDefault(value, defaultValue);
    }

    public static boolean getLocalizedBooleanFromLocale(String propertyName, Locale aLocale, boolean defaultValue) {
        //Fix for scenarios where propertyName is passed as NULL because the related RBKey could be NULL
        if (StringUtil.isEmpty(propertyName))
            return defaultValue;

        String value = loopThroughBundles(propertyName, aLocale, null);

        return parseBooleanValueOrDefault(value, defaultValue);
    }

    public static Locale getRBLocale()
    {
      String clientOverrideBundle = get(IBharosaConstants.BHAROSA_CONFIG_RESOURCEBUNDLE_CLIENTOVERRIDE, "").trim();
      if (clientOverrideBundle.length() > 0) {
          try {
              return ResourceBundle.getBundle(clientOverrideBundle, BharosaLocale.getCurrentLocale()).getLocale();
          } catch (MissingResourceException mrex) {
              if (false == true) 
                logger.debug(mrex);
          }
      }
      String[] bundleList = get(IBharosaConstants.BHAROSA_CONFIG_RESOURCEBUNDLE_LIST, "bharosa_resources").split("[\\W]+");
      for (int i = 0; i < bundleList.length; i++) {
          try {
              return ResourceBundle.getBundle(bundleList[i], BharosaLocale.getCurrentLocale()).getLocale();
          } catch (MissingResourceException mrex) {
              if (false == true) logger.debug(mrex);
          }
      }
      return BharosaLocale.getCurrentLocale();
    }

    protected static String loopThroughBundles(String propertyName, Locale aLocale, String defaultValue) {
        //Fix for scenarios where propertyName is passed as NULL because the related RBKey could be NULL
        if (StringUtil.isEmpty(propertyName))
            return defaultValue;

        if (getBoolean(IBharosaConstants.BHAROSA_CONFIG_BYPASS_RESOURCEBUNDLE, false)) {
            return get(propertyName, defaultValue);
        }
        String clientOverrideBundle = get(IBharosaConstants.BHAROSA_CONFIG_RESOURCEBUNDLE_CLIENTOVERRIDE, "").trim();
        if (clientOverrideBundle.length() > 0) {
            try {
                return ResourceBundle.getBundle(clientOverrideBundle, aLocale).getString(propertyName);
            } catch (MissingResourceException mrex) {
                if (false == true) logger.debug(mrex);
            }
        }
        String[] bundleList = get(IBharosaConstants.BHAROSA_CONFIG_RESOURCEBUNDLE_LIST, "bharosa_resources").split("[\\W]+");
        for (int i = 0; i < bundleList.length; i++) {
            try {
                return ResourceBundle.getBundle(bundleList[i], aLocale).getString(propertyName);
            } catch (MissingResourceException mrex) {
                if (false == true) logger.debug(mrex);
            }
        }
        return get(propertyName, defaultValue);
    }

    /**
     * Returns the localized value for the property name, using the
     * <b>current</b> locale and <b>specified</b> bundle name.
     *
     * @param propertyName
     * @param resourceBundleName
     */
    public static String getLocalizedFromNamedBundle(String propertyName, String resourceBundleName) {
        return getLocalizedFromNamedBundleAndLocale(propertyName, resourceBundleName, BharosaLocale.getCurrentLocale(), null);
    }

    public static String getLocalizedFromNamedBundle(String propertyName, String resourceBundleName, String defaultValue) {
        return getLocalizedFromNamedBundleAndLocale(propertyName, resourceBundleName, BharosaLocale.getCurrentLocale(), defaultValue);
    }

    public static int getLocalizedIntFromNamedBundle(String propertyName, String resourceBundleName, int defaultValue) {
        String value = getLocalizedFromNamedBundleAndLocale(propertyName, resourceBundleName, BharosaLocale.getCurrentLocale(), null);

        return parseIntValueOrDefault(value, defaultValue);
    }

    public static boolean getLocalizedBooleanFromNamedBundle(String propertyName, String resourceBundleName, boolean defaultValue) {
        String value = getLocalizedFromNamedBundleAndLocale(propertyName, resourceBundleName, BharosaLocale.getCurrentLocale(), null);

        return parseBooleanValueOrDefault(value, defaultValue);
    }


    /**
     * Returns the localized value for the property name, using the
     * <b>specified</b> locale and <b>specified</b> bundle name.
     *
     * @param propertyName
     * @param aLocale
     * @return
     */
    public static String getLocalizedFromNamedBundleAndLocale(String propertyName, String resourceBundleName, Locale aLocale) {
        return getLocalizedFromNamedBundleAndLocale(propertyName, resourceBundleName, aLocale, null);
    }

    public static String getLocalizedFromNamedBundleAndLocale(String propertyName, String resourceBundleName, Locale aLocale, String defaultValue) {
        //Fix for scenarios where propertyName is passed as NULL because the related RBKey could be NULL
        if (StringUtil.isEmpty(propertyName))
            return defaultValue;

        if (getBoolean(IBharosaConstants.BHAROSA_CONFIG_BYPASS_RESOURCEBUNDLE, false)) {
            return get(propertyName, defaultValue);
        }

        String clientOverrideBundle = get(IBharosaConstants.BHAROSA_CONFIG_RESOURCEBUNDLE_CLIENTOVERRIDE, "").trim();
        if (!StringUtil.isEmpty(clientOverrideBundle)) {
            try {
                return ResourceBundle.getBundle(clientOverrideBundle, aLocale).getString(propertyName);
            } catch (MissingResourceException mrex) {
                if (false == true) logger.debug("Client Override: " + mrex);
            }
        }

        try {
            return ResourceBundle.getBundle(resourceBundleName, aLocale).getString(propertyName);
        } catch (MissingResourceException mrex) {
            //logger.debug(mrex);
            return get(propertyName, defaultValue);
        }
    }

    public static int getLocalizedIntFromNamedBundleAndLocale(String propertyName, String resourceBundleName, Locale aLocale, int defaultValue) {
        String value = getLocalizedFromNamedBundleAndLocale(propertyName, resourceBundleName, aLocale, null);

        return parseIntValueOrDefault(value, defaultValue);
    }

    public static boolean getLocalizedBooleanFromNamedBundleAndLocale(String propertyName, String resourceBundleName, Locale aLocale, boolean defaultValue) {
        String value = getLocalizedFromNamedBundleAndLocale(propertyName, resourceBundleName, aLocale, null);

        return parseBooleanValueOrDefault(value, defaultValue);
    }

    /**
     * This return the integer value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param defaultValue Default value to return if the property is not found or there
     *                     is a exception in converting.
     * @return Return the integer value of the given property name.
     */
    static public int getInt(String propertyName, int defaultValue) {
        BharosaProperty prop = getProperty(propertyName);
        if (prop != null) {
            return prop.getInt(defaultValue);
        }
        return defaultValue;
    }

    protected static int parseIntValueOrDefault(String value, int defaultValue) {
        int intValue = -1;
        if (!StringUtil.isEmpty(value)) {
            value = value.trim();
        }

        try {
            if (!StringUtil.isEmpty(value)) {
                intValue = Integer.parseInt(value);
            } else {
                intValue = defaultValue;
            }
        } catch (Exception ex) {
            if (logger.isDebugEnabled())
                logger.debug("Unable to parse int propertyValue="
                        + value + ", using defaultValue=" + defaultValue, ex);

            return defaultValue;
        }

        return intValue;
    }

    /**
     * This return the long value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param defaultValue Default value to return if the property is not found or there is a exception in converting.
     * @return Return the long value of the given property name.
     */
    static public long getLong(String propertyName, long defaultValue) {
        BharosaProperty prop = getProperty(propertyName);
        if (prop != null) {
            return prop.getLong(defaultValue);
        }
        return defaultValue;
    }

    /**
     * This return the float value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param defaultValue Default value to return if the property is not found or there is a exception in converting.
     * @return Return the float value of the given property name.
     */
    static public float getFloat(String propertyName, float defaultValue) {
        BharosaProperty prop = getProperty(propertyName);
        if (prop != null) {
            return prop.getFloat(defaultValue);
        }
        return defaultValue;
    }

    /**
     * This return the boolean value for the given property name.
     *
     * @param propertyName Name of the property.
     * @param defaultValue Default value to return if the property is not found or there is a exception in converting.
     * @return Return the boolean value of the given property name.
     */
    static public boolean getBoolean(String propertyName, boolean defaultValue) {
        BharosaProperty prop = getProperty(propertyName);
        if (prop != null) {
            return prop.getBoolean(defaultValue);
        }
        return defaultValue;
    }


  /**
   * Returns localized property based on an AppId and current locale (ASA style properties).
   * 
   * @param appId App ID to use for property lookup.
   * @param prop Name of the property.
   * @param defaultResult Default value to return if the propery is not found.
   * @return Return the String value of the given property name.
   */
  public static String getLocalizedAppProp(String appId, String prop, String defaultResult){
    return getAppProp(appId, prop, defaultResult, BharosaLocale.getCurrentLocale());
  }

  /**
   * Returns property based on an AppId (ASA style properties)
   *
   * @param appId App ID to use for property lookup.
   * @param prop Name of the property.
   * @param defaultResult Default value to return if the propery is not found.
   * @return Return the String value of the given property name.
   */
  public static String getAppProp(String appId, String prop, String defaultResult) {
    return getAppProp(appId, prop, defaultResult, null);
  }

  /**
   * Returns localized property based on an AppId and provided locale (ASA style properties)
   *
   * @param appId App ID to use for property lookup.
   * @param prop Name of the property.
   * @param defaultResult Default value to return if the propery is not found.
   * @return Return the String value of the given property name.
   */
  public static String getAppProp(String appId, String prop, String defaultResult, Locale locale) {
    String propBase = APP_PROP_BASE + appId + ".";

    String result;

    if (locale != null) {
      result = BharosaConfig.getLocalizedFromLocale(propBase + prop, locale);
    } else {
      result = BharosaConfig.get(propBase + prop);
    }

    if (StringUtil.isEmpty(result)) {
      String parent = BharosaConfig.get(propBase + "extends");
      if (!StringUtil.isEmpty(parent)) {
        result = getAppProp(parent, prop, defaultResult, locale);
      } else {
        if (locale != null) {
          result =
              BharosaConfig.getLocalizedFromLocale(DEFAULT_APP_PROP_BASE + prop,
                                                   locale, defaultResult);
        } else {
          result = BharosaConfig.get(DEFAULT_APP_PROP_BASE + prop, defaultResult);
        }
      }
    }
    return result;
  }

  /**
   * Returns int value of property based on an AppId (ASA style properties)
   *
   * @param appId App ID to use for property lookup.
   * @param prop Name of the property.
   * @param defaultResult Default value to return if the propery is not found.
   * @return Return the int value of the given property name.
   */
  public static int getAppPropInt(String appId, String prop, int defaultResult) {
  
    String propBase = APP_PROP_BASE + appId + ".";

    int result = BharosaConfig.getInt(propBase + prop, -1);

    if (result == -1) {
      String parent = BharosaConfig.get(propBase + "extends");
      if (!StringUtil.isEmpty(parent)) {
        result = getAppPropInt(parent, prop, defaultResult);
      } else {
        result = BharosaConfig.getInt(DEFAULT_APP_PROP_BASE + prop, defaultResult);
      }
    }

    return result;
  }

  /**
   * Returns boolean value of property based on an AppId (ASA style properties)
   *
   * @param appId App ID to use for property lookup.
   * @param prop Name of the property.
   * @param defaultResult Default value to return if the propery is not found.
   * @return Return the boolean value of the given property name.
   */
  public static boolean getAppPropBoolean(String appId, String prop, boolean defaultResult) {

    String propBase = APP_PROP_BASE + appId + ".";

    boolean result;
    String tmpResult = BharosaConfig.get(propBase + prop);

    if (StringUtil.isEmpty(tmpResult)) {
      String parent = BharosaConfig.get(propBase + "extends");
      if (!StringUtil.isEmpty(parent)) {
        result = getAppPropBoolean(parent, prop, defaultResult);
      } else {
        result = BharosaConfig.getBoolean(DEFAULT_APP_PROP_BASE + prop, defaultResult);
      }
    } else {
      result = StringUtil.equalsIgnoreCase(tmpResult, "true");
    }
    return result;
  }


  /**
   * Returns property name formatted based on an AppId (ASA style properties)
   *
   * @param appId App ID to use for to create property name.
   * @param prop Name of the property to format.
   * @return Return the String property name formated based on given App Id.
   */
  public static String getAppPropName(String  appId, String prop) {
    String propBase = APP_PROP_BASE + appId + ".";
    String propName = propBase + prop;

    String propValue = BharosaConfig.get(propName);

    if (StringUtil.isEmpty(propValue)) {

      String parent = BharosaConfig.get(propBase + "extends");
      boolean propFound = false;

      while (!StringUtil.isEmpty(parent) && !propFound) {
        propBase = APP_PROP_BASE + parent + ".";
        propName = propBase + prop;
        propValue = BharosaConfig.get(propName);

        if (!StringUtil.isEmpty(propValue)) {
          propFound = true;
        } else {
          parent = BharosaConfig.get(propBase + "extends");
        }
      }
    }

    if (StringUtil.isEmpty(propValue)) {
      propName = DEFAULT_APP_PROP_BASE + prop;
    }

    return propName;
  }


  protected static boolean parseBooleanValueOrDefault(String value, boolean defaultValue) {
        if (!StringUtil.isEmpty(value)) {
            value = value.trim();
        }

        if (StringUtil.equalsIgnoreCase(value, "true")) {
            return true;
        } else if (StringUtil.equalsIgnoreCase(value, "false")) {
            return false;
        }

        if (logger.isDebugEnabled())
            logger.debug("Unable to parse boolean propertyValue="
                    + value + ", using defaultValue=" + defaultValue);

        return defaultValue;
    }

    /**
     * Returns the hashMap of the properties. Don't misuse it.
     *
     * @return HashMap of the properties.
     */
    static public HashMap getHashMap() {
        if (!initDone) {
            init();
        }
        HashMap retMap = new HashMap();
        retMap.putAll(thisInstance.fallbackConfig.getMap());
        retMap.putAll(thisInstance.config.getMap());
        return retMap;
    }

    /**
     * This prints all the property values.
     *
     * @return propery Map as string
     */
    static public String getStringRepresentation() {
        return thisInstance.config.getStringRepresentation();
    }

    /**
     * Returns Map of the Properties with keys matching the keyword.
     *
     * @param pSearchKeyword Search keyword
     * @return a HashMap containing the properties that match the search Keyword
     */
    static public HashMap searchProperties4Export(String pSearchKeyword) {
        return searchProperties(pSearchKeyword,
                getBoolean("bharosa.config.export.list.filter.enum", false));
    }

    /**
     * Returns Map of the Properties with keys matching the keyword excluding
     * enums.
     *
     * @param pSearchKeyword Search keyword
     * @return a HashMap containing the properties that match the search Keyword
     */
    static public HashMap searchProperties4UI(String pSearchKeyword) {
        return searchProperties(pSearchKeyword,
                getBoolean("bharosa.config.ui.list.filter.enum", true));
    }

    /**
     * Returns Map of the Properties with keys matching the keyword.
     *
     * @param pSearchKeyword Search keyword
     * @return a HashMap containing the properties that match the search Keyword
     */
    static public HashMap searchProperties(String pSearchKeyword, boolean pEnumFilter) {
        if (logger.isDebugEnabled())
            logger.debug("searchProperties called..."
                    + " for keyword [" + pSearchKeyword + "]");
        boolean enumFilter = pEnumFilter;
        if (enumFilter && StringUtil.isEmpty(pSearchKeyword)) {
            pSearchKeyword = "*";
        }

        HashMap retMap = new HashMap();
        if (StringUtil.isEmpty(pSearchKeyword)) {
            retMap = getHashMap();//thisInstance.config.getMap();
        } else {
            Iterator iter = getHashMap().keySet().iterator();
            while (iter.hasNext()) {
                String lKey = (String) iter.next();
                if ((lKey.toLowerCase().indexOf(pSearchKeyword.toLowerCase()) != -1) || StringUtil.matches(pSearchKeyword, lKey)) {
                    BharosaProperty lVal = getProperty(lKey);
                    if (!(enumFilter && StringUtil.matches("*.enum*", lKey))) {
                        retMap.put(lKey, lVal);
                    }
                }
            }
        }
        if (logger.isDebugEnabled())
            logger.debug("searchProperties returned..."
                    + retMap.size() + " properties"
                    + " for keyword [" + pSearchKeyword + "]");
        return retMap;
    }

    /**
     * This method returns all the property names with the given value
     *
     * @param value of the property
     * @return List of property name strings
     */
    static public List searchPropertiesByValue(String value) {
        List list = new ArrayList();
        Iterator iter = getHashMap().values().iterator();
        while (iter.hasNext()) {
            BharosaProperty prop = (BharosaProperty) iter.next();
            if (prop.getValue().equals(value)) {
                list.add(prop.getName());
            }
        }
        return list;
    }

    private void decryptProperties(BharosaConfigIntf pFallbackConfig, BharosaConfigIntf pConfig) {
        if (logger.isDebugEnabled())
            logger.debug("decryptProperties: "
                    + " FallbackConfig [" + pFallbackConfig + "]"
                    + " Config [" + pConfig + "]");
        // Decrypt all erypted properties
        pFallbackConfig.decryptProperties();

        if (pFallbackConfig != pConfig) {
            // Decrypt all erypted properties
            pConfig.decryptProperties();
        }
    }

    public static String getClientCypherKey() {
        return get(PROP_CLIENT_CIPHER_KEY);
    }

    public static String getServerName() {
        return SERVER;
    }

    public static boolean isPropertyOverrideSupported() {
        return thisInstance.config.isPropertyOverrideSupported();
    }

    /**
     * Handle resource bundle file updates
     *
     * @param modifiedFile File which has been modified
     */
    public void handleFileModified(File modifiedFile) {
        //Since only resource bundles are monitored by this class, we will reset all the resource bundles
        clearAllResourceBundleCache();

    }

    private void monitorResourceBundles() {
        int monitorSeconds = BharosaConfig.getInt("bharosa.resourcebundle.monitor.sec", 30);
        try {
            String clientOverrideBundle = get(IBharosaConstants.BHAROSA_CONFIG_RESOURCEBUNDLE_CLIENTOVERRIDE, "").trim();
            if (clientOverrideBundle.length() > 0) {
                String fileName = clientOverrideBundle + BharosaConfig.get("bharosa.resource.bundle.extension", ".properties");
                logger.info("Will try to monitoring Resource bundle " + fileName + " every " + monitorSeconds + " seconds");
                FileUtil.setFileMonitor(fileName, this, monitorSeconds);
            }
        } catch (Throwable t) {
            //ignore this error
            if (false == true) logger.debug("monitorResourceBundles(): got an error=" + t.getMessage(), t);
        }
        try {
            String[] bundleList = get(IBharosaConstants.BHAROSA_CONFIG_RESOURCEBUNDLE_LIST, "bharosa_resources").split("[\\W]+");
            for (int i = 0; i < bundleList.length; i++) {
                try {
                    String fileName = bundleList[i] + BharosaConfig.get("bharosa.resource.bundle.extension", ".properties");
                    logger.info("Will try to monitoring Resource bundle " + fileName + " every " + monitorSeconds + " seconds");
                    FileUtil.setFileMonitor(fileName, this, monitorSeconds);
                } catch (Throwable t) {
                    //ignore this error
                    if (false == true) logger.debug("monitorResourceBundles(): got an error=" + t.getMessage(), t);
                }
            }
        } catch (Throwable t) {
            //ignore this error
            if (false == true) logger.debug("monitorResourceBundles(): got an error=" + t.getMessage(), t);
        }

    }

    void clearAllResourceBundleCache() {
        logger.info("clearResourceBundleCache()");
        try {
            String clientOverrideBundle = get(IBharosaConstants.BHAROSA_CONFIG_RESOURCEBUNDLE_CLIENTOVERRIDE, "").trim();
            if (clientOverrideBundle.length() > 0) {
                try {
                    clearResourceBundleCache(clientOverrideBundle);
                } catch (Throwable t) {
                    //ignore this error
                    if (false == true) logger.debug("clearAllResourceBundleCache(): got an error=" + t.getMessage(), t);
                }
            }
            String[] bundleList = get(IBharosaConstants.BHAROSA_CONFIG_RESOURCEBUNDLE_LIST, "bharosa_resources").split("[\\W]+");
            for (int i = 0; i < bundleList.length; i++) {
                try {
                    clearResourceBundleCache(bundleList[i]);
                } catch (Throwable t) {
                    //ignore this error
                    if (false == true) logger.debug("clearAllResourceBundleCache(): got an error=" + t.getMessage(), t);
                }
            }
        } catch (Throwable t) {
            logger.debug("Error clearing ResourceBundle cache");
        }
    }

    void clearResourceBundleCache(String resoureBundleName) {
        if (logger.isDebugEnabled())
            logger.debug("Clearing resource bundle " + resoureBundleName);
        try {
            Class klass = ResourceBundle.getBundle(resoureBundleName).getClass().getSuperclass();
            Field field = klass.getDeclaredField("cacheList");
            field.setAccessible(true);
            sun.misc.SoftCache cache = (sun.misc.SoftCache) field.get(null);
            cache.clear();
        } catch (Throwable t) {
            logger.debug("Error clearing ResourceBundle cache for " + resoureBundleName + ". error=" + t);
        }
    }
  
    public static boolean isAddAllowed(int loadType) {
      UserDefEnumElement elem = loadTypeEnum.getElement(loadType);
      if (elem == null) return true;
      if ("false".equalsIgnoreCase(elem.getProperty("allowAdd"))) return false;
      return true;
    }  
    public static boolean isUpdateAllowed(int loadType) {
      UserDefEnumElement elem = loadTypeEnum.getElement(loadType);
      if (elem == null) return true;
      if ("false".equalsIgnoreCase(elem.getProperty("allowUpdate"))) return false;
      return true;
    }
    
    public static boolean isDeleteAllowed(int loadType) {
      UserDefEnumElement elem = loadTypeEnum.getElement(loadType);
      if (elem == null) return true;
      if ("false".equalsIgnoreCase(elem.getProperty("allowDelete"))) return false;
      return true;
    }
    
    public static String getLoadTypeEnumElementName(int loadType) {
      UserDefEnumElement elem = loadTypeEnum.getElement(loadType);
      return (elem != null && elem.getElementId() != null) ? elem.getName() : "unknown";
    }
    
}
