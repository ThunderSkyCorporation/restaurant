package com.bharosa.common.util;

import java.io.File;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.bharosa.common.logger.Logger;

import java.net.URL;

/**
 * This class provides utility methods for operations concerning Locale
 * resolution. The current locale is stored in a ThreadLocal variable.
 */
public class BharosaLocale {
    static final Logger LOGGER = Logger.getLogger(BharosaLocale.class);
    static ThreadLocal /*<Locale>*/locale = new ThreadLocal /*<Locale>*/();
    static ThreadLocal /*<Locale>*/formattingLocale =
        new ThreadLocal /*<Locale>*/();
    static final Map /*<String, UserDefEnumElement>*/SUPPORTED_LOCALES =
        new HashMap /*<String, UserDefEnumElement>*/();

    private static String defaultLanugage;
    private static Locale defaultLocale;

    static {
        staticInitialize();
        BharosaConfig.registerReloadListener(new BharosaConfigReloadListener() {
                public void configReloaded() {
                    synchronized (SUPPORTED_LOCALES) {
                        LOGGER.info("Config reloaded.");
                        SUPPORTED_LOCALES.clear();
                        staticInitialize();
                    }
                }
            });
    }

    static void staticInitialize() {
        readSupportedLocales();
        pickDefaultLocale();
    }

    private static void pickDefaultLocale() {
        Locale platformDefault = Locale.getDefault();
        int defaultValue =
            BharosaConfig.getInt("bharosa.default.locale", UserDefEnum.INVALID);
        if (defaultValue != UserDefEnum.INVALID) {
            Locale temp = userDefEnumElementToLocale(defaultValue);
            if (temp != null)
                platformDefault = temp;
        }

        defaultLanugage = platformDefault.getLanguage();
        defaultLocale = platformDefault;
        Locale.setDefault(platformDefault);

        LOGGER.info("Default Locale = " + defaultLocale);
    }

    private static void readSupportedLocales() {
        UserDefEnum localeEnum =
            UserDefEnum.getEnumOrEmptyEnumIfUndefined(IBharosaConstants.BHAROSA_LOCALE_ENUM_NAME);
        LOGGER.debug("We support " + localeEnum.getEnumElementCount() +
                     " locales.");

        String localeLimiter =
            BharosaConfig.get(IBharosaConstants.BHAROSA_LOCALE_LIMITER);

        for (Enumeration /*<UserDefEnumElement>*/iter =
             localeEnum.getEnumElements(); iter.hasMoreElements(); ) {
            UserDefEnumElement each = (UserDefEnumElement)iter.nextElement();
            boolean toInclude =
                (StringUtil.isEmpty(localeLimiter) || StringUtil.equalsIgnoreCase("true",
                                                                                  each.getProperty(localeLimiter)));

            if (toInclude) {
                Locale eachLocale = userDefEnumElementToLocale(each);
                String key = buildLocaleKey(eachLocale);
                SUPPORTED_LOCALES.put(key, each);
            }
        }
    }

    public static Locale userDefEnumElementToLocale(UserDefEnumElement element) {
        String language =
            element.getProperty(IBharosaConstants.LANGUAGE_KEY, "");
        String country =
            element.getProperty(IBharosaConstants.COUNTRY_KEY, "");
        String variant =
            element.getProperty(IBharosaConstants.VARIANT_KEY, "");
        return new Locale(language, country, variant);
    }

    /**
     * Returns a list of all locales specified in the bharosa.locale.enum
     *
     * @return List of UserDefEnumElement
     */
    public static List /*<UserDefEnumElement>*/getAvailableLocales() {
        return new ArrayList(SUPPORTED_LOCALES.values());
    }

    /**
     * Returns the locale set by one of the setCurrentLocale methods, or the
     * default locale if no locale has been set for the current thread.
     *
     * @see BharosaLocale#setCurrentLocale(HttpServletRequest)
     * @see BharosaLocale#setCurrentLocale(UserDefEnumElement)
     * @return Locale
     */
    public static Locale getCurrentLocale() {
        Locale currentLocale = (Locale)locale.get();
        if (currentLocale == null) {
            resetCurrentLocale();
            currentLocale = getDefaultLocale();
        }
        return currentLocale;
    }

    public static Locale getCurrentLocaleForFormatting() {
        Locale currentLocale = (Locale)formattingLocale.get();
        if (currentLocale == null) {
            resetFormattingLocale();
            currentLocale = getDefaultLocale();
        }
        return currentLocale;
    }

    /**
     * If the Accept-Language is empty, uses the default locale.
     * @param request
     */
    public static void setCurrentLocale(HttpServletRequest request) {

        Locale aLocale = request.getLocale();

        String userLocaleStr =
            request.getParameter(IBharosaConstants.BHAROSA_USER_LOCALE);
        if (!StringUtil.isEmpty(userLocaleStr)) {

            String[] localeElems = StringUtil.split(userLocaleStr, "_");
            String language = "";
            String country = "";
            String variant = "";

            if (localeElems.length > 0) {
                language = localeElems[0];
                if (localeElems.length > 1) {
                    country = localeElems[1];
                    if (localeElems.length > 2) {
                        variant = localeElems[2];
                    }
                }
                formattingLocale.set(new Locale(language, country, variant));
                if (!SUPPORTED_LOCALES.isEmpty()) {
                    Locale testLocale =
                        getSupportedLocaleOrNull(language, country, variant);
                    if (testLocale != null) {
                        locale.set(testLocale);
                        return;
                    }
                }
            }
        }

        Locale localeFromSession =
            (Locale)request.getSession().getAttribute(IBharosaConstants.BHAROSA_LOCALE);
        if (localeFromSession != null) {
            locale.set(localeFromSession);
            Locale formatLocaleFromSession =
                (Locale)request.getSession().getAttribute(IBharosaConstants.BHAROSA_FORMAT_LOCALE);
            if (formattingLocale != null) {
                formattingLocale.set(formatLocaleFromSession);
            }
            return;
        }

        Enumeration locales = request.getLocales();
        setCurrentLocale(aLocale, locales);
    }

    /**
     * Sets the current locale for this thread, using the element from the supported Locale enum.
     *
     * @param locale
     * @param locales Enumeration of locales
     */

    public static void setCurrentLocale(Locale aLocale, Enumeration locales) {
        if (aLocale == null) {
            aLocale = getDefaultLocale();
        }
        formattingLocale.set(aLocale);

        if (locales != null) {
            while (locales.hasMoreElements()) {
                Locale eachLocale = (Locale)locales.nextElement();
                if (SUPPORTED_LOCALES.isEmpty()) {
                    // Supported Translation Locales unspecified -- use preference
                    setCurrentLocale(eachLocale);
                    return;
                }
                Locale testLocale = getSupportedLocaleOrNull(eachLocale);
                if (testLocale != null) {
                    locale.set(testLocale);
                    return;
                }
            }
        } else {
            Locale testLocale = getSupportedLocaleOrNull(aLocale);
            if (testLocale != null) {
                locale.set(testLocale);
                return;
            }
        }
        // no matching supported locale -- use default
        resetCurrentLocale();
    }

    /**
     * Sets the current locale for this thread, using the element from the supported Locale enum.
     *
     * @param element
     */
    public static void setCurrentLocale(UserDefEnumElement element) {
        if (!element.getEnumId().equals(IBharosaConstants.BHAROSA_LOCALE_ENUM_NAME)) {
            LOGGER.warn("Setting locale using element from wrong enum " +
                        element.getEnumId());
        }
        setCurrentLocale(userDefEnumElementToLocale(element));
    }

    /**
     * Sets the current locale for this thread, using the default variant if the
     * specified locale has no variant set.
     *
     * @param aLocale
     */
    static void setCurrentLocale(Locale aLocale) {
        locale.set(aLocale);
    }

    /**
     * Picks the locale out of the bharosa.locale.enum that is matches the
     * specified locale. If there is no matching locale in bharosa.locale.enum,
     * this method returns null.
     *
     * @see BharosaLocale#getSupportedLocaleOrNull(String, String, String)
     * @param aLocale
     * @return Locale
     */
    public static Locale getSupportedLocaleOrNull(Locale aLocale) {
        return getSupportedLocaleOrNull(aLocale.getLanguage(),
                                        aLocale.getCountry(),
                                        aLocale.getVariant());
    }

    /**
     * Picks the locale out of the bharosa.locale.enum that is matches the
     * specified locale. If there is no matching locale in bharosa.locale.enum,
     * this method returns the previously specified default.
     *
     * @see BharosaLocale#getSupportedLocaleOrDefault(String, String, String)
     * @param aLocale
     * @return Locale
     */
    public static Locale getSupportedLocaleOrDefault(Locale aLocale) {
        return getSupportedLocaleOrDefault(aLocale.getLanguage(),
                                           aLocale.getCountry(),
                                           aLocale.getVariant());
    }

    /**
     * Picks the locale out of the bharosa.locale.enum that is matches the
     * specified locale. If there is no matching locale in bharosa.locale.enum,
     * this method returns null.
     *
     * This method resolves resources in the following order:
     * <ol>
     * <li>Looks for language_country_variant in bharosa.locale.enum</li>
     * <li>Failing that, looks for language_country in bharosa.locale.enum</li>
     * <li>Failing that, looks for language in bharosa.locale.enum</li>
     * <li>Failing that, returns null.</li>
     * </ol>
     *
     * @param language
     *           ISO 639-1 Language code
     * @param country
     *           ISO 3661-1 alpha-2 Country code
     * @param variant
     *           The variant
     * @return Locale
     */
    public static Locale getSupportedLocaleOrNull(String language,
                                                  String country,
                                                  String variant) {
        // Special handling for Norwegian locales
        // Norwegan locales are non standard - NO, nb_NO, nn_NO
      if (StringUtil.equalsIgnoreCase(country, "NO") && (StringUtil.equalsIgnoreCase(language, "nb") || (StringUtil.equalsIgnoreCase(language, "nn")))){
        language = "no";
        country = "";
      }
      
        String key = buildLocaleKey(language, country, variant);
        UserDefEnumElement localeElement =
            (UserDefEnumElement)SUPPORTED_LOCALES.get(key);
        Locale result;
        if (localeElement != null) {
            result = userDefEnumElementToLocale(localeElement);
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Locale " + result + " is supported.");
            }
            return result;
        }
        if (LOGGER.isDebugEnabled()) {
            Locale unsupportedLocale = new Locale(language, country, variant);
            LOGGER.debug("Locale " + unsupportedLocale + " is not supported.");
        }
        if (!StringUtil.isEmpty(variant)) {
            return getSupportedLocaleOrNull(language, country, "");
        }
        if (!StringUtil.isEmpty(country)) {
            return getSupportedLocaleOrNull(language, "", "");
        }

        return null;
    }
    
  public static String[] getInstalledResourceBundleFileNames(String bundleName) {
    ArrayList fileNameList = new ArrayList();

    if (bundleName.toLowerCase().endsWith(".properties")) {
      bundleName =
          bundleName.substring(0, bundleName.length() - ".properties".length());
    }

    if (!StringUtil.isEmpty(bundleName)){
      fileNameList.add(bundleName + ".properties");
  
      Iterator localeIter = SUPPORTED_LOCALES.values().iterator();
  
      while (localeIter.hasNext()) {
        Locale locale =
          userDefEnumElementToLocale((UserDefEnumElement)localeIter.next());
        String[] suffixComps =
        { locale.getLanguage(), locale.getCountry(), locale.getVariant() };
        String suffix = "";
  
        for (int i = 0; i < suffixComps.length; i++) {
          if (StringUtil.isEmpty(suffixComps[i])) {
            break;
          }
  
          suffix += ("_" + suffixComps[i]);
          fileNameList.add(bundleName + suffix + ".properties");
        }
      } // end of while
    }
    return (String[])fileNameList.toArray(new String[fileNameList.size()]);
  }

  /**
   * Picks the locale out of the bharosa.locale.enum that is matches the
   * specified locale. If there is no matching locale in bharosa.locale.enum,
   * this method returns the previously specified default.
   *
   * This method resolves resources in the following order:
   * <ol>
   * <li>Looks for language_country_variant in bharosa.locale.enum</li>
   * <li>Failing that, looks for language_country in bharosa.locale.enum</li>
   * <li>Failing that, looks for language in bharosa.locale.enum</li>
   * <li>Failing that, returns the previously specified default.</li>
   * </ol>
   *
   * @param language
   *           ISO 639-1 Language code
   * @param country
   *           ISO 3661-1 alpha-2 Country code
   * @param variant
   *           The variant
   * @return Locale
   */
    public static Locale getSupportedLocaleOrDefault(String language,
                                                     String country,
                                                     String variant) {
        Locale result = getSupportedLocaleOrNull(language, country, variant);
        if (result != null)
            return result;

        return getDefaultLocale();
    }

    private static String buildLocaleKey(String language, String country,
                                         String variant) {
        return language + "_" + country + "_" + variant;
    }

    private static String buildLocaleKey(Locale aLocale) {
        return buildLocaleKey(aLocale.getLanguage(), aLocale.getCountry(),
                              aLocale.getVariant());
    }

    /**
     * Sets the locale for the current thread to the default locale.
     */
    public static void resetCurrentLocale() {
        setCurrentLocale(getDefaultLocale());
    }

    public static void resetFormattingLocale() {
        formattingLocale.set(getDefaultLocale());
    }

    /**
     * Returns the default locale.
     *
     * @return Locale
     */
    public static Locale getDefaultLocale() {
        Locale locale = defaultLocale;
        if (locale == null || locale.toString().equals("")) {
            locale =
                    userDefEnumElementToLocale(BharosaConfig.getInt("bharosa.default.locale",
                                                                    0));
        }
        return locale;
    }

    public static String getDefaultLanguage() {
        return defaultLanugage;
    }

    public static Locale userDefEnumElementToLocale(int enumValue) {
        UserDefEnumElement localeElem =
            UserDefEnum.getElement(IBharosaConstants.BHAROSA_LOCALE_ENUM_NAME,
                                   enumValue);

        if (localeElem != null) {
            return userDefEnumElementToLocale(localeElem);
        }
        return null;
    }
}
