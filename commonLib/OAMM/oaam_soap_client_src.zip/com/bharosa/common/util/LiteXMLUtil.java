/* $Header: oaam/apps/oaam_core/src/com/bharosa/common/util/LiteXMLUtil.java /main/2 2011/03/17 11:15:03 jpdavis Exp $ */

/* Copyright (c) 2009, 2011, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jpdavis     04/21/09 - Creation
 */

/**
 *  @version $Header: oaam/apps/oaam_core/src/com/bharosa/common/util/LiteXMLUtil.java /main/1 2009/12/02 01:00:38 bodurai Exp $
 *  @author  jpdavis 
 *  @since   release specific (what release of product did this appear in)
 *  Make methods available in client build, remove dependency on server side components.
 */

package com.bharosa.common.util;

public class LiteXMLUtil {

	public static String encodeSpecialCharacters(String data) {
		if (data == null) return "";
	     return data.replaceAll("&(?!\\w+;)", "&amp;")
	             .replaceAll("<", "&lt;")
	             .replaceAll(">", "&gt;")
	             .replaceAll("\"", "&quot;")
	             .replaceAll("'", "&#039;");
	 }

	public static String decodeSpecialCharacters(String data) {
		if (data == null) return "";
	     return data.replaceAll("&amp;", "&")
	             .replaceAll("&lt;", "<")
	             .replaceAll("&gt;", ">")
	             .replaceAll("&quot;", "\"")
	             .replaceAll("&#039;", "'");
	 }
	
}