package com.bharosa.vcryptclient.client.exceptions;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;

/**
 * This is the base class for all BharosaClient exceptions.
 */

public class BharosaClientException 
	extends Exception {

	static Logger  logger = Logger.getLogger(BharosaClientException.class);
	
}
