package com.bharosa.vcryptclient.client.exceptions;

/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

import com.bharosa.common.logger.Logger;

/**
 * This exception is thrown for all Bharosa KeyPad related errors
 */

public class BharosaClientKeyPadException 
	extends BharosaClientException {

	static Logger  logger = Logger.getLogger(BharosaClientKeyPadException.class);

	String errorString = null;
	
	/**
	 * Constructs the exception for the error string.
	 *
	 * @param errorString The error string.
	 */
	public BharosaClientKeyPadException( String errorString ) {
		this.errorString = errorString;
	}
}
