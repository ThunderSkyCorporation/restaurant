/*
 * Copyright (c) 2005 Bharosa, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Bharosa, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Bharosa,Inc.
 */

package com.bharosa.vcryptclient.client.exceptions;

import com.bharosa.common.exception.BharosaException;
import com.bharosa.common.exception.BharosaErrorIds;
/**
 * ClientDataAccessException.java
 * Description: This class is thrown by classes which are aware of Access
 *
 * @author Derick
 */
public class ClientDataAccessException extends BharosaException {

	public ClientDataAccessException(String errorId) {
		super( errorId );
	}


	/**
	 * This exeption is thrown when setting client data access
	 * @param data null data
	 */
	static public ClientDataAccessException clientDataAccessSetupException(
			  String data) {
		return new ClientDataAccessException( BharosaErrorIds.CLIENT_ACCESS_SETUP,
									   new Object[] { data } );
	}

	/**
	 * This exeption is thrown when getting info from table
	 * @param data null data
	 */
	static public ClientDataAccessException clientDataAccessGetValueException(
			  String data) {
		return new ClientDataAccessException( BharosaErrorIds.CLIENT_ACCESS_GET_VALUE,
									   new Object[] { data } );
	}

	/**
	 * This exeption is thrown when updating info
	 * @param data null data
	 */
	static public ClientDataAccessException clientDataAccessSetValueException(
			  String data) {
		return new ClientDataAccessException( BharosaErrorIds.CLIENT_ACCESS_SET_VALUE,
									   new Object[] { data } );
	}

	/**
	 * Creates an exception instance with the error id, with variables.
	 * @param errorId Error Id.
	 * @param varArray Array of objects contains the values used to substitude.
	 */
	private ClientDataAccessException( String errorId, Object[] varArray ) {
		super( errorId, varArray );
	}

}

