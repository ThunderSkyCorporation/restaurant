package com.bharosa.vcryptclient.client.util;


import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.common.util.UserDefEnum;
import com.bharosa.common.exception.BharosaException;
import com.bharosa.vcrypt.auth.intf.VCryptAuth;
import com.bharosa.vcrypt.auth.intf.VCryptAuthResult;
import com.bharosa.vcrypt.auth.intf.VCryptAuthUser;
import com.bharosa.vcrypt.auth.intf.VCryptLocale;
import com.bharosa.vcrypt.auth.intf.VCryptLocalizedString;
import com.bharosa.vcrypt.auth.intf.VCryptQuestion;
import com.bharosa.vcrypt.auth.intf.VCryptWheel;
import com.bharosa.vcrypt.auth.util.VCryptAuthUtil;
import com.bharosa.vcrypt.common.util.VCryptCommonUtil;
import com.bharosa.vcrypt.common.util.VCryptResponse;
import com.bharosa.vcrypt.common.util.VCryptServletUtil;
import com.bharosa.vcrypt.servlet.auth.VCryptServletAuthUtil;
import com.bharosa.vcrypt.servlet.tracker.VCryptServletTrackerUtil;
import com.bharosa.common.logger.Logger;

import javax.servlet.http.HttpServletRequest;

import java.io.File;
import java.io.OutputStream;
import java.util.*;

import javax.servlet.http.HttpServletResponse;

public class SliderUtil {

    static Logger logger = Logger.getLogger(SliderUtil.class);

    static boolean doPerfLog = BharosaConfig.getBoolean("com.bharosa.client.BharosaHelper.doPerfLog", false);

  /**
   * Return isPinEnabled value for this session.
   *
   * @param authUser VCryptAuthUser
   * @return a <code>boolean</code> value
   */
  public static boolean isPinEnabled( VCryptAuthUser authUser ) {

    if( authUser != null ) {
      String isPinEnabled = (String)authUser.getSecurityPreferences().get("isPinEnabled");
      return (new Boolean(isPinEnabled)).booleanValue();
    }
    return false;
  }
  
  /**
   * Return pin status value for this session.
   *
   * @param authUser VCryptAuthUser
   * @return a <code>String</code> value
   */
  public static String getUserPinStatus( VCryptAuthUser authUser ) {

    if( authUser != null ) {
      return (String) authUser.getSecurityPreferences().get("pinStatus");
    }
    return "";
  }
  
  /**
   * This creates a unique Bharosa Slider for the session.
   *
   * @return VCryptWheel
   */
  static public VCryptWheel createSlider( ) {

    Long previousAuthSessionId = null;
    String ipAddress = null;
    int fingerPrintType = 0;
    String fingerPrint = null;
    int wheelLength = 12;
    int numberOfWheels = 4;
    int authSessionType = UserDefEnum.getElementValue("auth.session.type.enum", "login");;
    int clientType = UserDefEnum.getElementValue("auth.client.type.enum", "slider");
    String clientVersion = "2.0";

    try {
      VCryptAuth auth = VCryptAuthUtil.getVCryptAuthInstance();
      VCryptWheel wheel = auth.genWheel( wheelLength, numberOfWheels, previousAuthSessionId,
                           authSessionType, clientType, clientVersion, ipAddress, fingerPrintType,
                           fingerPrint );

      return wheel;
    } catch( Exception ex ) {
      logger.error("Caught Exception.", ex );
      return null;
    }
  }
  
  /**
   * This decodes the data inputted by the user using the
   * Bharosa Slider.
   *
   * @param request a <code>HttpServletRequest</code> value
   * @param sliderSessionId a <code>Long</code> value
   * @param customerId a <code>String</code> value
   * @return a <code>int</code> value
   */
  public static int authenticateSlider( HttpServletRequest request, Long sliderSessionId, String customerId  ){
    
    request.getSession().setAttribute("vcrypt_prev_session_id", sliderSessionId);
    VCryptAuthResult authResult = VCryptServletAuthUtil.authenticateSlider( request, customerId );
    int authStatus
      = UserDefEnum.getElementValue("auth.status.enum","system_error" );
    if( authResult == null ) {
      logger.error("Got null authResult");
    } else {
      authStatus = authResult.getCode( );

      if( authStatus != 0  ) { //BharosaEnumAuthStatus.SUCCESS.getValue()
        logger.info("Slider authentication failed for loginId="
              + customerId + ", resultCode=" + authStatus
              + ", result=" + authStatus);
      }
    }
    return authStatus;
  }


  /**
   * This is to notify the Bharosa Server that the user had opted
   * to use Slider has additional security mechanism.
   *
   * @param customerId String
   * @param newPin String
   */
  public static void optIn( String customerId, String newPin ){

    if (logger.isDebugEnabled())
      logger.debug("Setting user pin.");
    
    int pinStatus = UserDefEnum.getElementValue("vcrypt.user.password.status.enum","active" );
    VCryptAuth auth = VCryptAuthUtil.getVCryptAuthInstance();
    auth.setPIN(customerId, newPin, pinStatus );
  }
  
  /**
   * This is to notify the Bharosa Server that the user had opted
   * not to use Slider has additional security mechanism.
   *
   * @param customerId String
   */
  public static void optOut( String customerId ){
    int pinStatus = UserDefEnum.getElementValue("vcrypt.user.password.status.enum","disabled" );
    VCryptAuth auth = VCryptAuthUtil.getVCryptAuthInstance();
    auth.setPIN(customerId, null, pinStatus );
  }
  
  
  /**
   * This get the HTML to be insert for the Slider
   *
   * @param slider a <code>VCryptWheel</code>
   * @return a <code>String</code> value
   */
  public static String getSliderHTML(VCryptWheel slider){

    String flashFile = BharosaConfig.get("bharosa.slider.flash.file", "slider/flash/slider_bharosa_nologo.swf");

    if (logger.isDebugEnabled()) logger.debug("Flash File used is: " + flashFile);

    String sliderTutorialFile = BharosaConfig.get("bharosa.slider.tutorial.file", "slider/html/sliderTutorial.html");

    if (logger.isDebugEnabled()) logger.debug("slider tutorial file used is: " + sliderTutorialFile);

    String imageDir = BharosaConfig.get("bharosa.slider.image.dir", "slider/images");

    if (logger.isDebugEnabled()) logger.debug("img directory referred is: " + imageDir);

    //define html hidden parameters for slider.
    String hiddenStr = "<input type='hidden' name='client_type_id' id='client_type_id' value='2'>"
      + "<input type='hidden' name='angle1' id='angle1' value='0'>"
      + "<input type='hidden' name='angle2' id='angle2' value='0'>"
      + "<input type='hidden' name='angle3' id='angle3' value='0'>"
      + "<input type='hidden' name='angle4' id='angle4' value='0'>"
      + "<input type='hidden' name='timer1' id='timer1' value='0'>"
      + "<input type='hidden' name='timer2' id='timer2' value='0'>"
      + "<input type='hidden' name='timer3' id='timer3' value='0'>"
      + "<input type='hidden' name='timer4' id='timer4' value='0'>";

    //define styles used by for this slider code
    String sliderLinkColor = BharosaConfig.get("bharosa.slider.link.color","#19478d");
    String sliderLinkHoverColor = BharosaConfig.get("bharosa.slider.link.hover.color","#2087aa");
    
    String styleStr =
      " <style type='text/css'>"
      + ".verdana8grey {font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 8.5pt;color: #333333;text-decoration: none;}"
      + ".secondaryLink {FONT-WEIGHT: bold; FONT-SIZE: 10px; COLOR: #19478d}"
      + ".secondaryLink A:link {COLOR: " + sliderLinkColor + "; TEXT-DECORATION: none}"
      + ".secondaryLink A:visited {COLOR: " + sliderLinkColor + "; TEXT-DECORATION: none}"
      + ".secondaryLink A:active {COLOR: " + sliderLinkHoverColor + "; TEXT-DECORATION: none}"
      + ".secondaryLink A:hover {COLOR: " + sliderLinkHoverColor + "; TEXT-DECORATION: none}"
      + "</style>";

    String scriptStr =
      "<script type='text/javascript' language='javascript'>"
            + "function customSliderInput() {"
      + "}"
      + "function sliderInput( angle1, angle2, angle3,angle4, timer1, timer2, timer3, timer4 ) {"
      + "document.getElementById('angle1').value = angle1;"
      + "document.getElementById('angle2').value = angle2;"
      + "document.getElementById('angle3').value = angle3;"
      + "document.getElementById('angle4').value = angle4;"
      + "document.getElementById('timer1').value = timer1;"
      + "document.getElementById('timer2').value = timer2;"
      + "document.getElementById('timer3').value = timer3;"
      + "document.getElementById('timer4').value = timer4;"
        + "customSliderInput();"
        + "}"
      + "var showSliderDirs = \"<a href='' onclick='javascript:showDirections();return false;'>Show directions</a>\";"
      + "var hideSliderDirs = \"<a href='' onclick='javascript:hideDirections();return false;'>Hide directions</a>\";"
      + "function showDirections() {"
      + "document.getElementById('directionUrl').innerHTML = hideSliderDirs;"
      + "document.getElementById('sliderDirections').style.visibility = 'visible';"
      + "}"
      + "function hideDirections() {"
      + "document.getElementById('directionUrl').innerHTML = showSliderDirs;"
      + "document.getElementById('sliderDirections').style.visibility = 'hidden';"
      + "}"
      + "var screenWidth = screen.width;"
      + "var screenHeight = screen.height;"
      + "var tut_normalMoveLeft = 280;"
      + "var tut_normalMoveTop = 370;"
      + "if (document.all) {"
      + "tut_normalMoveTop = 280;"
      + "}"
      + "if (screenWidth < 1024) {"
      + "tut_normalMoveLeft = (tut_normalMoveLeft) - (tut_normalMoveLeft*0.58);"
      + "tut_normalMoveTop = tut_normalMoveTop - (tut_normalMoveTop*0.48);"
      + "} else if (screenWidth < 1280) {"
      + "tut_normalMoveLeft = (tut_normalMoveLeft) - (tut_normalMoveLeft*0.30);"
      + "tut_normalMoveTop = tut_normalMoveTop - (tut_normalMoveTop*0.25);"
      + "} else if (screenWidth < 1400) {"
      + "tut_normalMoveLeft = (tut_normalMoveLeft) - (tut_normalMoveLeft*0.10);"
      + "}"
      + "function tutWindow(url) {"
      + "var tutWin=window.open(url,'tutorial','left=0,top=0,scrollbars=no,toolbar=no,menubar=no,location=no,scrolling=no,directories=no,status=no,resizable=no,copyhistory=no,width=670,height=220');"
      + "try {"
      + "tutWin.moveTo(tut_normalMoveLeft,tut_normalMoveTop);"
      + "} catch(exception) {}"
      + "try {"
      + "tutWin.focus();"
      + "} catch(exception) {}"
      + "}"
      + "</script>";

    //constructing the slider directions html
    String sliderDirsPosition = "top:-210px;";
    String sliderDirsLocationStr = "below";
    if ("false".equals(BharosaConfig.get("bharosa.slider.directions.display.above", "true"))){
      sliderDirsPosition = "top:100;";
      sliderDirsLocationStr = "above";
    }
    
    String sliderDirsContact = BharosaConfig.getLocalized("bharosa.slider.directions.contact","For assistance, call customer support.");
    boolean showSlider = BharosaConfig.getBoolean("bharosa.default.show.slider.directions", true);

    String sliderDirs =
      "<table width='560' cellpadding='0' cellspacing='0' border='0'><tr><td>"
      + "<div name='sliderDirections' id='sliderDirections' style='position:absolute;" + sliderDirsPosition + ";" + (showSlider?"visibility:visible;":"visibility:hidden;") + "'>"
      + "<table width='550' border='1' cellpadding='5' cellspacing='0' bordercolor='#999999' bgcolor='#eeeeee'>"
      + "<tr><td>"
      + "<table width='550' border='0' cellpadding='0' cellspacing='0'>"
      + "<tr><td>"
      + "<span class='verdana8grey'><strong>Using the Slider is as easy as 1-2-3!</strong></span><br>"
      + "<ol>"
      + "<li class='verdana8grey'>Find <strong>one symbol</strong> on the Virtual Slider " + sliderDirsLocationStr + "."
      + "<br>(<strong>Remember it!</strong> You will use it for the following steps.)<span class='verdana8grey'><br>&nbsp;</span></li>"
      + "<li class='verdana8grey'>Line up your symbol under the first <strong>character</strong> of your PIN"
      + "<br>(see diagram)<span class='verdana8grey'><br>&nbsp;</span></li>"
      + "<li class='verdana8grey'>Hit <strong>Enter </strong>(on the Virtual Slider or on your keyboard)<span class='verdana8grey'><br>&nbsp;</span></li>"
      + "<li class='verdana8grey'>Keeping your <strong>same symbol</strong>, repeat steps 2-3 to enter all your PIN characters."
      + " (Use reset if you make a mistake.)</li>"
      + "</ol>"
      + "<center><span class='verdana8grey'>" + sliderDirsContact + "</span></center>"
      + "</td>"
      + "<td><img src='" + imageDir + "/s_directions_card.gif' width='125' height='184'></td>"
      + "</tr>"
      + "<script language='javascript' type='text/javascript'>"
      + "if (!document.all) {"
      + "document.writeln(\"<tr><td height='6'></td></tr>\");"
      + "}"
      + "</script>"
      + "</table>"
      + "</td>"
      + "</tr>"
      + "</table>"
      + "</div>"
      + "</td></tr></table>";

    //Get the inner wheels from request attribute
    String defSliderDir = "showSliderDirs";
    
    if (showSlider) {
      defSliderDir = "hideSliderDirs";
    }
    String sliderGenStr =
      "<table border='0' cellpadding='0' cellspacing='0'>"
      + "<tr><td align='center'>"
      + "<object classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000' codebase='https://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0' width='629' height='80' align='middle' id='slider' name='slider'>"
      + "<param name='allowScriptAccess' value='sameDomain' />"
      + "<param name='movie' value='" + flashFile + "' />"
      + "<param name='quality' value='high' />"
      + "<param name='bgcolor' value='#ffffff' />"
      + "<param name='wmode' value='transparent' />"
      + "<param name='FlashVars' value='" + slider.getWheel() + "'/>"
      + "<embed src='" + flashFile + "'"
      + " FlashVars='" + slider.getWheel() + "' quality='high' bgcolor='#ffffff' width='629' height='80' align='middle' allowScriptAccess='sameDomain' type='application/x-shockwave-flash' pluginspage='https://www.macromedia.com/go/getflashplayer' />"
      + "</object>"
      + "</td></tr>"
      + "<tr><td height='3'></td></tr>"
      + "<tr><td valign='top'>"
      + "<table valign='top' border='0' cellpadding='0' cellspacing='0' width='560'>"
      + "<tr><td valign='top' class='secondaryLink' style='padding-left:40px;'>"
      + "<span name='directionUrl' id='directionUrl' valign='top'>"
      + "<script>document.writeln(" + defSliderDir + ")</script>"
      + "</span></td>"
      + "<td valign='top' class='secondaryLink' align='right'>"
      + "<a href='' onclick='javascript:tutWindow(\"" + sliderTutorialFile
      + "\");return false;'>Take a Tutorial</a>"
      + "</td></tr>"
      + "</table>"
      + "</td></tr>"
      + "</table>";

    String containerStart = "<div id=\"sliderContainerDiv\" name=\"sliderContainerDiv\" style=\"position:relative;\" align=\"center\" >";
    String containerEnd = "</div>";

    return containerStart + styleStr + scriptStr + sliderDirs + sliderGenStr + hiddenStr + containerEnd;
  }
  
  /**
   * This get the HTML to be insert for the Slider
   *
   * @param request a <code>HttpServletRequest</code> value
   * @param response a <code>HttpServletResponse</code> value
   * @return a <code>String</code> value
   */
  public static String getSliderTutorialHTML() {

    String contextPath = ""; //request.getContextPath();

    String flashFile = BharosaConfig.get("bharosa.slider.tutorial.flash", "slider/flash/flash/Slider_tut_nologo.swf");
    String tourFlashFile = BharosaConfig.get("bharosa.slider.tour.flash", "slider/flash/Slider_tour_nologo.swf");

    //Get the inner wheels from request attribute
    String sliderGenStr =
      "<object classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000' codebase='https://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0' width='652' height='200' align='middle'>"
      + "<param name='allowScriptAccess' value='sameDomain' />"
      + "<param name='movie' value='"
      + flashFile + "' />"
      + "<param name='quality' value='high' />"
      + "<param name='bgcolor' value='#ffffff' />"
      + "<param name='wmode' value='transparent' />"
      + "<param name='FlashVars' value='tourFile=" + tourFlashFile + "'/>"
      + "<embed src='" + flashFile
      + "' FlashVars='tourFile=" + tourFlashFile + "' quality='high' bgcolor='#ffffff' width='652' height='200' align='middle' allowScriptAccess='sameDomain' type='application/x-shockwave-flash' pluginspage='https://www.macromedia.com/go/getflashplayer' />"
      + "</object>";
    return sliderGenStr;
  }

}
