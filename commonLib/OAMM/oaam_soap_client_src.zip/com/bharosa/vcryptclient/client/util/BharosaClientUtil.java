/* $Header: oaam/apps/oaam_server/src/com/bharosa/vcryptclient/client/util/BharosaClientUtil.java /main/1 2010/12/08 12:08:31 srchittu Exp $ */

/* Copyright (c) 2010, 2011, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    Utility Class Client interface provides methods required for the front end/client side.

   PRIVATE CLASSES

   NOTES

   MODIFIED    (MM/DD/YY)
    srchittu   12/08/10 - Util class to get BhaorsaClient
    pdorai     10/03/10 - Creation
 */

package com.bharosa.vcryptclient.client.util;

import com.bharosa.common.logger.Logger;
import com.bharosa.vcryptclient.client.intf.BharosaClient;
import com.bharosa.vcryptclient.client.impl.BharosaClientImpl;

public class BharosaClientUtil {

    private static Logger logger = Logger.getLogger(BharosaClientUtil.class);
    private static BharosaClient clientInstance;

    private BharosaClientUtil() {
        super();
    }

    /**
     * This methods returns an instance of BharosaClient class.
     *
     * @return Returns instance of BharosaClient class
     */
    static public BharosaClient getBharosaClientInstance() {

        if (clientInstance != null) {
            return clientInstance;
        }
        synchronized (BharosaClientUtil.class) {
            if (clientInstance == null) {
                logger.info("Creating new BharosaClient instance...");
                try {
                    clientInstance = BharosaClientImpl.getInstance();
                } catch (Exception ex) {
                    logger.error("Error creating BharosaClient instance.", ex);
                }
            }
        }
        return clientInstance;
    }

}
