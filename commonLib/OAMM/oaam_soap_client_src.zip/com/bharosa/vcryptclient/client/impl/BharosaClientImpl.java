/* $Header: oaam/apps/oaam_server/src/com/bharosa/vcryptclient/client/impl/BharosaClientImpl.java /main/2 2010/12/08 12:08:31 srchittu Exp $ */

/* Copyright (c) 2010, 2011, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    Client interface provides methods required for the front end/client side.

   PRIVATE CLASSES    

   NOTES    

   MODIFIED    (MM/DD/YY)   
    pdorai     10/03/10 - Creation
 */
package com.bharosa.vcryptclient.client.impl;

import com.bharosa.common.logger.Logger;

import com.bharosa.common.util.BharosaConfig;
import com.bharosa.common.util.StringUtil;
import com.bharosa.vcryptclient.client.exceptions.BharosaClientKeyPadException;
import com.bharosa.vcrypt.auth.intf.VCryptLocalizedString;
import com.bharosa.vcrypt.auth.keypad.*;
import com.bharosa.vcryptclient.client.intf.BharosaClient;
/**
 * Provides various methods required for the front end/client side.
 *
 * @author philomina
 * @version 1.0
 * @since 1.0
 */
public class BharosaClientImpl
	implements BharosaClient {

	static Logger logger = Logger.getLogger(BharosaClientImpl.class);
	static private BharosaClientImpl theInstance = null;

	static public BharosaClientImpl getInstance() {
		if( theInstance == null ) {
			theInstance = new BharosaClientImpl();
		}
		return theInstance;
	}

	/**
	 * This is the private constructor. Use getInstance method to get
	 * the singleton instance of this class.
	 *
	 */
	private BharosaClientImpl( ) {

	}


	/**
	 * This method is to create the captionpad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getCaptionPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {
		return getCaptionPad(keypadName, frameFile, bgFile, new VCryptLocalizedString(captionText), isADACompliant, hasJS, hasImgs);
	}
	
	/**
	 * This method is to create the captionpad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>VCryptLocalizedString</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getCaptionPad(String keypadName, String frameFile,
								  String bgFile, VCryptLocalizedString captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getCaptionPad()...");

		if (logger.isDebugEnabled()) {
			logger.debug("getCaptionPad()...keypadName=" + keypadName
						 + ", frameFile=" + frameFile
						 + ", bgFile=" + bgFile + ", captionText=" + captionText.getText()
						 + ", isADACompliant=" + isADACompliant
						 + ", hasJS=" + hasJS
						 + ", hasImgs=" + hasImgs);

		}

			if( bgFile == null ) {
				if (logger.isDebugEnabled()) logger.debug("No pre-assigned background image found, so using the default");
				bgFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.captionpad.background.file",
																KeyPadUtil.authentiPadResource,
															   "textpad_bg/BG_003.jpg"))).getAbsolutePath();
			}

			if( StringUtil.isEmpty(frameFile) ) {
				if(logger.isDebugEnabled()) logger.debug("No pre-assigned frame image found, so using the default");
				frameFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.captionpad.frame.file",
																	KeyPadUtil.authentiPadResource,
																  	"textpad_bg/TP_frame_PhE.png"))).getAbsolutePath();
			}

		return getKeyPad(keypadName, frameFile, bgFile,
						 captionText, isADACompliant, hasJS, hasImgs, BharosaClient.TYPE_CAPTIONPAD);
	}

	/**
	 * This method is to create the confirmCaptionPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getConfirmCaptionPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {
		return getConfirmCaptionPad(keypadName, frameFile, bgFile, new VCryptLocalizedString(captionText), isADACompliant, hasJS, hasImgs);
	}
	
	/**
	 * This method is to create the confirmCaptionPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>VCryptLocalizedString</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getConfirmCaptionPad(String keypadName, String frameFile,
											String bgFile, VCryptLocalizedString captionText,
											boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getConfirmCaptionPad()...");

		if (logger.isDebugEnabled()) {
			logger.debug("getConfirmCaptionPad()...keypadName=" + keypadName
						 + ", frameFile=" + frameFile
						 + ", bgFile=" + bgFile + ", captionText=" + captionText
						 + ", isADACompliant=" + isADACompliant
						 + ", hasJS=" + hasJS
						 + ", hasImgs=" + hasImgs);

		}

			if( bgFile == null ) {
				if (logger.isDebugEnabled()) logger.debug("No pre-assigned background image found, so using the default");
				bgFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.captionconfirmpad.background.file",
																KeyPadUtil.authentiPadResource,
															   "textpad_bg/BG_003.jpg"))).getAbsolutePath();
			}

			if( StringUtil.isEmpty(frameFile) ) {
				if(logger.isDebugEnabled()) logger.debug("No pre-assigned frame image found, so using the default");
				frameFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.captionconfirmpad.frame.file",
																	KeyPadUtil.authentiPadResource,
																  	"textpad_bg/TP_frame_Ph.png"))).getAbsolutePath();
			}

		return getKeyPad(keypadName, frameFile, bgFile,
						 captionText, isADACompliant, hasJS, hasImgs, BharosaClient.TYPE_CONFIRMCAPTIONPAD);
	}

	/**
	 * This method is to create the TextPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getTextPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {
		return getTextPad(keypadName, frameFile, bgFile, new VCryptLocalizedString(captionText), isADACompliant, hasJS, hasImgs);
	}
	
	/**
	 * This method is to create the TextPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>VCryptLocalizedString</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getTextPad(String keypadName, String frameFile,
								  String bgFile, VCryptLocalizedString captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {

		if( logger.isDebugEnabled()) logger.debug("BEGIN:getTextPad()...");

		if (logger.isDebugEnabled()) {
			logger.debug("getTextPad()...keypadName=" + keypadName
						 + ", frameFile=" + frameFile
						 + ", bgFile=" + bgFile + ", captionText=" + captionText
						 + ", isADACompliant=" + isADACompliant
						 + ", hasJS=" + hasJS
						 + ", hasImgs=" + hasImgs);

		}

		if( bgFile == null ) {
			if (logger.isDebugEnabled()) logger.debug("No pre-assigned background image found, so using the default");
			bgFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.textpad.background.file",
															KeyPadUtil.authentiPadResource,
														   "textpad_bg/UIO_BG.jpg"))).getAbsolutePath();
		}

		if( StringUtil.isEmpty(frameFile) ) {
			if(logger.isDebugEnabled()) logger.debug("No pre-assigned frame image found, so using the default");
			frameFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.textpad.frame.file",
																KeyPadUtil.authentiPadResource,
															 	"textpad_bg/TP_O_password.png"))).getAbsolutePath();
		}

		return getKeyPad(keypadName, frameFile, bgFile,
						 captionText, isADACompliant, hasJS, hasImgs, BharosaClient.TYPE_TEXTPAD);
	}

	/**
	 * This method is to create the AlphaKeyPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getAlphaNumericKeyPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {
		return getAlphaNumericKeyPad(keypadName, frameFile, bgFile, new VCryptLocalizedString(captionText), isADACompliant, hasJS, hasImgs);
	}
	
	/**
	 * This method is to create the AlphaKeyPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getAlphaNumericKeyPad(String keypadName, String frameFile,
											 String bgFile, VCryptLocalizedString captionText,
											 boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getAlphaNumericKeyPad()...");

		if (logger.isDebugEnabled()) {
			logger.debug("getAlphaNumericKeyPad()...keypadName=" + keypadName
						 + ", frameFile=" + frameFile
						 + ", bgFile=" + bgFile + ", captionText=" + captionText
						 + ", isADACompliant=" + isADACompliant
						 + ", hasJS=" + hasJS
						 + ", hasImgs=" + hasImgs);

		}

            if (StringUtil.isEmpty(bgFile))
            {
                if(logger.isDebugEnabled()) logger.debug("No pre-assigned background image found, so using the default");
                bgFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.keypad.background.file",
                												KeyPadUtil.authentiPadResource,
                                                               "alphapad_bg/UIO_BG.jpg"))).getAbsolutePath();
            }

            if (StringUtil.isEmpty(frameFile))
            {
                if(logger.isDebugEnabled()) logger.debug("No pre-assigned frame image found, so using the default");
                frameFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.keypad.frame.file",
                													KeyPadUtil.authentiPadResource,
																  	"alphapad_bg/kp_frame_O.png"))).getAbsolutePath();
            }

		return getKeyPad(keypadName, frameFile, bgFile,
						 captionText, isADACompliant, hasJS, hasImgs, BharosaClient.TYPE_ALPHANUMERICPAD);
	}

	/**
	 * This method is to create the FullKeyPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getFullKeyPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {
		return getFullKeyPad(keypadName, frameFile, bgFile, new VCryptLocalizedString(captionText), isADACompliant, hasJS, hasImgs);
	}
	
  /**
     * This method is to create the FullKeyPad.
     *
     * @param keypadName a <code>String</code> value
     * @param frameFile a <code>String</code> value
     * @param bgFile a <code>String</code> value
     * @param captionText a <code>VCryptLocalizedString</code> value
     * @param isADACompliant a <code>boolean</code> value
     * @param hasJS a <code>boolean</code> value
     * @param hasImgs a <code>boolean</code> value
     * @return an <code>AuthentiPad</code> value
     * @exception BharosaClientKeyPadException if an error occurs
     */
    public AuthentiPad getFullKeyPad(String keypadName, String frameFile,
                         String bgFile, VCryptLocalizedString captionText,
                         boolean isADACompliant, boolean hasJS, boolean hasImgs)
      throws BharosaClientKeyPadException {

      if(logger.isDebugEnabled()) logger.debug("BEGIN:getFullKeyPad()...");

      if (logger.isDebugEnabled()) {
        logger.debug("getFullKeyPad()...keypadName=" + keypadName
               + ", frameFile=" + frameFile
               + ", bgFile=" + bgFile + ", captionText=" + captionText
               + ", isADACompliant=" + isADACompliant
               + ", hasJS=" + hasJS
               + ", hasImgs=" + hasImgs);

      }

              if (StringUtil.isEmpty(bgFile))
              {
                  if(logger.isDebugEnabled()) logger.debug("No pre-assigned background image found, so using the default");
                  bgFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.keypad.background.file",
                		  											KeyPadUtil.authentiPadResource,
                                                                 "alphapad_bg/UIO_BG.jpg"))).getAbsolutePath();
              }

              if (StringUtil.isEmpty(frameFile))
              {
                  if(logger.isDebugEnabled()) logger.debug("No pre-assigned frame image found, so using the default");
                  frameFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.keypad.frame.file",
                		  												KeyPadUtil.authentiPadResource,
                                    									"alphapad_bg/kp_frame_O.png"))).getAbsolutePath();
              }

      return getKeyPad(keypadName, frameFile, bgFile,
               captionText, isADACompliant, hasJS, hasImgs, BharosaClient.TYPE_FULLKEYPAD);
    }

    /**
	 * This method is to create the QuestionPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getQuestionPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {
		return getQuestionPad(keypadName, frameFile, bgFile, new VCryptLocalizedString(captionText), isADACompliant, hasJS, hasImgs);
	}
	
	/**
	 * This method is to create the QuestionPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>VCryptLocalizedString</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getQuestionPad(String keypadName, String frameFile,
									  String bgFile, VCryptLocalizedString captionText,
									  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getQuestionPad()...");

		if (logger.isDebugEnabled()) {
			logger.debug("getQuestionPad()...keypadName=" + keypadName
						 + ", frameFile=" + frameFile
						 + ", bgFile=" + bgFile + ", captionText=" + captionText
						 + ", isADACompliant=" + isADACompliant
						 + ", hasJS=" + hasJS
						 + ", hasImgs=" + hasImgs);

		}

		if (StringUtil.isEmpty(bgFile))
		{
			if(logger.isDebugEnabled()) logger.debug("No pre-assigned background image found, so using the default");
			bgFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.questionpad.background.file",
															KeyPadUtil.authentiPadResource,
														   "questionpad_bg/BG_003.jpg"))).getAbsolutePath();
		}

		if (StringUtil.isEmpty(frameFile))
		{
			if(logger.isDebugEnabled()) logger.debug("No pre-assigned frame image found, so using the default");
			frameFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.questionpad.frame.file",
																KeyPadUtil.authentiPadResource,
																"questionpad_bg/QuP_frame_logo.png"))).getAbsolutePath();
		}

		return getKeyPad(keypadName, frameFile, bgFile,
						 captionText, isADACompliant, hasJS, hasImgs, BharosaClient.TYPE_QUESTIONPAD);
	}

	/**
	 * This method is to create the TextPadReset.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getResetTextPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {
		return getResetTextPad(keypadName, frameFile, bgFile, new VCryptLocalizedString(captionText), isADACompliant, hasJS, hasImgs);
	}
	
	/**
	 * This method is to create the TextPadReset.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getResetTextPad(String keypadName, String frameFile,
								  String bgFile, VCryptLocalizedString captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getResetTextPad()...");

		if (logger.isDebugEnabled()) {
			logger.debug("getResetTextPad()...keypadName=" + keypadName
						 + ", frameFile=" + frameFile
						 + ", bgFile=" + bgFile + ", captionText=" + captionText
						 + ", isADACompliant=" + isADACompliant
						 + ", hasJS=" + hasJS
						 + ", hasImgs=" + hasImgs);

		}

		if( bgFile == null ) {
			if (logger.isDebugEnabled()) logger.debug("No pre-assigned background image found, so using the default");
			bgFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.textpadreset.background.file",
															KeyPadUtil.authentiPadResource,
														   "textpad_bg/BG_003.jpg"))).getAbsolutePath();
		}

		if( StringUtil.isEmpty(frameFile) ) {
			if(logger.isDebugEnabled()) logger.debug("No pre-assigned frame image found, so using the default");
			frameFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.textpadreset.frame.file",
																KeyPadUtil.authentiPadResource,
															  	"textpad_bg/TP_frame_PWreset.png"))).getAbsolutePath();
		}

		return getKeyPad(keypadName, frameFile, bgFile,
						 captionText, isADACompliant, hasJS, hasImgs, BharosaClient.TYPE_RESETTEXTPAD);
	}

	/**
	 * This method is to create the PinPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getPinPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {
		return getPinPad(keypadName, frameFile, bgFile, new VCryptLocalizedString(captionText), isADACompliant, hasJS, hasImgs);
	}
	
	/**
	 * This method is to create the pinpad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>VCryptLocalizedString</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getPinPad(String keypadName, String frameFile,
								 String bgFile, VCryptLocalizedString captionText,
								 boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getPinPad()....");

		if (logger.isDebugEnabled()) {
			logger.debug("getPinPad()...keypadName=" + keypadName
						 + ", frameFile=" + frameFile
						 + ", bgFile=" + bgFile + ", captionText=" + captionText
						 + ", isADACompliant=" + isADACompliant
						 + ", hasJS=" + hasJS
						 + ", hasImgs=" + hasImgs);
		}

		if( bgFile == null ) {
			if (logger.isDebugEnabled()) logger.debug("No pre-assigned background image found, so using the default");
			bgFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.pinpad.background.file",
															KeyPadUtil.authentiPadResource,
														   	"pinpad_bg/UIO_BG.jpg"))).getAbsolutePath();
		}

		if( StringUtil.isEmpty(frameFile) ) {
			if(logger.isDebugEnabled()) logger.debug("No pre-assigned frame image found, so using the default");
			frameFile = (KeyPadUtil.getFile(BharosaConfig.getLocalizedFromNamedBundle("bharosa.authentipad.pinpad.frame.file",
																KeyPadUtil.authentiPadResource,
															  	"pinpad_bg/PP_O_frame.png"))).getAbsolutePath();
		}

		return getKeyPad(keypadName, frameFile, bgFile,
						 captionText, isADACompliant, hasJS, hasImgs, BharosaClient.TYPE_PINPAD);
	}

	/**
	 * This decodes the user input using graphic keypad.
	 *
	 * @param inputAttribute a <code>String</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String decodeKeyPad( AuthentiPad keyPad, String inputAttribute )
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:decodeKeyPad()... ");

		if( keyPad == null ) {
			if (logger.isDebugEnabled()) logger.debug("Keypad instance is null.");
			throw new BharosaClientKeyPadException("Keypad instance is null.");
		}

		String userEnteredValue = KeyPadUtil.decodeKeyPadCode(keyPad, inputAttribute);

		if(logger.isDebugEnabled()) logger.debug("END:decodeKeyPad()...");
		return userEnteredValue;
	}
	
	/**
	 * This method is to create the keypad depending upon the keypad type.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @param keypadType an <code>int</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	AuthentiPad getKeyPad(String keypadName, String frameFile, String bgFile, VCryptLocalizedString captionText,
						  boolean isADACompliant, boolean hasJS, boolean hasImgs,
						  int keypadType)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getKeyPad()...");

		try {

			if (logger.isDebugEnabled()) logger.debug("getKeyPad()...keypadName=" + keypadName
													  + ", frameFile=" + frameFile
													  + ", bgFile=" + bgFile + ", captionText=" + captionText
													  + ", keypadType=" + keypadType + ", isADACompliant=" + isADACompliant
													  + ", hasJS=" + hasJS
													  + ", hasImgs=" + hasImgs);

			//Call the Bharosa KeyPad library for getting the KeyPad
			AuthentiPad keyPad = null;

            switch (keypadType) {
                case BharosaClient.TYPE_PINPAD:
                    if (logger.isDebugEnabled()) logger.debug("Keypad Type is PinPad.");
                    keyPad = new PinPad(keypadName, bgFile, frameFile);
                    keyPad.setCaptionText(captionText);
                    break;

                case BharosaClient.TYPE_CAPTIONPAD:
                    if (logger.isDebugEnabled()) logger.debug("Keypad Type is CaptionPad.");
                    keyPad = new CaptionPad(keypadName, bgFile, frameFile);
                    keyPad.setUserInput(captionText.getText());
                    break;

                case BharosaClient.TYPE_CONFIRMCAPTIONPAD:
                    if (logger.isDebugEnabled()) logger.debug("Keypad Type is ConfirmCaptionPad.");
                    keyPad = new CaptionConfirmPad(keypadName, bgFile, frameFile);
                    keyPad.setCaptionText(captionText);
                    break;

                case BharosaClient.TYPE_RESETTEXTPAD:
                    if (logger.isDebugEnabled()) logger.debug("Keypad Type is ResetTextPad.");
                    keyPad = new TextPadReset(keypadName, bgFile, frameFile);
                    keyPad.setCaptionText(captionText);
                    break;

                case BharosaClient.TYPE_ALPHANUMERICPAD:
                    if (logger.isDebugEnabled()) logger.debug("Keypad Type is Alpha Numeric Keypad.");
                    keyPad = new AlphaNumericKeyPad(keypadName, bgFile, frameFile);
                    keyPad.setCaptionText(captionText);
                    break;

                case BharosaClient.TYPE_FULLKEYPAD:
                    if (logger.isDebugEnabled()) logger.debug("Keypad Type is Full Keypad.");
                    keyPad = new FullKeyPad(keypadName, bgFile, frameFile);
                    keyPad.setCaptionText(captionText);
                    break;

                case BharosaClient.TYPE_QUESTIONPAD:
                    if (logger.isDebugEnabled()) logger.debug("Keypad Type is Question Pad.");
                    keyPad = new QuestionPad(keypadName, bgFile, frameFile);
                    keyPad.setCaptionText(captionText);
                    keyPad.setQuestionText(" ");
                    break;

                case BharosaClient.TYPE_TEXTPAD:
                    if (logger.isDebugEnabled()) logger.debug("Keypad Type is TextPad.");

                default:                    
                    keyPad = new TextPad(keypadName, bgFile, frameFile);
                    keyPad.setCaptionText(captionText);
            }

			keyPad.setIsADACompliant(isADACompliant);
			keyPad.setHasImgs(hasImgs);
			keyPad.setHasJS(hasJS);

			if(logger.isDebugEnabled()) logger.debug("END:getKeyPad()...");
			return keyPad;

		} catch( Exception ex ) {
			logger.error("Error creating the KeyPad", ex);
			throw new BharosaClientKeyPadException("Error while creating pad.error=" + ex.toString());
		}
	}

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getCaptionPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getCaptionPadHTML()...");

		return getKeyPadHTML(keyPad,isSubmitForm, canHide, BharosaClient.TYPE_CAPTIONPAD);
	}

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getConfirmCaptionPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getConfirmCaptionPadHTML()...");

		return getKeyPadHTML(keyPad,isSubmitForm, canHide, BharosaClient.TYPE_CONFIRMCAPTIONPAD);
	}

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getTextPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getTextPadHTML()...");

		return getKeyPadHTML(keyPad,isSubmitForm, canHide, BharosaClient.TYPE_TEXTPAD);
	}

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getResetTextPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getResetTextPadHTML()...");

		return getKeyPadHTML(keyPad,isSubmitForm, canHide, BharosaClient.TYPE_RESETTEXTPAD);
	}

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getPinPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getPinPadHTML()...");

		return getKeyPadHTML(keyPad,isSubmitForm, canHide, BharosaClient.TYPE_PINPAD);
	}

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @param keypadType an <code>int</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	String getKeyPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide, int keypadType)
		throws BharosaClientKeyPadException {

		return getAuthentiPadHTML(keyPad, isSubmitForm, canHide);
	}

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getAuthentiPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException {

		if(logger.isDebugEnabled()) logger.debug("BEGIN:getAuthentiPadHTML()...");

		try {
			if (logger.isDebugEnabled()) logger.debug("getAuthentiPadHTML()...isSubmitForm=" + isSubmitForm
													  + ", canHide=" + canHide);

			if( keyPad == null ) {
				if (logger.isDebugEnabled()) logger.debug("Keypad instance is null.");
				throw new BharosaClientKeyPadException("Keypad instance is null.");
			}

			//This is where the KeyPad display code starts
			//Get the appropriate Image Map
			String finalStr = keyPad.getHTML();
			String keypadName = keyPad.getPadName();

			String scriptStr = "<script language='javascript' type='text/javascript'>";
      scriptStr += "if (" + keypadName + " && " + keypadName + " != undefined){";

      if ( isSubmitForm ) {
				scriptStr = scriptStr + keypadName + ".submitForm = true;";
			} else {
				scriptStr = scriptStr + keypadName + ".submitForm = false;";
			}

			if( canHide ) {
				scriptStr = scriptStr + keypadName + ".canHide = true;";
			} else {
				scriptStr = scriptStr + keypadName + ".canHide = false;";
			}
      scriptStr += "}";

			scriptStr = scriptStr + "</script>";
			if(logger.isDebugEnabled()) logger.debug("END:getAuthentiPadHTML()...");
			return finalStr + scriptStr;

		} catch( Exception ex ) {
			logger.error("Error writing the HTML script", ex);
			throw new BharosaClientKeyPadException("Error while creating pad.error=" + ex.toString());
		}
	}


}
