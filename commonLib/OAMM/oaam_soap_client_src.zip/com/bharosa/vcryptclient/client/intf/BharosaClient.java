/* $Header: oaam/apps/oaam_server/src/com/bharosa/vcryptclient/client/intf/BharosaClient.java /main/2 2010/12/08 12:08:31 srchittu Exp $ */

/* Copyright (c) 2010, 2011, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    Client interface provides methods required for the front end/client side.

   PRIVATE CLASSES    

   NOTES    

   MODIFIED    (MM/DD/YY)   
    pdorai     10/03/10 - Creation
 */

package com.bharosa.vcryptclient.client.intf;

import com.bharosa.vcryptclient.client.exceptions.BharosaClientKeyPadException;
import com.bharosa.vcrypt.auth.intf.VCryptLocalizedString;
import com.bharosa.vcrypt.auth.keypad.AuthentiPad;

/**
 * Provides various methods required for the front end/client side.
 *
 * @author philomina
 * @version 1.0
 * @since 1.0
 */
public interface BharosaClient {

	//keypad type constants.
	static int TYPE_PINPAD = 1;
	static int TYPE_TEXTPAD = 2;
	static int TYPE_CAPTIONPAD = 3;
	static int TYPE_CONFIRMCAPTIONPAD = 4;
	static int TYPE_RESETTEXTPAD = 5;
	static int TYPE_ALPHANUMERICPAD = 6;
	static int TYPE_FULLKEYPAD = 7;
	static int TYPE_QUESTIONPAD = 8;

  /**
	 * This method is to create the textpad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getResetTextPad(String keypadName, String frameFile,
								  String bgFile, VCryptLocalizedString captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;

	/**
	 * This method is to create the captionpad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getCaptionPad(String keypadName, String frameFile,
								  String bgFile, VCryptLocalizedString captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;

	/**
	 * This method is to create the confirmCaptionPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getConfirmCaptionPad(String keypadName, String frameFile,
											String bgFile, VCryptLocalizedString captionText,
											boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;

	/**
	 * This method is to create the textpad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getTextPad(String keypadName, String frameFile,
								  String bgFile, VCryptLocalizedString captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;

	/**
	 * This method is to create the pinpad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getPinPad(String keypadName, String frameFile,
								 String bgFile, VCryptLocalizedString captionText,
								 boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;

	/**
	 * This decodes the user input using graphic keypad.
	 *	 
	 * @param keyPad a <code>String</code> value
	 * @param inputAttribute a <code>String</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String decodeKeyPad( AuthentiPad keyPad, String inputAttribute )
		throws BharosaClientKeyPadException;

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getCaptionPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException;

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getConfirmCaptionPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException;

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getTextPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException;

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getPinPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException;

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getResetTextPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException;

	/**
	 * This method is to get the keypad html string for display.
	 *
	 * @param keyPad an <code>AuthentiPad</code> value
	 * @param isSubmitForm a <code>boolean</code> value
	 * @param canHide a <code>boolean</code> value
	 * @return a <code>String</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public String getAuthentiPadHTML(AuthentiPad keyPad,boolean isSubmitForm, boolean canHide)
		throws BharosaClientKeyPadException;

	/**
	 * This method is to create the alpha numeric keypad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getAlphaNumericKeyPad(String keypadName, String frameFile,
											 String bgFile, VCryptLocalizedString captionText,
											 boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;


  /**
   * This method is to create the full keypad.
   *
   * @param keypadName a <code>String</code> value
   * @param frameFile a <code>String</code> value
   * @param bgFile a <code>String</code> value
   * @param captionText a <code>String</code> value
   * @param isADACompliant a <code>boolean</code> value
   * @param hasJS a <code>boolean</code> value
   * @param hasImgs a <code>boolean</code> value
   * @return an <code>AuthentiPad</code> value
   * @exception BharosaClientKeyPadException if an error occurs
   */
  public AuthentiPad getFullKeyPad(String keypadName, String frameFile,
                       String bgFile, VCryptLocalizedString captionText,
                       boolean isADACompliant, boolean hasJS, boolean hasImgs)
    throws BharosaClientKeyPadException;

	/**
	 * This method is to create the questionpad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	public AuthentiPad getQuestionPad(String keypadName, String frameFile,
									  String bgFile, VCryptLocalizedString captionText,
									  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;
	


	/**
	 * This method is to create the captionpad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getCaptionPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;
	
	/**
	 * This method is to create the confirmCaptionPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getConfirmCaptionPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;
	
	/**
	 * This method is to create the TextPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getTextPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;
	
	/**
	 * This method is to create the AlphaKeyPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getAlphaNumericKeyPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;
	
	/**
	 * This method is to create the FullKeyPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getFullKeyPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;
	
	/**
	 * This method is to create the QuestionPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getQuestionPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;
	
	/**
	 * This method is to create the TextPadReset.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getResetTextPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;
	
	/**
	 * This method is to create the PinPad.
	 *
	 * @param keypadName a <code>String</code> value
	 * @param frameFile a <code>String</code> value
	 * @param bgFile a <code>String</code> value
	 * @param captionText a <code>String</code> value
	 * @param isADACompliant a <code>boolean</code> value
	 * @param hasJS a <code>boolean</code> value
	 * @param hasImgs a <code>boolean</code> value
	 * @return an <code>AuthentiPad</code> value
	 * @exception BharosaClientKeyPadException if an error occurs
	 */
	 /** @deprecated */ 
	public AuthentiPad getPinPad(String keypadName, String frameFile,
								  String bgFile, String captionText,
								  boolean isADACompliant, boolean hasJS, boolean hasImgs)
		throws BharosaClientKeyPadException;
	
		
}
